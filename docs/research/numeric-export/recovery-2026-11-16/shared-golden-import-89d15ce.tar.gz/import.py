import hashlib,json,shutil,subprocess
from pathlib import Path
ROOT=Path('/workspace/scratch/prismpm-numeric')
ART=Path('/workspace/scratch/cs-numeric-kernels/artifacts/numeric-task2c/ci-44039536685/backport-shared-golden-proposal-44039536685-1')
OUT=Path('/workspace/diagnostic-tools/shared-golden-import')
BASE='bc049680103bbaf285a5582a346a73f4d2f790e4'
SOURCE='324955b6923c1d194d7bc870a2d2a05eb687048c'
EXPECTED={
 'tests/golden/stdlib/build/manifest.json':('1388ec84c3fa97e9cbac0c4f4f7c0ddf7469f3f46e27fbf90cc70195f8d5c7c8',57438),
 'tests/golden/stdlib/build/model.prism.json':('47c8038d51cbf230c73a2bf565c10b729dab1d27e2bbad0d69c77619d304f97e',4723),
 'tests/golden/stdlib/golden-manifest.json':('d25bd858d005b1f4e2bcde5f606229657f240c92505fa84271c7228bd4377504',108056),
 'tests/golden/stdlib/verified/lexlean-attestation.json':('8a009108372a5b0ffcb2243233282313348b7c2be8f22c06301de13ca2b2ec94',2022137),
 'tests/golden/stdlib/verified/manifest.json':('f6fbaf3c36f235539aa4a9cb26d8df435f1bf28a74a3f5c33fe490ae1e69bf75',2284137),
}
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
def identity(b):return {'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def dump(name,obj): (OUT/name).write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
def tree(root):
 files={}
 for p in root.rglob('*'):
  assert not p.is_symlink(),str(p)
  if p.is_file():files[str(p.relative_to(root))] = p
 return files
assert git('rev-parse','HEAD').decode().strip()==BASE
assert git('status','--porcelain')==b''
assert shutil.disk_usage(ROOT).free>=8*1024**3
retained=json.loads((ART/'result.json').read_bytes())
assert retained['revision']==SOURCE and retained['status']=='complete-review-required'
generated=tree(ART/'generated')
live={str(p.relative_to(ROOT)):p for p in (ROOT/'tests/golden').rglob('*') if p.is_file()}
assert len(generated)==424 and set(live)==set(generated)
source_paths=set(git('ls-tree','-r','--name-only',SOURCE,'--','tests/golden').decode().splitlines())
assert source_paths==set(generated)
rows=[]; changed=[]
for name,p in sorted(generated.items()):
 before=live[name].read_bytes(); original=git('show',SOURCE+':'+name); after=p.read_bytes()
 assert before==original, name+' current differs from source324'
 assert identity(after)['sha256']==retained['sha256']['generated/'+name],name+' retained hash mismatch'
 if before!=after:changed.append(name)
 if name in EXPECTED:assert (identity(after)['sha256'],len(after))==EXPECTED[name],name
 rows.append({'path':name,'source324':identity(original),'before':identity(before),'retained_after':identity(after),'unchanged':before==after})
assert set(changed)==set(EXPECTED) and len(changed)==5
continuity=git('diff','--name-status',SOURCE+'..'+BASE).decode()
allowed={'scripts/conditional-capture-bootstrap.py','scripts/conditional-capture-candidate-command.mjs','scripts/conditional-capture-candidate-command.test.mjs','scripts/conditional-capture-candidate.py','scripts/conditional-capture-candidate.test.py'}
assert {line.split('\t')[-1] for line in continuity.splitlines()}==allowed
(OUT/'source-continuity-name-status.txt').write_text(continuity)
dump('before-and-retained-identities.json',rows)
dump('pre-copy-results.json',{'base':BASE,'base_tree':git('rev-parse','HEAD^{tree}').decode().strip(),'source':SOURCE,'source_tree':git('rev-parse',SOURCE+'^{tree}').decode().strip(),'generated_files':424,'live_source324_equal_files':424,'unchanged_generated_files':419,'changed_paths':changed,'all_retained_generated_hashes_verified':True,'free_bytes':shutil.disk_usage(ROOT).free})
# Only the five reviewed original byte strings are copied, without serialization.
for name in sorted(EXPECTED):shutil.copyfile(generated[name],ROOT/name)
assert shutil.disk_usage(ROOT).free>=8*1024**3
live_after={str(p.relative_to(ROOT)):p for p in (ROOT/'tests/golden').rglob('*') if p.is_file()}
assert set(live_after)==set(generated)
for name,p in generated.items():assert live_after[name].read_bytes()==p.read_bytes(),name
actual=git('diff','--name-only','--no-renames').decode().splitlines()
assert set(actual)==set(EXPECTED) and len(actual)==5
assert git('diff','--cached','--name-only')==b''
assert git('ls-files','--others','--exclude-standard')==b''
dump('post-copy-results.json',{'fulltree_exact_equal_files':424,'generated_unchanged_files':419,'changed_paths':actual,'staged_paths':[],'untracked_paths':[],'free_bytes':shutil.disk_usage(ROOT).free})
print('PASS: 424 current files equal source324 before copy; all 424 retained hashes verified; exactly 419 unchanged; copied exactly five; full live 424-file tree equals retained generated tree.')
print(json.dumps([r for r in rows if r['path'] in EXPECTED],indent=2))

# Shared-golden import evidence

Bounded evidence for commit `89d15ce4c2604033689acb097bf0f5279751640f`; full report: `/workspace/scratch/cs-numeric-kernels/.superpowers/sdd/numeric-kernels/shared-golden-import-report.md`.

- pre-copy-results.json — preconditions and original tree checks
- before-and-retained-identities.json — 424 per-file identities
- source-continuity-name-status.txt — complete later source path inventory
- post-copy-results.json — fulltree/path checks after copy
- final-results.json — fresh committed/live verification
- import.py — byte import/check procedure
- verify-and-report.py — final verification/report procedure

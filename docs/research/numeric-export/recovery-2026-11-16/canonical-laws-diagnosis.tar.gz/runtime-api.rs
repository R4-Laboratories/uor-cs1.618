//! Diagnostic wrapper only: invoke the exact linked LexLean runtime API.
use std::{env,fs,path::Path};
fn main() {
    if let Ok(source) = env::var("NATIVE_LAWS") {
        let source = fs::read_to_string(source).expect("native Laws");
        let core = lexlean::ir::core::CoreModule::from_source(&source, "1.2").expect("native source parser");
        for row in core.declarations {
            println!("native-row\t{}\t{:?}\tcompiled={}\tgenerated={}", row.name, row.kind, row.compiled, row.generated);
        }
    }
    let args: Vec<_> = env::args().skip(1).collect();
    let (out, inputs) = args.split_first().expect("OUT generated modules...");
    let texts: Vec<_> = inputs.iter().map(|p| fs::read_to_string(p).expect("input")).collect();
    fs::create_dir_all(out).expect("out");
    let modules = lexlean::backend::runtime::imported_by(texts.iter().map(String::as_str)).expect("runtime API");
    for m in modules {
        let name = format!("{}.lean", m.name.replace('.', "/"));
        let p = Path::new(out).join(name);
        fs::create_dir_all(p.parent().expect("parent")).expect("directory");
        fs::write(p, m.text.as_bytes()).expect("runtime bytes");
        println!("{}\t{}\t{}\t{}",m.name,m.text.len(),m.declarations.len(),m.imports.join(","));
    }
}

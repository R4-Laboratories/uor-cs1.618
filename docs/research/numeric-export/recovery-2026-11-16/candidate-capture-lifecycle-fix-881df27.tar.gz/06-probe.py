import hashlib,importlib.util,json,pathlib,subprocess,time
root=pathlib.Path(__file__).parent
path=pathlib.Path('/workspace/scratch/prismpm-numeric/scripts/conditional-capture-candidate.py')
spec=importlib.util.spec_from_file_location('candidate',path); c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
output=root/'probe-output';output.mkdir(mode=0o700)
d=c.Diagnostics(time.monotonic()+480);d.bind_output(output)
owner=c.Lifecycle(d.deadline,None,[],diagnostics=d);owner.volumes={'input':'fixture-input','work':'fixture-work'}
original=c.legacy.run_bounded;events=[]
def structural(argv,**kwargs):
 events.append(argv[3:]); n=str(len(events)).encode()
 return subprocess.CompletedProcess(argv,1,b'actual-stdout-'+n+b'\n',b'actual-stderr-'+n+b'\n')
c.legacy.run_bounded=structural
try:
 try:
  try: owner.call('image','inspect','explicit-structural-operation')
  finally: owner.finish(False)
 except RuntimeError as error:
  d.exception(error)
  message=str(error)
finally:
 c.legacy.run_bounded=original
 d.close()
expected_out=b''.join(b'actual-stdout-'+str(n).encode()+b'\n' for n in range(1,4))
expected_err=b''.join(b'actual-stderr-'+str(n).encode()+b'\n' for n in range(1,4))
assert (d.directory/'exception.stdout').read_bytes()==expected_out
assert (d.directory/'exception.stderr').read_bytes()==expected_err
assert not (output/c.ENVELOPE_NAME).exists()
print(json.dumps({'events':events,'cleanup_calls':owner.cleanup_calls,'reconciled':d.reconciled,
 'retention_incomplete':d.retention_incomplete,'exception':message,'locator':d.locator(),
 'stdout_hex':expected_out.hex(),'stderr_hex':expected_err.hex(),'no_envelope':True,
 'files':[{'path':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
          for p in sorted(d.directory.iterdir())]},sort_keys=True))

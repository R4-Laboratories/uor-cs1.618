import Init
namespace Probe
 theorem addZeroLeft (n : Nat) : 0 + n = n := by
  induction n with
  | zero => rfl
  | succ n ih => congr 1
 theorem selfLe (n : Nat) : n <= n := by constructor
 theorem identityImplication (a b : Nat) : a <= b -> a <= b := by
  constructor
 theorem addMono (a b c : Nat) : a <= b -> a + c <= b + c := by
  induction c with
  | zero => constructor
  | succ c ih => constructor
end Probe
#print axioms Probe.addZeroLeft
#print axioms Probe.selfLe

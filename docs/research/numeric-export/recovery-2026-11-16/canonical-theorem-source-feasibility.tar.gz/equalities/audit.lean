module
public import Init
set_option autoImplicit false
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000000
set_option linter.constructorNameAsVariable false
namespace Feasibility.Helpers

public theorem addZeroRight (a : Nat) : ((a + 0) = a) := by
  rfl

public theorem addSuccRight (a : Nat) (b : Nat) : ((a + (b + 1)) = ((a + b) + 1)) := by
  rfl

public theorem addZeroLeft (n : Nat) : ((0 + n) = n) := by
  induction n with
  | zero =>
    rfl
  | succ k ih =>
    simp only [addSuccRight, ih]

public theorem addAssociative (a : Nat) (b : Nat) (c : Nat) : (((a + b) + c) = (a + (b + c))) := by
  induction c with
  | zero =>
    rfl
  | succ k ih =>
    simp only [addSuccRight, ih]

public theorem copiedZeroRight (a : Nat) : ((a + 0) = a) := by
  exact addZeroRight (a)

end Feasibility.Helpers

#print axioms Feasibility.Helpers.addZeroRight
#print axioms Feasibility.Helpers.addSuccRight
#print axioms Feasibility.Helpers.addZeroLeft
#print axioms Feasibility.Helpers.addAssociative
#print axioms Feasibility.Helpers.copiedZeroRight

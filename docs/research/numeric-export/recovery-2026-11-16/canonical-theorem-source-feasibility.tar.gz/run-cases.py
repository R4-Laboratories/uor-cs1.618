from pathlib import Path
import shutil,json,subprocess,time,hashlib
out=Path(__file__).parent
base=out/'structural';compiler='/workspace/diagnostic-tools/lexlean-target/release/lexlean';lean='/workspace/diagnostic-tools/elan/toolchains/leanprover--lean4---v4.32.1/bin/lean'
cases={
'equalities':r'''
theorem{name: addZeroRight, parameters: [a : Nat], statement: ((a + 0) = a), proof: reflexivity{}}
theorem{name: addSuccRight, parameters: [a : Nat, b : Nat], statement: ((a + (b + 1)) = ((a + b) + 1)), proof: reflexivity{}}
theorem{name: addZeroLeft, parameters: [n : Nat], statement: ((0 + n) = n), proof: induction{scrutinee: n, branches: [{constructor: "zero", binders: [], proof: reflexivity{}}, {constructor: "succ", binders: [k, ih], proof: simplify{definitions: [addSuccRight, ih]}}]}}
theorem{name: addAssociative, parameters: [a : Nat, b : Nat, c : Nat], statement: (((a + b) + c) = (a + (b + c))), proof: induction{scrutinee: c, branches: [{constructor: "zero", binders: [], proof: reflexivity{}}, {constructor: "succ", binders: [k, ih], proof: simplify{definitions: [addSuccRight, ih]}}]}}
theorem{name: copiedZeroRight, parameters: [a : Nat], statement: ((a + 0) = a), proof: apply{theorem: addZeroRight, arguments: [a]}}
''',
'inequalities':r'''
theorem{name: selfLe, parameters: [a : Nat], statement: (a <= a), proof: decide{}}
theorem{name: monotone, parameters: [a : Nat, b : Nat, c : Nat], statement: ((a <= b) -> ((a + c) <= (b + c))), proof: induction{scrutinee: c, branches: [{constructor: "zero", binders: [], proof: constructor{branches: [reflexivity{}]}}, {constructor: "succ", binders: [k, ih], proof: constructor{branches: [reflexivity{}]}}]}}
theorem{name: transitive, parameters: [a : Nat, b : Nat, c : Nat], statement: ((a <= b) -> ((b <= c) -> (a <= c))), proof: constructor{branches: [reflexivity{}]}}
theorem{name: cancellation, parameters: [a : Nat, b : Nat, c : Nat], statement: (((a + c) < (b + c)) -> (a < b)), proof: induction{scrutinee: c, branches: [{constructor: "zero", binders: [], proof: congruence{}}, {constructor: "succ", binders: [k, ih], proof: congruence{}}]}}
''',
'local-apply':r'''
theorem{name: selfEquality, parameters: [n : Nat], statement: (n = n), proof: induction{scrutinee: n, branches: [{constructor: "zero", binders: [], proof: reflexivity{}}, {constructor: "succ", binders: [k, ih], proof: apply{theorem: ih, arguments: []}}]}}
''',
'imported-apply':r'''
theorem{name: selfLe, parameters: [n : Nat], statement: (n <= n), proof: apply{theorem: Nat.le_refl, arguments: [n]}}
''',
'proof-parameter':r'''
theorem{name: identityLe, parameters: [a : Nat, b : Nat, h : (a <= b)], statement: (a <= b), proof: reflexivity{}}
''',
'empty-constructor':r'''
theorem{name: selfLe, parameters: [a : Nat], statement: (a <= a), proof: constructor{branches: []}}
'''
}
allresults=[]
for name,body in cases.items():
 if name == "equalities": continue
 p=out/name;(p/'src').mkdir(parents=True,exist_ok=True)
 for f in ['lexlean.toml','lean-toolchain','lakefile.toml','lake-manifest.json']:shutil.copyfile(base/f,p/f)
 (p/'src/Helpers.lex.tex').write_text('\\begin{lexlean}{Helpers}\n\\useglossary{lexlean.std.nat@1.2.0}\n\\title{addition}\n\\begin{semanticmodule}\n'+body+'\\end{semanticmodule}\n\\end{lexlean}\n')
 records=[]
 for command in ['lock','check','build']:
  args=[compiler,'--project',str(p/'lexlean.toml'),'--diagnostic-format','json',command]+(['--all'] if command!='lock' else [])
  env={'LANG':'C','LC_ALL':'C','PATH':'/usr/bin:/bin'};t=time.monotonic();r=subprocess.run(args,cwd=p,env=env,capture_output=True,timeout=20)
  (p/(command+'.stdout')).write_bytes(r.stdout);(p/(command+'.stderr')).write_bytes(r.stderr);records.append({'argv':args,'env':env,'cwd':str(p),'exit':r.returncode,'elapsed_seconds':time.monotonic()-t})
  if r.returncode:print(name,command,r.returncode,r.stdout.decode()[:1300],flush=True);break
 else:
  b=json.loads((p/'build.stdout').read_text());emitted=p/b['artifacts'][0]/'modules/Feasibility/Helpers.lean'
  names=[line.split('public theorem ',1)[1].split(' ',1)[0] for line in emitted.read_text().splitlines() if line.startswith('public theorem ')]
  audit=p/'audit.lean';audit.write_bytes(emitted.read_bytes()+('\n'+'\n'.join('#print axioms Feasibility.Helpers.'+n for n in names)+'\n').encode())
  args=[lean,'-j2',str(audit)];env={'LANG':'C','LC_ALL':'C','LEAN_NUM_THREADS':'2'};t=time.monotonic()
  try:
   r=subprocess.run(args,cwd=p,env=env,capture_output=True,timeout=20)
  except subprocess.TimeoutExpired as exc:
   (p/'audit.stdout').write_bytes(exc.stdout or b'');(p/'audit.stderr').write_bytes(exc.stderr or b'')
   records.append({'argv':args,'env':env,'cwd':str(p),'exit':None,'timeout_seconds':20,'elapsed_seconds':time.monotonic()-t})
   (p/'commands.json').write_text(json.dumps(records,indent=2)+'\n');allresults.append({'case':name,'commands':records});print(name,'lean TIMEOUT',flush=True);continue
  (p/'audit.stdout').write_bytes(r.stdout);(p/'audit.stderr').write_bytes(r.stderr);records.append({'argv':args,'env':env,'cwd':str(p),'exit':r.returncode,'elapsed_seconds':time.monotonic()-t,'emitted_sha256':hashlib.sha256(emitted.read_bytes()).hexdigest()});print(name,'lean',r.returncode,r.stdout.decode()[:3500],flush=True)
 (p/'commands.json').write_text(json.dumps(records,indent=2)+'\n');allresults.append({'case':name,'commands':records})
(out/'cases-results.json').write_text(json.dumps(allresults,indent=2)+'\n')

module
public import Init
set_option autoImplicit false
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000000
set_option linter.constructorNameAsVariable false
namespace Feasibility.Helpers

public theorem selfLe (a : Nat) : (a <= a) := by
  decide

public theorem monotone (a : Nat) (b : Nat) (c : Nat) : ((a <= b) -> ((a + c) <= (b + c))) := by
  induction c with
  | zero =>
    constructor
    ·
      rfl
  | succ k ih =>
    constructor
    ·
      rfl

public theorem transitive (a : Nat) (b : Nat) (c : Nat) : ((a <= b) -> ((b <= c) -> (a <= c))) := by
  constructor
  ·
    rfl

public theorem cancellation (a : Nat) (b : Nat) (c : Nat) : (((a + c) < (b + c)) -> (a < b)) := by
  induction c with
  | zero =>
    congr 1
  | succ k ih =>
    congr 1

end Feasibility.Helpers

#print axioms Feasibility.Helpers.selfLe
#print axioms Feasibility.Helpers.monotone
#print axioms Feasibility.Helpers.transitive
#print axioms Feasibility.Helpers.cancellation

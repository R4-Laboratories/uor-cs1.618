module
public import Init
set_option autoImplicit false
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000000
set_option linter.constructorNameAsVariable false
namespace Feasibility.Helpers

public theorem addZeroRight (n : Nat) : ((n + 0) = n) := by
  rfl

public theorem addZeroLeft (n : Nat) : ((0 + n) = n) := by
  induction n with
  | zero =>
    rfl
  | succ k ih =>
    simp only [ih]

public theorem selfLe (n : Nat) : (n <= n) := by
  constructor
  ·
    rfl

end Feasibility.Helpers

#print axioms Feasibility.Helpers.addZeroRight
#print axioms Feasibility.Helpers.addZeroLeft
#print axioms Feasibility.Helpers.selfLe

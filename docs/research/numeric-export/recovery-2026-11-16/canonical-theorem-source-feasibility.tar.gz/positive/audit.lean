module
public import Init
set_option autoImplicit false
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000000
set_option linter.constructorNameAsVariable false
namespace Feasibility.Helpers

public theorem addZeroRight (a : Nat) : ((a + 0) = a) := by
  rfl

public theorem copiedZeroRight (a : Nat) : ((a + 0) = a) := by
  exact addZeroRight (a)

public theorem casesEquality (n : Nat) : (n = n) := by
  cases n with
  | zero =>
    rfl
  | succ k =>
    rfl

public theorem inductionEquality (n : Nat) : (n = n) := by
  induction n with
  | zero =>
    rfl
  | succ k ih =>
    rfl

end Feasibility.Helpers

#print axioms Feasibility.Helpers.addZeroRight
#print axioms Feasibility.Helpers.copiedZeroRight
#print axioms Feasibility.Helpers.casesEquality
#print axioms Feasibility.Helpers.inductionEquality

import subprocess,pathlib,hashlib,json,shutil
root=pathlib.Path('/workspace/scratch/prismpm-numeric');base='881df278923ff271fc179703e55ea91c45f2394d'
immutable=['scripts/conditional-capture-sdk.py','scripts/conditional-capture-command.mjs','scripts/sdk-command-owner.mjs','scripts/sdk-command-owner.py']
def git(*args):return subprocess.check_output(['git',*args],cwd=root)
def sha(body):return hashlib.sha256(body).hexdigest()
protected=immutable+['scripts/conditional-capture-sdk.test.py','scripts/conditional-capture-candidate.py','scripts/conditional-capture-bootstrap.py','scripts/conditional-capture-candidate-command.mjs','scripts/conditional-capture-candidate.test.py','scripts/conditional-capture-candidate-command.test.mjs']
golden=git('show','--pretty=format:','--name-only','89d15ce4c2604033689acb097bf0f5279751640f').decode().splitlines()
protected+= [p for p in golden if p]
rows=[]
for path in protected:
 before=git('show',base+':'+path);actual=(root/path).read_bytes();assert actual==before,path
 rows.append({'path':path,'bytes':len(actual),'sha256':sha(actual),'base_equal':True})
path='crates/prismpm/src/oci/publication_context/capture_tests.rs';before=git('show',base+':'+path);after=(root/path).read_bytes()
start=b'    let started = std::time::Instant::now();';assert before.split(start,1)[1]==after.split(start,1)[1]
graph=b'fn graph_refusals(';end=b'#[test]';assert before.split(graph,1)[1].split(end,1)[0].split(b'// cfg(test)',1)[0]==after.split(graph,1)[1].split(b'// cfg(test)',1)[0]
print(json.dumps({'base':base,'protected':rows,'original_capture_body_byte_identical':True,'original_graph_refusals_byte_identical':True,'free_bytes':shutil.disk_usage(root).free,'changed_paths':git('diff','--name-only').decode().splitlines(),'new_paths':git('ls-files','--others','--exclude-standard').decode().splitlines()},sort_keys=True,indent=2))

import pathlib,re,subprocess,json
root=pathlib.Path('/workspace/scratch/prismpm-numeric');owner=(root/'tests/publication-context-linkage/capture-owner.mjs').read_text()
body=owner.split('const gateTests = [',1)[1].split('].map',1)[0]
expected=['cases::node_suite::tests::'+name+': test' for name in re.findall("'([^']+)'",body)]+['12 tests, 0 benchmarks']
elf=root/'target/debug/deps/repo_conformance-1650c30cd5608902'
p=subprocess.run([str(elf),'cases::node_suite::tests::','--list'],capture_output=True,timeout=10)
assert p.returncode==0 and p.stdout.decode().splitlines()==expected,(p.stdout,p.stderr)
print(json.dumps({'elf':str(elf),'status':p.returncode,'complete_count':12,'lines':expected},indent=2))

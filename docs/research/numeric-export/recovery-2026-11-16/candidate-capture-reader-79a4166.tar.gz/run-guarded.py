import subprocess,json,time,sys,pathlib,os,signal,shutil
root=pathlib.Path('/workspace/diagnostic-tools/candidate-capture-reader');name=sys.argv[1];cmd=sys.argv[2:];start=time.time();minimum=shutil.disk_usage('/workspace').free;stopped=False
with (root/(name+'.stdout')).open('wb') as out,(root/(name+'.stderr')).open('wb') as err:
 p=subprocess.Popen(cmd,stdout=out,stderr=err,start_new_session=True)
 while p.poll() is None:
  free=shutil.disk_usage('/workspace').free;minimum=min(minimum,free)
  if free<int(8.5*1024**3):
   stopped=True;os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=3)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL)
   break
  time.sleep(.2)
 status=p.wait()
(root/(name+'.json')).write_text(json.dumps({'argv':cmd,'cwd':str(pathlib.Path.cwd()),'status':status,'elapsed_seconds':time.time()-start,'minimum_free_bytes':minimum,'disk_guard_stopped':stopped},sort_keys=True)+'\n')
print(name,status,'minimum_free_bytes',minimum,'disk_guard_stopped',stopped)
sys.exit(status)

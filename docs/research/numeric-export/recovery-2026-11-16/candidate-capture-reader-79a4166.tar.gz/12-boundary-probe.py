import subprocess,json,os,pathlib
root=pathlib.Path('/workspace/scratch/prismpm-numeric')
elf=root/'target/debug/deps/prismpm-e88e534b42a91ec6'
case='oci::publication_context::capture_tests::actual_source_free_capture_constructs_complete_conditional_context'
results=[]
for key,value,expected in [('PRISMPM_OC10_CAPTURE_ROUTE','unknown-route','unknown PRISMPM_OC10_CAPTURE_ROUTE'),('PRISMPM_OC10_SDK_CHILD','sealed-current-test-elf','SDK child lost its installed inventory')]:
 env=os.environ.copy();env.pop('PRISMPM_OC10_CAPTURE_ROUTE',None);env.pop('PRISMPM_OC10_SDK_CHILD',None);env[key]=value
 p=subprocess.run([str(elf),'--exact',case,'--nocapture'],env=env,capture_output=True,timeout=10)
 assert p.returncode!=0 and expected.encode() in p.stderr,(p.returncode,p.stdout,p.stderr)
 results.append({'key':key,'status':p.returncode,'expected_refusal':expected,'stdout':p.stdout.decode(),'stderr':p.stderr.decode()})
print(json.dumps(results,sort_keys=True,indent=2))

# Objective bot diagnosis — preparation only

## Finding

A current-map, legal ground-level plant can make a bot attempt defusal continuously through site cover until the bomb explodes. This is reproduced, not an inferred elevated-map problem. The bot's `canDefuse` checks omit line of sight, so they return before a valid navigation route can be followed. No product code was changed.

A distinct disconnected-ground-route / genuinely unreachable-defuser selection was **not reproduced**: all 452 current navigation nodes form one connected component. Euclidean assignment can still preserve the stalled kit bot while an un-kitted teammate who could already interact is sent to cover. That consequence does not require an unreachable route; the selected bot has a valid route and fails to take it.

## Environment and scope

- Repository: `/workspace/scratch/cs-numeric-kernels`, HEAD `5aba4d79e9f2c51f3f3bb9dd0e2bc13be6b455a7`.
- `public/wasm/cs_verdant.wasm` SHA-256: `b4d9096a739d6dd7fec457155c751fb1851d2230bd147015f3ed561b0697e2ce`.
- `public/wasm/cs_round.wasm` SHA-256: `ab75a7806437f5611bc2e28afbdd6e2d56b941390fee8d6a9f033d0b255618fa`.
- No `AGENTS.md` exists at `/`, `/workspace`, `/workspace/scratch`, or the repository root. Only relevant server/shared/test sources were inspected.
- Disposable simulation script: `/tmp/objective-bot-recon.mts`; command from repository root: `./node_modules/.bin/tsx /tmp/objective-bot-recon.mts`.
- Focused existing tests: `./node_modules/.bin/tsx --test tests/objective.test.ts tests/bot-objective.test.ts` — **18 passed, 0 failed**. No broad suite/browser rerun, edits, or commits.

## Exact real-map reproduction

Use real `createEngine` and `createRoundKernel`, loaded from the checked-in WASM, and ordinary `Match.step(1/60)`:

1. Join attacker `a` and defender `d`. Set live phase with 90 seconds remaining. Keep `d` human/inactive at defender spawn during planting.
2. Put grounded attacker at `(-16.1, 0, -13)`, within site A. Feed fresh neutral input with `use=true` for exactly 180 ticks. The authoritative objective code emits one `plant` event at time 3 seconds, at A, with the full 40-second bomb timer.
3. Move attacker to `(0, 0, 23)` so combat does not interfere. Put grounded kit defender `d` at `(-17, 0, -12.1)` and turn its bot flag on. Advance until the round ends.

These are valid standing positions beside site A's crate, not points inside solids. The current navigator returns an attacker route from spawn to `(-15,-13)`; `engine.move(-15,0,-13,-1.1,0,.34,1.78)` reaches the exact plant position. Defender spawn also has a route to `(-17,-11)`; `engine.move(-17,0,-11,0,-1.1,.34,1.78)` reaches the exact bot position. Support is 0 at both endpoints.

Measured results:

```text
Plant: x=-16.1 y=0 z=-13 site=A remaining=40
2D distance = 1.2727922061357848
3D distance = 1.2727922061357848
Defuse ray length = 1.3076696830622014
First solid hit = 0.5811865258054231
Valid route from bot: (-15,-11) -> (-15,-13)
After 600 ticks: use=true on all 600, movement inputs=0,
                 progress=0, unchanged bot position, remaining≈30
After 2400 ticks: use=true on all 2400, movement inputs=0,
                  maximum progress=0, winner=attack, terminal=exploded
Events: plant at ≈3s; explode at ≈43s; no defuse
```

The crate occupies x `[-19.5,-16.5]`, z `[-15.5,-12.5]`, height 2 (`shared/map.ts`). The short line between the two valid positions cuts its corner. At `server/match.ts:231` and `:250`, the assigned bot considers distance below 1.8 sufficient and emits stationary use input. Authoritative `objective` at `:183-184` correctly rejects the obstruction. Both bot shortcuts must be considered; fixing just the generated-tactic facts leaves the fallback shortcut.

## Assignment consequence and its limit

Add another alive bot, `second`, without a kit, at `(-15,0,-12)` with the same planted bomb:

```text
blocked kit bot distance = 1.2727922061357848
clear un-kitted bot distance = 1.4866068747318517
botDefuser() = d
```

A direct authoritative one-tick `objective(second,dt)` probe with `use=true` produces `action=DEFUSING`, `progress=1/600`; cancel that probe before simulating. Over the next 600 normal ticks, assignment stays `d`, its progress stays 0 and it uses all 600 ticks, while `second` follows the cover role (ending near `(-16.3975,-16.8316)`) and has no progress. Thus another bot being available does not necessarily rescue the stall.

With **both** bots kitted at these same starting points, the cover bot moves nearer, takes over assignment, and completes defusal. Do not claim every multi-bot arrangement is permanently locked. Do not claim disconnected route selection: the selected bot's own route exists. `nav.path=[]` also means both endpoints snapped to the same node in this graph; it is not by itself evidence of unreachable routing.

## Smallest useful fix to prepare

1. Share the actual device-reach geometry predicate between authoritative defusal and both bot readiness checks: 3D interaction range and the exact existing hand/device-endpoint obstruction ray. Keep grounded/stationary requirements authoritative; bots must be allowed to stop and lose velocity before progress begins. A single helper prevents the present duplicate checks from drifting again.
2. If an assigned bot cannot geometrically interact, keep routing around the obstruction instead of treating proximity as successful arrival. For the exact reproduction, the existing path via `(-15,-11)` is sufficient once the premature interaction shortcut is removed. Also review the `dist > 1.2` movement gate: a blocked bot even closer than 1.2 must continue approaching a valid interaction position. Where snapping to the nearest bomb node leaves no usable endpoint, choose a reachable navigation approach point with valid interaction geometry.
3. Do not make a route-cost rewrite a prerequisite for this proven fix. Current ground graph disconnection is ruled out. A later assignment improvement should compare routes to valid interaction positions and treat unavailable routes explicitly; Euclidean cost alone is an approximation, but it is not the root cause of this reproduction.

## Meaningful regression and existing coverage of this path

Add one bot integration regression beside `tests/bot-objective.test.ts`, using the exact legal 180-tick plant above and the blocked kit bot start. Advance fixed ticks with the attacker safely away. Assert that the bot leaves its blocked start, eventually gains authoritative progress, ends with exactly one `defuse`, defender winner/one score award, and positive bomb time. This tests real geometry, navigation, bot input, authoritative interaction and round outcome together; merely asserting `input.use=false` on one tick would miss a replacement navigation stall. The same setup with the un-kitted clear teammate can additionally ensure cover assignment does not prevent eventual completion, but a separate assignment rewrite is not required to fix this path.

Relevant existing tests, all passing:

- `tests/bot-objective.test.ts:10`: one kit defuser, cover role, replacement after death. It uses an unobstructed synthetic planted position at `(0,20)` and checks initial input, not a completed defuse around cover.
- `tests/bot-objective.test.ts:13`: actual bot carrier reaches a navigable site and plants; escort stays nearby. It stops when planted and does not exercise a defender approach.
- `tests/objective.test.ts:15-17`: physical drop/pickup/plant cues, full timer, cancellation, exact kit/normal defuse duration and single award. Defender control is human/direct input.
- `tests/objective.test.ts:18`, `:29`: deadline beats a same-tick completion; bounded explosion damage and one explosion; exact plant tick 180 and explosion tick 2400. These validate the failed attempt's terminal outcome but do not detect a bot wasting all 2400 ticks.
- `tests/objective.test.ts:23`: authoritative obstruction/range rejection, recovery and before-deadline completion. It moves the human defender directly to a clear position; no bot route follows the initial rejection.
- `tests/objective.test.ts:24`, `:26`: exact elevated device endpoint / upper-versus-lower cover obstruction. These manually place the bomb and human defender around the low metal cover at `(3,16)`, outside a legal bombsite. They protect authoritative ray geometry, but are not evidence of bots reaching an elevated legal plant in normal map play.

The missing coverage is specifically the transition from **bot interaction rejected by real cover** to **bot navigation around cover and completed authoritative defuse**, following a legal plant. Existing plant, authoritative defuse, and explosion tests can remain the baseline.

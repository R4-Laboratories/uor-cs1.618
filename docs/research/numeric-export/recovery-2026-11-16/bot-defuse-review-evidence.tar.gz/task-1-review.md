# Task 1 independent review

Reviewed `a627140..287bb3056eab005f62e7caab3ad24bc919a6e552` against the task brief, reconnaissance and approved routing plan. Scope is the supplied diff for `server/match.ts` and `tests/bot-objective.test.ts`; this is not a whole-branch or publication review.

## Verdict

**Spec: PASS. Quality: PASS. No blocking or non-blocking findings identified in this patch.** No severity/file-line findings to report.

- `server/match.ts:183-200`: authoritative defusal keeps the alive/live/planted/team/single-owner, grounded and stationary gates. The extracted predicate preserves strict 3D distance `<2.3`, the exact hand `y+0.5` to device `y+0.2` ray, its short-ray case and `len-0.05` tolerance. Defuse durations, progress, expiry ordering, scoring and kit preference are unchanged. Both bot readiness shortcuts now use this predicate.
- `server/match.ts:202-212`: approach selection searches actual navigation nodes with valid device geometry and accepts graph paths. Inspection of `server/navigation.ts:18-24` confirms that `path=[]` is ambiguous between same-node and unavailable routes; the explicit `[id]` same-node endpoint is therefore necessary and correctly distinguished by node identity.
- `server/match.ts:268-274`: an assigned defuser continues routing within the ordinary `1.2` arrival cutoff. Its final waypoint survives the general `0.7` consumption threshold until actual interaction geometry succeeds. This fixes both the reproduced premature-use stall and the independent empty-route stall. Cached routes can persist until the existing `1+random()` replan deadline; the countdown continues before early returns, so stale cover/objective routes are replaced without an unbounded cache stall. That cadence and its bounded transition delay are unchanged.
- `tests/bot-objective.test.ts:16-46`: three actual-engine/round-WASM regressions use a real 180-tick legal plant, including the exact crate-corner reproduction, an explicitly asserted `<1.2` blocked start, and an explicitly asserted same-node empty route. They verify no initial illegal progress/use, movement, eventual authoritative progress, successful defusal before expiry, one defender award, one defuse/no explosion and stable terminal scoring/events. These test complete behavior rather than mocking the new helper or route selection.

## Verification evidence

The implementation report records final red evidence against the base (18 passing, three failing regressions), final focused green (21 passing), full verification including 136 passing tests/build/pins, final test-only fixture verification (136 passing), and the objective browser gate. No reported checks were rerun: source review and the targeted navigation API/physics-support inspection left no unanswered risk requiring another execution. The browser gate exercises the shared human interaction/HUD path; the new simulation tests exercise the changed bot routing path.

## Remaining limits

- Ground-graph routing and the navigator's existing nearest-node/off-grid segment assumptions remain. The support query at ceiling zero matches this ground-level graph; arbitrary elevated approach navigation is not implemented or claimed.
- A bomb with no valid reachable interaction node yields an empty route; assignment feasibility and disconnected-route selection remain outside this reproduced repair. Existing kit/owner/dead-defuser policy is preserved.
- Replanning retains the existing cadence and may briefly follow a previous cached route after the bot's role changes. No new general cache invalidation policy was requested or needed for the reproduced failures.
- Review relies on the implementation report for execution results. Whole-branch review, publication and deployed-content verification remain separate work.

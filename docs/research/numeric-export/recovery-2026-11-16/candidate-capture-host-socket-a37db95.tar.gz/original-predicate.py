import ast,json,pathlib,socket,stat,tempfile
source=pathlib.Path('scripts/numeric/candidate-capture-qualification.py').read_text();tree=ast.parse(source)
function=next(node for node in tree.body if isinstance(node,ast.FunctionDef) and node.name=='bridge_privileged')
call=next(node for node in ast.walk(function) if isinstance(node,ast.Call) and len(node.args)==2 and isinstance(node.args[1],ast.Constant) and node.args[1].value=='actual fixed Docker socket')
with tempfile.TemporaryDirectory() as temporary:
 root=pathlib.Path(temporary);(root/'var').mkdir();(root/'run').mkdir();(root/'var/run').symlink_to('../run')
 with socket.socket(socket.AF_UNIX,socket.SOCK_STREAM) as endpoint:
  endpoint.bind(str(root/'run/docker.sock'));logical=root/'var/run/docker.sock'
  actual=eval(compile(ast.Expression(call.args[0]),'<actual old predicate>','eval'),{'stat':stat,'socket':logical.lstat(),'Path':lambda value:root/value.lstrip('/')})
  print(json.dumps({'real_socket':stat.S_ISSOCK(logical.lstat().st_mode),'parent_link':'../run','logical':str(logical),'resolved':str(logical.resolve()),'actual_old_predicate':actual}))
  assert actual,'actual old production predicate rejects a real socket behind the fixed OS parent alias'

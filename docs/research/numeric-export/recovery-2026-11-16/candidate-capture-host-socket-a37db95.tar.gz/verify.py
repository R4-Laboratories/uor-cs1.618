import ast,hashlib,json,os,pathlib,shutil,subprocess
folder=pathlib.Path(__file__).resolve().parent;game=pathlib.Path('/workspace/scratch/cs-numeric-kernels');source=pathlib.Path('/workspace/scratch/prismpm-numeric');env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'}
def sha(body):return hashlib.sha256(body).hexdigest()
def git(root,*args):return subprocess.check_output(['git','-C',str(root),*args],env=env).decode().strip()
owned=['scripts/numeric/candidate-capture-qualification.py','scripts/numeric/tests/test_candidate_capture_qualification.py']
changed=set(git(game,'diff','--name-only').splitlines());assert set(owned)<=changed
assert all(name.startswith('docs/') for name in changed-set(owned))
assert not git(game,'diff','--cached','--name-only','--',*owned)
for name in owned:ast.parse((game/name).read_bytes(),filename=name)
indexes={}
for directory,digest,count in [(folder.parent,'dbc44ad0a35c1813d404db09933dc769127418f59b1de6e87bca14e7a1d052fa',77),(folder.parent/'fix-1','31b0122ec142a3a4d78545101fa284ef343a51cbafb636212ef59f1ef79cf69a',51),(folder.parent/'host-handoff','bf3ee419ed3ad092aa165a83f9d10540acd29a14b06be9c58516dd6c24d31b72',45)]:
 body=(directory/'evidence-index.json').read_bytes();assert sha(body)==digest;rows=json.loads(body)['files'];assert len(rows)==count
 for row in rows:
  content=(directory/row['path']).read_bytes();assert len(content)==row['bytes'] and sha(content)==row['sha256']
 indexes[str(directory)]={'index_sha256':digest,'files_unchanged':count}
original=json.loads((folder.parent/'18-commit-proof.json').read_text())
for name,row in original['owned_files'].items():
 if name not in owned and not name.endswith('.yml'):
  body=(game/name).read_bytes();assert len(body)==row['bytes'] and sha(body)==row['sha256']
workflow='.github/workflows/prismpm-candidate-capture-qualification.yml'
assert (game/workflow).read_bytes()==subprocess.check_output(['git','-C',str(game),'show','b09d45c:'+workflow],env=env)
actual={'source':git(source,'rev-parse','HEAD','HEAD^{tree}')+'\n','index_sha256':sha((source/'.git/index').read_bytes())}
assert actual==original['source_unchanged'] and git(source,'status','--porcelain=v1','--untracked-files=all')==''
report={'scope':'socket-filesystem-components-only-no-privileged-witness-or-daemon','parent':git(game,'rev-parse','HEAD'),'owned_files':{name:{'bytes':(game/name).stat().st_size,'sha256':sha((game/name).read_bytes())} for name in owned},'source_unchanged':actual,'indexes_unchanged':indexes,'workflow_unchanged_sha256':sha((game/workflow).read_bytes()),'other_parent_changes':sorted(changed-set(owned)),'python_ast':'PASS','free_bytes':shutil.disk_usage(game).free}
assert report['free_bytes']>=8*1024**3
(folder/'06-preservation-proof.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))

import hashlib,json,os,pathlib,shutil,subprocess
folder=pathlib.Path(__file__).resolve().parent;game=pathlib.Path('/workspace/scratch/cs-numeric-kernels');env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'}
def sha(body):return hashlib.sha256(body).hexdigest()
def git(*args):return subprocess.check_output(['git','-C',str(game),*args],env=env)
previous=json.loads((folder/'06-preservation-proof.json').read_text());commit=git('rev-parse','HEAD').decode().strip();tree=git('rev-parse','HEAD^{tree}').decode().strip();parent=git('rev-parse','HEAD^').decode().strip()
assert parent==previous['parent'];assert set(git('diff-tree','--no-commit-id','--name-only','-r','HEAD').decode().splitlines())==set(previous['owned_files'])
for name,row in previous['owned_files'].items():
 body=git('show','HEAD:'+name);assert body==(game/name).read_bytes();assert len(body)==row['bytes'] and sha(body)==row['sha256']
assert not git('diff','--name-only','--',*previous['owned_files']).strip() and not git('diff','--cached','--name-only','--',*previous['owned_files']).strip()
source=pathlib.Path('/workspace/scratch/prismpm-numeric')
actual={'source':subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD','HEAD^{tree}'],env=env).decode(),'index_sha256':sha((source/'.git/index').read_bytes())}
assert actual==previous['source_unchanged'];assert not subprocess.check_output(['git','-C',str(source),'status','--porcelain=v1','--untracked-files=all'],env=env).strip()
for name,row in previous['indexes_unchanged'].items():
 directory=pathlib.Path(name);body=(directory/'evidence-index.json').read_bytes();assert sha(body)==row['index_sha256']
 for item in json.loads(body)['files']:
  content=(directory/item['path']).read_bytes();assert len(content)==item['bytes'] and sha(content)==item['sha256']
proof={'commit':commit,'tree':tree,'parent':parent,'owned_files':previous['owned_files'],'source_unchanged':actual,'prior_indexes_unchanged':previous['indexes_unchanged'],'free_bytes':shutil.disk_usage(game).free}
assert proof['free_bytes']>=8*1024**3
(folder/'09-commit-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof,indent=2))

import ast,hashlib,json,os,pathlib,shutil,subprocess,yaml
game=pathlib.Path('/workspace/scratch/cs-numeric-kernels');source=pathlib.Path('/workspace/scratch/prismpm-numeric');folder=pathlib.Path(__file__).parent
initial=folder.parent;env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'}
def git(root,*args):return subprocess.check_output(['git','-C',str(root),*args],env=env).decode().strip()
def sha(body):return hashlib.sha256(body).hexdigest()
owned=['.github/workflows/prismpm-candidate-capture-qualification.yml','scripts/numeric/candidate-capture-qualification.py','scripts/numeric/tests/test_candidate_capture_qualification.py']
assert git(game,'rev-parse','HEAD')=='8812d8511c53871783cc5ad15eb6ec4ba15134b0'
assert set(git(game,'diff','--name-only').splitlines())==set(owned)
assert not git(game,'diff','--cached','--name-only')
for path in owned:
    if path.endswith('.py'):ast.parse((game/path).read_bytes(),filename=path)
workflow=yaml.load((game/owned[0]).read_text(),Loader=yaml.BaseLoader);shells=0
for job in workflow['jobs'].values():
    for step in job['steps']:
        if 'run' in step:
            subprocess.run(['bash','-n'],input=step['run'].encode(),check=True);shells+=1
index=(initial/'evidence-index.json').read_bytes();assert sha(index)=='dbc44ad0a35c1813d404db09933dc769127418f59b1de6e87bca14e7a1d052fa'
records=json.loads(index)['files'];assert len(records)==77
for row in records:
    body=(initial/row['path']).read_bytes();assert len(body)==row['bytes'] and sha(body)==row['sha256']
original=json.loads((initial/'18-commit-proof.json').read_text())
for path,row in original['owned_files'].items():
    if path not in owned:
        body=(game/path).read_bytes();assert len(body)==row['bytes'] and sha(body)==row['sha256']
actual={'source':git(source,'rev-parse','HEAD','HEAD^{tree}')+'\n','index_sha256':sha((source/'.git/index').read_bytes())}
assert actual==original['source_unchanged'] and git(source,'status','--porcelain=v1','--untracked-files=all')==''
authorities={}
for path in ['tests/publication-context-linkage/compile.mjs','tests/publication-context-linkage/checks.mjs',
             'tests/publication-context-linkage/mutations.mjs','tests/publication-context-linkage/driver/src/main.rs',
             'tests/browser-view/generated-package.mjs','tests/browser-view/generated-wasm.mjs',
             'vendor/lexlean/src/api.rs','vendor/lexlean/src/artifact/manifest.rs','vendor/lexlean/src/verify/mod.rs',
             'vendor/lexlean/src/backend/runtime.rs','vendor/lexlean/language/runtime-1.2/library.toml']:
    body=subprocess.check_output(['git','-C',str(source),'show','f292c710:'+path],env=env)
    authorities[path]={'bytes':len(body),'sha256':sha(body),'git_blob':git(source,'rev-parse','f292c710:'+path)}
record={'scope':'fix1-components-syntax-preservation-only-no-SDK','parent':git(game,'rev-parse','HEAD'),
        'source':actual,'original_77_evidence_files':'unchanged','original_index_sha256':sha(index),
        'fixed_source_authorities':authorities,'shell_steps_checked':shells,
        'owned_files':{path:{'bytes':(game/path).stat().st_size,'sha256':sha((game/path).read_bytes())} for path in owned},
        'free_bytes':shutil.disk_usage(game).free}
assert record['free_bytes']>=8*1024**3
(folder/'12-preservation-proof.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'python_ast':'PASS','bash_syntax_steps':shells,'initial_evidence_files_unchanged':77,'source_unchanged':True,'free_bytes':record['free_bytes']}))

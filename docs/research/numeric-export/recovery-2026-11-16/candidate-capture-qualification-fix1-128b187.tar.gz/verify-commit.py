import hashlib,json,os,pathlib,shutil,subprocess
game=pathlib.Path('/workspace/scratch/cs-numeric-kernels');source=pathlib.Path('/workspace/scratch/prismpm-numeric');folder=pathlib.Path(__file__).parent
env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'}
def git(root,*args):return subprocess.check_output(['git','-C',str(root),*args],env=env).decode().strip()
def sha(body):return hashlib.sha256(body).hexdigest()
before=json.loads((folder/'12-preservation-proof.json').read_text());expected=before['owned_files']
head=git(game,'rev-parse','HEAD');tree=git(game,'rev-parse','HEAD^{tree}');parent=git(game,'rev-parse','HEAD^')
assert parent==before['parent']
assert set(git(game,'diff-tree','--no-commit-id','--name-only','-r','HEAD').splitlines())==set(expected)
for path,row in expected.items():
    body=subprocess.check_output(['git','-C',str(game),'show',head+':'+path],env=env)
    assert len(body)==row['bytes'] and sha(body)==row['sha256'] and (game/path).read_bytes()==body
assert not git(game,'diff','--name-only') and not git(game,'diff','--cached','--name-only')
actual={'source':git(source,'rev-parse','HEAD','HEAD^{tree}')+'\n','index_sha256':sha((source/'.git/index').read_bytes())}
assert actual==before['source'] and git(source,'status','--porcelain=v1','--untracked-files=all')==''
index=(folder.parent/'evidence-index.json').read_bytes();assert sha(index)==before['original_index_sha256']
for row in json.loads(index)['files']:
    body=(folder.parent/row['path']).read_bytes();assert len(body)==row['bytes'] and sha(body)==row['sha256']
record={'scope':'isolated-fix1-game-commit-only-no-publication','commit':head,'tree':tree,'parent':parent,'owned_files':expected,
        'source_unchanged':actual,'original_77_files_unchanged':True,'game_status':git(game,'status','--short'),'free_bytes':shutil.disk_usage(game).free}
assert record['free_bytes']>=8*1024**3
(folder/'15-commit-proof.json').write_text(json.dumps(record,indent=2)+'\n')
report=game/'.superpowers/sdd/candidate-source-capture/task-4b-report.md'
report.write_text(report.read_text()+'\n## Fix1 isolated commit\n\nCommit `'+head+'`, tree `'+tree+'`, parent `'+parent+'`. Exactly three owned paths; committed Git bytes equal the tested and recorded working bytes. Tracked game index/worktree clean; unrelated parent archive/report/working files untouched. Original77 indexed evidence files and index reverified unchanged after commit; source unchanged and clean. Final recorded free '+str(record['free_bytes'])+' bytes. Distinct `fix-1/evidence-index.json` indexes this updated report copy and all new fix evidence, excluding itself. No active process, push, launch, Docker or build. Ready for independent scoped re-review.\n')
shutil.copyfile(report,folder/'task-4b-report.md')
print(json.dumps({'commit':head,'tree':tree,'owned_files':len(expected),'source_unchanged':True,'original_evidence_unchanged':True,'free_bytes':record['free_bytes']}))

import hashlib,json,os,pathlib,shutil,subprocess,sys,time
folder=pathlib.Path(__file__).resolve().parent
name,cwd,*argv=sys.argv[1:]
assert name and '/' not in name and argv
assert shutil.disk_usage(cwd).free>=8*1024**3
started=time.monotonic();before=shutil.disk_usage(cwd).free
process=subprocess.run(argv,cwd=cwd,capture_output=True,timeout=180)
assert len(process.stdout)<=2*1024**2 and len(process.stderr)<=2*1024**2
for channel in ['stdout','stderr']:(folder/(name+'.'+channel)).write_bytes(getattr(process,channel))
selected={key:os.environ.get(key) for key in ['PATH','LANG','LC_ALL','PYTHONPATH','NODE_PATH','CARGO_HOME','ELAN_HOME']}
inputs={'argv':argv,'cwd':cwd,'environment':selected}
record={**inputs,'tool_input_sha256':hashlib.sha256(json.dumps(inputs,sort_keys=True).encode()).hexdigest(),
        'exit':process.returncode,'elapsed_seconds':time.monotonic()-started,'free_before':before,'free_after':shutil.disk_usage(cwd).free,
        'streams':{channel:{'path':name+'.'+channel,'bytes':len(getattr(process,channel)),'sha256':hashlib.sha256(getattr(process,channel)).hexdigest()} for channel in ['stdout','stderr']}}
(folder/(name+'.json')).write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'name':name,'exit':process.returncode,'elapsed_seconds':record['elapsed_seconds'],'free_bytes':record['free_after']}))
print(process.stdout.decode(errors='replace')[-2000:]);print(process.stderr.decode(errors='replace')[-4000:])
sys.exit(process.returncode)

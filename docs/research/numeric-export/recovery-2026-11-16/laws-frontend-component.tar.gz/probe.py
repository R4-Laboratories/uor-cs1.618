from pathlib import Path
import os,json,subprocess,time,signal,hashlib,shutil
ROOT=Path('/workspace/diagnostic-tools/laws-investigation')
SRC=Path('/workspace/diagnostic-tools/canonical-packaging-combined-v3/mul32/lean-work')
WORK=ROOT/'no-c'; WORK.mkdir(exist_ok=False)
LIB=WORK/'.lake/build/lib/lean'; LIB.mkdir(parents=True)
LEAN=Path('/workspace/diagnostic-tools/lean-4.32.1-linux/bin/lean')
COMP=Path('/workspace/scratch/compiler-restoration-check/lean')
mods=['LexLeanRuntime.Portable','LexLeanRuntime.Collections','LexLeanRuntime.Laws','BoundedNumeric.Foundation.Library.V1.Model','BoundedNumeric.Wide','BoundedNumeric.Bounds','BoundedNumeric.Float','BoundedNumeric.NumericPackage']
hashfile=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
report={'scope':'isolated component diagnostic, normal frontend/LCNF with no C output, all project modules including Bounds; not SDK or Prism verification','lean_sha256':hashfile(LEAN),'compiler_sha256':hashfile(COMP/'.lake/build/bin/prod-export'),'bindings':[],'processes':[]}
def save(): (ROOT/'result.json').write_text(json.dumps(report,indent=2)+'\n')
for mod in mods:
 rel=Path(mod.replace('.','/')+'.lean'); p=WORK/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(SRC/rel,p)
 report['bindings'].append({'module':mod,'source':str(SRC/rel),'target':str(p),'sha256':hashfile(p)})
env=dict(os.environ,LEAN_PATH=str(LIB)+':'+str(COMP/'.lake/build/lib/lean'),PATH=str(LEAN.parent)+':'+os.environ['PATH'])
start=time.monotonic()
def run(label,args):
 assert shutil.disk_usage(ROOT).free >= 8*1024**3
 remaining=300-(time.monotonic()-start)
 assert remaining>0
 t=time.monotonic()
 with (ROOT/(label+'.log')).open('w') as f:
  p=subprocess.Popen([str(x) for x in args],cwd=WORK,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
  try: code=p.wait(timeout=remaining)
  except subprocess.TimeoutExpired:
   os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=3)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
   code='timeout300-total'
 report['processes'].append({'label':label,'argv':[str(x) for x in args],'exit':code,'elapsed_seconds':time.monotonic()-t,'log_sha256':hashfile(ROOT/(label+'.log'))});save()
 print(label,code,round(time.monotonic()-t,3),flush=True)
 if code!=0:raise SystemExit(1)
for mod in mods:
 rel=Path(mod.replace('.','/'));out=LIB/rel;out.parent.mkdir(parents=True,exist_ok=True)
 setup=WORK/(mod+'.setup.json')
 setup.write_text(json.dumps({'name':mod,'isModule':True,'package':'numeric_packaging_diagnostic','options':{},'plugins':[],'dynlibs':[],'importArts':{}}))
 run(mod,[LEAN,'-j2',WORK/rel.with_suffix('.lean'),'-o',out.with_suffix('.olean'),'-i',out.with_suffix('.ilean'),'--setup',setup,'--json'])
args=[COMP/'.lake/build/bin/prod-export']
for mod in sorted(x for x in mods if x.startswith('BoundedNumeric.')):args+=['--module',mod]
for root in ['BoundedNumeric.Float.mul32','BoundedNumeric.NumericPackage.acceptance']:args+=['--root',root]
args+=['--ir-module','cs_numeric_mul32','--out',ROOT/'export']
run('extract',args)
report['artifacts']=[{'path':str(p.relative_to(WORK)),'size':p.stat().st_size,'sha256':hashfile(p)} for p in sorted(LIB.rglob('*')) if p.is_file()]
report['total_seconds']=time.monotonic()-start
report['disk_free']=shutil.disk_usage(ROOT).free
save()

import BoundedNumeric.NumericPackage
set_option pp.explicit true
#print BoundedNumeric.Wide.convertUInt32ToUInt64
#print BoundedNumeric.Wide.int16Add
#print BoundedNumeric.Wide.unsignedLess
#print BoundedNumeric.Wide.multiply
#print LexLeanRuntime.checkedFromInt
#print LexLeanRuntime.instFixedUInt64
#print LexLeanRuntime.instFixedInt16
#print axioms BoundedNumeric.NumericPackage.acceptance

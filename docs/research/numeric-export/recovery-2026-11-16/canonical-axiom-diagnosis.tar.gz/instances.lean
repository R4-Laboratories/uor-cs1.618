import BoundedNumeric.NumericPackage
#print axioms LexLeanRuntime.instFixedUInt32
#print axioms LexLeanRuntime.instFixedUInt64
#print axioms LexLeanRuntime.instFixedInt16
#print axioms LexLeanRuntime.checkedFromInt
#print axioms UInt64.ofInt
#print axioms UInt64.land
#print axioms UInt64.lor
#print axioms UInt64.xor
#print axioms UInt64.complement
#print axioms UInt64.shiftLeft
#print axioms UInt64.shiftRight
#print axioms Int16.ofInt
#print axioms Int16.toInt
#print axioms Int16.land
#print axioms Int16.shiftLeft
#print axioms Int16.shiftRight
#print axioms instBEqUInt32
#print axioms instBEqUInt64
#print UInt64.ofInt
#print UInt64.shiftLeft
#print UInt64.shiftRight

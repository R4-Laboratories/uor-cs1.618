import BoundedNumeric.NumericPackage
set_option pp.explicit true
def diagnosticEqual32 (a b : UInt32) : Bool := LexLeanRuntime.equal a b
def diagnosticEqual64 (a b : UInt64) : Bool := LexLeanRuntime.equal a b
#print axioms diagnosticEqual32
#print axioms diagnosticEqual64
#print axioms Bool.and
#print axioms BoundedNumeric.NumericPackage.acceptance
#print axioms LexLeanRuntime.instFixedUInt32
#print axioms LexLeanRuntime.instFixedUInt64
#print axioms LexLeanRuntime.instFixedInt16
#print axioms UInt64.land
#print axioms BitVec.and
#print axioms Nat.and_lt_two_pow
#print axioms Nat.lt_pow_two_of_testBit
#print axioms Nat.testBit_and
#print UInt64.land
#print BitVec.and
#print Nat.and_lt_two_pow

//! Closed constructive Nat component, selected only for empty-policy 1.2 arithmetic.
mod certificate;
mod check;
mod emit;
mod synthesize;
#[cfg(test)]
mod tests;
use crate::ir::semantic::{
    SemanticDeclaration, SemanticModule, SemanticParameter, SemanticProof, SemanticTerm,
    SemanticType,
};
use crate::{code, diagnostic::Diagnostic};
use certificate::*;
use serde::{Deserialize, Serialize};
use std::{
    collections::BTreeMap,
    time::{Duration, Instant},
};

pub(crate) struct Stage {
    started: Instant,
    timeout: Duration,
    max_bytes: usize,
    used: usize,
}
impl Stage {
    pub(crate) fn new(started: Instant, timeout_ms: u64, max_bytes: u64) -> Self {
        Self {
            started,
            timeout: Duration::from_millis(timeout_ms.min(300_000)),
            max_bytes: usize::try_from(max_bytes).unwrap_or(usize::MAX),
            used: 0,
        }
    }
    fn tick(&self) -> Result<(), String> {
        if self.started.elapsed() >= self.timeout {
            Err("cumulative constructive stage deadline".into())
        } else {
            Ok(())
        }
    }
    fn remaining(&self) -> usize {
        self.max_bytes - self.used
    }
    fn charge(&mut self, n: usize) -> Result<(), String> {
        self.tick()?;
        let next = self.used.checked_add(n).ok_or("output byte overflow")?;
        if next > self.max_bytes {
            return Err("cumulative constructive output limit".into());
        }
        self.used = next;
        Ok(())
    }
}
fn diagnostic(reason: String) -> Diagnostic {
    Diagnostic::new(
        code!("LLB6008"),
        format!("constructive-nat-v1 refused: {reason}"),
    )
}
fn input(parameters: &[SemanticParameter], statement: &SemanticTerm) -> Result<Input, String> {
    if parameters.len() > PARAMETERS {
        return Err("parameter cap".into());
    }
    if parameters.iter().any(|p| p.r#type != SemanticType::Nat) {
        return Err("only Nat parameters are supported".into());
    }
    let mut names = BTreeMap::new();
    for (i, p) in parameters.iter().enumerate() {
        if names.insert(p.name.as_str(), i).is_some() {
            return Err("duplicate binder".into());
        }
    }
    let mut arena = Arena::default();
    let mut count = 0;
    fn charge(n: &mut usize) -> Result<(), String> {
        if *n >= INPUT_NODES {
            return Err("input term node cap".into());
        }
        *n += 1;
        Ok(())
    }
    fn term(
        t: &SemanticTerm,
        names: &BTreeMap<&str, usize>,
        a: &mut Arena,
        n: &mut usize,
    ) -> Result<usize, String> {
        charge(n)?;
        match t {
            SemanticTerm::Var { name } => a.intern(Term::Var {
                index: *names.get(name.as_str()).ok_or("unbound variable")?,
            }),
            SemanticTerm::Nat { value } => a.intern(Term::Literal {
                value: Nat::parse(value)?,
            }),
            SemanticTerm::Add { left, right } => {
                let l = term(left, names, a, n)?;
                let r = term(right, names, a, n)?;
                a.add(l, r)
            }
            _ => Err("unsupported Nat additive term".into()),
        }
    }
    fn atom(
        t: &SemanticTerm,
        names: &BTreeMap<&str, usize>,
        a: &mut Arena,
        n: &mut usize,
    ) -> Result<Atom, String> {
        charge(n)?;
        let (relation, left, right) = match t {
            SemanticTerm::Le { left, right } => (Relation::Le, left, right),
            SemanticTerm::Lt { left, right } => (Relation::Lt, left, right),
            SemanticTerm::Eq { left, right } => (Relation::Eq, left, right),
            _ => return Err("unsupported atomic proposition".into()),
        };
        Ok(Atom::new(
            relation,
            term(left, names, a, n)?,
            term(right, names, a, n)?,
        ))
    }
    let mut hypotheses = Vec::new();
    let mut current = statement;
    while let SemanticTerm::Implies {
        premise,
        conclusion,
    } = current
    {
        charge(&mut count)?;
        if hypotheses.len() >= HYPOTHESES {
            return Err("hypothesis cap".into());
        }
        hypotheses.push(atom(premise, &names, &mut arena, &mut count)?);
        current = conclusion;
    }
    let goal = atom(current, &names, &mut arena, &mut count)?;
    Ok(Input {
        binders: parameters.iter().map(|p| p.name.clone()).collect(),
        terms: arena.terms,
        hypotheses,
        goal,
    })
}
// Serialize through the original restricted canonical JSON without changing its
// i64 integer contract. Nat128 values have their separate canonical string type.
#[cfg(test)]
thread_local! {
    static OUTPUT_OBSERVATIONS: std::cell::RefCell<Option<Vec<(&'static str, usize)>>> = const { std::cell::RefCell::new(None) };
}
#[cfg(test)]
fn observe_output(kind: &'static str, len: usize) {
    OUTPUT_OBSERVATIONS.with_borrow_mut(|events| {
        if let Some(events) = events {
            events.push((kind, len));
        }
    });
}
#[derive(Debug)]
enum CanonicalFailure {
    Budget,
    Invalid(String),
}
impl From<CanonicalFailure> for String {
    fn from(failure: CanonicalFailure) -> Self {
        match failure {
            CanonicalFailure::Budget => "canonical certificate byte limit".into(),
            CanonicalFailure::Invalid(reason) => reason,
        }
    }
}
struct ByteWriter {
    bytes: Vec<u8>,
    limit: usize,
    exhausted: bool,
}
impl std::io::Write for ByteWriter {
    fn write(&mut self, bytes: &[u8]) -> std::io::Result<usize> {
        if self
            .bytes
            .len()
            .checked_add(bytes.len())
            .is_none_or(|n| n > self.limit)
        {
            self.exhausted = true;
            return Err(std::io::Error::other(
                "certificate serialization byte limit",
            ));
        }
        self.bytes.extend_from_slice(bytes);
        #[cfg(test)]
        observe_output("canonical", self.bytes.len());
        Ok(bytes.len())
    }
    fn flush(&mut self) -> std::io::Result<()> {
        Ok(())
    }
}
// Serialize the original restricted Json value directly into a bounded writer.
// Its BTreeMap supplies the exact canonical key order; serde_json emits the same
// minimal UTF-8/string escapes and i64 representation as the original Json writer.
// No unbounded canonical String/file Vec is constructed before checking its size.
struct CanonicalJson<'a>(&'a crate::artifact::canonical_json::Json);
impl Serialize for CanonicalJson<'_> {
    fn serialize<S: serde::Serializer>(&self, serializer: S) -> Result<S::Ok, S::Error> {
        use crate::artifact::canonical_json::Json;
        use serde::ser::{SerializeMap, SerializeSeq};
        match self.0 {
            Json::Bool(value) => serializer.serialize_bool(*value),
            Json::Int(value) => serializer.serialize_i64(*value),
            Json::Str(value) => serializer.serialize_str(value),
            Json::Arr(items) => {
                let mut seq = serializer.serialize_seq(Some(items.len()))?;
                for item in items {
                    seq.serialize_element(&CanonicalJson(item))?;
                }
                seq.end()
            }
            Json::Obj(items) => {
                let mut map = serializer.serialize_map(Some(items.len()))?;
                for (key, value) in items {
                    map.serialize_entry(key, &CanonicalJson(value))?;
                }
                map.end()
            }
        }
    }
}
fn canonical<T: Serialize>(value: &T, limit: usize) -> Result<Vec<u8>, CanonicalFailure> {
    use std::io::Write;
    // Reserve the file LF before even the first serialization pass.
    let body_limit = limit.checked_sub(1).ok_or(CanonicalFailure::Budget)?;
    let mut writer = ByteWriter {
        bytes: Vec::new(),
        limit: body_limit,
        exhausted: false,
    };
    serde_json::to_writer(&mut writer, value).map_err(|error| {
        if writer.exhausted {
            CanonicalFailure::Budget
        } else {
            CanonicalFailure::Invalid(error.to_string())
        }
    })?;
    let json = crate::artifact::canonical_json::Json::parse(&writer.bytes)
        .map_err(CanonicalFailure::Invalid)?;
    // Reuse the allocation while keeping both passes bounded before each append.
    writer.bytes.clear();
    serde_json::to_writer(&mut writer, &CanonicalJson(&json)).map_err(|error| {
        if writer.exhausted {
            CanonicalFailure::Budget
        } else {
            CanonicalFailure::Invalid(error.to_string())
        }
    })?;
    writer.limit = limit;
    writer
        .write_all(b"\n")
        .map_err(|_| CanonicalFailure::Budget)?;
    Ok(writer.bytes)
}

fn compile_checked(
    parameters: &[SemanticParameter],
    statement: &SemanticTerm,
    stage: &mut Stage,
) -> Result<(Certificate, String), String> {
    stage.tick()?;
    let input = input(parameters, statement)?;
    let certificate = synthesize::synthesize(&input, stage)?;
    let remaining = stage.remaining();
    let bytes = canonical(&certificate, remaining)?;
    stage.charge(bytes.len())?;
    let decoded: Certificate = serde_json::from_slice(&bytes).map_err(|e| e.to_string())?;
    let checked = check::check(&input, &decoded, stage)?;
    let proof = emit::emit(&checked, stage)?;
    stage.charge(proof.len())?;
    Ok((decoded, proof))
}
#[cfg(test)]
fn compile(parameters: &[SemanticParameter], statement: &SemanticTerm) -> Result<String, String> {
    compile_checked(
        parameters,
        statement,
        &mut Stage::new(Instant::now(), 300_000, 67_108_864),
    )
    .map(|(_, p)| p)
}

#[derive(Serialize, Deserialize, Debug, Clone, PartialEq, Eq)]
#[serde(deny_unknown_fields)]
pub(crate) struct Row {
    module: String,
    theorem: String,
    source_sha256: String,
    parameters: Vec<SemanticParameter>,
    statement: SemanticTerm,
    certificate: Certificate,
}
#[derive(Serialize, Deserialize, Debug, Clone, PartialEq, Eq)]
#[serde(deny_unknown_fields)]
struct Artifact {
    spec: String,
    rule_version: String,
    compiler_version: String,
    compiler_semantics_id: String,
    source_id: String,
    semantic_id: String,
    rows: Vec<Row>,
}
#[derive(Default)]
pub(crate) struct Plan {
    proofs: BTreeMap<String, String>,
    rows: Vec<Row>,
}
impl Plan {
    pub(crate) fn proof(&self, name: &str) -> Option<&str> {
        self.proofs.get(name).map(String::as_str)
    }
    pub(crate) fn rows(self) -> Vec<Row> {
        self.rows
    }
}
pub(crate) fn selected(module: &SemanticModule, declaration: &SemanticDeclaration) -> bool {
    module.spec == "lexlean/semantic-module/2"
        && matches!(declaration,SemanticDeclaration::Theorem{axioms,proof:SemanticProof::LinearArithmetic{..},..} if axioms.is_empty())
}
pub(crate) fn plan(
    module_name: &str,
    source_sha256: &str,
    module: &SemanticModule,
    stage: &mut Stage,
) -> Result<Plan, Diagnostic> {
    let mut plan = Plan::default();
    for declaration in module.lowered_declarations() {
        if !selected(module, declaration) {
            continue;
        }
        if let SemanticDeclaration::Theorem {
            name,
            type_parameters,
            parameters,
            statement,
            proof: SemanticProof::LinearArithmetic { definitions },
            ..
        } = declaration
        {
            if !type_parameters.is_empty() || !definitions.is_empty() {
                return Err(diagnostic(
                    "type parameters and definition unfolding are unsupported".into(),
                ));
            }
            let (certificate, proof) =
                compile_checked(parameters, statement, stage).map_err(diagnostic)?;
            if plan.proofs.insert(name.clone(), proof).is_some() {
                return Err(diagnostic("duplicate selected theorem".into()));
            }
            plan.rows.push(Row {
                module: module_name.into(),
                theorem: name.clone(),
                source_sha256: source_sha256.into(),
                parameters: parameters.clone(),
                statement: statement.clone(),
                certificate,
            });
        }
    }
    Ok(plan)
}
pub(crate) fn project_allowance(max_bytes: u64, report_total: u64) -> Result<usize, Diagnostic> {
    let remaining = max_bytes
        .checked_sub(report_total)
        .ok_or_else(project_budget_diagnostic)?;
    Ok(usize::try_from(remaining).unwrap_or(usize::MAX))
}
fn project_budget_diagnostic() -> Diagnostic {
    Diagnostic::new(
        code!("LLS8002"),
        "constructive certificate exceeds cumulative output budget",
    )
}
pub(crate) fn artifact(
    rows: Vec<Row>,
    source_id: String,
    semantic_id: String,
    project_remaining: usize,
    stage: &mut Stage,
) -> Result<Vec<u8>, Diagnostic> {
    let artifact = Artifact {
        spec: "lexlean/constructive-nat-certificate/1".into(),
        rule_version: "constructive-nat-v1".into(),
        compiler_version: crate::COMPILER_VERSION.into(),
        compiler_semantics_id: crate::compiler_semantics_id_for("1.2").to_hex(),
        source_id,
        semantic_id,
        rows,
    };
    let stage_remaining = stage.remaining();
    let bytes =
        canonical(&artifact, stage_remaining.min(project_remaining)).map_err(|failure| {
            match failure {
                CanonicalFailure::Budget if project_remaining <= stage_remaining => {
                    project_budget_diagnostic()
                }
                other => diagnostic(other.into()),
            }
        })?;
    // Decode the complete fixed artifact and require exact row membership/identity
    // before publication, then check every decoded DAG against original input.
    verify_artifact(&bytes, &artifact, stage).map_err(diagnostic)?;
    stage.charge(bytes.len()).map_err(diagnostic)?;
    Ok(bytes)
}
fn verify_artifact(bytes: &[u8], expected: &Artifact, stage: &Stage) -> Result<(), String> {
    stage.tick()?;
    if bytes.len() > stage.max_bytes {
        return Err("artifact byte cap".into());
    }
    let parsed: Artifact = serde_json::from_slice(bytes).map_err(|e| e.to_string())?;
    if parsed != *expected {
        return Err("artifact binding or missing/extra/duplicate row".into());
    }
    let mut keys = std::collections::BTreeSet::new();
    for row in &parsed.rows {
        if !keys.insert((&row.module, &row.theorem)) {
            return Err("duplicate theorem row".into());
        }
        let input = input(&row.parameters, &row.statement)?;
        check::check(&input, &row.certificate, stage)?;
    }
    Ok(())
}

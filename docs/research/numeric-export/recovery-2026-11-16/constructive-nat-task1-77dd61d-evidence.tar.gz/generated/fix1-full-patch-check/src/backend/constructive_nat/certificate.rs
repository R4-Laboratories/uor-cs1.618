//! Closed, bounded wire representation. No executable payload or lemma name.
use serde::{Deserialize, Deserializer, Serialize, Serializer};
use std::{
    collections::BTreeMap,
    fmt,
    ops::{Deref, DerefMut},
};

pub(super) const PARAMETERS: usize = 32;
pub(super) const HYPOTHESES: usize = 64;
pub(super) const INPUT_NODES: usize = 1024;
pub(super) const COEFFICIENT: u16 = 4096;
pub(super) const LEAVES: usize = 4096;
pub(super) const SCALE: usize = 16;
pub(super) const CANDIDATES: usize = 8192;
pub(super) const NODES: usize = 16384;
pub(super) const PROOF_BYTES: usize = 1048576;

/// A vector whose wire decoder checks length before decoding/allocating its next member.
#[derive(Debug, Clone, PartialEq, Eq, Serialize)]
#[serde(transparent)]
pub(super) struct Bounded<T, const N: usize>(pub Vec<T>);
impl<T, const N: usize> Default for Bounded<T, N> {
    fn default() -> Self {
        Self(Vec::new())
    }
}
impl<T, const N: usize> Deref for Bounded<T, N> {
    type Target = Vec<T>;
    fn deref(&self) -> &Self::Target {
        &self.0
    }
}
impl<T, const N: usize> DerefMut for Bounded<T, N> {
    fn deref_mut(&mut self) -> &mut Self::Target {
        &mut self.0
    }
}
impl<'de, T: Deserialize<'de>, const N: usize> Deserialize<'de> for Bounded<T, N> {
    fn deserialize<D: Deserializer<'de>>(d: D) -> Result<Self, D::Error> {
        struct Visitor<T, const N: usize>(std::marker::PhantomData<T>);
        impl<'de, T: Deserialize<'de>, const N: usize> serde::de::Visitor<'de> for Visitor<T, N> {
            type Value = Bounded<T, N>;
            fn expecting(&self, f: &mut fmt::Formatter) -> fmt::Result {
                write!(f, "at most {N} entries")
            }
            fn visit_seq<A: serde::de::SeqAccess<'de>>(
                self,
                mut a: A,
            ) -> Result<Self::Value, A::Error> {
                let mut out = Vec::new();
                while out.len() < N {
                    match a.next_element()? {
                        Some(x) => out.push(x),
                        None => return Ok(Bounded(out)),
                    }
                }
                if a.next_element::<serde::de::IgnoredAny>()?.is_some() {
                    return Err(serde::de::Error::custom("constructive sequence cap"));
                }
                Ok(Bounded(out))
            }
        }
        d.deserialize_seq(Visitor::<T, N>(std::marker::PhantomData))
    }
}

#[derive(Debug, Copy, Clone, PartialEq, Eq, PartialOrd, Ord)]
pub(super) struct Nat(pub u128);
impl Serialize for Nat {
    fn serialize<S: Serializer>(&self, s: S) -> Result<S::Ok, S::Error> {
        s.serialize_str(&self.0.to_string())
    }
}
impl<'de> Deserialize<'de> for Nat {
    fn deserialize<D: Deserializer<'de>>(d: D) -> Result<Self, D::Error> {
        struct NatVisitor;
        impl serde::de::Visitor<'_> for NatVisitor {
            type Value = Nat;
            fn expecting(&self, f: &mut fmt::Formatter) -> fmt::Result {
                f.write_str("a canonical unsigned Nat128 decimal string")
            }
            fn visit_str<E: serde::de::Error>(self, s: &str) -> Result<Nat, E> {
                Nat::parse(s).map_err(E::custom)
            }
        }
        d.deserialize_str(NatVisitor)
    }
}
impl Nat {
    pub(super) fn parse(s: &str) -> Result<Self, String> {
        if s.is_empty()
            || s.len() > 39
            || !s.bytes().all(|b| b.is_ascii_digit())
            || (s.len() > 1 && s.starts_with('0'))
        {
            return Err("noncanonical Nat128".into());
        }
        s.parse().map(Self).map_err(|_| "Nat128 overflow".into())
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub(super) struct Form {
    pub coefficients: [u16; PARAMETERS],
    pub constant: Nat,
}
impl Form {
    pub(super) fn literal(n: Nat) -> Self {
        Self {
            coefficients: [0; PARAMETERS],
            constant: n,
        }
    }
    pub(super) fn variable(i: usize) -> Result<Self, String> {
        if i >= PARAMETERS {
            return Err("parameter scope".into());
        }
        let mut f = Self::literal(Nat(0));
        f.coefficients[i] = 1;
        Ok(f)
    }
    pub(super) fn add(&self, b: &Self) -> Result<Self, String> {
        let mut out = Self::literal(Nat(self
            .constant
            .0
            .checked_add(b.constant.0)
            .ok_or("Nat128 addition overflow")?));
        for (i, (&a, &b)) in self.coefficients.iter().zip(&b.coefficients).enumerate() {
            out.coefficients[i] = a
                .checked_add(b)
                .filter(|x| *x <= COEFFICIENT)
                .ok_or("coefficient cap")?;
        }
        out.validate(PARAMETERS)?;
        Ok(out)
    }
    pub(super) fn validate(&self, scope: usize) -> Result<(), String> {
        if scope > PARAMETERS
            || self.coefficients.iter().any(|&x| x > COEFFICIENT)
            || self.coefficients[scope..].iter().any(|&x| x != 0)
        {
            return Err("coefficient/scope cap".into());
        }
        // A canonical expression has exactly one final constant, including zero.
        if self
            .coefficients
            .iter()
            .map(|&x| usize::from(x))
            .sum::<usize>()
            .checked_add(1)
            .ok_or("leaf overflow")?
            > LEAVES
        {
            return Err("canonical leaf cap".into());
        }
        Ok(())
    }
}
#[derive(Debug, Clone, PartialEq, Eq, PartialOrd, Ord, Serialize, Deserialize)]
#[serde(tag = "kind", rename_all = "snake_case", deny_unknown_fields)]
pub(super) enum Term {
    Var { index: usize },
    Literal { value: Nat },
    Add { left: usize, right: usize },
}
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub(super) struct TermRow {
    pub term: Term,
    pub normal: Form,
}
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub(super) enum Relation {
    Le,
    Lt,
    Eq,
}
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub(super) struct Atom {
    pub relation: Relation,
    pub left: usize,
    pub right: usize,
}
impl Atom {
    pub(super) fn new(relation: Relation, left: usize, right: usize) -> Self {
        Self {
            relation,
            left,
            right,
        }
    }
}
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub(super) enum Side {
    Left,
    Right,
}
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(tag = "kind", rename_all = "snake_case", deny_unknown_fields)]
pub(super) enum Normalization {
    Assoc { a: usize, b: usize, c: usize },
    Comm { a: usize, b: usize },
    ZeroLeft { a: usize },
    ZeroRight { a: usize },
    LiteralAdd { a: usize, b: usize },
    CongrAdd { left: usize, right: usize },
}
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(tag = "rule", rename_all = "snake_case", deny_unknown_fields)]
pub(super) enum Op {
    Hyp {
        index: usize,
    },
    ReflLe {
        term: usize,
    },
    ReflEq {
        term: usize,
    },
    LiteralLe {
        left: usize,
        right: usize,
    },
    WeakenLt {
        input: usize,
    },
    TransLe {
        left: usize,
        right: usize,
    },
    AddLe {
        left: usize,
        right: usize,
    },
    AddLtLe {
        left: usize,
        right: usize,
    },
    EqSymm {
        input: usize,
    },
    EqTrans {
        left: usize,
        right: usize,
    },
    NormalizeEq {
        step: Normalization,
    },
    RewriteSide {
        input: usize,
        equality: usize,
        side: Side,
    },
    CancelLt {
        input: usize,
    },
}
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub(super) struct Node {
    pub op: Op,
    pub conclusion: Atom,
}
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub(super) struct Certificate {
    pub terms: Bounded<TermRow, NODES>,
    pub nodes: Bounded<Node, NODES>,
    pub final_node: usize,
}
#[derive(Debug, Clone)]
pub(super) struct Input {
    pub binders: Vec<String>,
    pub terms: Vec<TermRow>,
    pub hypotheses: Vec<Atom>,
    pub goal: Atom,
}
#[derive(Default)]
pub(super) struct Arena {
    pub terms: Vec<TermRow>,
    pub index: BTreeMap<Term, usize>,
}
impl Arena {
    pub(super) fn from_rows(rows: &[TermRow]) -> Self {
        Self {
            terms: rows.to_vec(),
            index: rows
                .iter()
                .enumerate()
                .map(|(i, r)| (r.term.clone(), i))
                .collect(),
        }
    }
    pub(super) fn intern(&mut self, term: Term) -> Result<usize, String> {
        if let Some(i) = self.index.get(&term) {
            return Ok(*i);
        }
        if self.terms.len() >= NODES {
            return Err("term arena cap".into());
        }
        let normal = match term {
            Term::Var { index } => Form::variable(index)?,
            Term::Literal { value } => Form::literal(value),
            Term::Add { left, right } => self
                .terms
                .get(left)
                .ok_or("term scope")?
                .normal
                .add(&self.terms.get(right).ok_or("term scope")?.normal)?,
        };
        let i = self.terms.len();
        self.index.insert(term.clone(), i);
        self.terms.push(TermRow { term, normal });
        Ok(i)
    }
    pub(super) fn add(&mut self, a: usize, b: usize) -> Result<usize, String> {
        self.intern(Term::Add { left: a, right: b })
    }
    pub(super) fn lit(&mut self, n: u128) -> Result<usize, String> {
        self.intern(Term::Literal { value: Nat(n) })
    }
    pub(super) fn canonical(&mut self, f: &Form) -> Result<usize, String> {
        f.validate(PARAMETERS)?;
        let mut t = self.lit(f.constant.0)?;
        for i in (0..PARAMETERS).rev() {
            for _ in 0..f.coefficients[i] {
                let v = self.intern(Term::Var { index: i })?;
                t = self.add(v, t)?;
            }
        }
        Ok(t)
    }
}

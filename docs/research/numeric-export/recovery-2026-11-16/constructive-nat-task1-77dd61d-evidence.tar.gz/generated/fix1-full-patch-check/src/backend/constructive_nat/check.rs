//! Independent rule interpreter: synthesizer claims are never trusted.
use super::{certificate::*, Stage};
use std::collections::BTreeMap;

pub(super) struct Checked<'a> {
    certificate: &'a Certificate,
    input: &'a Input,
}
impl<'a> Checked<'a> {
    pub(super) fn certificate(&self) -> &Certificate {
        self.certificate
    }
    pub(super) fn input(&self) -> &Input {
        self.input
    }
}

pub(super) fn check<'a>(
    input: &'a Input,
    c: &'a Certificate,
    stage: &Stage,
) -> Result<Checked<'a>, String> {
    stage.tick()?;
    if input.binders.len() > PARAMETERS
        || input.hypotheses.len() > HYPOTHESES
        || c.terms.len() > NODES
        || c.nodes.len() > NODES
        || c.nodes.is_empty()
    {
        return Err("certificate cap".into());
    }
    let mut index = BTreeMap::new();
    for (i, row) in c.terms.iter().enumerate() {
        stage.tick()?;
        let expected = match row.term {
            Term::Var { index } if index < input.binders.len() => Form::variable(index)?,
            Term::Literal { value } => Form::literal(value),
            Term::Add { left, right } if left < i && right < i => {
                c.terms[left].normal.add(&c.terms[right].normal)?
            }
            _ => return Err("forward term or binder scope".into()),
        };
        row.normal.validate(input.binders.len())?;
        if row.normal != expected || index.insert(row.term.clone(), i).is_some() {
            return Err("noncanonical term arena or false normalization".into());
        }
    }
    if c.terms.get(..input.terms.len()) != Some(input.terms.as_slice()) {
        return Err("original source/binder identity mismatch".into());
    }
    for (i, node) in c.nodes.iter().enumerate() {
        stage.tick()?;
        let actual = conclusion(&c.terms, &index, &input.hypotheses, &c.nodes[..i], &node.op)?;
        if actual != node.conclusion {
            return Err(format!("incorrect conclusion at node {i}"));
        }
    }
    if c.final_node >= c.nodes.len() || c.nodes[c.final_node].conclusion != input.goal {
        return Err("certificate does not prove original goal".into());
    }
    Ok(Checked {
        certificate: c,
        input,
    })
}

// This interpreter uses only earlier checked conclusions and exact term identities.
// In particular no normalization equality is inferred merely from equal vectors.
pub(super) fn conclusion(
    terms: &[TermRow],
    index: &BTreeMap<Term, usize>,
    hypotheses: &[Atom],
    prior: &[Node],
    op: &Op,
) -> Result<Atom, String> {
    let term = |i: usize| terms.get(i).ok_or_else(|| "term scope".to_owned());
    let premise = |i: usize, r: Relation| -> Result<Atom, String> {
        let a = prior.get(i).ok_or("forward/cyclic premise")?.conclusion;
        if a.relation != r {
            return Err("premise relation/strictness".into());
        }
        Ok(a)
    };
    let known = |t: Term| {
        index
            .get(&t)
            .copied()
            .ok_or_else(|| "missing conclusion term".to_owned())
    };
    let add = |a, b| known(Term::Add { left: a, right: b });
    let literal = |i| -> Result<Nat, String> {
        match term(i)?.term {
            Term::Literal { value } => Ok(value),
            _ => Err("expected literal".into()),
        }
    };
    let eq = |a, b| Atom::new(Relation::Eq, a, b);
    Ok(match op {
        Op::Hyp { index } => *hypotheses.get(*index).ok_or("hypothesis identity")?,
        Op::ReflLe { term: t } => {
            term(*t)?;
            Atom::new(Relation::Le, *t, *t)
        }
        Op::ReflEq { term: t } => {
            term(*t)?;
            eq(*t, *t)
        }
        Op::LiteralLe { left, right } => {
            if literal(*left)?.0 > literal(*right)?.0 {
                return Err("false literal inequality".into());
            }
            Atom::new(Relation::Le, *left, *right)
        }
        Op::WeakenLt { input } => {
            let a = premise(*input, Relation::Lt)?;
            Atom::new(Relation::Le, a.left, a.right)
        }
        Op::TransLe { left, right } | Op::EqTrans { left, right } => {
            let r = if matches!(op, Op::TransLe { .. }) {
                Relation::Le
            } else {
                Relation::Eq
            };
            let a = premise(*left, r)?;
            let b = premise(*right, r)?;
            if a.right != b.left {
                return Err("transitivity middle mismatch".into());
            }
            Atom::new(r, a.left, b.right)
        }
        Op::AddLe { left, right } | Op::AddLtLe { left, right } => {
            let r = if matches!(op, Op::AddLe { .. }) {
                Relation::Le
            } else {
                Relation::Lt
            };
            let a = premise(*left, r)?;
            let b = premise(*right, Relation::Le)?;
            Atom::new(r, add(a.left, b.left)?, add(a.right, b.right)?)
        }
        Op::EqSymm { input } => {
            let a = premise(*input, Relation::Eq)?;
            eq(a.right, a.left)
        }
        Op::NormalizeEq { step } => match *step {
            Normalization::Assoc { a, b, c } => eq(add(add(a, b)?, c)?, add(a, add(b, c)?)?),
            Normalization::Comm { a, b } => eq(add(a, b)?, add(b, a)?),
            Normalization::ZeroLeft { a } => {
                term(a)?;
                eq(add(known(Term::Literal { value: Nat(0) })?, a)?, a)
            }
            Normalization::ZeroRight { a } => {
                term(a)?;
                eq(add(a, known(Term::Literal { value: Nat(0) })?)?, a)
            }
            Normalization::LiteralAdd { a, b } => {
                let s = literal(a)?
                    .0
                    .checked_add(literal(b)?.0)
                    .ok_or("Nat128 overflow")?;
                eq(add(a, b)?, known(Term::Literal { value: Nat(s) })?)
            }
            Normalization::CongrAdd { left, right } => {
                let a = premise(left, Relation::Eq)?;
                let b = premise(right, Relation::Eq)?;
                eq(add(a.left, b.left)?, add(a.right, b.right)?)
            }
        },
        Op::RewriteSide {
            input,
            equality,
            side,
        } => {
            let a = prior.get(*input).ok_or("forward relation")?.conclusion;
            let e = premise(*equality, Relation::Eq)?;
            match side {
                Side::Left if a.left == e.left => Atom::new(a.relation, e.right, a.right),
                Side::Right if a.right == e.left => Atom::new(a.relation, a.left, e.right),
                _ => return Err("whole-side equality mismatch".into()),
            }
        }
        Op::CancelLt { input } => {
            let a = premise(*input, Relation::Lt)?;
            match (&term(a.left)?.term, &term(a.right)?.term) {
                (Term::Add { left: a, right: c }, Term::Add { left: b, right: d }) if c == d => {
                    Atom::new(Relation::Lt, *a, *b)
                }
                _ => return Err("cancellation common summand mismatch".into()),
            }
        }
    })
}

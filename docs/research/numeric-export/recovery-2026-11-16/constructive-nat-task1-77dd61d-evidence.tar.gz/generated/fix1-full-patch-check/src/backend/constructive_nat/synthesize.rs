//! Two finite recipes, with no saturation, guessed substitution, or fallback.
use super::{certificate::*, check, Stage};
use std::collections::{BTreeMap, VecDeque};

struct Builder<'a> {
    input: &'a Input,
    stage: &'a Stage,
    arena: Arena,
    nodes: Vec<Node>,
    normalized: BTreeMap<usize, usize>,
}
impl<'a> Builder<'a> {
    fn new(input: &'a Input, stage: &'a Stage) -> Self {
        Self {
            input,
            stage,
            arena: Arena::from_rows(&input.terms),
            nodes: Vec::new(),
            normalized: BTreeMap::new(),
        }
    }
    fn push(&mut self, op: Op) -> Result<usize, String> {
        self.stage.tick()?;
        if self.nodes.len() >= NODES {
            return Err("certificate node cap".into());
        }
        let conclusion = check::conclusion(
            &self.arena.terms,
            &self.arena.index,
            &self.input.hypotheses,
            &self.nodes,
            &op,
        )?;
        let i = self.nodes.len();
        self.nodes.push(Node { op, conclusion });
        Ok(i)
    }
    fn atom(&self, p: usize) -> Atom {
        self.nodes[p].conclusion
    }
    fn refl(&mut self, t: usize) -> Result<usize, String> {
        self.push(Op::ReflEq { term: t })
    }
    fn sym(&mut self, p: usize) -> Result<usize, String> {
        self.push(Op::EqSymm { input: p })
    }
    fn trans(&mut self, p: usize, q: usize) -> Result<usize, String> {
        self.push(Op::EqTrans { left: p, right: q })
    }
    fn congr(&mut self, p: usize, q: usize) -> Result<usize, String> {
        let a = self.atom(p);
        let b = self.atom(q);
        self.arena.add(a.left, b.left)?;
        self.arena.add(a.right, b.right)?;
        self.push(Op::NormalizeEq {
            step: Normalization::CongrAdd { left: p, right: q },
        })
    }
    fn assoc(&mut self, a: usize, b: usize, c: usize) -> Result<usize, String> {
        let ab = self.arena.add(a, b)?;
        self.arena.add(ab, c)?;
        let bc = self.arena.add(b, c)?;
        self.arena.add(a, bc)?;
        self.push(Op::NormalizeEq {
            step: Normalization::Assoc { a, b, c },
        })
    }
    fn comm(&mut self, a: usize, b: usize) -> Result<usize, String> {
        self.arena.add(a, b)?;
        self.arena.add(b, a)?;
        self.push(Op::NormalizeEq {
            step: Normalization::Comm { a, b },
        })
    }
    fn left_comm(&mut self, a: usize, b: usize, c: usize) -> Result<usize, String> {
        let assoc = self.assoc(a, b, c)?;
        let first = self.sym(assoc)?;
        let comm = self.comm(a, b)?;
        let rc = self.refl(c)?;
        let second = self.congr(comm, rc)?;
        let third = self.assoc(b, a, c)?;
        let p = self.trans(first, second)?;
        self.trans(p, third)
    }
    // Merge two canonical sorted additive lists. The explicit stack is bounded by
    // the already checked leaf count; no recursion follows the expanded list.
    fn merge(&mut self, mut a: usize, mut b: usize) -> Result<usize, String> {
        self.arena.terms[a]
            .normal
            .add(&self.arena.terms[b].normal)?;
        let mut frames = Vec::new();
        let mut proof;
        loop {
            self.stage.tick()?;
            match (
                self.arena.terms[a].term.clone(),
                self.arena.terms[b].term.clone(),
            ) {
                (Term::Literal { value: x }, Term::Literal { value: y }) => {
                    self.arena.add(a, b)?;
                    self.arena
                        .lit(x.0.checked_add(y.0).ok_or("Nat128 overflow")?)?;
                    proof = self.push(Op::NormalizeEq {
                        step: Normalization::LiteralAdd { a, b },
                    })?;
                    break;
                }
                (Term::Add { left: v, right: t }, rb)
                    if matches!(rb, Term::Literal { .. })
                        || matches!(rb,Term::Add{left:w,..} if self.variable(v)?<=self.variable(w)?) =>
                {
                    if frames.len() >= LEAVES {
                        return Err("merge leaf cap".into());
                    }
                    let p = self.assoc(v, t, b)?;
                    frames.push((p, v));
                    a = t;
                }
                (_, Term::Add { left: v, right: t }) => {
                    if frames.len() >= LEAVES {
                        return Err("merge leaf cap".into());
                    }
                    let p = self.left_comm(a, v, t)?;
                    frames.push((p, v));
                    b = t;
                }
                _ => return Err("internal noncanonical merge operand".into()),
            }
        }
        while let Some((prefix, v)) = frames.pop() {
            let r = self.refl(v)?;
            let suffix = self.congr(r, proof)?;
            proof = self.trans(prefix, suffix)?;
        }
        Ok(proof)
    }
    fn variable(&self, t: usize) -> Result<usize, String> {
        match self.arena.terms[t].term {
            Term::Var { index } => Ok(index),
            _ => Err("expected canonical variable".into()),
        }
    }
    fn normalize(&mut self, t: usize) -> Result<usize, String> {
        let mut stack = vec![(t, false)];
        while let Some((id, ready)) = stack.pop() {
            self.stage.tick()?;
            if self.normalized.contains_key(&id) {
                continue;
            }
            match self.arena.terms[id].term.clone() {
                Term::Literal { .. } => {
                    let p = self.refl(id)?;
                    self.normalized.insert(id, p);
                }
                Term::Var { .. } => {
                    let z = self.arena.lit(0)?;
                    self.arena.add(id, z)?;
                    let p = self.push(Op::NormalizeEq {
                        step: Normalization::ZeroRight { a: id },
                    })?;
                    let p = self.sym(p)?;
                    self.normalized.insert(id, p);
                }
                Term::Add { left, right } if !ready => {
                    if stack
                        .len()
                        .checked_add(3)
                        .ok_or("normalization stack overflow")?
                        > NODES
                    {
                        return Err("normalization stack cap".into());
                    }
                    stack.extend([(id, true), (right, false), (left, false)]);
                }
                Term::Add { left, right } => {
                    let l = self.normalized[&left];
                    let r = self.normalized[&right];
                    let p = self.congr(l, r)?;
                    let q = self.merge(self.atom(l).right, self.atom(r).right)?;
                    let result = self.trans(p, q)?;
                    self.normalized.insert(id, result);
                }
            }
        }
        Ok(self.normalized[&t])
    }
    fn equal(&mut self, a: usize, b: usize) -> Result<usize, String> {
        if self.arena.terms[a].normal != self.arena.terms[b].normal {
            return Err("different normal forms".into());
        }
        if a == b {
            return self.refl(a);
        }
        let x = self.normalize(a)?;
        let y = self.normalize(b)?;
        let y = self.sym(y)?;
        self.trans(x, y)
    }
    fn rewrite_to(&mut self, mut p: usize, left: usize, right: usize) -> Result<usize, String> {
        let a = self.atom(p);
        if a.left != left {
            let e = self.equal(a.left, left)?;
            p = self.push(Op::RewriteSide {
                input: p,
                equality: e,
                side: Side::Left,
            })?;
        }
        let a = self.atom(p);
        if a.right != right {
            let e = self.equal(a.right, right)?;
            p = self.push(Op::RewriteSide {
                input: p,
                equality: e,
                side: Side::Right,
            })?;
        }
        Ok(p)
    }
    fn normal_relation(&mut self, p: usize) -> Result<usize, String> {
        let a = self.atom(p);
        let l = self
            .arena
            .canonical(&self.arena.terms[a.left].normal.clone())?;
        let r = self
            .arena
            .canonical(&self.arena.terms[a.right].normal.clone())?;
        self.rewrite_to(p, l, r)
    }
    fn add_rel(&mut self, p: usize, q: usize, strict: bool) -> Result<usize, String> {
        let a = self.atom(p);
        let b = self.atom(q);
        self.arena.add(a.left, b.left)?;
        self.arena.add(a.right, b.right)?;
        self.push(if strict {
            Op::AddLtLe { left: p, right: q }
        } else {
            Op::AddLe { left: p, right: q }
        })
    }
    fn finish(self, final_node: usize) -> Certificate {
        Certificate {
            terms: Bounded(self.arena.terms),
            nodes: Bounded(self.nodes),
            final_node,
        }
    }
}
fn single(f: &Form) -> Option<usize> {
    if f.constant.0 != 0 {
        return None;
    }
    let mut found = None;
    for (i, &n) in f.coefficients.iter().enumerate() {
        if n == 1 && found.is_none() {
            found = Some(i)
        } else if n != 0 {
            return None;
        }
    }
    found
}
fn closed(f: &Form) -> Option<u128> {
    f.coefficients
        .iter()
        .all(|&x| x == 0)
        .then_some(f.constant.0)
}

fn path(input: &Input, start: usize, stage: &Stage) -> Result<Vec<usize>, String> {
    // Enqueue neighbors in source order; first visit is the shortest,
    // lexicographically least hypothesis-index path. Each vertex is visited once.
    let mut visited = [false; PARAMETERS];
    visited[start] = true;
    let mut queue = VecDeque::from([(start, Vec::new())]);
    let mut best: Option<(u128, usize, Vec<usize>)> = None;
    while let Some((v, p)) = queue.pop_front() {
        stage.tick()?;
        for (h, a) in input.hypotheses.iter().enumerate() {
            if !matches!(a.relation, Relation::Le | Relation::Lt)
                || single(&input.terms[a.left].normal) != Some(v)
            {
                continue;
            }
            let mut next = p.clone();
            next.push(h);
            let right = &input.terms[a.right].normal;
            if let Some(bound) = closed(right) {
                let candidate = (bound, next.len(), next.clone());
                if best.as_ref().is_none_or(|old| candidate < *old) {
                    best = Some(candidate)
                }
            }
            if let Some(w) = single(right) {
                if !visited[w] {
                    visited[w] = true;
                    queue.push_back((w, next));
                }
            }
        }
    }
    best.map(|(_, _, p)| p)
        .ok_or_else(|| "Recipe A: no reachable literal upper bound".into())
}
fn recipe_a(input: &Input, stage: &Stage) -> Result<Certificate, String> {
    let mut b = Builder::new(input, stage);
    let goal = input.goal;
    if goal.relation != Relation::Le
        || !matches!(input.terms[goal.right].term, Term::Literal { .. })
    {
        return Err("Recipe A requires a literal upper goal".into());
    }
    let mut bounds = BTreeMap::new();
    // Solve only variables present in the goal, preserving unused hypotheses.
    for v in 0..input.binders.len() {
        if input.terms[goal.left].normal.coefficients[v] == 0 {
            continue;
        }
        let selected = path(input, v, stage)?;
        let mut result = None;
        for h in selected {
            let mut p = b.push(Op::Hyp { index: h })?;
            if b.atom(p).relation == Relation::Lt {
                p = b.push(Op::WeakenLt { input: p })?;
            }
            p = b.normal_relation(p)?;
            result = Some(if let Some(old) = result {
                b.push(Op::TransLe {
                    left: old,
                    right: p,
                })?
            } else {
                p
            });
        }
        let p = result.ok_or("empty bound path")?;
        let var = b.arena.intern(Term::Var { index: v })?;
        let right = b.atom(p).right;
        let p = b.rewrite_to(p, var, right)?;
        bounds.insert(v, p);
    }
    let mut proofs = BTreeMap::new();
    let mut stack = vec![(goal.left, false)];
    while let Some((t, ready)) = stack.pop() {
        stage.tick()?;
        if proofs.contains_key(&t) {
            continue;
        }
        match b.arena.terms[t].term.clone() {
            Term::Var { index } => {
                proofs.insert(t, *bounds.get(&index).ok_or("unbounded goal variable")?);
            }
            Term::Literal { .. } => {
                let p = b.push(Op::ReflLe { term: t })?;
                proofs.insert(t, p);
            }
            Term::Add { left, right } if !ready => {
                if stack.len() + 3 > NODES {
                    return Err("goal traversal cap".into());
                }
                stack.extend([(t, true), (right, false), (left, false)]);
            }
            Term::Add { left, right } => {
                let p = b.add_rel(proofs[&left], proofs[&right], false)?;
                proofs.insert(t, p);
            }
        }
    }
    let p = proofs[&goal.left];
    let m = closed(&b.arena.terms[b.atom(p).right].normal).ok_or("nonliteral computed bound")?;
    let literal = b.arena.lit(m)?;
    let p = b.rewrite_to(p, goal.left, literal)?;
    let q = b.push(Op::LiteralLe {
        left: literal,
        right: goal.right,
    })?;
    let last = b.push(Op::TransLe { left: p, right: q })?;
    Ok(b.finish(last))
}
fn cancel_forms(a: &Form, b: &Form) -> (Form, Form, Form) {
    let mut common = Form::literal(Nat(a.constant.0.min(b.constant.0)));
    let mut left = a.clone();
    let mut right = b.clone();
    left.constant.0 -= common.constant.0;
    right.constant.0 -= common.constant.0;
    for i in 0..PARAMETERS {
        common.coefficients[i] = a.coefficients[i].min(b.coefficients[i]);
        left.coefficients[i] -= common.coefficients[i];
        right.coefficients[i] -= common.coefficients[i];
    }
    (left, right, common)
}
fn recipe_b(input: &Input, stage: &Stage) -> Result<Certificate, String> {
    if input.goal.relation != Relation::Lt {
        return Err("Recipe B requires a strict goal".into());
    }
    let mut attempts = 0;
    for (h, strict) in input
        .hypotheses
        .iter()
        .enumerate()
        .filter(|(_, a)| a.relation == Relation::Lt)
    {
        let mut scaled_l = Form::literal(Nat(0));
        let mut scaled_r = Form::literal(Nat(0));
        for k in 1..=SCALE {
            stage.tick()?;
            scaled_l = scaled_l.add(&input.terms[strict.left].normal)?;
            scaled_r = scaled_r.add(&input.terms[strict.right].normal)?;
            // Direct candidate precedes source-order equalities, forward/reverse,
            // left/right. At most one input equality is transported.
            let candidates = std::iter::once(None).chain(
                input
                    .hypotheses
                    .iter()
                    .enumerate()
                    .filter(|(_, a)| a.relation == Relation::Eq)
                    .flat_map(|(e, _)| {
                        [false, true].into_iter().flat_map(move |reverse| {
                            [Side::Left, Side::Right]
                                .into_iter()
                                .map(move |side| Some((e, reverse, side)))
                        })
                    }),
            );
            for candidate in candidates {
                if attempts >= CANDIDATES {
                    return Err("Recipe B candidate cap".into());
                }
                attempts += 1;
                stage.tick()?;
                let (mut left, mut right) = (scaled_l.clone(), scaled_r.clone());
                if let Some((e, reverse, side)) = candidate {
                    let eq = input.hypotheses[e];
                    let (from, to) = if reverse {
                        (eq.right, eq.left)
                    } else {
                        (eq.left, eq.right)
                    };
                    let target = if side == Side::Left {
                        &mut left
                    } else {
                        &mut right
                    };
                    if *target != input.terms[from].normal {
                        continue;
                    }
                    *target = input.terms[to].normal.clone();
                }
                let (a, d, c) = cancel_forms(&left, &right);
                if a != input.terms[input.goal.left].normal
                    || d != input.terms[input.goal.right].normal
                {
                    continue;
                }
                let mut b = Builder::new(input, stage);
                let base = b.push(Op::Hyp { index: h })?;
                let weak = b.push(Op::WeakenLt { input: base })?;
                let mut p = base;
                for _ in 1..k {
                    p = b.add_rel(p, weak, true)?;
                }
                if let Some((e, reverse, side)) = candidate {
                    let mut ep = b.push(Op::Hyp { index: e })?;
                    if reverse {
                        ep = b.sym(ep)?;
                    }
                    ep = b.normal_relation(ep)?;
                    p = b.normal_relation(p)?;
                    p = b.push(Op::RewriteSide {
                        input: p,
                        equality: ep,
                        side,
                    })?;
                }
                let at = b.arena.canonical(&a)?;
                let dt = b.arena.canonical(&d)?;
                let ct = b.arena.canonical(&c)?;
                let ac = b.arena.add(at, ct)?;
                let dc = b.arena.add(dt, ct)?;
                p = b.rewrite_to(p, ac, dc)?;
                p = b.push(Op::CancelLt { input: p })?;
                p = b.rewrite_to(p, input.goal.left, input.goal.right)?;
                return Ok(b.finish(p));
            }
        }
    }
    Err("Recipe B exhausted the bounded enumeration".into())
}
pub(super) fn synthesize(input: &Input, stage: &Stage) -> Result<Certificate, String> {
    match input.goal.relation {
        Relation::Le => recipe_a(input, stage),
        Relation::Lt => recipe_b(input, stage),
        Relation::Eq => Err("unsupported equality goal".into()),
    }
}

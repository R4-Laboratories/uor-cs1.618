# Local diagnostic errors

The original complete error registry remains in model/errors.toml.

## LLB6008 — Constructive Nat diagnostic proof refused

The local constructive-nat-v1 compiler refuses unsupported empty-policy language 1.2 linear_arithmetic, exhausted bounds/deadlines, malformed certificates or fixed-output bindings. No alternate prover is invoked. This is component evidence, not source admission.

//! Axiom-free Init proof terms. Only checker-created values enter this module.
use super::{certificate::*, check::Checked, Stage};
use std::fmt::{self, Write};

struct Text(String);
impl Text {
    fn append(&mut self, s: &str) -> Result<(), String> {
        if self
            .0
            .len()
            .checked_add(s.len())
            .ok_or("proof size overflow")?
            > PROOF_BYTES
        {
            return Err("emitted proof byte cap".into());
        }
        self.0.push_str(s);
        Ok(())
    }
}
impl fmt::Write for Text {
    fn write_str(&mut self, s: &str) -> fmt::Result {
        self.append(s).map_err(|_| fmt::Error)
    }
}

// Nat literals and closed sums must reach Lean as closed expressions. Naming
// them with local lets introduces fvars, which Lean's fast Nat reducer declines
// before whnf (pinned Meta/WHNF.lean, withNatValue). Keep the proof DAG shared,
// but render its term syntax directly, with every byte/leaf charged in advance.
#[derive(Clone, Copy)]
struct TermText<'a> {
    terms: &'a [TermRow],
    binders: &'a [String],
    id: usize,
}
impl fmt::Display for TermText<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        enum Part {
            Term(usize),
            Token(&'static str),
        }
        let mut stack = vec![Part::Term(self.id)];
        let mut leaves = 0;
        while let Some(part) = stack.pop() {
            match part {
                Part::Token(s) => f.write_str(s)?,
                Part::Term(id) => match &self.terms.get(id).ok_or(fmt::Error)?.term {
                    Term::Add { left, right } => {
                        if stack.len().checked_add(5).ok_or(fmt::Error)? > NODES {
                            return Err(fmt::Error);
                        }
                        stack.extend([
                            Part::Token(")"),
                            Part::Term(*right),
                            Part::Token(" + "),
                            Part::Term(*left),
                            Part::Token("("),
                        ]);
                    }
                    Term::Literal { value } => {
                        if leaves >= LEAVES {
                            return Err(fmt::Error);
                        }
                        leaves += 1;
                        write!(f, "(nat_lit {})", value.0)?;
                    }
                    Term::Var { index } => {
                        if leaves >= LEAVES {
                            return Err(fmt::Error);
                        }
                        leaves += 1;
                        let name = self.binders.get(*index).ok_or(fmt::Error)?;
                        // The same segment quoting as semantic::identifier,
                        // streamed without allocating a copy of a source name.
                        for (i, segment) in name.split('.').enumerate() {
                            if i != 0 {
                                f.write_str(".")?;
                            }
                            let quote = crate::backend::lean_tokens::is_reserved(segment)
                                || crate::verify::source_audit::forbids_segment(segment);
                            if quote {
                                f.write_str("«")?;
                            }
                            f.write_str(segment)?;
                            if quote {
                                f.write_str("»")?;
                            }
                        }
                    }
                },
            }
        }
        Ok(())
    }
}
fn relation(r: Relation) -> &'static str {
    match r {
        Relation::Eq => "=",
        Relation::Le => "≤",
        Relation::Lt => "<",
    }
}
pub(super) fn emit(checked: &Checked<'_>, stage: &Stage) -> Result<String, String> {
    let c = checked.certificate();
    let input = checked.input();
    let t = |id| TermText {
        terms: &c.terms,
        binders: &input.binders,
        id,
    };
    let mut out = Text(String::new());
    let mut render = || -> fmt::Result {
        if !input.hypotheses.is_empty() {
            out.write_str("  intro")?;
            for i in 0..input.hypotheses.len() {
                write!(out, " __cnh{i}")?;
            }
            out.write_char('\n')?;
        }
        for (i, node) in c.nodes.iter().enumerate() {
            stage.tick().map_err(|_| fmt::Error)?;
            let a = node.conclusion;
            write!(
                out,
                "  have __cnp{i} : {} {} {} := ",
                t(a.left),
                relation(a.relation),
                t(a.right)
            )?;
            match &node.op {
                Op::Hyp { index } => write!(out, "__cnh{index}")?,
                Op::ReflLe { term } => write!(out, "Nat.le_refl {}", t(*term))?,
                Op::ReflEq { term } => write!(out, "Eq.refl {}", t(*term))?,
                Op::LiteralLe { .. } => out.write_str("of_decide_eq_true (Eq.refl true)")?,
                Op::WeakenLt { input } => write!(out, "Nat.le_of_lt __cnp{input}")?,
                Op::TransLe { left, right } => {
                    write!(out, "Nat.le_trans __cnp{left} __cnp{right}")?
                }
                Op::AddLe { left, right } => {
                    write!(out, "Nat.add_le_add __cnp{left} __cnp{right}")?
                }
                Op::AddLtLe { left, right } => {
                    let a = c.nodes[*left].conclusion;
                    let b = c.nodes[*right].conclusion;
                    write!(out, "Nat.lt_of_lt_of_le (Nat.add_lt_add_right __cnp{left} {}) (Nat.add_le_add (Nat.le_refl {}) __cnp{right})", t(b.left), t(a.right))?;
                }
                Op::EqSymm { input } => write!(out, "Eq.symm __cnp{input}")?,
                Op::EqTrans { left, right } => write!(out, "Eq.trans __cnp{left} __cnp{right}")?,
                Op::NormalizeEq { step } => match *step {
                    Normalization::Assoc { a, b, c } => {
                        write!(out, "Nat.add_assoc {} {} {}", t(a), t(b), t(c))?
                    }
                    Normalization::Comm { a, b } => write!(out, "Nat.add_comm {} {}", t(a), t(b))?,
                    Normalization::ZeroLeft { a } => write!(out, "Nat.zero_add {}", t(a))?,
                    Normalization::ZeroRight { a } => write!(out, "Nat.add_zero {}", t(a))?,
                    Normalization::LiteralAdd { .. } => {
                        write!(out, "Eq.refl {}", t(node.conclusion.right))?
                    }
                    Normalization::CongrAdd { left, right } => {
                        let a = c.nodes[left].conclusion;
                        let b = c.nodes[right].conclusion;
                        write!(out, "Eq.trans (congrArg (fun __cnz : Nat => __cnz + {}) __cnp{left}) (congrArg (fun __cnz : Nat => {} + __cnz) __cnp{right})", t(b.left), t(a.right))?;
                    }
                },
                Op::RewriteSide {
                    input,
                    equality,
                    side,
                } => {
                    let a = c.nodes[*input].conclusion;
                    out.write_str("Eq.mp (congrArg (fun __cnz : Nat => ")?;
                    match side {
                        Side::Left => write!(out, "__cnz {} {}", relation(a.relation), t(a.right))?,
                        Side::Right => write!(out, "{} {} __cnz", t(a.left), relation(a.relation))?,
                    }
                    write!(out, ") __cnp{equality}) __cnp{input}")?;
                }
                Op::CancelLt { input } => write!(out, "Nat.lt_of_add_lt_add_right __cnp{input}")?,
            }
            out.write_char('\n')?;
        }
        writeln!(out, "  exact __cnp{}", c.final_node)
    };
    render()
        .map_err(|_| "bounded proof rendering refused (byte/leaf/stack/deadline cap)".to_owned())?;
    stage.tick()?;
    Ok(out.0)
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn proof_expansion_checks_before_growth() {
        let mut out = Text(String::new());
        out.append(&"x".repeat(PROOF_BYTES)).unwrap();
        assert_eq!(out.0.len(), PROOF_BYTES);
        assert!(out.append("x").is_err());
        assert_eq!(out.0.len(), PROOF_BYTES);
    }
    #[test]
    fn shared_zero_dag_cannot_evade_expanded_leaf_bound() {
        let mut terms = vec![TermRow {
            term: Term::Literal { value: Nat(0) },
            normal: Form::literal(Nat(0)),
        }];
        for i in 0..12 {
            terms.push(TermRow {
                term: Term::Add { left: i, right: i },
                normal: Form::literal(Nat(0)),
            });
        }
        let mut exact = Text(String::new());
        write!(
            exact,
            "{}",
            TermText {
                terms: &terms,
                binders: &[],
                id: 12
            }
        )
        .unwrap();
        assert_eq!(exact.0.matches("nat_lit").count(), 4096);
        terms.push(TermRow {
            term: Term::Add { left: 12, right: 0 },
            normal: Form::literal(Nat(0)),
        });
        let mut above = Text(String::new());
        assert!(write!(
            above,
            "{}",
            TermText {
                terms: &terms,
                binders: &[],
                id: 13
            }
        )
        .is_err());
        assert_eq!(above.0.matches("nat_lit").count(), 4096);
    }
}

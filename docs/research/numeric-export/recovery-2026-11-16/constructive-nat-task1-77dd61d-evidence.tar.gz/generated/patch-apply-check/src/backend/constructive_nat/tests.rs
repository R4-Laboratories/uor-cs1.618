use super::*;
use crate::ir::semantic::SemanticType;
fn v(n: &str) -> SemanticTerm {
    SemanticTerm::Var { name: n.into() }
}
fn n(x: u128) -> SemanticTerm {
    SemanticTerm::Nat {
        value: x.to_string(),
    }
}
fn add(a: SemanticTerm, b: SemanticTerm) -> SemanticTerm {
    SemanticTerm::Add {
        left: Box::new(a),
        right: Box::new(b),
    }
}
fn le(a: SemanticTerm, b: SemanticTerm) -> SemanticTerm {
    SemanticTerm::Le {
        left: Box::new(a),
        right: Box::new(b),
    }
}
fn lt(a: SemanticTerm, b: SemanticTerm) -> SemanticTerm {
    SemanticTerm::Lt {
        left: Box::new(a),
        right: Box::new(b),
    }
}
fn eq(a: SemanticTerm, b: SemanticTerm) -> SemanticTerm {
    SemanticTerm::Eq {
        left: Box::new(a),
        right: Box::new(b),
    }
}
fn imp(a: SemanticTerm, b: SemanticTerm) -> SemanticTerm {
    SemanticTerm::Implies {
        premise: Box::new(a),
        conclusion: Box::new(b),
    }
}
fn params(ns: &[&str]) -> Vec<SemanticParameter> {
    ns.iter()
        .map(|x| SemanticParameter {
            name: (*x).into(),
            r#type: SemanticType::Nat,
        })
        .collect()
}
#[test]
fn recipe_a_renamed_reordered_transitive_and_unused_hypotheses() {
    let statement = imp(
        le(v("spare"), n(99)),
        imp(
            lt(v("z"), v("a")),
            imp(le(v("a"), n(17)), le(add(add(v("z"), n(3)), v("z")), n(37))),
        ),
    );
    let proof = compile(&params(&["a", "spare", "z"]), &statement)
        .expect("generic constructive upper bound");
    assert!(!proof.contains("omega"));
    assert!(!proof.contains("simp"));
}
#[test]
fn recipe_b_reversed_equality_and_permuted_sums() {
    let statement = imp(
        lt(v("x"), v("y")),
        imp(
            eq(add(v("y"), v("result")), add(v("x"), v("x"))),
            lt(v("result"), v("y")),
        ),
    );
    let proof = compile(&params(&["result", "y", "x"]), &statement)
        .expect("generic constructive cancellation");
    assert!(!proof.contains("omega"));
    assert!(!proof.contains("simp"));
}
fn stage() -> Stage {
    Stage::new(Instant::now(), 300_000, 67_108_864)
}
fn cert(ps: &[SemanticParameter], s: &SemanticTerm) -> (Input, Certificate) {
    let input = input(ps, s).unwrap();
    let c = synthesize::synthesize(&input, &stage()).unwrap();
    check::check(&input, &c, &stage()).unwrap();
    (input, c)
}
fn repeat(x: SemanticTerm, k: usize) -> SemanticTerm {
    (1..k).fold(x.clone(), |a, _| add(a, x.clone()))
}
#[test]
fn recipe_a_cycles_smallest_bound_shortest_path_and_lexicographic_ties() {
    let s = [
        le(v("x"), v("y")),
        le(v("y"), v("x")),
        le(v("y"), n(9)),
        le(v("x"), n(10)),
        le(v("x"), n(9)),
        le(v("x"), n(9)),
    ]
    .into_iter()
    .rev()
    .fold(le(v("x"), n(9)), |s, h| imp(h, s));
    let (_, c) = cert(&params(&["y", "x"]), &s);
    let hyps: Vec<usize> = c
        .nodes
        .iter()
        .filter_map(|n| {
            if let Op::Hyp { index } = n.op {
                Some(index)
            } else {
                None
            }
        })
        .collect();
    assert_eq!(hyps, vec![4]);
    let s = imp(
        le(v("x"), v("y")),
        imp(
            le(v("x"), v("z")),
            imp(le(v("y"), n(8)), imp(le(v("z"), n(8)), le(v("x"), n(8)))),
        ),
    );
    let (_, c) = cert(&params(&["x", "z", "y"]), &s);
    let hyps: Vec<usize> = c
        .nodes
        .iter()
        .filter_map(|n| {
            if let Op::Hyp { index } = n.op {
                Some(index)
            } else {
                None
            }
        })
        .collect();
    assert_eq!(hyps, vec![0, 2]);
}
#[test]
fn scale_sixteen_succeeds_seventeen_refuses_without_fallback() {
    for k in [1, 2, 3, 16, 17] {
        let rhs = if k == 1 {
            v("result")
        } else {
            add(v("result"), repeat(v("y"), k - 1))
        };
        let s = imp(
            lt(v("x"), v("y")),
            imp(eq(repeat(v("x"), k), rhs), lt(v("result"), v("y"))),
        );
        let r = compile(&params(&["result", "x", "y"]), &s);
        if k <= 16 {
            assert!(r.is_ok(), "scale {k}: {r:?}")
        } else {
            assert!(r.unwrap_err().contains("exhausted"));
        }
    }
}
#[test]
fn candidate_enumeration_stops_at_the_bound() {
    let mut s = lt(v("z"), v("y"));
    for _ in 0..32 {
        s = imp(eq(v("x"), v("x")), s)
    }
    for _ in 0..32 {
        s = imp(lt(v("x"), v("y")), s)
    }
    assert!(compile(&params(&["x", "y", "z"]), &s)
        .unwrap_err()
        .contains("candidate cap"));
}
#[test]
fn exact_scope_hypothesis_and_input_size_boundaries() {
    let ps: Vec<_> = (0..32)
        .map(|i| SemanticParameter {
            name: format!("x{i}"),
            r#type: SemanticType::Nat,
        })
        .collect();
    assert!(compile(&ps, &le(n(0), n(0))).is_ok());
    let mut extra = ps.clone();
    extra.push(SemanticParameter {
        name: "extra".into(),
        r#type: SemanticType::Nat,
    });
    assert!(compile(&extra, &le(n(0), n(0)))
        .unwrap_err()
        .contains("parameter cap"));
    let mut s = le(n(0), n(0));
    for _ in 0..64 {
        s = imp(le(n(0), n(0)), s)
    }
    assert!(compile(&[], &s).is_ok());
    s = imp(le(n(0), n(0)), s);
    assert!(compile(&[], &s).unwrap_err().contains("hypothesis cap"));
    fn zeros(k: usize) -> SemanticTerm {
        if k == 1 {
            n(0)
        } else {
            add(zeros(k / 2), zeros(k - k / 2))
        }
    }
    // Supported atoms/implications always have odd total node counts: 1023 is
    // the greatest realizable input below 1024; 1025 is the first above it.
    assert!(compile(&[], &le(zeros(511), n(0))).is_ok());
    assert!(compile(&[], &le(zeros(512), n(0)))
        .unwrap_err()
        .contains("input term node cap"));
}
#[test]
fn nat128_decimal_and_checked_arithmetic() {
    for (text, ok) in [
        ("0", true),
        ("340282366920938463463374607431768211455", true),
        ("340282366920938463463374607431768211456", false),
        ("00", false),
        ("01", false),
        ("+1", false),
        ("-1", false),
        ("1.0", false),
        ("", false),
    ] {
        let wire = serde_json::to_string(text).unwrap();
        assert_eq!(serde_json::from_str::<Nat>(&wire).is_ok(), ok, "{text}");
    }
    assert!(compile(&[], &le(n(u128::MAX), n(u128::MAX))).is_ok());
    assert!(compile(&[], &le(add(n(u128::MAX), n(1)), n(u128::MAX)))
        .unwrap_err()
        .contains("overflow"));
    let mut f = Form::literal(Nat(0));
    f.coefficients[0] = 4095;
    assert!(f.validate(1).is_ok());
    f.coefficients[0] = 4096;
    assert!(f.validate(1).unwrap_err().contains("leaf"));
    f.coefficients[0] = 4097;
    assert!(f.validate(1).unwrap_err().contains("coefficient"));
    let a = Form {
        coefficients: [4096; 32],
        constant: Nat(0),
    };
    assert!(a
        .add(&Form::variable(0).unwrap())
        .unwrap_err()
        .contains("coefficient"));
}
#[test]
fn malformed_certificate_mutations_are_refused() {
    let s = imp(
        lt(v("x"), v("y")),
        imp(
            eq(add(v("x"), v("x")), add(v("z"), v("y"))),
            lt(v("z"), v("y")),
        ),
    );
    let (input, c) = cert(&params(&["x", "y", "z"]), &s);
    let mut bad = c.clone();
    bad.nodes[0].op = Op::Hyp { index: 64 };
    assert!(check::check(&input, &bad, &stage()).is_err());
    let mut bad = c.clone();
    bad.nodes[1].op = Op::WeakenLt { input: 1 };
    assert!(check::check(&input, &bad, &stage()).is_err());
    let mut bad = c.clone();
    bad.nodes[0].conclusion.relation = Relation::Le;
    assert!(check::check(&input, &bad, &stage()).is_err());
    let mut bad = c.clone();
    bad.terms[0].term = Term::Var { index: 32 };
    assert!(check::check(&input, &bad, &stage()).is_err());
    let mut bad = c.clone();
    bad.terms[0].term = Term::Add { left: 0, right: 0 };
    assert!(check::check(&input, &bad, &stage()).is_err());
    let mut bad = c.clone();
    bad.terms[0].normal.constant = Nat(1);
    assert!(check::check(&input, &bad, &stage()).is_err());
    let mut bad = c.clone();
    bad.final_node = 0;
    assert!(check::check(&input, &bad, &stage()).is_err());
    let mut wrong = input.clone();
    wrong.goal.left = wrong.goal.right;
    assert!(check::check(&wrong, &c, &stage()).is_err());
    let mut wrong = input.clone();
    wrong.hypotheses.swap(0, 1);
    assert!(check::check(&wrong, &c, &stage()).is_err());
    for (i, node) in c.nodes.iter().enumerate() {
        let mut bad = c.clone();
        match node.op {
            Op::RewriteSide {
                input,
                equality,
                side,
            } => {
                bad.nodes[i].op = Op::RewriteSide {
                    input,
                    equality,
                    side: if side == Side::Left {
                        Side::Right
                    } else {
                        Side::Left
                    },
                }
            }
            Op::AddLtLe { left, right } => bad.nodes[i].op = Op::AddLe { left, right },
            Op::EqTrans { left, right } => {
                bad.nodes[i].op = Op::EqTrans {
                    left: right,
                    right: left,
                }
            }
            _ => continue,
        }
        assert!(
            check::check(&input, &bad, &stage()).is_err(),
            "mutation at {i}"
        );
    }
    let mut wire = serde_json::to_value(&c).unwrap();
    wire["nodes"][0]["op"]["payload"] = serde_json::json!("by omega");
    assert!(serde_json::from_value::<Certificate>(wire).is_err());
}
#[test]
fn certificate_node_boundary_and_bounded_decode() {
    let input = input(&[], &le(n(0), n(0))).unwrap();
    let node = Node {
        op: Op::ReflLe { term: 0 },
        conclusion: input.goal,
    };
    let mut c = Certificate {
        terms: Bounded(input.terms.clone()),
        nodes: Bounded(vec![node.clone(); NODES]),
        final_node: NODES - 1,
    };
    assert!(check::check(&input, &c, &stage()).is_ok());
    c.nodes.push(node);
    assert!(check::check(&input, &c, &stage()).is_err());
    let bytes = serde_json::to_vec(&c).unwrap();
    assert!(serde_json::from_slice::<Certificate>(&bytes).is_err());
    let c = Certificate {
        terms: Bounded(vec![]),
        nodes: Bounded(vec![]),
        final_node: 0,
    };
    assert!(check::check(&input, &c, &stage()).is_err());
}
#[test]
fn unsupported_shapes_wrong_bounds_and_types_refuse() {
    assert!(compile(&params(&["x"]), &le(v("x"), n(5))).is_err());
    assert!(compile(&params(&["x"]), &imp(le(v("x"), n(6)), le(v("x"), n(5)))).is_err());
    assert!(compile(&[], &eq(n(1), n(1))).is_err());
    assert!(compile(&[], &le(v("ghost"), n(5))).is_err());
    let bad = [SemanticParameter {
        name: "x".into(),
        r#type: SemanticType::Int,
    }];
    assert!(compile(&bad, &le(v("x"), n(5))).is_err());
    assert!(compile(&[], &SemanticTerm::Bool { value: true }).is_err());
    assert!(compile(&[], &le(SemanticTerm::Bool { value: true }, n(1))).is_err());
}
#[test]
fn serialization_and_shared_stage_budgets_do_not_reset() {
    let s = imp(le(v("x"), n(3)), le(v("x"), n(4)));
    let ps = params(&["x"]);
    let (_, c) = cert(&ps, &s);
    let bytes = canonical(&c, 1_000_000).unwrap();
    assert_eq!(
        bytes,
        canonical(
            &serde_json::from_slice::<Certificate>(&bytes).unwrap(),
            1_000_000
        )
        .unwrap()
    );
    assert!(canonical(&c, bytes.len() - 1).is_err());
    let mut exhausted = Stage::new(
        Instant::now() - Duration::from_secs(301),
        300_000,
        67_108_864,
    );
    assert!(compile_checked(&ps, &s, &mut exhausted)
        .unwrap_err()
        .contains("deadline"));
    let mut cumulative = stage();
    compile_checked(&ps, &s, &mut cumulative).unwrap();
    let first = cumulative.used;
    cumulative.max_bytes = first;
    assert!(compile_checked(&ps, &s, &mut cumulative).is_err());
    assert_eq!(cumulative.used, first);
}
#[test]
fn fixed_artifact_refuses_missing_extra_duplicate_and_changed_rows() {
    let ps = params(&["x"]);
    let s = imp(le(v("x"), n(1)), le(v("x"), n(1)));
    let (_, c) = cert(&ps, &s);
    let row = Row {
        module: "Generic".into(),
        theorem: "bound".into(),
        source_sha256: "0".repeat(64),
        parameters: ps,
        statement: s,
        certificate: c,
    };
    let expected = Artifact {
        spec: "lexlean/constructive-nat-certificate/1".into(),
        rule_version: "constructive-nat-v1".into(),
        compiler_version: crate::COMPILER_VERSION.into(),
        compiler_semantics_id: crate::compiler_semantics_id_for("1.2").to_hex(),
        source_id: "1".repeat(64),
        semantic_id: "2".repeat(64),
        rows: vec![row.clone()],
    };
    let bytes = canonical(&expected, 1_000_000).unwrap();
    assert!(verify_artifact(&bytes, &expected, &stage()).is_ok());
    for rows in [vec![], vec![row.clone(), row.clone()]] {
        let mut bad = expected.clone();
        bad.rows = rows;
        assert!(
            verify_artifact(&canonical(&bad, 1_000_000).unwrap(), &expected, &stage()).is_err()
        );
    }
    let mut bad = expected.clone();
    bad.rows[0].theorem = "extra".into();
    assert!(verify_artifact(&canonical(&bad, 1_000_000).unwrap(), &expected, &stage()).is_err());
    let mut bad = expected.clone();
    bad.source_id = "3".repeat(64);
    assert!(verify_artifact(&canonical(&bad, 1_000_000).unwrap(), &expected, &stage()).is_err());
}

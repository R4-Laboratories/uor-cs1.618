module
import MicroControl.Small
import MicroControl.Add
import MicroControl.Equal
import MicroControl.Unequal
import MicroControl.Nested
#print axioms MicroControl.Small.arithmetic
#print axioms MicroControl.Add.arithmetic
#print axioms MicroControl.Equal.arithmetic
#print axioms MicroControl.Unequal.arithmetic
#print axioms MicroControl.Nested.arithmetic

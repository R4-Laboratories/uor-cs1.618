"""Exactly one authorized offline candidate integration build and two selectors."""
from pathlib import Path
import os,sys,json,subprocess,time,signal,hashlib
ROOT=Path('/workspace/diagnostic-tools/constructive-nat-task1');E=ROOT/'evidence';TARGET=Path('/workspace/diagnostic-tools/lexlean-target');base=json.loads((E/'baseline.json').read_text());records=[]
env=dict(os.environ,CARGO_HOME='/workspace/diagnostic-tools/cargo-home',CARGO_TARGET_DIR=str(TARGET),CARGO_BUILD_JOBS='2',CARGO_INCREMENTAL='0',RUSTC='/workspace/diagnostic-tools/rust-1.97.1/bin/rustc',PATH='/workspace/diagnostic-tools/rust-1.97.1/bin:/workspace/diagnostic-tools/lean-4.32.1-linux/bin:/usr/bin:/bin')
assert not any(k.startswith('CARGO_BIN_EXE') for k in env)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def size(p):return sum(f.stat().st_size for f in p.rglob('*') if f.is_file())
def measure():return {'growth_bytes':size(ROOT)+size(TARGET)-base['cache_bytes_before'],'free_bytes':os.statvfs(ROOT).f_bavail*os.statvfs(ROOT).f_frsize}
def run(label,args,limit):
 p=None;reason=None;start=time.monotonic();rec={'label':label,'argv':args,'cwd':str(ROOT/'package'),'environment':{k:env[k] for k in ['CARGO_HOME','CARGO_TARGET_DIR','CARGO_BUILD_JOBS','CARGO_INCREMENTAL','RUSTC','PATH']},'deadline_seconds':limit,'growth_ceiling_bytes':640*1024**2,'proactive_growth_stop_bytes':632*1024**2,'disk_floor_bytes':8*1024**3,'samples':[]};outpath=E/(label+'.stdout');errpath=E/(label+'.stderr')
 try:
  first=measure();rec['samples'].append(first)
  if first['growth_bytes']>=632*1024**2 or first['free_bytes']<8*1024**3+16*1024**2:raise RuntimeError('resource stop before spawn')
  with outpath.open('wb',buffering=0) as out,errpath.open('wb',buffering=0) as err:
   p=subprocess.Popen(args,cwd=ROOT/'package',env=env,stdout=out,stderr=err,start_new_session=True);rec['pid']=p.pid
   while True:
    m=measure();m['seconds']=time.monotonic()-start;m['output_bytes']=outpath.stat().st_size+errpath.stat().st_size;rec['samples'].append(m)
    if m['growth_bytes']>=632*1024**2:reason='growth-stop'
    elif m['free_bytes']<8*1024**3+16*1024**2:reason='disk-floor-stop'
    elif m['seconds']>=limit:reason='deadline-stop'
    elif m['output_bytes']>=16*1024**2:reason='live-output-stop'
    if reason or p.poll() is not None:break
    time.sleep(.25)
 except BaseException as exc:reason=type(exc).__name__+':'+str(exc)
 finally:
  if p is not None:
   if reason or p.poll() is None:
    try:os.killpg(p.pid,signal.SIGTERM)
    except ProcessLookupError:pass
    try:p.wait(timeout=2)
    except subprocess.TimeoutExpired:
     try:os.killpg(p.pid,signal.SIGKILL)
     except ProcessLookupError:pass
     p.wait(timeout=2)
   try:os.killpg(p.pid,signal.SIGKILL)
   except ProcessLookupError:pass
   rec['exit']=p.wait()
  else:rec['exit']=None
  rec['stop']=reason;rec['seconds']=time.monotonic()-start;records.append(rec);(E/'integration-final-commands.json').write_text(json.dumps({'component_only':True,'scoped_resource_ruling':'task-1-brief.md Scoped final integration-test resource ruling','commands':records},indent=2)+'\n')
 print(label,rec['exit'],reason,rec['seconds'],flush=True)
 if rec['exit']!=0 or reason:sys.exit(1)
 return rec
before={x['path']:sha(ROOT/'package'/x['path']) for x in json.loads((E/'component-inventory-current.json').read_text())['files']}
run('integration-final-build',['/workspace/diagnostic-tools/rust-1.97.1/bin/cargo','test','--manifest-path',str(ROOT/'package/Cargo.toml'),'--release','--locked','--offline','--test','unit','--no-run','--message-format=json'],360)
artifacts=[]
for line in (E/'integration-final-build.stdout').read_text().splitlines():
 try:o=json.loads(line)
 except ValueError:continue
 if o.get('reason')=='compiler-artifact' and o.get('target',{}).get('name')=='unit' and o.get('executable'):artifacts.append(o)
assert len(artifacts)==1,artifacts
elf=Path(artifacts[0]['executable']);elfhash=sha(elf)
for sel in ['canonical_json_is_restricted','axiom_parser_matches_the_golden_vectors']:run('integration-final-'+sel,[str(elf),sel,'--exact','--nocapture'],30)
assert sha(elf)==elfhash
assert all(sha(ROOT/'package'/n)==h for n,h in before.items())
result={'component_only':True,'status':'PASS','scope':'actual freshly compiled candidate integration test; exactly two pure selectors, no SDK qualification','artifact':artifacts[0],'elf_sha256':elfhash,'elf_bytes':elf.stat().st_size,'package_before_after_unchanged':True,'package_inventory_sha256':sha(E/'component-inventory-current.json'),'test_source_sha256':sha(ROOT/'package/tests/unit.rs'),'selectors':['canonical_json_is_restricted','axiom_parser_matches_the_golden_vectors'],'final_resources':measure()}
(E/'integration-final-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)

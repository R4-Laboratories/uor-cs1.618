from proof_guard import *
import shutil,hashlib
E=ROOT/'evidence';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();cli=Path('/workspace/diagnostic-tools/lexlean-target/release/lexlean-constructive-diagnostic');runtime=Path('/workspace/diagnostic-tools/laws-investigation/no-c/.lake/build/lib/lean');records=[];selected=[]
env=dict(os.environ,PATH='/workspace/diagnostic-tools/lean-4.32.1-linux/bin:/usr/bin:/bin',LEAN_NUM_THREADS='1');owner=ProofOwner('fix1-proof-validation',300,rss_limit=2*1024**3,cgroup_reserve=4*1024**3);out=ROOT/'generated/fix1-proof-validation';out.mkdir();env['LEAN_PATH']=str(out)+':'+str(runtime)
originals=json.loads((E/'original-artifacts-current.json').read_text());protected=[Path(x['path']) for x in originals if 'sha256' in x]+[cli,Path('/workspace/diagnostic-tools/lean-4.32.1-linux/bin/lean'),Path('/workspace/diagnostic-tools/lean-4.32.1-linux/bin/leanchecker')]+[x for x in runtime.rglob('*') if x.is_file() and x.name.startswith(('Laws.olean','Portable.olean','Collections.olean'))];bindings={str(p):sha(p) for p in protected}
for oldlabel,newlabel,count in [('positive-direct','fix1-positive',14),('fix1-hygiene-red','fix1-hygiene',6)]:
 old=ROOT/'fixtures'/oldlabel;project=ROOT/'fixtures'/newlabel;assert not project.exists();project.mkdir();shutil.copytree(old/'src',project/'src')
 for name in ['lexlean.toml','lexlean.lock','lean-toolchain','lakefile.toml','lake-manifest.json']:shutil.copyfile(old/name,project/name)
 inputs={str(p):sha(p) for p in project.rglob('*') if p.is_file()};bindings.update(inputs)
 for name,args in [('lock',['lock','--check']),('fmt',['fmt','--check']),('check',['check']),('build',['build'])]:
  rec=owner.run(newlabel+'-'+name,[str(cli),*args],project,env);assert rec['exit']==0 and rec['stop'] is None
 build=next((project/'.lexlean/build').iterdir());manifest=json.loads((build/'manifest.json').read_text());cert=json.loads((build/'proofs/constructive-nat.json').read_text());assert len(cert['rows'])==count
 assert cert['compiler_version']=='0.4.0-constructive.1' and cert['compiler_semantics_id']=='bd003277b8a6a32f8f37f710eb6553f3fce4e5c56181578db0f86cec215a3729'
 for row in manifest['outputs']:
  p=build/row['path'];assert p.stat().st_size==row['byte_length'] and sha(p)==row['sha256'];bindings[str(p)]=sha(p)
 assert sha(build/'proofs/constructive-nat.json')==sha(next((old/'.lexlean/build').iterdir())/'proofs/constructive-nat.json')
 keys=[(row['module'],row['theorem']) for row in cert['rows']];assert len(set(keys))==count;selected.extend(keys)
 for mod in sorted(set(mod for mod,_ in keys)):
  src=mod.replace('.','/')+'.lean';dest=out/(mod.replace('.','/')+'.olean');dest.parent.mkdir(parents=True,exist_ok=True)
  for kind,args in [('lean',['/workspace/diagnostic-tools/lean-4.32.1-linux/bin/lean','-o',str(dest),src]),('checker',['/workspace/diagnostic-tools/lean-4.32.1-linux/bin/leanchecker',mod])]:
   rec=owner.run(kind+'-'+mod,args,build/'modules',env);assert rec['exit']==0 and rec['stop'] is None
 records.append({'project':newlabel,'certificate_sha256':sha(build/'proofs/constructive-nat.json'),'manifest_sha256':sha(build/'manifest.json'),'selected':keys,'certificate_unchanged_from_pre_fix':True,'source_bindings':inputs})
audit=out/'Audit.lean';audit.write_text('\n'.join('import '+m for m in sorted(set(m for m,_ in selected)))+'\n'+'\n'.join('#print axioms '+m+'.'+t for m,t in selected)+'\n')
rec=owner.run('axioms',['/workspace/diagnostic-tools/lean-4.32.1-linux/bin/lean',str(audit)],out,env);assert rec['exit']==0 and rec['stop'] is None
lines=(E/'fix1-proof-validation-axioms.stdout').read_text().splitlines();expected=["'"+m+'.'+t+"' does not depend on any axioms" for m,t in selected];assert lines==expected,(lines,expected)
assert all(sha(Path(p))==h for p,h in bindings.items());assert not Path('/workspace/diagnostic-tools/lexlean-target/release/liblexlean.rlib').exists()
result={'component_only':True,'status':'PASS','selected_count':len(selected),'all_selected_axioms_empty':True,'top_level_helpers':[],'stage_seconds':time.monotonic()-owner.started,'max_combined_rss':max(r['max_rss_bytes'] for r in owner.commands),'cli_sha256':sha(cli),'projects':records,'protected_before_after':bindings,'all_commands_succeeded':True,'scope':'five unchanged Bounds plus nine generic and six legal-name-collision declarations; no SDK/admission claim'};(E/'fix1-proof-validation-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ['projects','protected_before_after']}))

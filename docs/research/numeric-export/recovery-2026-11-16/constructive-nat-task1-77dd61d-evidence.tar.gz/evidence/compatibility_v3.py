from pathlib import Path
import os,sys,json,hashlib,re
from proof_guard import ProofOwner,ROOT
owner=ProofOwner('compatibility-final-v3',180,rss_limit=2*1024**3,cgroup_reserve=4*1024**3);bins={'base':'/workspace/diagnostic-tools/lexlean-target/release/lexlean','candidate':'/workspace/diagnostic-tools/lexlean-target/release/lexlean-constructive-diagnostic'};env=dict(os.environ,PATH='/workspace/diagnostic-tools/lean-4.32.1-linux/bin:/usr/bin:/bin',LEAN_NUM_THREADS='1');results={}
def run(label,args,cwd):
 r=owner.run(label,args,cwd,env,seconds=20)
 if r['exit']!=0 or r['stop']:
  print((ROOT/'evidence'/r['stdout']).read_text()[-2000:]);print((ROOT/'evidence'/r['stderr']).read_text()[-2000:]);raise SystemExit('FAILED '+label)
for lang in ['1.1','1.2']:
 for kind,binary in bins.items():
  dst=ROOT/'fixtures'/f'compat-v3-{lang}-{kind}';src=ROOT/'fixtures/positive';dst.mkdir(exist_ok=False);(dst/'src').mkdir()
  for n in ['lexlean.toml','lakefile.toml','lake-manifest.json','lean-toolchain']:(dst/n).write_bytes((src/n).read_bytes())
  p=dst/'lexlean.toml';s=p.read_text().replace('language = "1.2"',f'language = "{lang}"');s=re.sub(r'entrypoints = .*', 'entrypoints = ["src/'+('Compatibility' if lang=='1.2' else 'Main')+'.lex.tex"]',s);p.write_text(s)
  if lang=='1.1':
   v={'kind':'var','name':'x'};module={'spec':'lexlean/semantic-module/1','declarations':[{'kind':'theorem','name':'originalReflexivity','parameters':[{'name':'x','type':{'kind':'nat'}}],'statement':{'kind':'eq','left':v,'right':v},'proof':{'kind':'reflexivity'},'axioms':[]}]}
   (dst/'src/Main.lex.tex').write_text('\\begin{lexlean}{Main}\n\\useglossary{lexlean.std.nat@1.1.0}\n\\title{addition}\n\\semanticdata{'+json.dumps(module,separators=(',',':'))+'}\n\\end{lexlean}\n')
  else:(dst/'src/Compatibility.lex.tex').write_bytes((src/'src/Compatibility.lex.tex').read_bytes())
  for cmd in ['lock','fmt','check','build']:run(f'{lang}-{kind}-{cmd}',[binary,'--project',str(dst/'lexlean.toml'),cmd],dst)
  build=next((dst/'.lexlean/build').iterdir());manifest=json.loads((build/'manifest.json').read_text());paths=[x['path'] for x in manifest['outputs'] if x['kind'] in ['lean','tex']];results[(lang,kind)]={'build':build,'files':{p:(build/p).read_bytes() for p in paths},'semantics':manifest['compiler']['semantics_id']}
 assert results[(lang,'base')]['files']==results[(lang,'candidate')]['files'],('lowering changed',lang)
 if lang=='1.1':assert results[(lang,'base')]['semantics']==results[(lang,'candidate')]['semantics']
 else:
  c=json.loads((results[(lang,'candidate')]['build']/'proofs/constructive-nat.json').read_text());assert c['rows']==[];assert results[(lang,'base')]['semantics']!=results[(lang,'candidate')]['semantics']
 print('BYTE IDENTICAL Lean+TeX lowering',lang,flush=True)
# Reuse the already successful v2 language1.0 outputs; do not rerun those checks.
for kind in bins:
 build=next((ROOT/'fixtures'/f'compat-v2-1.0-{kind}'/'.lexlean/build').iterdir());manifest=json.loads((build/'manifest.json').read_text());paths=[r['path'] for r in manifest['outputs'] if r['kind'] in ['lean','tex']];results[('1.0',kind)]={'build':build,'files':{p:(build/p).read_bytes() for p in paths},'semantics':manifest['compiler']['semantics_id']}
assert results[('1.0','base')]['files']==results[('1.0','candidate')]['files'];assert results[('1.0','base')]['semantics']==results[('1.0','candidate')]['semantics']
report=[]
for (lang,kind),r in sorted(results.items()):report.append({'language':lang,'compiler':kind,'build':str(r['build']),'semantics':r['semantics'],'lean_tex':{p:hashlib.sha256(v).hexdigest() for p,v in r['files'].items()}})
(ROOT/'evidence/compatibility-final-v3-result.json').write_text(json.dumps({'component_only':True,'comparisons':report,'scope':'1.0 empty titled legacy module (v2 result reused); 1.1 semanticdata Nat reflexivity theorem; 1.2 original nonempty-policy LinearArithmetic plus empty-policy Reflexivity. Exact generated Lean/TeX byte equality; full manifests legitimately differ.','preceding_fixture_failures':['Identity-only source lacked mandatory title.','Authoring semanticmodule notation is1.2-only; corrected1.1 fixture to original semanticdata contract.'],'environment_interruption':'Prior v3 command was not created; no v3 files or process existed at resumption.','implementation_changed':False},indent=2)+'\n');print('PASS: legacy and nonselected lowering controls')

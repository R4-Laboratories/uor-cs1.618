# Constructive Nat component evidence

All paths are relative to this evidence directory unless specified. Logs and failed inputs are retained; this index is a guide, not a success assertion.

| Purpose | Primary receipts |
|---|---|
| Base/tool/resource identities | baseline.json; tool-identities.json; original-runtime-identities.json; original-artifacts-current.json |
| Package scope and provenance | component-inventory-current.json; pristine-*; ../package/DIAGNOSTIC-PROVENANCE.json |
| Red/green development | red-initial.*; check-first.*; green-first.*; green-second.*; green-third.* |
| Corrected CLI build and retirement | build-direct-emitter.*; owned-retired-cli-4.json |
| Final focused tests | constructive-final-tests.* (14 passed, exit0, no guard) |
| Existing focused controls | focused-base-commands.json; focused-base-*.stdout/stderr |
| Actual 14 proof replay and axioms | full-direct-validation-commands.json; full-direct-validation-result.json; full-direct-validation-*.stdout/stderr |
| Authored fixtures and certificates | ../fixtures/positive-direct; ../generated/positive-direct; fixture-origin.json |
| Compatibility/semantic identities | compatibility-final-v5-result.json; compatibility-final-v5-commands.json; compatibility-final-v2-commands.json; semantics-compatibility.json; identity-commands.json |
| Retained fixture errors | authored-first.*; base-lock-*; compatibility-final-{commands,v2-commands,v3-commands,v4-commands}.json |
| Original large Lean failure | lean-resource-stop.json; lean-audit*; ../fixtures/positive |
| Old/new discriminating generated controls | micro-old-commands.json; direct-micro-remaining-commands.json; direct-micro-remaining-result.json |
| Checker import-cost discrimination | checker-baseline-{commands,inputs}.json; checker-2g-{commands,inputs}.json |
| Execution owners and exact limit record | run.py; proof_guard.py; proof_guard-before-2g.py; proof-guard-2g-config.json |
| Candidate-owned resource cleanup | owned-reaped-{1,2,3}.json; owned-retired-cli-4.json |

The SDD report records limits and remaining gaps. No SDK/source-admission claim is made. The corrected CLI ELF was historically retired, then the final integration build honestly relinked it with identical hash; see integration-final-result.json for current retained artifacts.

`evidence-files.json` records each retained evidence file hash/length except itself and Python bytecode caches; it is a checkpoint inventory, not a self-hashing manifest.

Unchanged integration-control availability inspection: `unchanged-controls-inspection.json`, `unchanged-controls-search.stdout/stderr`; no matching ELF found at that checkpoint; superseded by the authorized fresh candidate integration build below.

Final actual candidate integration tests: `integration-final-commands.json`, `integration-final-result.json`, `integration-final-*.stdout/stderr`; both exact selectors passed. Diagnostic owner `integration_final.py`; completed library-test ELF retirement `owned-retired-libtest-5.json`.

Final source packaging: `component-inventory-final.json`, `patch-application.json`, `packaging-first-failure.txt`; `retained-input-output-inventory.json` hashes all retained fixtures/generated files. Final portable patch metadata is in the game scripts/numeric/constructive-proof-candidate directory.

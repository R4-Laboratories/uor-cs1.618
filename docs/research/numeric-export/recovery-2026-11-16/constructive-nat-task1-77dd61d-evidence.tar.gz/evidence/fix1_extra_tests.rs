
fn observed<T>(action: impl FnOnce() -> T) -> (T, Vec<(&'static str, usize)>) {
    OUTPUT_OBSERVATIONS.with_borrow_mut(|events| *events = Some(Vec::new()));
    let result = action();
    let events = OUTPUT_OBSERVATIONS.with_borrow_mut(|events| events.take().unwrap());
    (result, events)
}

#[test]
fn fix1_partial_proof_allowance_is_checked_before_each_append() {
    let ps = params(&["x"]);
    let s = imp(le(v("x"), n(3)), le(v("x"), n(4)));
    let (input, c) = cert(&ps, &s);
    let bytes = canonical(&c, 1_000_000).unwrap();
    let checked_stage = stage();
    let checked = check::check(&input, &c, &checked_stage).unwrap();
    let complete = emit::emit(&checked, &checked_stage).unwrap();
    for remaining in [0, 7, complete.len() - 1, complete.len()] {
        let mut budget = Stage::new(Instant::now(), 300_000, (bytes.len() + remaining) as u64);
        budget.charge(bytes.len()).unwrap();
        let (result, events) = observed(|| emit::emit(&checked, &budget));
        assert!(events.iter().all(|(kind, len)| *kind == "proof" && *len <= remaining));
        if remaining == 0 { assert!(events.is_empty()); }
        if remaining == complete.len() { assert_eq!(result.unwrap(), complete); }
        else { assert!(result.is_err()); }
        assert_eq!(budget.used, bytes.len(), "producer cannot reset/charge unrelated stage bytes");
    }
    let mut exact = Stage::new(Instant::now(), 300_000, (bytes.len() + complete.len()) as u64);
    compile_checked(&ps, &s, &mut exact).unwrap();
    assert_eq!(exact.remaining(), 0);
    let mut short = Stage::new(Instant::now(), 300_000, bytes.len() as u64);
    let (result, events) = observed(|| compile_checked(&ps, &s, &mut short));
    assert!(result.is_err());
    assert!(!events.iter().any(|(kind, _)| *kind == "proof"));
}

#[test]
fn fix1_existing_reports_bound_artifact_writer_before_growth() {
    let make = |remaining, budget: &mut Stage| artifact(Vec::new(), "1".repeat(64), "2".repeat(64), remaining, budget);
    let bytes = make(1_000_000, &mut stage()).unwrap();
    let reports = 23;
    for delta in [0, 1] {
        let allowance = project_allowance((reports + bytes.len() - delta) as u64, reports as u64).unwrap();
        let mut budget = stage();
        let (result, events) = observed(|| make(allowance, &mut budget));
        assert!(events.iter().all(|(kind, len)| *kind == "canonical" && *len <= allowance));
        if delta == 0 {
            assert_eq!(result.unwrap(), bytes);
            assert_eq!(budget.used, bytes.len());
        } else {
            assert_eq!(result.unwrap_err().code.as_str(), "LLS8002");
            assert!(events.iter().all(|(_, len)| *len < allowance), "body must leave room for LF before every append");
            assert_eq!(budget.used, 0);
        }
    }
    let (result, events) = observed(|| project_allowance(22, reports as u64));
    assert_eq!(result.unwrap_err().code.as_str(), "LLS8002");
    assert!(events.is_empty());
    let mut exhausted = Stage::new(Instant::now(), 300_000, 0);
    let (result, events) = observed(|| make(1_000_000, &mut exhausted));
    assert_eq!(result.unwrap_err().code.as_str(), "LLB6008");
    assert!(events.is_empty());
}

#[test]
fn fix1_bounded_canonical_writer_matches_original_bytes() {
    let controls: String = (0..32).map(char::from).collect();
    let value = serde_json::json!({"z": [true, false, -9223372036854775808i64, 9223372036854775807i64], "a": [controls, "é café\\\""], "empty": {}});
    let original = crate::artifact::canonical_json::Json::parse(&serde_json::to_vec(&value).unwrap()).unwrap().to_file_bytes();
    let (result, events) = observed(|| canonical(&value, original.len()));
    assert_eq!(result.unwrap(), original);
    assert!(events.iter().all(|(_, len)| *len <= original.len()));
    let (result, events) = observed(|| canonical(&value, 0));
    assert!(matches!(result, Err(CanonicalFailure::Budget)));
    assert!(events.is_empty());
    let mut writer = ByteWriter { bytes: Vec::new(), limit: 3, exhausted: false };
    use std::io::Write;
    writer.write_all(b"abc").unwrap();
    assert!(writer.write_all(b"d").is_err());
    assert_eq!(writer.bytes, b"abc");
}

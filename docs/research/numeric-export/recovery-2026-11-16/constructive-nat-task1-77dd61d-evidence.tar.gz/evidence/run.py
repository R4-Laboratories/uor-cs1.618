import os,sys,subprocess,time,json,signal,pathlib
root=pathlib.Path('/workspace/diagnostic-tools/constructive-nat-task1'); evidence=root/'evidence'; baseline=json.loads((evidence/'baseline.json').read_text()); label=sys.argv[1]; args=sys.argv[2:]
env=dict(os.environ,CARGO_HOME='/workspace/diagnostic-tools/cargo-home',CARGO_TARGET_DIR='/workspace/diagnostic-tools/lexlean-target',CARGO_BUILD_JOBS='2',CARGO_INCREMENTAL='0',RUSTC='/workspace/diagnostic-tools/rust-1.97.1/bin/rustc',PATH='/workspace/diagnostic-tools/rust-1.97.1/bin:/workspace/diagnostic-tools/lean-4.32.1-linux/bin:/usr/bin:/bin')
started=time.time(); killed=None; samples=[]
def sizes(p):
 return sum(f.stat().st_size for f in p.rglob('*') if f.is_file())
def measure():
 free=os.statvfs(root).f_bavail*os.statvfs(root).f_frsize; growth=sizes(root)+sizes(pathlib.Path(env['CARGO_TARGET_DIR']))-baseline['cache_bytes_before']; samples.append({'seconds':time.time()-started,'free':free,'growth':growth});return free,growth
free,growth=measure()
if free<8*1024**3 or growth>512*1024**2: sys.exit('RESOURCE STOP before start')
with (evidence/(label+'.stdout')).open('wb') as out,(evidence/(label+'.stderr')).open('wb') as err:
 p=subprocess.Popen(args,cwd=root/'package',env=env,stdout=out,stderr=err,start_new_session=True)
 while p.poll() is None:
  time.sleep(1)
  if int(time.time()-started)%5==0:
   free,growth=measure()
   if free<8*1024**3+16*1024**2 or growth>500*1024**2 or time.time()-started>360 or out.tell()+err.tell()>16*1024**2:
    killed='RESOURCE/TIME/OUTPUT STOP';os.killpg(p.pid,signal.SIGTERM);p.wait(timeout=10)
 rc=p.wait()
measure();(evidence/(label+'.json')).write_text(json.dumps({'argv':args,'environment':{k:env[k] for k in ['CARGO_HOME','CARGO_TARGET_DIR','CARGO_BUILD_JOBS','CARGO_INCREMENTAL','RUSTC','PATH']},'cwd':str(root/'package'),'exit':rc,'stop':killed,'samples':samples},indent=2)+'\n');print(label,'exit',rc,'stop',killed,'last',samples[-1]);print((evidence/(label+'.stdout')).read_text()[-8000:]);print((evidence/(label+'.stderr')).read_text()[-8000:]);sys.exit(rc if not killed else 99)

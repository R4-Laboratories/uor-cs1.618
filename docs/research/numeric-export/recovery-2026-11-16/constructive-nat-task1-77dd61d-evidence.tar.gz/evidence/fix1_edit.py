from pathlib import Path
R=Path('/workspace/diagnostic-tools/constructive-nat-task1/package')
p=R/'src/backend/constructive_nat/emit.rs';s=p.read_text();s=s.replace('struct Text(String);','struct Text(String, usize);').replace('> PROOF_BYTES','> self.1').replace('        self.0.push_str(s);','        self.0.push_str(s);\n        #[cfg(test)]\n        super::observe_output("proof", self.0.len());');s=s.replace('Text(String::new())','Text(String::new(), PROOF_BYTES)');s=s.replace('let mut out = Text(String::new(), PROOF_BYTES);\n    let mut render','let mut out = Text(String::new(), PROOF_BYTES.min(stage.remaining()));\n    let mut render')
for a,b in [('Nat.','_root_.Nat.'),('Eq.','_root_.Eq.'),('of_decide_eq_true','_root_.of_decide_eq_true'),('congrArg','_root_.congrArg'),(': Nat',': _root_.Nat'),('refl true','refl _root_.Bool.true')]:s=s.replace(a,b)
p.write_text(s)
p=R/'src/backend/constructive_nat/mod.rs';s=p.read_text();s=s.replace('    fn charge(&mut self, n: usize) -> Result<(), String> {','    fn remaining(&self) -> usize {\n        self.max_bytes - self.used\n    }\n    fn charge(&mut self, n: usize) -> Result<(), String> {')
a=s.index('fn canonical<T: Serialize>');z=s.index('\nfn compile_checked(',a)
s=s[:a]+'''#[cfg(test)]
thread_local! {
    static OUTPUT_OBSERVATIONS: std::cell::RefCell<Option<Vec<(&'static str, usize)>>> = const { std::cell::RefCell::new(None) };
}
#[cfg(test)]
fn observe_output(kind: &'static str, len: usize) {
    OUTPUT_OBSERVATIONS.with_borrow_mut(|events| {
        if let Some(events) = events { events.push((kind, len)); }
    });
}
#[derive(Debug)]
enum CanonicalFailure {
    Budget,
    Invalid(String),
}
impl From<CanonicalFailure> for String {
    fn from(failure: CanonicalFailure) -> Self {
        match failure {
            CanonicalFailure::Budget => "canonical certificate byte limit".into(),
            CanonicalFailure::Invalid(reason) => reason,
        }
    }
}
struct ByteWriter {
    bytes: Vec<u8>,
    limit: usize,
    exhausted: bool,
}
impl std::io::Write for ByteWriter {
    fn write(&mut self, bytes: &[u8]) -> std::io::Result<usize> {
        if self.bytes.len().checked_add(bytes.len()).is_none_or(|n| n > self.limit) {
            self.exhausted = true;
            return Err(std::io::Error::other("certificate serialization byte limit"));
        }
        self.bytes.extend_from_slice(bytes);
        #[cfg(test)]
        observe_output("canonical", self.bytes.len());
        Ok(bytes.len())
    }
    fn flush(&mut self) -> std::io::Result<()> { Ok(()) }
}
// Serialize the original restricted Json value directly into a bounded writer.
// Its BTreeMap supplies the exact canonical key order; serde_json emits the same
// minimal UTF-8/string escapes and i64 representation as the original Json writer.
// No unbounded canonical String/file Vec is constructed before checking its size.
struct CanonicalJson<'a>(&'a crate::artifact::canonical_json::Json);
impl Serialize for CanonicalJson<'_> {
    fn serialize<S: serde::Serializer>(&self, serializer: S) -> Result<S::Ok, S::Error> {
        use crate::artifact::canonical_json::Json;
        use serde::ser::{SerializeMap, SerializeSeq};
        match self.0 {
            Json::Bool(value) => serializer.serialize_bool(*value),
            Json::Int(value) => serializer.serialize_i64(*value),
            Json::Str(value) => serializer.serialize_str(value),
            Json::Arr(items) => {
                let mut seq = serializer.serialize_seq(Some(items.len()))?;
                for item in items { seq.serialize_element(&CanonicalJson(item))?; }
                seq.end()
            }
            Json::Obj(items) => {
                let mut map = serializer.serialize_map(Some(items.len()))?;
                for (key, value) in items { map.serialize_entry(key, &CanonicalJson(value))?; }
                map.end()
            }
        }
    }
}
fn canonical<T: Serialize>(value: &T, limit: usize) -> Result<Vec<u8>, CanonicalFailure> {
    use std::io::Write;
    // Reserve the file LF before even the first serialization pass.
    let body_limit = limit.checked_sub(1).ok_or(CanonicalFailure::Budget)?;
    let mut writer = ByteWriter { bytes: Vec::new(), limit: body_limit, exhausted: false };
    serde_json::to_writer(&mut writer, value).map_err(|error| {
        if writer.exhausted { CanonicalFailure::Budget } else { CanonicalFailure::Invalid(error.to_string()) }
    })?;
    let json = crate::artifact::canonical_json::Json::parse(&writer.bytes).map_err(CanonicalFailure::Invalid)?;
    // Reuse the allocation while keeping both passes bounded before each append.
    writer.bytes.clear();
    serde_json::to_writer(&mut writer, &CanonicalJson(&json)).map_err(|error| {
        if writer.exhausted { CanonicalFailure::Budget } else { CanonicalFailure::Invalid(error.to_string()) }
    })?;
    writer.limit = limit;
    writer.write_all(b"\\n").map_err(|_| CanonicalFailure::Budget)?;
    Ok(writer.bytes)
}
''' +s[z:]
s=s.replace('let remaining = stage.max_bytes - stage.used;','let remaining = stage.remaining();')
s=s.replace('pub(crate) fn artifact(\n','pub(crate) fn project_allowance(max_bytes: u64, report_total: u64) -> Result<usize, Diagnostic> {\n    let remaining = max_bytes.checked_sub(report_total).ok_or_else(project_budget_diagnostic)?;\n    Ok(usize::try_from(remaining).unwrap_or(usize::MAX))\n}\nfn project_budget_diagnostic() -> Diagnostic {\n    Diagnostic::new(code!("LLS8002"), "constructive certificate exceeds cumulative output budget")\n}\npub(crate) fn artifact(\n')
s=s.replace('    semantic_id: String,\n    stage: &mut Stage,\n) -> Result<Vec<u8>, Diagnostic>','    semantic_id: String,\n    project_remaining: usize,\n    stage: &mut Stage,\n) -> Result<Vec<u8>, Diagnostic>')
s=s.replace('    let bytes = canonical(&artifact, stage.max_bytes - stage.used).map_err(diagnostic)?;','    let stage_remaining = stage.remaining();\n    let bytes = canonical(&artifact, stage_remaining.min(project_remaining)).map_err(|failure| {\n        match failure {\n            CanonicalFailure::Budget if project_remaining <= stage_remaining => project_budget_diagnostic(),\n            other => diagnostic(other.into()),\n        }\n    })?;')
p.write_text(s)
p=R/'src/api.rs';s=p.read_text();old='        let bytes = crate::backend::constructive_nat::artifact(constructive_rows, checked.source_id.to_hex(), checked.semantic_id.to_hex(), &mut constructive_stage).map_err(LexLeanError::from_diagnostic)?;';new='''        let certificate_allowance = crate::backend::constructive_nat::project_allowance(
            project.config.limits.max_total_source_bytes, report_total,
        ).map_err(LexLeanError::from_diagnostic)?;
        let bytes = crate::backend::constructive_nat::artifact(
            constructive_rows, checked.source_id.to_hex(), checked.semantic_id.to_hex(),
            certificate_allowance, &mut constructive_stage,
        ).map_err(LexLeanError::from_diagnostic)?;''';assert old in s;s=s.replace(old,new);p.write_text(s)

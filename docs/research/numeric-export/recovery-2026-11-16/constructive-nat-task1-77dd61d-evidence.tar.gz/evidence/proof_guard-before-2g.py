"""Task-owned diagnostic subprocess owner. No SDK/admission claim."""
from pathlib import Path
import os,subprocess,time,signal,json
ROOT=Path('/workspace/diagnostic-tools/constructive-nat-task1')
RSS_LIMIT=1024**3
OUTPUT_LIMIT=16*1024**2
class ProofOwner:
 def __init__(self,label,seconds=300):
  self.label=label;self.started=time.monotonic();self.deadline=self.started+min(seconds,300);self.commands=[]
 def run(self,label,args,cwd,env,seconds=None):
  start=time.monotonic();deadline=min(self.deadline,start+seconds) if seconds is not None else self.deadline
  stdout=ROOT/'evidence'/f'{self.label}-{label}.stdout';stderr=ROOT/'evidence'/f'{self.label}-{label}.stderr'
  record={'argv':args,'cwd':str(cwd),'environment':{k:env[k] for k in ['PATH','LEAN_PATH'] if k in env},'stdout':stdout.name,'stderr':stderr.name,'rss_limit_bytes':RSS_LIMIT,'output_limit_bytes':OUTPUT_LIMIT,'samples':[]};p=None;reason=None
  try:
   with stdout.open('wb',buffering=0) as out,stderr.open('wb',buffering=0) as err:
    if start>=deadline:reason='deadline-before-spawn'
    else:
     p=subprocess.Popen(args,cwd=cwd,env=env,stdout=out,stderr=err,start_new_session=True)
     record['pid']=p.pid
     while True:
      rss=0;members=[]
      for entry in Path('/proc').iterdir():
       if not entry.name.isdigit():continue
       try:
        stat=(entry/'stat').read_text();fields=stat[stat.rfind(')')+2:].split()
        if int(fields[2])!=p.pid or fields[0]=='Z':continue
        mem=(entry/'statm').read_text().split();rss+=int(mem[1])*os.sysconf('SC_PAGE_SIZE');members.append(int(entry.name))
       except (FileNotFoundError,ProcessLookupError,PermissionError,IndexError,ValueError):pass
      size=stdout.stat().st_size+stderr.stat().st_size
      sample={'seconds':time.monotonic()-start,'rss_bytes':rss,'output_bytes':size,'members':members};record['samples'].append(sample)
      if rss>=RSS_LIMIT:reason='combined-rss-limit'
      elif size>OUTPUT_LIMIT:reason='live-output-limit'
      elif time.monotonic()>=deadline:reason='cumulative-or-command-deadline'
      if reason:break
      if p.poll() is not None and not members:break
      if p.poll() is not None:
       if any(member!=p.pid for member in members):reason='descendants-remain-after-child-exit'
       break
      time.sleep(.1)
  except BaseException as exc:
   reason='owner-exception:'+type(exc).__name__+':'+str(exc)
  finally:
   if p is not None:
    if reason or p.poll() is None:
     try:os.killpg(p.pid,signal.SIGTERM)
     except ProcessLookupError:pass
     try:p.wait(timeout=2)
     except subprocess.TimeoutExpired:
      try:os.killpg(p.pid,signal.SIGKILL)
      except ProcessLookupError:pass
      p.wait(timeout=2)
     # Reap any owned descendants even if the direct child exited on TERM.
     try:os.killpg(p.pid,signal.SIGKILL)
     except ProcessLookupError:pass
    record['exit']=p.wait()
   else:record['exit']=None
   record['stop']=reason;record['seconds']=time.monotonic()-start;record['stage_seconds']=time.monotonic()-self.started;record['max_rss_bytes']=max((x['rss_bytes'] for x in record['samples']),default=0);self.commands.append(record)
   (ROOT/'evidence'/f'{self.label}-commands.json').write_text(json.dumps({'component_only':True,'stage_limit_seconds':self.deadline-self.started,'commands':self.commands},indent=2)+'\n')
  print(label,record['exit'],reason,'RSS',record['max_rss_bytes'],'seconds',record['seconds'],flush=True)
  return record

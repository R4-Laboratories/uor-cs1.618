from proof_guard import *
import sys
label=sys.argv[1];project=ROOT/'fixtures'/label;build=next((project/'.lexlean/build').iterdir());out=ROOT/'generated'/label;out.mkdir(parents=True,exist_ok=False);env=dict(os.environ,PATH='/workspace/diagnostic-tools/lean-4.32.1-linux/bin:/usr/bin:/bin',LEAN_PATH=str(out)+':/workspace/diagnostic-tools/canonical-packaging-combined-v3/mul64/lean-work/.lake/build/lib/lean');owner=ProofOwner(label,120)
for name in ['Small','Add','Equal','Unequal','Nested']:
 dest=out/'MicroControl'/f'{name}.olean';dest.parent.mkdir(exist_ok=True)
 owner.run(name,['/workspace/diagnostic-tools/lean-4.32.1-linux/bin/lean','-o',str(dest),f'MicroControl/{name}.lean'],build/'modules',env,seconds=15)
print([(r['argv'][-1],r['exit'],r['stop']) for r in owner.commands])

from pathlib import Path
import json,hashlib,difflib,subprocess,os,shutil
ROOT=Path('/workspace/diagnostic-tools/constructive-nat-task1');E=ROOT/'evidence';PKG=ROOT/'package';BASE=Path('/workspace/scratch/prismpm-numeric/vendor/lexlean');GAME=Path('/workspace/scratch/cs-numeric-kernels');OUT=GAME/'scripts/numeric/constructive-proof-candidate'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,d):p.write_text(json.dumps(d,indent=2)+'\n')
b=json.loads((E/'baseline.json').read_text());old=json.loads((E/'component-inventory-current.json').read_text())
assert subprocess.check_output(['git','-C',str(BASE),'status','--porcelain=v1'])==b''
for f in b['pristine']:assert sha(BASE/f['path'])==f['sha256']
for f in old['files']:assert sha(PKG/f['path'])==f['sha256']
assert os.statvfs(ROOT).f_bavail*os.statvfs(ROOT).f_frsize>8*1024**3
OUT.mkdir(parents=True,exist_ok=True)
chunks=[]
for rel in sorted(old['changed']+old['added']+old['removed']):
 a=BASE/rel;z=PKG/rel;left=a.read_text().splitlines(keepends=True) if a.exists() else [];right=z.read_text().splitlines(keepends=True) if z.exists() else []
 chunks.append('diff --git a/'+rel+' b/'+rel+'\n')
 if not a.exists():chunks.append('new file mode 100644\n')
 if not z.exists():chunks.append('deleted file mode 100644\n')
 for line in difflib.unified_diff(left,right,fromfile='a/'+rel if a.exists() else '/dev/null',tofile='b/'+rel if z.exists() else '/dev/null'):
  chunks.append(line if line.endswith('\n') else line+'\n\\ No newline at end of file\n')
patch=OUT/'lexlean-constructive-task1.patch';patch.write_text(''.join(chunks))
# Affected files only, never a duplicate full package or original worktree mutation.
check=ROOT/'generated/patch-apply-check';assert not check.exists();check.mkdir()
for rel in old['changed']+old['removed']:
 p=check/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(BASE/rel,p)
records=[]
for args in [['git','apply','--check',str(patch)],['git','apply',str(patch)]]:
 p=subprocess.run(args,cwd=check,capture_output=True,text=True,timeout=30);records.append({'argv':args,'cwd':str(check),'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr});assert p.returncode==0,p.stderr
for rel in old['changed']+old['added']:assert (check/rel).read_bytes()==(PKG/rel).read_bytes()
for rel in old['removed']:assert not(check/rel).exists()
dump(E/'patch-application.json',{'component_only':True,'patch_sha256':sha(patch),'changed':old['changed'],'added':old['added'],'removed':old['removed'],'commands':records,'all_affected_output_bytes_match':True,'original_source_untouched':True,'validation_copy_scope':'affected files only; retained generated/patch-apply-check'})
old['candidate_cli_retained']=True;old['candidate_cli_sha256']='809655b1688dfb6847c86159fcd6a2bee7de98a7f93e0e016dcf559a5cd31f89';old['candidate_integration_elf_retained']=True;old['candidate_libtest_elf_retained']=False
dump(E/'component-inventory-final.json',old)
dump(OUT/'candidate-package-inventory.json',old)
dump(OUT/'pristine-package-inventory.json',{'development_commit':b['development_commit'],'development_tree':b['development_tree'],'package_root':'vendor/lexlean','upstream_revision':'e0b74b81e6f49c83596a957d232c8383a5db1a25','archive_sha256':'f2d579289052493d2c68274b10015d2cce544a78fbb876d73062184f09fb0a18','package_manifest_sha256':'dd35c1b0359c90c5896c5188c9e10bb4008883cb21ee92d35bc2fd4c8d4ac759','files':b['pristine']})
shutil.copyfile(E/'tool-identities.json',OUT/'tool-identities.json')
print('patch bytes',patch.stat().st_size,'affected paths',len(old['changed'])+len(old['added'])+len(old['removed']),'basefiles',len(b['pristine']),'candidatefiles',len(old['files']))

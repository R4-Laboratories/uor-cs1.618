from pathlib import Path
import os,sys,json,subprocess,time,hashlib
root=Path('/workspace/diagnostic-tools/constructive-nat-task1');label=sys.argv[1];project=Path(sys.argv[2]);binary=sys.argv[3]
env=dict(os.environ,PATH='/workspace/diagnostic-tools/rust-1.97.1/bin:/workspace/diagnostic-tools/lean-4.32.1-linux/bin:/usr/bin:/bin');start=time.monotonic();commands=[]
for i,args in enumerate([['--version'],['lock'],['fmt'],['fmt','--check'],['lock','--check'],['check'],['build']]):
 cmd=[binary,'--project',str(project/'lexlean.toml'),*args];remaining=300-(time.monotonic()-start)
 if remaining<=0:raise SystemExit('cumulative 300s fixture stage exhausted')
 r=subprocess.run(cmd,cwd=project,env=env,capture_output=True,timeout=remaining)
 if len(r.stdout)+len(r.stderr)>16777216:raise SystemExit('output limit')
 (root/'evidence'/f'{label}-{i}.stdout').write_bytes(r.stdout);(root/'evidence'/f'{label}-{i}.stderr').write_bytes(r.stderr)
 commands.append({'argv':cmd,'cwd':str(project),'exit':r.returncode,'stdout':f'{label}-{i}.stdout','stderr':f'{label}-{i}.stderr','seconds_from_stage_start':time.monotonic()-start})
 (root/'evidence'/f'{label}-commands.json').write_text(json.dumps({'environment':{'PATH':env['PATH']},'commands':commands},indent=2)+'\n')
 print(args,'exit',r.returncode,r.stdout.decode()[-1500:],r.stderr.decode()[-2000:])
 if r.returncode:sys.exit(r.returncode)

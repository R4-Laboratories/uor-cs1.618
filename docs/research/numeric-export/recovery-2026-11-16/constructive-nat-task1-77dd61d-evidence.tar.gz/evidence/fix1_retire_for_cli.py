from pathlib import Path
import hashlib,json
R=Path('/workspace/diagnostic-tools/constructive-nat-task1');E=R/'evidence';T=Path('/workspace/diagnostic-tools/lexlean-target/release/deps');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
receipt=json.loads((E/'fix1-green-tests-corrected.json').read_text());assert receipt['exit']==0 and receipt['stop'] is None
original=json.loads((E/'original-artifacts-current.json').read_text())
def check():
 for x in original:
  p=Path(x['path'])
  if 'sha256' in x:assert sha(p)==x['sha256']
  else:assert not p.exists()
check();paths=[T/'liblexlean_constructive_diagnostic-910ff143c3cac728.rlib',T/'liblexlean_constructive_diagnostic-910ff143c3cac728.rmeta',T/'lexlean_constructive_diagnostic-fb1afe7df53ef029'];rows=[]
for p in paths:
 st=p.stat();assert st.st_nlink==1;rows.append({'path':str(p),'bytes':st.st_size,'inode':st.st_ino,'nlink':st.st_nlink,'sha256':sha(p)})
receipt={'component_only':True,'authorization':'parent exact candidate rlib/rmeta plus completed test ELF retirement after focused tests','provenance':{'library':'distinct candidate lib target; original liblexlean-a94b64ad71245838 files separately hashed and untouched','tests':'fix1-green-tests-corrected receipt: completed focused suite'},'files':rows,'original_artifacts_unchanged':True}
(E/'fix1-retired-for-cli.json').write_text(json.dumps(receipt,indent=2)+'\n')
for p in paths:p.unlink()
check();print('retired candidate-only bytes',sum(x['bytes'] for x in rows))

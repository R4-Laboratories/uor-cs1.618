from proof_guard import *
import hashlib,json
E=ROOT/'evidence';rows=[]
for line in (E/'fix1-integration-build.stdout').read_text().splitlines():
 try:row=json.loads(line)
 except ValueError:continue
 if row.get('reason')=='compiler-artifact' and row.get('target',{}).get('name')=='unit' and row.get('executable'):rows.append(row)
assert len(rows)==1;artifact=rows[0];elf=Path(artifact['executable']);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();before=sha(elf);env=dict(os.environ,PATH='/workspace/diagnostic-tools/lean-4.32.1-linux/bin:/usr/bin:/bin');owner=ProofOwner('fix1-integration',30,rss_limit=2*1024**3,cgroup_reserve=4*1024**3)
for name in ['canonical_json_is_restricted','axiom_parser_matches_the_golden_vectors']:
 rec=owner.run(name,[str(elf),name,'--exact','--nocapture'],ROOT/'package',env);assert rec['exit']==0 and rec['stop'] is None;output=(E/('fix1-integration-'+name+'.stdout')).read_text();assert '1 passed; 0 failed; 0 ignored' in output
assert sha(elf)==before
(E/'fix1-integration-result.json').write_text(json.dumps({'status':'PASS','component_only':True,'artifact':artifact,'elf':{'path':str(elf),'bytes':elf.stat().st_size,'sha256':before},'selectors':['canonical_json_is_restricted','axiom_parser_matches_the_golden_vectors'],'test_source_sha256':sha(ROOT/'package/tests/unit.rs'),'scope':'actual candidate integration ELF; exact pure selectors only; no CLI invocation or SDK qualification'},indent=2)+'\n')

from proof_guard import *
import sys,shutil,hashlib
label=sys.argv[1];project=ROOT/'fixtures'/label;assert not project.exists();project.mkdir();(project/'src').mkdir()
old=ROOT/'fixtures/positive-direct'
for n in ['lean-toolchain','lakefile.toml','lake-manifest.json']:shutil.copyfile(old/n,project/n)
config=(old/'lexlean.toml').read_text().replace('ConstructiveComponent','HygieneComponent').replace('entrypoints = ["src/Bounds.lex.tex", "src/Compatibility.lex.tex", "src/Generic.lex.tex"]','entrypoints = ["src/BinderCongr.lex.tex", "src/BinderDecide.lex.tex", "src/Namespace.lex.tex"]');(project/'lexlean.toml').write_text(config)
def theorem(name,params,statement):return f'theorem{{\n name: {name},\n parameters: [{params}],\n statement: {statement},\n proof: linear_arithmetic{{}},\n axioms: []\n}}\n'
def module(name,body):(project/'src'/f'{name}.lex.tex').write_text('\\begin{lexlean}{'+name+'}\n\\useglossary{lexlean.std.nat@1.2.0}\n\\title{addition}\n\\begin{semanticmodule}\n'+body+'\\end{semanticmodule}\n\\end{lexlean}\n')
module('BinderDecide',theorem('bound','of_decide_eq_true : Nat','((of_decide_eq_true <= 3) -> (of_decide_eq_true <= 4))'))
module('BinderCongr',theorem('bound','congrArg : Nat, y : Nat, result : Nat','((congrArg < y) -> (((y + result) = (congrArg + congrArg)) -> (result < y)))'))
module('Namespace',theorem('of_decide_eq_true','x : Nat','((x <= 1) -> (x <= 1))')+theorem('congrArg','x : Nat','((x <= 1) -> (x <= 1))')+theorem('literalBound','x : Nat','((x <= 3) -> (x <= 4))')+theorem('rewriteBound','x : Nat, y : Nat, result : Nat','((x < y) -> (((y + result) = (x + x)) -> (result < y)))'))
env=dict(os.environ,PATH='/workspace/diagnostic-tools/lean-4.32.1-linux/bin:/usr/bin:/bin',LEAN_NUM_THREADS='1');owner=ProofOwner(label,300,rss_limit=2*1024**3,cgroup_reserve=4*1024**3);cli='/workspace/diagnostic-tools/lexlean-target/release/lexlean-constructive-diagnostic'
for name,args in [('lock',['lock']),('fmt',['fmt']),('check',['check']),('build',['build'])]:
 rec=owner.run(name,[cli,*args],project,env,seconds=30);assert rec['exit']==0 and not rec['stop'],rec
build=next((project/'.lexlean/build').iterdir());out=ROOT/'generated'/label;(out/'HygieneComponent').mkdir(parents=True);env['LEAN_PATH']=str(out)+':/workspace/diagnostic-tools/laws-investigation/no-c/.lake/build/lib/lean'
for name in ['BinderDecide','BinderCongr','Namespace']:
 owner.run('lean-'+name,['/workspace/diagnostic-tools/lean-4.32.1-linux/bin/lean','-o',str(out/'HygieneComponent'/f'{name}.olean'),f'HygieneComponent/{name}.lean'],build/'modules',env,seconds=30)
print([(r['argv'][-1],r['exit'],r['stop']) for r in owner.commands])

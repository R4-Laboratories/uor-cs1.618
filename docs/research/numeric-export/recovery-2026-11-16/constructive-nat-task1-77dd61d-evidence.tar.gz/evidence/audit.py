from pathlib import Path
import os,sys,json,hashlib,time,subprocess
root=Path('/workspace/diagnostic-tools/constructive-nat-task1');build=next((root/'fixtures/positive/.lexlean/build').iterdir());out=root/'generated/oleans';out.mkdir(parents=True,exist_ok=False);runtime=Path('/workspace/diagnostic-tools/canonical-packaging-combined-v3/mul64/lean-work/.lake/build/lib/lean');env=dict(os.environ,PATH='/workspace/diagnostic-tools/lean-4.32.1-linux/bin:/usr/bin:/bin',LEAN_PATH=str(out)+':'+str(runtime));lean='/workspace/diagnostic-tools/lean-4.32.1-linux/bin/lean';checker='/workspace/diagnostic-tools/lean-4.32.1-linux/bin/leanchecker';start=time.monotonic();commands=[];cert=json.loads((build/'proofs/constructive-nat.json').read_text());mods=sorted({r['module'] for r in cert['rows']})
def run(label,args,cwd):
 rem=300-(time.monotonic()-start)
 if rem<=0:raise SystemExit('cumulative 300s proof-audit stage exhausted')
 r=subprocess.run(args,cwd=cwd,env=env,capture_output=True,timeout=rem)
 if len(r.stdout)+len(r.stderr)>16777216:raise SystemExit('audit output limit')
 (root/'evidence'/f'{label}.stdout').write_bytes(r.stdout);(root/'evidence'/f'{label}.stderr').write_bytes(r.stderr);commands.append({'argv':args,'cwd':str(cwd),'exit':r.returncode,'stdout':label+'.stdout','stderr':label+'.stderr','seconds_from_stage_start':time.monotonic()-start});(root/'evidence/lean-audit-commands.json').write_text(json.dumps({'environment':{'PATH':env['PATH'],'LEAN_PATH':env['LEAN_PATH']},'commands':commands},indent=2)+'\n');print(label,r.returncode,r.stdout.decode()[-5000:],r.stderr.decode()[-3000:]);
 if r.returncode:sys.exit(r.returncode)
 return r.stdout.decode()
for mod in mods:
 rel=Path(mod.replace('.','/'));dest=(out/rel).with_suffix('.olean');dest.parent.mkdir(parents=True,exist_ok=True);run('lean-'+mod,[lean,'-o',str(dest),str(rel.with_suffix('.lean'))],build/'modules');run('leanchecker-'+mod,[checker,mod],out)
audit=root/'generated/AxiomAudit.lean';audit.write_text('module\n'+''.join('import '+m+'\n' for m in mods)+''.join('#print axioms '+r['module']+'.'+r['theorem']+'\n' for r in cert['rows']));text=run('axiom-audit',[lean,str(audit)],root/'generated');expected={r['module']+'.'+r['theorem'] for r in cert['rows']};actual=set()
for line in text.splitlines():
 if line.endswith("' does not depend on any axioms") and line.startswith("'"):actual.add(line.split("'")[1])
 else:raise SystemExit('unexpected axiom audit output: '+line)
assert actual==expected,(actual,expected)
(root/'evidence/lean-audit-result.json').write_text(json.dumps({'component_only':True,'compiled_modules':mods,'empty_axiom_theorems':sorted(actual),'total_seconds':time.monotonic()-start,'generated_helpers':'Only local proof/term bindings; no additional top-level helper declarations.'},indent=2)+'\n');print('PASS:',len(actual),'exact empty axiom sets; no sorryAx')

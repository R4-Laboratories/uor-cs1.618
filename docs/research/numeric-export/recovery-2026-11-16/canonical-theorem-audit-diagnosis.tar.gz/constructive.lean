import Init
set_option autoImplicit false
namespace Diagnostic
 theorem limbAddBound (a b carry : Nat) (ha : a <= 4294967295) (hb : b <= 4294967295) (hc : carry <= 1) : a + b + carry <= 8589934591 :=
  Nat.add_le_add (Nat.add_le_add ha hb) hc
 theorem cellAddBound (product out carry : Nat) (hp : product <= 18446744065119617025) (ho : out <= 4294967295) (hc : carry <= 4294967295) : product + out + carry <= 18446744073709551615 :=
  Nat.add_le_add (Nat.add_le_add hp ho) hc
 theorem divDoubleRemainderBound (r d : Nat) (hr : r < d) (hd : d <= 9007199254740991) : r + r <= 18014398509481982 :=
  Nat.add_le_add (Nat.le_trans (Nat.le_of_lt hr) hd) (Nat.le_trans (Nat.le_of_lt hr) hd)
 theorem divReducedRemainderBound (r d reduced : Nat) (hr : r < d) (he : r + r = reduced + d) : reduced < d := by
  have h : reduced + d < r + d := he ▸ Nat.add_lt_add_left hr r
  exact Nat.lt_trans (Nat.lt_of_add_lt_add_right h) hr
 theorem divQuotientStepBound (q : Nat) (hq : q <= 18014398509481983) : q + q + 1 <= 36028797018963967 :=
  Nat.add_le_add (Nat.add_le_add hq hq) (Nat.le_refl 1)
end Diagnostic
#print axioms Diagnostic.limbAddBound
#print axioms Diagnostic.cellAddBound
#print axioms Diagnostic.divDoubleRemainderBound
#print axioms Diagnostic.divReducedRemainderBound
#print axioms Diagnostic.divQuotientStepBound

import Init
namespace DiagnosticOmega
theorem limbAddBound (a : Nat) (b : Nat) (carry : Nat) : ((a <= 4294967295) -> ((b <= 4294967295) -> ((carry <= 1) -> (((a + b) + carry) <= 8589934591)))) := by
  omega
theorem cellAddBound (product : Nat) (out : Nat) (carry : Nat) : ((product <= 18446744065119617025) -> ((out <= 4294967295) -> ((carry <= 4294967295) -> (((product + out) + carry) <= 18446744073709551615)))) := by
  omega
theorem divDoubleRemainderBound (r : Nat) (d : Nat) : ((r < d) -> ((d <= 9007199254740991) -> ((r + r) <= 18014398509481982))) := by
  omega
theorem divReducedRemainderBound (r : Nat) (d : Nat) (reduced : Nat) : ((r < d) -> (((r + r) = (reduced + d)) -> (reduced < d))) := by
  omega
theorem divQuotientStepBound (q : Nat) : ((q <= 18014398509481983) -> (((q + q) + 1) <= 36028797018963967)) := by
  omega
end DiagnosticOmega
#print axioms DiagnosticOmega.cellAddBound
#print axioms DiagnosticOmega.divDoubleRemainderBound
#print axioms DiagnosticOmega.divQuotientStepBound
#print axioms DiagnosticOmega.divReducedRemainderBound
#print axioms DiagnosticOmega.limbAddBound

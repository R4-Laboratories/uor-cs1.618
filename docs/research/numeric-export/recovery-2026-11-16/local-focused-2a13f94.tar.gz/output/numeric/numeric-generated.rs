#![allow(dead_code)]

// Generated from Lean 4 module: Numeric

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Counter {
    pub value: u32,
    pub count: u32,
}

pub fn countStep(delta: u32, state: Option<crate::Counter>) -> Option<crate::Counter> {
    match state {
        None => state,
        Some(val_136) => { let _x_139 = (val_136).value; { let _x_140 = (_x_139).checked_add(delta); match _x_140 {
        None => None,
        Some(val_142) => { let _x_143 = (val_136).count; { let _x_144 = 1; { let _x_145 = (_x_143).checked_add(_x_144); match _x_145 {
        None => None,
        Some(val_147) => { let _x_148 = crate::Counter { value: val_142, count: val_147 }; { let _x_149 = Some(_x_148); _x_149 } },
    } } } },
    } } },
    }
}

pub fn counted(fuel: u64, delta: u32, x: u32) -> Option<crate::Counter> {
    { let _x_1 = 128; if (fuel <= _x_1) { { let _x_17 = 0; { let _x_11 = crate::Counter { value: x, count: _x_17 }; { let _x_12 = Some(_x_11); { let _x_13 = countedLoop(fuel, delta, _x_12); _x_13 } } } } } else { None } }
}

pub fn countedLoop(mut x_1: u64, x_2: u32, mut x_3: Option<crate::Counter>) -> Option<crate::Counter> {
    loop { return match x_1 {
        0 => x_3,
        _ => { let n_12 = (x_1).saturating_sub(1); { let _x_16 = countStep(x_2, x_3); { (x_1, x_3,) = (n_12, _x_16,); continue; } } },
    }; }
}

pub fn narrow(x: i64) -> Option<i16> {
    { let _x_4 = core::convert::TryFrom::try_from(x).ok(); _x_4 }
}

pub fn renamed(x: u32) -> Option<u64> {
    { let _x_3 = core::convert::TryFrom::try_from(x).ok(); _x_3 }
}

pub fn repeat4(x: u32) -> Option<u32> {
    { let _x_4 = step(x); match _x_4 {
        None => _x_4,
        Some(val_65) => { let _x_67 = step(val_65); match _x_67 {
        None => _x_67,
        Some(val_68) => { let _x_69 = step(val_68); match _x_69 {
        None => _x_69,
        Some(val_70) => { let _x_71 = step(val_70); _x_71 },
    } },
    } },
    } }
}

pub fn signedStep(x: i16) -> Option<i16> {
    { let _x_2 = 1; { let _x_7 = _x_2; { let _x_5 = (x).checked_add(_x_7); _x_5 } } }
}

pub fn signedTwice(x: i16) -> Option<i16> {
    { let _x_4 = signedStep(x); match _x_4 {
        None => _x_4,
        Some(val_49) => { let _x_51 = signedStep(val_49); _x_51 },
    } }
}

pub fn signedUnsigned(x: i16) -> Option<u32> {
    { let _x_4 = core::convert::TryFrom::try_from(x).ok(); _x_4 }
}

pub fn step(x: u32) -> Option<u32> {
    { let _x_7 = 1; { let _x_5 = (x).checked_add(_x_7); _x_5 } }
}

pub fn unsignedSigned(x: u16) -> Option<i64> {
    { let _x_4 = core::convert::TryFrom::try_from(x).ok(); _x_4 }
}

pub fn wideSigned(x: u64) -> Option<i64> {
    { let _x_4 = core::convert::TryFrom::try_from(x).ok(); _x_4 }
}

pub fn widen(x: u32) -> Option<u64> {
    { let _x_4 = core::convert::TryFrom::try_from(x).ok(); _x_4 }
}


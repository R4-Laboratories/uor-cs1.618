// Compiler-owned replay oracle. Implementations are generated from Lean LCNF.
#[path = "compute-error.rs"]
mod compute_error;
pub use compute_error::ComputeError;
#[path = "numeric-generated.rs"]
mod generated;
pub use generated::*;
#[path = "failure-generated.rs"]
mod unused;

#[unsafe(no_mangle)]
pub extern "C" fn numeric_check() -> u32 {
    for x in [0, 1, u32::MAX - 4, u32::MAX - 3, u32::MAX] {
        assert_eq!(repeat4(x), x.checked_add(4));
        assert_eq!(widen(x), Some(u64::from(x)));
        assert_eq!(renamed(x), Some(u64::from(x)));
    }
    for x in [i16::MIN, -1, 0, 1, i16::MAX - 2, i16::MAX - 1, i16::MAX] {
        assert_eq!(signedTwice(x), x.checked_add(2));
        assert_eq!(signedUnsigned(x), u32::try_from(x).ok());
    }
    for x in [i64::MIN, -32769, -32768, -1, 0, 32767, 32768, i64::MAX] {
        assert_eq!(narrow(x), i16::try_from(x).ok());
    }
    for x in [0, 1, u16::MAX] {
        assert_eq!(unsignedSigned(x), Some(i64::from(x)));
    }
    for x in [0, 1, i64::MAX as u64, (i64::MAX as u64) + 1, u64::MAX] {
        assert_eq!(wideSigned(x), i64::try_from(x).ok());
    }
    for fuel in [0, 1, 4, 127, 128] {
        for delta in [0, 1, 3] {
            let result = counted(fuel, delta, 7).unwrap();
            assert_eq!(result.value, 7 + (fuel as u32) * delta);
            assert_eq!(result.count, fuel as u32);
        }
    }
    assert!(counted(129, 1, 0).is_none());
    assert!(counted(1, 1, u32::MAX).is_none());
    assert_eq!(counted(0, 1, u32::MAX).unwrap().value, u32::MAX);
    assert_eq!(unused::unusedFailure(0), Err(ComputeError::AddOverflow));
    0
}

#[cfg(not(target_arch = "wasm32"))]
fn main() {
    assert_eq!(numeric_check(), 0);
}

import Prod.Export
import Conformance.NumericClosureFixture
run_meta do
  let live ← Prod.exportNames #[``NumericFixture.liveDictionary] "LiveDictionary"
  IO.FS.writeFile "../output/numeric-source-fix-round3/live-after.ir" live.ir
  IO.FS.writeFile "../output/numeric-source-fix-round3/live-after.coverage.json" live.coverage
  Lean.logInfo live.ir
  Lean.logInfo live.coverage

import pathlib,subprocess,json,hashlib
root=pathlib.Path('/workspace/scratch/prismpm-numeric'); out=pathlib.Path(__file__).parent
subjects=[('14-planted-ordering','tests/publication-context-linkage/capture-owner.mjs','    createCaptureLocator({sourceRoot:repository, work});\n','', 'component actual factory body'),
 ('15-planted-refusal','tests/publication-context-linkage/capture-retained-controls.mjs', "if (reader_result === 'refused') assert.throws(verifyTransport, readerCheck, id + ' direct reader rejection');", "if (reader_result === 'refused') {try {verifyTransport();} catch {}}", 'component runner refuses swallowed checks')]
rows=[]
for name,path,needle,replacement,pattern in subjects:
 p=root/path; original=p.read_bytes(); assert original.count(needle.encode())==1
 try:
  p.write_bytes(original.replace(needle.encode(),replacement.encode()))
  result=subprocess.run(['python3',str(out/'run.py'),name,'node','--test','--test-name-pattern='+pattern,'tests/publication-context-linkage/capture-retained-controls.test.mjs'],cwd=root)
  assert result.returncode==1, 'planted defect was not rejected'
 finally: p.write_bytes(original)
 assert p.read_bytes()==original
 rows.append({'path':path,'sha256_restored':hashlib.sha256(original).hexdigest(),'defect':name,'expected_exit':1})
(out/'planted-control.json').write_text(json.dumps(rows,indent=2)+'\n')

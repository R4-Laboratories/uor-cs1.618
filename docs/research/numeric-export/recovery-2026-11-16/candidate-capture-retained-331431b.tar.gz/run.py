import subprocess,json,pathlib,sys,time,hashlib,shutil
root=pathlib.Path('/workspace/scratch/prismpm-numeric'); out=pathlib.Path(__file__).parent
name=sys.argv[1]; argv=sys.argv[2:]
assert shutil.disk_usage(root).free >= 8*1024**3
started=time.time(); p=subprocess.run(argv,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
for stream,data in [('stdout',p.stdout),('stderr',p.stderr)]:
 assert len(data)<=2*1024**2, 'diagnostic bound exceeded'
 (out/(name+'.'+stream)).write_bytes(data)
row={'argv':argv,'cwd':str(root),'environment':'runner inherits host; child environment overrides, if any, are explicit in argv','exit':p.returncode,'seconds':round(time.time()-started,3),'free_bytes':shutil.disk_usage(root).free}
(out/(name+'.command.json')).write_text(json.dumps(row,indent=2)+'\n')
print(json.dumps(row)); print(p.stdout.decode(errors='replace')[-8000:]); print(p.stderr.decode(errors='replace')[-3000:]);sys.exit(p.returncode)

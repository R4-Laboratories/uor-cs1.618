import pathlib,hashlib,json,subprocess,shutil,re
root=pathlib.Path('/workspace/scratch/prismpm-numeric'); out=pathlib.Path(__file__).parent
base='f8808ad717a1582cd39d8c01bc452519a112afdd'
owned=['tests/publication-context-linkage/capture-owner.mjs','tests/publication-context-linkage/capture-retained-controls.mjs','tests/publication-context-linkage/capture-retained-controls.test.mjs','xtask/src/main.rs']
rows=json.loads((out/'protected-before.json').read_text()); changed=[]
for row in rows:
 p=root/row['path']; data=p.readlink().as_posix().encode() if row['kind']=='symlink' else p.read_bytes()
 if hashlib.sha256(data).hexdigest()!=row['sha256']: changed.append(row['path'])
assert sorted(changed)==sorted([owned[0],owned[3]])
prior=json.loads(pathlib.Path('/workspace/diagnostic-tools/candidate-capture-reader/fix-1/05-scope-audit.json').read_text())
protected=[]
for old in prior['protected']:
 path=old['path']
 if path in owned: continue
 data=(root/path).read_bytes(); original=subprocess.check_output(['git','show',base+':'+path],cwd=root)
 assert data==original
 protected.append(dict(path=path,bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),base_equal=True))
owner=(root/owned[0]).read_text(); original=subprocess.check_output(['git','show',base+':'+owned[0]],cwd=root,text=True)
assert owner.count('await prerequisite(')==original.count('await prerequisite(')
assert 't.test(' not in owner
node_suite=(root/'crates/conformance/src/cases/node_suite.rs').read_bytes()
assert node_suite==subprocess.check_output(['git','show',base+':crates/conformance/src/cases/node_suite.rs'],cwd=root)
register=(root/'crates/conformance/src/cases/mod.rs').read_text(); start=register.index('"OC-10" =>'); end=register.index('"OC-01" |',start)
section=register[start:end]; assert 'owner.test.mjs", 65' in section and 'capture-guard.test.mjs",\n                    2,' in section
focused=(root/owned[2]).read_text(); assert not re.search(r'(?:process\.env\[.*?\]|process\.env\.\w+)\s*=|delete\s+process\.env',focused)
xtask=(root/owned[3]).read_text(); xtask_original=subprocess.check_output(['git','show',base+':'+owned[3]],cwd=root,text=True)
assert xtask==xtask_original.replace('            "tests/publication-context-linkage/candidate-transport.test.mjs",','            "tests/publication-context-linkage/candidate-transport.test.mjs",\n            "tests/publication-context-linkage/capture-retained-controls.test.mjs",')
result=dict(base=base,owned=owned,protected=protected,all_tracked_baseline_members=len(rows),unchanged_nonowned_members=len(rows)-2,changed_existing=changed,original_oc10_counts=[65,2],original_node_boundary_code_identical=True,owner_prerequisite_calls=owner.count('await prerequisite('),new_global_environment_mutations=False,free_bytes=shutil.disk_usage(root).free)
assert result['free_bytes']>=8*1024**3
(out/'scope-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='protected'},indent=2))
tools=['/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node','/usr/bin/python3','/usr/bin/timeout','/workspace/diagnostic-tools/rust-1.97.1/bin/rustc','/workspace/scratch/prismpm-numeric/target/debug/prismpm-semantic-source']
measured=[]
for path in tools:
 p=pathlib.Path(path); body=p.read_bytes(); measured.append(dict(path=path,realpath=str(p.resolve()),bytes=len(body),sha256=hashlib.sha256(body).hexdigest()))
(out/'tool-hashes.json').write_text(json.dumps(measured,indent=2)+'\n')

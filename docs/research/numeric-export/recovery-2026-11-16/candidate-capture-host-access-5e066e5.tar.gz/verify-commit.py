import hashlib,json,os,pathlib,shutil,subprocess
folder=pathlib.Path(__file__).resolve().parent;game=pathlib.Path('/workspace/scratch/cs-numeric-kernels')
source=pathlib.Path('/workspace/scratch/prismpm-numeric');env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'}
def sha(body):return hashlib.sha256(body).hexdigest()
def git(root,*args):return subprocess.check_output(['git','-C',str(root),*args],env=env)
previous=json.loads((folder/'09-preservation-proof.json').read_text())
commit,tree,parent=git(game,'rev-parse','HEAD','HEAD^{tree}','HEAD^').decode().splitlines()
assert set(git(game,'diff-tree','--no-commit-id','--name-only','-r',commit).decode().splitlines())==set(previous['owned_files'])
assert not git(game,'diff',previous['parent'],parent,'--',*previous['owned_files']).strip()
for name,row in previous['owned_files'].items():
    body=git(game,'show',commit+':'+name)
    assert body==(game/name).read_bytes() and len(body)==row['bytes'] and sha(body)==row['sha256']
assert not git(game,'diff','--name-only','--',*previous['owned_files']).strip()
assert not git(game,'diff','--cached','--name-only','--',*previous['owned_files']).strip()
for name,row in previous['protected_files'].items():
    body=(game/name).read_bytes();assert len(body)==row['bytes'] and sha(body)==row['sha256']
assert git(source,'rev-parse','HEAD').decode().strip()==previous['source_head']
assert sha((source/'.git/index').read_bytes())==previous['source_index_sha256']
assert not git(source,'status','--porcelain=v1','--untracked-files=all').strip()
for item in previous['prior_indexes']:
    directory=pathlib.Path(item['directory']);body=(directory/'evidence-index.json').read_bytes();assert sha(body)==item['sha256']
    for row in json.loads(body)['files']:
        content=(directory/row['path']).read_bytes();assert len(content)==row['bytes'] and sha(content)==row['sha256']
proof={'commit':commit,'tree':tree,'parent':parent,'owned_files':previous['owned_files'],
       'source_head':previous['source_head'],'source_tree':previous['source_tree'],
       'source_index_sha256':previous['source_index_sha256'],'prior_files_unchanged':207,
       'prior_indexes':previous['prior_indexes'],'protected_files':previous['protected_files'],
       'free_bytes':shutil.disk_usage(game).free}
assert proof['free_bytes']>=8*1024**3
(folder/'12-commit-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps({'commit':commit,'tree':tree,'parent':parent,'owned_files':proof['owned_files'],
                  'prior_files_unchanged':207,'source_clean':True,'free_bytes':proof['free_bytes']},indent=2))

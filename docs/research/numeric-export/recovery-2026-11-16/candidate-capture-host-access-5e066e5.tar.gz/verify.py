import ast,hashlib,json,os,pathlib,shutil,subprocess
folder=pathlib.Path(__file__).resolve().parent
game=pathlib.Path('/workspace/scratch/cs-numeric-kernels');source=pathlib.Path('/workspace/scratch/prismpm-numeric')
env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'}
owned=['scripts/numeric/candidate-capture-qualification.py','scripts/numeric/tests/test_candidate_capture_qualification.py']
def sha(body):return hashlib.sha256(body).hexdigest()
def git(root,*args):return subprocess.check_output(['git','-C',str(root),*args],env=env)
baseline=json.loads((folder/'00-prior-evidence.json').read_text());count=0
for item in baseline['indexes']:
    directory=pathlib.Path(item['directory']);body=(directory/'evidence-index.json').read_bytes()
    assert sha(body)==item['sha256'];rows=json.loads(body)['files'];assert len(rows)==item['files']
    for row in rows:
        raw=(directory/row['path']).read_bytes();assert len(raw)==row['bytes'] and sha(raw)==row['sha256'];count+=1
assert count==207
assert git(source,'rev-parse','HEAD').decode().strip()==baseline['source_head']
assert sha((source/'.git/index').read_bytes())==baseline['source_index_sha256']
assert not git(source,'status','--porcelain=v1','--untracked-files=all').strip()
assert not git(game,'diff','--cached','--name-only','--',*owned).strip()
changed=set(git(game,'diff','--name-only').decode().splitlines());assert set(owned)<=changed
assert all(p.startswith('docs/') for p in changed-set(owned))
for name in owned:ast.parse((game/name).read_bytes(),filename=name)
protected=['.github/workflows/prismpm-candidate-capture-qualification.yml','.github/actions/prismpm-source-cache/action.yml',
           'scripts/numeric/candidate-capture-probe.py','scripts/numeric/candidate-capture-subject.mjs',
           'scripts/numeric/restore-prismpm-candidate.py',
           *['scripts/numeric/prismpm-capture-candidate/'+name for name in ('manifest.json','README.md','candidate.bundle','candidate.patch')]]
protected_rows={}
for name in protected:
    body=(game/name).read_bytes();assert body==git(game,'show','a37db958cbed291f215cf034069ffddfbd1fee44:'+name)
    protected_rows[name]={'bytes':len(body),'sha256':sha(body)}
old=ast.parse(git(game,'show','a37db958cbed291f215cf034069ffddfbd1fee44:'+owned[0]));new=ast.parse((game/owned[0]).read_bytes())
functions=lambda tree:{n.name:ast.dump(n,include_attributes=False) for n in tree.body if isinstance(n,ast.FunctionDef)}
old_functions,new_functions=functions(old),functions(new)
modified=[name for name,body in old_functions.items() if new_functions.get(name)!=body]
assert set(modified)=={'bridge_drop','bridge_child','bridge_admission','bridge_privileged','bridge_runner'}
failed=game/'docs/research/numeric-export/recovery-2026-11-16/ci-44092790586'
for name,digest in {'completed-run.json':'adfcc7f910bd3f929d008cbe355e599b7b7d58c803e927554bd4e60f130f8cb7',
    'failed-steps.log':'808fc1273b0974b8c5094283c3ab6e7e7e938c771b71c70f62ccaa7c844472b2',
    'full-run.log':'7941353ac36c0bab0fd6bfb0f51a9e2584bd8349ffb634b78e44943727a6f64e',
    'source-image-failure-artifact.zip':'9639e77154ef7dd2d26814861ca556d3e67eb5490a7e2867403bc6e44571df95',
    'artifacts.json':'8a231b030d9f9a60cfa782169f8885b39eb03daa492f952e9b6f731696a1b13a'}.items():
    assert sha((failed/name).read_bytes())==digest
result={'scope':'host-access-components-only-no-privileged-or-hosted-success','parent':git(game,'rev-parse','HEAD').decode().strip(),
        'owned_files':{name:{'bytes':(game/name).stat().st_size,'sha256':sha((game/name).read_bytes())} for name in owned},
        'prior_indexes':baseline['indexes'],'prior_files_unchanged':count,'protected_files':protected_rows,
        'source_head':baseline['source_head'],'source_tree':git(source,'rev-parse','HEAD^{tree}').decode().strip(),
        'source_index_sha256':baseline['source_index_sha256'],'unchanged_original_functions':len(old_functions)-len(modified),
        'modified_original_functions':modified,'python_ast':'PASS','local_uid':os.getuid(),'local_gid':os.getgid(),
        'sudo_available':shutil.which('sudo') is not None,'free_bytes':shutil.disk_usage(game).free}
assert result['free_bytes']>=8*1024**3
(folder/'09-preservation-proof.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))

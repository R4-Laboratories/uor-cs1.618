# Task4b game implementation report

2026-11-17. Implementation is ready for independent review. No actual SDK/daemon qualification, OC10 success, application acceptance, full-VV completion, push or hosted launch is claimed. No Docker command, image pull, local Rust build, source modification or subagent was used. Task4a2 resolved the previously reported typed generated-root discovery blocker; this implementation consumes its exact independently reviewed source contracts.

## Scope and fixed identity

Game parent `57c6baee81001500987d93736785cad191d90589`, tree `cff3f1551626785bb7916e1cadd0677c4e16b804`. Final scoped commit/tree are recorded below and in the evidence commit proof. Exactly nine owned files: `.github/workflows/prismpm-candidate-capture-qualification.yml`; `scripts/numeric/candidate-capture-qualification.py`, `candidate-capture-probe.py`, `candidate-capture-subject.mjs`; `scripts/numeric/tests/test_candidate_capture_qualification.py`; and `scripts/numeric/prismpm-capture-candidate/{manifest.json,candidate.bundle,candidate.patch,README.md}`. Existing workflows, restorer, historical source/native snapshots and unrelated parent documentation are unchanged.

Snapshot authentic reviewed source `f292c7100874c0e0b2d1e0e81b27caeec8391f77`, tree `d48cdfd94e6d46925e9269e364c2b7a6eb975d8a`, incremental base `3666dc0f9da56fcf066d96ec01cd9e14ec9a2974`. Private bare refs/read-only source object alternates preserve original commit objects without source HEAD/index/ref mutation. Bundle SHA256 `83e40e2d7b2d8bd2fae049bcda9c50e603a1442236ac4272d56e994bea6b5fdb`; patch SHA256 `b66d199fdb146f6fb844ad7c698e54a4fa9a2b31b488183d8f31ea716c779a19`. Unchanged restorer SHA256 `90b1fe176eaa8eebb4eb6648363308b512d9ebfd649ca010d429eebc8379450d` actually restored exact f292/d48 in a fresh disposable base checkout; clean tree and original authority bytes were checked and checkout removed.

Read-only source remains clean at parent's later native six-file import `463177a0971d95e112e10ed5da39c8cbaf0a4c96`, tree `0990e900cf1cb5bb4a481bba781a86cc3fcf0999`; index SHA256 `b57cc2bd2190d7e5fa1cbb941b29eb22160d41aab91e63a4fdf48a601b3a9fb1` unchanged. Task4b deliberately remains f292; native run44060585070/source881 is not relabelled. `13-final-authority-proof.json` records all nine game hashes, source authority Git blobs/SHA256, clean source/index, parent and cleanup-reference identities.

## Authority and subjects

Preparation binds all three game code authorities independently to actual game commit/tree/Git blob/length/SHA256 and copied bytes only under ignored source target/candidate-qualification-driver. Separate required `subject_adapter` authority is implemented. Actual source Git tree/tracked bytes/modes, original source inventories, d6 distribution/config, source-container mount/image/rootfs, source Python/tools and actual GitHub runner context remain distinct. Partial records never invent SDK/container identity. Admission rejects ambient route/output/SDK-child, compiler/profile/Rust/Node overrides.

Fixed Node adapter authenticates and imports original run/verifyCompilerTools/sourceInventory/captureCompilerArtifact. Q1 tracked root and Q2 fresh private root each have actual independent absent-target builds with exact original locked/offline two-crate libtest argv, fresh:false Cargo row, expected manifest/source path, moved actual inode, separately owned execution copy, actual complete listing and source pre/post checks. Q2 complete source aliases are staged by original source rules. Genuine original compiler brand is used; JSON never revives it. Original compiler call timeout remains. Original conformance integration harness prebuild and held target are separate from these subjects.

Probe is11,747 bytes, SHA256 `00be1f55c9a6e40f910366d3c66c75912279ceac551f5486af3799dc5a306a2b`, below32KiB. Exact inspected twelve-element argv delivers game bytes directly; separate closed readonly/attachment parser never uses source bootstrap parser. Actual d6 Python3.12.3/UID/GID1000/isolation/no-bytecode/environment, authenticated capsules, source descriptor/materialization/views, original SDK baseline/listing and original10GiB work-volume check remain required. All114 ordered readonly mutation attempts record real errno and unchanged full closure. No normal guest call or capture envelope is produced.

## Scenarios and schedule

Each invocation owns fresh original lifecycle/token/actors/volumes, original2400s deadline/420s reserve/18 cleanup-call ceiling/two attachment waits and unchanged resource/security/mount policy. Negative scenarios reuse only reverified Q1 ELF, never actors. Q3 extra writer consumes the same cleanup counter/deadline.

| Scenario | Required actual result | Nominal cleanup maximum |
| --- | --- | ---: |
| Q1 | tracked-root readonly probe, actual EOF/exit0, all actors/volumes absent | 12 |
| Q2 | separately compiled private-root readonly probe, EOF/exit0, all absent | 12 |
| Q3 | actual owned extra RW input writer blocks execution, actors absent, owned volumes retained | 7 |
| Q4 | actual partial stage input/EOF produces exact original early-close refusal, no execute | 6 |
| Q5 | actual create but deliberately discarded returned ID, exact-name/config reconcile then retire | 6 |
| Q6 | actual ready/live attachment interrupted, actor retired, owned volumes retained | 7 |

Total nominal50 cleanup calls, at most8 attachment waits. Q5 is controlled client observation loss, not claimed spontaneous daemon failure. Only a fully validated named ControlledFault completes a negative; later ordinary errors clear expected-refusal. Unknown IDs/uncertainty stay incomplete. Actual argv/inspect/stream bytes/EOF/exit and independent observation index bind cleanup counts and catch missing suffixes. Failed volume identities are not durable exports; no export actor exists.

Original pinned source-cache/devcontainers image prerequisite:240min, runCmd:true, no SDK build. Qualification needs image and has360 absolute minutes from first step:45 setup (warm acquisition/startup, both subjects, four components, original harness),240 six scenarios,65 original OC10 (unchanged60min Node plus5 outer),10 collection. Two collection minutes are reserved for host retention/upload. Remaining-budget guards never renew inner clocks/skip phases; no global CARGO_BUILD overrides.

Hosted cleanup copies exactly the existing13-path disposable-tool allowlist from `.github/workflows/prismpm-backport-full-validation.yml:82–91`, whole-file SHA256 `2cf87bf1edbdabb6f50bc5ae6329b3fe4165b37df8d8ade11c37e25d1242c71b`, line-range SHA256 `82d3cf47c12e96c9f977059afd6c70e2518a3451cce9995ce836922aaf8162c4`. It runs only after absolute clock, before checkout, requires GitHub Actions/github-hosted/Linux/Ubuntu24.04, fail-fast shell and fixed literal paths. No source/workspace/cache/active Docker state cleanup. Its cost is charged to45min setup. Nothing was cleaned locally or launched remotely.

## Original OC10 and complete retention

Genuine command is unchanged `cargo test --locked --offline -p repo-conformance --test conformance conformance_oc_10 -- --exact --nocapture` with held separate harness target. Required actual Cargo streams/status/libtest success and original numeric67-test/two-file owner summary join authenticated original source65+2 validator. Original Rust reporter intentionally hides child TAP: no synthetic suppressed TAP. Four original component commands precede scenarios. Complete requires original22 graph refusals, independent transport/oracle readers, all16 retained controls, native std/no_std and all six context/admission Wasm products/replays, all20 mutants, complete generated packages/proof/input/IR/compiler joins.

Discovery reads only fresh fixed capture/linkage registries, exact seven-key original schemas, <=256 files/1MiB aggregate/4KiB each and owned no-follow/single-link/name/root/module constraints. Capture-owner linkage.work/receipt joins typed linkage locator and later actualCapture path/hash back to actual capture-owner bytes. Exactly one capture and21 linkage workspaces are required. No tmp scan/prose-path parse/glob completeness. Typed pre-output spool locators bind only original fixed diagnostics; missing locator remains explicit failure.

Retain fixed original factory/owner/control/transport/capture/diagnostic receipts, capture original/private ELFs, and original exact-gate ELFs `publication-gate-built-tests` and `publication-gate-execution`, both source-recorded custody bound and distinct inodes. Full exact source/capture inventories use bounded PAX archives preserving direct aliases, explicit complete member inventory and registered cache exclusions only. Original Wasm hardlinks are allowed only when explicitly recorded and held; retained copies are ordinary files. Final source-container/image and SDK inspections are retained separately from initial records. Expected endpoints are independently fixed, not surviving-file enumerations.

Original `tests/browser-view/compiler-owner.mjs` SHA256 `0b64098649acb62b056b41a07ec2108894245f6a9d0e489b018c7c17931bf67d`, `createCompilerOwner()` → `constructCompilerOwner()` returned owner `.close()` (lines170–175,186–275), writes intent, cleans caches, verifies private executables, writes retirement. Require exact `SHA256(JSON.stringify(compilerEvidence))` without LF and original requested/retired statuses. Fixed mapping:

| Required retired original path | Required surviving copy |
| --- | --- |
| driver-target/debug/publication-context-linkage-driver | driver-execution |
| exporter/.lake/build/bin/prod-export (also entire exporter/.lake/build absent) | exporter-execution/prod-export |

Both retirement receipts and each survivor are mandatory. Survivor dev/inode/uid/gid/mode/links/size/hash and original/private same-byte join must hold. Explicit mapping names retired original, retained copy and retirement receipt. Missing surviving copy or either receipt fails. No reconstructed cache, omission based on glob, or weakened original close semantics.

Combined remote4GiB cap includes32MiB reserved metadata. Copies/archives have original/product bounds and8GiB local headroom guard. Missing/overflow/changed required evidence resets incomplete. Separate <=32MiB initial metadata upload; full raw upload requires freshly validated complete safe-file inventory/size marker. Local download guard includes compressed+extracted+working copies plus8GiB. No artifact download occurred; later metadata-only review cannot claim full artifacts reviewed.

## Closed records

Binding five schemas implemented: preparation/1 with subject_adapter, subject/1 tracked/private, readonly-probe/1 (attachment-ready/1 separate), scenario/1 qualified|expected-refusal|incomplete, collection/1 complete-conditional-evidence|incomplete. Accepted/application flags remain false. References `{path,bytes,sha256}`; finalLF/duplicate/unknown/missing fields/path/held-byte bounds enforced.

Additional game records: preparation-partial/1 `{schema,status,phase,game,source,driver,probe,subject_adapter,host_source,started,runner}` (incomplete, image|qualification); command/1 `{schema,name,argv,cwd,status,exit,elapsed_seconds,stdout,stderr,error}`; setup/1 `{schema,status,commands,subjects,harness,elapsed_seconds}`; original-oc10/1 `{schema,status,command,summary,source_validator}`; run/1 `{schema,status,phases,error}`, fixed completed phases setup,Q1..Q6,oc10. Actor rows `{role,name,id,absent}`; volumes `{role,name,absent}`; observations `{role,kind,path,bytes,sha256}` plus independent index. Fixed per-scenario roles/volumes/fault kinds. Subordinate original schemas and component-only scopes remain original, never promoted to application acceptance.

## Validation and honest chronology

Evidence `/workspace/diagnostic-tools/candidate-capture-qualification/` contains bounded raw outputs/exits/argv/cwd/selected environment/tool-input hashes and final explicit SHA256/size index. Runner bounds streams2MiB/command180s/checks8GiB. Component checks never invoke Docker or actual compiler.

1. Initial four probe tests preceded code; `01-probe-red.stdout/stderr` retain actual missing-probe RED, original command metadata was not captured. Seven-test pass observed in tool output. Driver basic tests preceded module and missing-module RED was observed, but raw log was not retained. No later fabricated RED replaces it.
2. Expanded driver/collector/workflow tests were written after code. First23 executions had three inherited duplicates (20 distinct), later removed. One fresh-subject test initially failed attempting to write its0500 fixture; fixture permissions were corrected, not presented as implementation RED.
3. Retained `04-current-components`24, `05-expanded-components`25, `06-joined-components`26, `11-final-components`26 PASS. Self-review fixed late ordinary-error/negative completion bug. `07-planted-late-fault`, `08-planted-uncertainty`, `09-planted-truncation` deliberately remove individual checks in memory: each selected test exits1 with intended assertion failure/no test error, working driver unchanged. These are postimplementation witnesses, not historical TDD or daemon results.
4. Final `12-final-retention-workflow-components`: `python3 -B -m unittest discover -s scripts/numeric/tests -p test_candidate_capture_qualification.py -v`,28 distinct tests PASS. Covers argv/runtime/capsule closure; real writable mutation refusal; file alias/link/size refusal; exact archive inventories; typed locator/count/stale/path/module joins; six scenarios/uncertainty/cleanup suffix; full probe mutation result; fresh Cargo/root/ELF/inode/listing substitutions; both compiler receipts/survivors; both exact-gate survivors/custody; original aggregate truncation; stale-complete reset; artifact/download cap; workflow pins/narrow trigger/always; hosted cleanup exact allowlist/clock/OS guard.
5. `10-restoration`, `10-original-restorer`, `10-restoration-proof.json`: actual unchanged restorer PASS, exact f292/d48 clean, source HEAD/tree/index unchanged, temporary checkout removed. Minimum local free9,121,570,816 bytes (>8GiB). `13-final-authority` AST Python syntax/owned hashes/source clean/index/source original authorities PASS. `14-node-syntax` `node --check scripts/numeric/candidate-capture-subject.mjs` PASS. Full staged whitespace check15 exited2 only on the authentic snapshot patch's retained whitespace/context lines; it is intentionally not rewritten. Check16 excludes that immutable patch/binary and passes all seven authored text/manifest paths. Raw failure and passing outputs are retained. Commit proof follows in index.

Small synthetic record/file/ELF-header fixtures are rejection components only. None constructs a compiler brand, runs actual source compilation, establishes actual SDK success or supplies complete actual collection. Actual hosted timing, Docker recovery, d6 compatibility and evidence capacity remain unproven until reviewed hosted execution.

## Review and launch boundary

Independent implementation review is required before parent publication. Workflow has only workflow_dispatch and push on numeric-kernels limited to this workflow, three fixed game authorities, focused tests and separate snapshot. Parent pushing exact independently reviewed commit registers/starts diagnostic without merging branch to main. No push/launch performed. Then actual image/setup/six scenarios/OC10 and bounded full artifact review must pass. Original independent full-VV/native obligations remain separate.

## Final isolated commit

Commit `8812d8511c53871783cc5ad15eb6ec4ba15134b0`, tree `9d09c7f69caabf1be372fd1e01d247fdd13656cf`, parent `57c6baee81001500987d93736785cad191d90589`. All nine committed Git bytes equal the tested/recorded working bytes. Tracked game index/worktree is clean; unrelated parent recovery working directory remains untracked. Final source HEAD/tree/index remains unchanged and clean. Final recorded local free 9434173440 bytes. Evidence manifest is `evidence-index.json`; it indexes this report copy, exact command streams/status and proofs without including itself. No push or hosted launch.


# Fix round1 — R1, R2, R3

2026-11-17. Repaired the three independently confirmed findings against base `8812d8511c53871783cc5ad15eb6ec4ba15134b0`. Scope is exactly driver, focused test file and qualification workflow. No source/probe/subject/snapshot/restorer/action/SDK pin changes, builds, Docker, network, push, launch or subagents. The original77-file evidence index and every indexed file, including the original report copy, are byte-for-byte unchanged. New commands, outputs, proof and report copy reside only in `/workspace/diagnostic-tools/candidate-capture-qualification/fix-1/`.

## R1 — independent mutant evidence inventory

`candidate-capture-qualification.py:1029` onward now separates fixed expectations from retained receipt membership. `collect_original_oc10` supplies each expected mutant kind from the independently fixed20-kind list; the collector cannot infer required roles from a reduced receipt. Ordinary mutants require std/no_std and wasm/wasm-repro; context mutants require context-fields std/no_std and the four context/admission Wasm roles. Baseline requires all four native/six Wasm roles. Exact generated package paths/kinds/file sets and original/native/private Wasm paths are fixed; manifest file digests and IR join each original generated package. Copies retain original custody and distinct original/private inodes.

All eight fixed f292 source modules, four runner witness files, both runner source roots, selected runner manifest, original mutated vector, proof members and generated package members are mandatory. Each mutant shares baseline frozen inputs/snapshot/compiler and changes only the one module selected by original mutations.mjs. `intended-mutation.tsv` must contain the selected original probe and the ordinary/context field count. Original source `compile.mjs:17–22,139–158,209–219,270–287`, `checks.mjs:66–102,166–185`, and `mutations.mjs:4–30` establish these inventories and joins.

Proof validation binds original fixed module list, manifest selection/module/source rows and IDs, five required build-output roles per module, original attestation/build-manifest digest and byte count, every declared output and olean, and required generated Lean/source/process members. Complete fixed proof/source/export/runner/package trees are reconciled independently with retainedFiles; a reduced retained inventory cannot omit a surviving original member, and removal of a mandatory member from both disk and receipt still fails. Original verifier's build/attestation writers are fixed `vendor/lexlean/src/api.rs:278–285,378–414,438–464`, `artifact/manifest.rs`, and `verify/mod.rs:1240–1280,2860–3016`.

Source review during repair corrected an intermediate assumption: the fixed Rust driver emits runtime `{name,text}` records, not strings. The final validator and fixtures use that actual shape. The five-entry fixed vendor runtime registry bounds names; project Lean imports and transitive runtime texts bind the driver's complete runtime closure, source text joins its proof member, and all original attested oleans remain required. Original verification can additionally import registered runtime modules for preservation certificates, so those original attestation rows are preserved as well. No new source API or fabricated proof/compiler artifact is introduced. Source-authority Git blob/SHA256 records are in `12-preservation-proof.json`.

Regression `test_mutant_inventory_omissions_never_redefine_complete_source_evidence` starts from the original ordinary/context writer layouts and real small files, then removes each native role, Wasm role/package, staged source, proof member, vector, runtime record and runtime proof member. Complete component layouts pass; every omission fails. `test_mutant_receipts_join_same_inputs_compiler_and_only_selected_source_change` rejects input/compiler/snapshot substitutions, no mutation and changes to another module. These are collector components, not actual generated compiler or daemon evidence.

## R2 — available failure retention before completion validation

`scenario_products` now attempts every fixed known endpoint independently, preserving its original cap. It separately loads and bounds the independent observation index, validates each typed row/path/ordinal/digest, and copies each safe raw observation under individual failure accounting. The original typed diagnostic locator has its scenario owner/token/fixed path checked before manifest access; its bounded original spool is retained independently of missing descriptor/stage/probe files. Complete probe/scenario/cleanup validation occurs only after these retention attempts. Missing endpoints still add explicit reasons and final status remains incomplete. No arbitrary tmp discovery, invented missing receipt or lower path/ownership bound.

Regression `test_early_and_attachment_failures_retain_available_observations_and_typed_spool` exercises actual temporary file collection with descriptor absent, stage-admission absent, and probe absent. In each case the actual available component inspection bytes and typed attachment-error spool appear in retained raw inventory, the missing member is absent, and final collection is incomplete. No daemon transcript is fabricated or relabelled actual qualification.

## R3 — fixed seven/three collection allocation

The authorized allocation is now seven source minutes plus at most one minute each for host retention, metadata upload and raw upload, all within the unchanged ten-minute collection allowance and21600-second job deadline. For first collection time `C` and original job start `J`, persist exactly once:

- `deadline = min(C + 600, J + 21600)`;
- `source_deadline = deadline - 180` (therefore source duration at most420 seconds);
- source timer uses `source_deadline - now`, never a renewed interval;
- host/metadata/raw admission requires at least180/120/60 seconds respectively before the same `deadline`; each admitted phase has at most60 seconds.

The closed `cs1618/candidate-collection-clock/1` record is `{schema,started,source_deadline,deadline,job_deadline}`. It is retained in raw and metadata. Source `run` and explicit `collect` both use the bounded collector. Re-entry reuses the same record. If no source container reached collection, host initializes one record from the actual first-step job clock; it still runs only the three bounded host phases. Host copies/checks the source clock and independently binds it to the original host job-start record.

Workflow retention and both upload actions have timeout-minutes:1. Host Python uses55 seconds, leaving five inside that step for genuine failure status. Each upload has a fresh same-clock admission step; its helper process has a five-second timeout and emits admitted=true only with its phase plus remaining phase allowance available. Guard/handoff costs consume the same absolute ten-minute window; insufficient time prevents the upload and records incomplete rather than granting another window. No phase timeout overrides original2400/420/18/2, OC10 or360-minute job limits. Genuine process/action failure remains failure; no fallback success.

Clock regressions cover early setup failure, near-job-deadline collection, source timer actual arming, repeat-call decreasing remaining time, zero-budget nonexecution/incomplete status, host/source clock identity, late raw upload refusal and fixed workflow action/admission bounds. Early example J1000/C1600 gives source deadline2020 and final2200; near-end C22400 gives source22420/final22600. Repeated source collection ten seconds later loses ten seconds rather than receiving another420.

## Commands and actual chronology

New four primary regressions were written before production repairs. `01-review-regressions-red` exits1 with16 assertion failures (12 inventory omissions across two families, three missing-endpoint retention failures, workflow bounds) and one missing-clock-helper error. Existing28 tests still pass. R1's first covering run `02-r1-green` actually exits1 because missing vector raised FileNotFoundError before the intended explicit inventory refusal; a required-member check corrected it, and `03-r1-green` passes. No failed output is hidden or relabelled green despite that early filename.

`04-r2-green` passes the three early/attachment cases. `05-r3-green` passes clock arithmetic/workflow checks. `06-complete-components` passes32 tests. Additional timer/persistent-clock tests were added after the initial R3 implementation; they are additional coverage, not claimed initial RED. The source/input/compiler-join test precedes its new helper: `07-additional-boundary-regressions` records the missing-helper error; `08-complete-components` passes35. Source-contract inspection then found the runtime-record shape issue; the expanded actual-shape fixture fails in `09-actual-runtime-shape-red` with six TypeErrors, and `10-runtime-shape-green` passes after correction.

Final `11-final-components` runs `python3 -B -m unittest discover -s scripts/numeric/tests -p test_candidate_capture_qualification.py -v`:35 distinct tests PASS, including all current regressions. `12-syntax-and-preservation`: Python AST syntax PASS, bash -n on all12 workflow run scripts PASS, exactly three modified tracked paths, six other original owned paths unchanged, original77 evidence files/index unchanged, source HEAD/tree/index unchanged and clean. `13-scoped-whitespace`: git diff --check on the three owned paths PASS. No unchanged snapshot restoration or broad source suite was rerun. Each bounded command retains exact argv/cwd/selected environment/tool-input hash, exit, full stdout/stderr and free-space measurements in fix-1.

Source remains463177a/tree0990, index b57cc2bd2190d7e5fa1cbb941b29eb22160d41aab91e63a4fdf48a601b3a9fb1; reviewed capture snapshot remains f292/d48. Precommit measured free9,247,465,472 bytes (>8GiB). Initial evidence index remains SHA256 dbc44ad0a35c1813d404db09933dc769127418f59b1de6e87bca14e7a1d052fa. Final fix commit/tree and separate evidence index follow below. Independent scoped re-review and all actual hosted qualification/artifact-review gates remain outstanding.

## Fix1 isolated commit

Commit `128b187d545aae090850bb0aaf1c1517be8db390`, tree `2662a899b05e1bd85369c6c31d557e66bba9822c`, parent `8812d8511c53871783cc5ad15eb6ec4ba15134b0`. Exactly three owned paths; committed Git bytes equal the tested and recorded working bytes. Tracked game index/worktree clean; unrelated parent archive/report/working files untouched. Original77 indexed evidence files and index reverified unchanged after commit; source unchanged and clean. Final recorded free 9247330304 bytes. Distinct `fix-1/evidence-index.json` indexes this updated report copy and all new fix evidence, excluding itself. No active process, push, launch, Docker or build. Ready for independent scoped re-review.

# Fix round2 — hosted privilege and artifact handoff

2026-11-17. Implements the binding diagnosis and READY design review (SHA256 df810cac137efa8f5802dd36f202e59320bc8035a564394b79fdf377150ebfb3). Code comparison base128b187d; dispatch9b73efe; actual parent documentation HEAD bfbc718f8cfa1b95f822c6490833125924b4bda7. Exactly three implementation paths: qualification workflow, driver, focused tests. Source463, capture snapshotf292, probe, subject adapter, restorer and all action/SDK pins remain unchanged. No Docker, builds, network, launch, push, subagents or account/group/sudoers changes.

Run44081334047 remains failed image retention with qualification skipped. Its full/failed logs and completed-run record are unchanged. The confirmed failure was sudo before Python; the exact sudoers reason is still unproved. This repair does not establish any actual scenario, original OC10 or SDK success.

## Fixed privilege and custody boundary

The normal runner invokes only `/usr/bin/sudo -n -- /usr/bin/python3 -I -B <workspace>/game/scripts/numeric/candidate-capture-qualification.py host-root --bridge-operation <closed operation>`. The eight operations are preflight-image, preflight-qualification, image-collect, qualification-collect, pull-budget, setup-budget, metadata-budget and raw-budget. There is no arbitrary command, shell, path, owner or environment argument. The root entry checks actual SUDO_UID/GID against the request and runner-owned fixed workspace/game/evidence/control paths; authenticates game HEAD and exact Git driver bytes against preparation; joins the runner-owned first-step clock; and creates exclusive root-owned operation state. Repeated operations refuse rather than replace that state.

Root and child environments are reduced to PATH=/usr/bin:/bin and LANG=C.UTF-8. The supervised child closes unrelated inherited descriptors and replaces stdio with /dev/null, retaining only its bounded result pipe. It replaces supplementary groups before dropping primary GID/UID to1000 and verifies actual resulting credentials. Only image inspection and the real preflight receive the measured Docker socket group. The original UID-sensitive source readers are unchanged. Existing host_collect/export_host are reused with an explicit UID1000-private metadata destination; no source validation is replaced by root readability.

The root supervisor has its own monotonic deadline and SIGALRM/SIGTERM/SIGINT handling. Its child session is killed and its direct child reaped on failure/timeout, including descendants in that group. Root transfer stops on deadline/signal. The runner cannot claim to kill a privileged process: root owns its earlier deadline. Root result streams and the child result pipe are independently bounded to8KiB. Root never receives or opens GITHUB_OUTPUT. The runner reconstructs only bounded minutes or Boolean controls and appends through a checked original runner-owned descriptor without changing owner/group/mode. Actual child/root nonzero exits remain nonzero even when safe diagnostic exports exist.

## One-time export and admission

UID1000 produces private metadata copies and uses the collector's already-retained raw copies. A held complete inventory includes directories, file paths, device/inode, bytes and SHA256. Every file is owned, no-follow, singly linked and stable during hashing; aliases, ownership changes, omissions, extras, size overflow and device mismatch refuse. Root validates an absent same-device fixed destination, uses Linux renameat2(RENAME_NOREPLACE), then transfers only enumerated descriptors to the actual runner. There is no second raw copy, replacement fallback or recursive original-source chmod/chown. Original source/private capture products remain untouched; only retained copies move from HOME/raw to evidence/raw-upload. Metadata moves to evidence/metadata-upload.

The actual runner traverses and hashes every expected export member before emitting a safe output. The uploaded metadata includes bridge-context.json, bridge-handoff.json and runner-admission.json, binding the original clock, measured identities/groups, original child status and relocation mapping. Mapping/handoff/status bytes count within the existing32MiB metadata and combined4GiB bounds; an8KiB reserve covers small runner records. An interrupted owner transfer stays incomplete and cannot generate an admission record. Image upload now also requires metadata_safe; always() alone cannot upload a partial tree. If sudo refuses before starting Python, an exact small runner-owned bridge-failure.json can be admitted as failure evidence while preserving the original failed exit.

Each job runs the exact root/drop/export/runner-read/output preflight after source preparation and before cache/image work or SDK acquisition. It uses tiny disposable copied bytes, preserves its private original's device/inode/owner/mode/content, checks the real socket permissions, and verifies that a distinct actual runner cannot open the private original. It exercises the production handoff route, not an unrelated sudo command. Preflight failure remains early and runner-readable.

## Persistent bounds and later guards

Preflight costs at most30 seconds within the original image240-minute or qualification45-minute setup window. Setup/upload guards retain a five-second bound. Host retention remains at most60 seconds. Root admission/authentication, child work, inventory/transfer and runner read/hash share the same request start and narrowed absolute deadline; runner verification explicitly adopts any earlier job/collection cutoff returned by the authenticated bridge. Root reserves half a second inside the step for return/status rather than renewing a budget.

Qualification joins the original UID1000 collection clock, or initializes a single root-held clock from the original first-step job start only when source collection never began. It persists that clock before host work. The unchanged seven-minute source/one-minute host/one-minute metadata/one-minute raw allocation, ten-minute collection and360-minute job limit remain. Later metadata/raw guards read only fixed root state, the matching runner admission and the persistent clock. They never collect source again, reopen transferred exports through UID1000 readers, relocate raw twice or recreate markers from surviving files. Missing/partial/mismatched state refuses. Small refusal status stays runner-owned; a partial transfer may intentionally prevent artifact upload rather than represent incomplete custody as safe.

## Evidence and actual test chronology

New evidence is confined to `/workspace/diagnostic-tools/candidate-capture-qualification/host-handoff/`. Original77 indexed files/index and fix1's51 indexed files/index remain byte-for-byte unchanged, including their old report copies. Every new command retains argv/cwd/selected environment/tool-input hash, exit, complete bounded streams and free-space measurements.

Seven initial bridge tests were written before production changes. `01-host-bridge-red` records the old workflow assertion failure plus missing-helper errors; the unavailable privileged test is explicitly skipped. `02-host-bridge-first` then passes six component tests with that one skip. `03-covering-first` runs42 tests and fails solely on the old collection-budget routing assertion; it was updated to require the new route while preserving the five-second helper and one-minute action checks. Additional coverage was written after the initial implementation and is not claimed as historical RED. `04-expanded-bridge` passes12 plus one skip. `05-covering` passes48 plus one skip. A later self-review tightened image partial-transfer admission and runner verification's earlier absolute cutoff; `06-deadline-final` passes14 plus one skip. Fault-injected sudo/partial-transfer results are explicitly component controls, never actual privileged success.

Final `08-final-components`: `python3 -B -m unittest discover -s scripts/numeric/tests -p test_candidate_capture_qualification.py -v` runs50 tests:49 PASS, one SKIP. Coverage includes real file relocation/read/hash, absent-target/cross-device refusal, missing/extra/aliased/hardlinked/changed/oversized/wrong-owner files, actual inherited-descriptor closure, actual child nonzero/signal/oversized-result/timeout and reap, planted interruption after one actual descriptor transfer, runner output owner/mode and scalar closure, failure-only/partial-image upload decisions, shortened absolute runner deadline, and repeated control-only guards without any source/export directories. Existing complete-inventory and failure-retention tests still pass.

The real two-identity fixture is implemented but UNRUN/SKIPPED locally: this process is UID/GID1000 and sudo is absent. `07-sudo-unavailable` retains actual command exit127 and `sudo: command not found`. No installation or account changes were attempted. Consequently actual cross-UID ownership transfer, privileged environment/drop/timeout behavior and hosted sudo policy remain pending the exact hosted preflight after independent review; static assertions and single-UID kernel tests do not establish those witnesses.

`09-syntax-preservation` passes Python AST and bash syntax for all14 workflow run steps, proves exactly three modified tracked paths and six protected original owned paths unchanged, verifies both old evidence indexes/all128 indexed files, and rechecks the unchanged failed-run logs. Source remains463177a/tree0990 with unchanged clean index b57cc2bd2190d7e5fa1cbb941b29eb22160d41aab91e63a4fdf48a601b3a9fb1. `10-scoped-whitespace` passes. No unrelated source suite or snapshot restoration was repeated. Recorded precommit free space9,162,285,056 bytes, above8GiB.

Independent scoped implementation review, actual hosted preflight, full original qualification and full artifact review remain required. The parent alone controls publication/launch.

## Fix2 isolated commit and release

Commit `b09d45c1d9813a06925dfbcf5dea9399c612d20b`, tree `621f473b8474d19c8b27d75ea401be6924f29eb6`, parent `bfbc718f8cfa1b95f822c6490833125924b4bda7`. Exactly the three authorized files; committed Git bytes equal the tested working bytes and preservation proof. Tracked game index/worktree clean; unrelated parent working/ files untouched. `12-commit-verification` rechecks protected evidence and unchanged clean source. Final recorded free9,162,137,600 bytes. Distinct host-handoff/evidence-index.json indexes only this round's commands, streams, proofs and updated report copy, excluding itself. No active process, push, launch, Docker or build. Implementation slot released for independent review and other authorized work.

# Fix round3 — fixed host socket parent alias

2026-11-17. Implements the authorized host-socket diagnosis in only `scripts/numeric/candidate-capture-qualification.py` and its focused test file. Code baseline b09d45c; parent documentation advanced to75bba7c018893bafc8bd234cb11c1f797927fe90 without implementation overlap. Workflow, probe, subject adapter, restorer, action/SDK pins, source463 and reviewed capture snapshotf292 remain unchanged. No Docker/daemon connection, builds, network, privileged tests, account/group changes, subagents, push or launch.

Run44089985756 remains a failed early preflight, with image work and qualification skipped. Its actual root process reached the compound socket predicate; the264-byte failure record establishes ordinary runner UID/GID1001 and genuine exit1. The log did not measure the hosted final socket type or canonical path, so the exact hosted trigger is still unproved. This repair addresses the definite parent-alias defect and ensures a later refusal records the distinguishing measurements. No actual hosted drop, cross-UID transfer, scenario, OC10 or SDK success is claimed.

## Closed endpoint policy and identity join

The production `bridge_socket` wrapper has no path/owner argument or CLI option: it always invokes the private measurement primitive with namespace `/`, trusted owner UID0 and the existing absolute deadline. The private namespace/owner parameters exist only to exercise real temporary fixtures without privileged tests. Docker commands, mount specifications and logical endpoint `/var/run/docker.sock` remain unchanged.

Exactly two layouts are admitted: real safe root-owned `/var/run`, or a root-owned `/var/run` link with exact text `/run` or `../run` leading directly to real safe root-owned `/run`. `/`, `/var` and the selected runtime directory must be real root-owned directories without group/other write or special bits. Other parent aliases, indirect chains and alternate link spellings fail. Symlink0777 is treated as a symlink mode, not a writable directory. The final endpoint is held using Linux O_PATH|O_NOFOLLOW and fstat must report an actual root-owned socket without world-write or special bits. A final symlink remains rejected, including the local environment's additional `/run/codex-docker/docker.sock` alias. This explicit root-owned final-socket policy is a narrow hosted endpoint constraint; it does not relax any source or private-artifact no-alias rule.

No-follow directory descriptors hold the selected parent identities. Final canonical and logical no-follow observations must join the held socket's device/inode/UID/GID/mode; parent/link/final identities are checked again before completion, and all descriptors close before return or exception. A changed real-directory runtime between its first lstat and descriptor acquisition also refuses. The measured socket group, never a constant group number, feeds the existing process-only credential drop. The dropped child independently remeasures the same fixed endpoint under the same deadline and requires the complete held record and group to match before accessing source preparation or proceeding to preflight/image inspection. It receives no inherited root-open socket handle.

## Bounded diagnostics and unchanged scheduling

The game-only `cs1618/host-docker-socket/1` measurement records logical/canonical names, layout, status/predicate, selected parent identities, `/var/run` type/link text and final canonical/logical socket identities. Unexpected link text is explicitly bounded to64 characters with original byte length and truncation flag. Failure predicates distinguish unsafe_parent, unexpected_parent_alias, final_not_socket, unsafe_socket, missing_member, filesystem_refusal and identity_changed. Successful state is admitted. The encoded measurement is bounded to1760 bytes; the complete error fits the original2048-byte runner error field and8KiB control stream. No environment dump or arbitrary file content is read.

Root admission failures carry that actual typed record through the existing stderr → runner failure-status → small artifact route before failure is returned. Successful metadata includes the record in existing bridge-context.json. A dropped-child measurement failure occurring before metadata creation is propagated from the child's actual bounded error rather than replaced with a secondary missing-export error. This is a narrow diagnostic preservation change in the existing route, not a new collector or handoff. Original nonzero exits, failure-only upload rules, custody checks, deadlines, metadata32MiB/combined4GiB caps and8GiB local reserve remain intact. Socket measurement and the child recheck consume the already-held deadline; no new command, phase, retry, timer renewal or workflow step is introduced.

## Tests, chronology and evidence

Separate evidence directory: `/workspace/diagnostic-tools/candidate-capture-qualification/host-socket/`. The original77, fix1's51 and host-handoff's45 indexed files and all three indexes are byte-for-byte unchanged. The new directory holds only this round's bounded command records/full streams, actual predicate reproduction, preservation/commit proof and updated report copy.

Before production changes, four new test methods were written. `01-socket-regression-red` fails with18 missing-helper/class errors across their cases. More directly, `02-original-predicate-red` extracts and evaluates the exact old production AST predicate on a real temporary AF_UNIX socket behind `var/run -> ../run`: it records real_socket=true, actual_old_predicate=false and the intended assertion failure. This is an actual local filesystem regression, not a daemon or hosted-layout witness. The reproduction script ran against the original working driver before repair; its baseline is b09d45c.

`03-socket-first` passes the initial four methods after repair. Three additional integration/race methods were then added, after the initial implementation; they are additional coverage rather than claimed earlier RED. `04-socket-integration` passes seven. Tests cover all three concrete positive fixtures (relative link, absolute link, real directory),13 negative cases (final/extra socket aliases, unexpected/indirect runtime links, aliased var/run parents, file/FIFO/directory/missing endpoint, wrong owner, writable parent and world-writable socket), expected dev/inode/group substitution, actual inode replacement between measurements, actual inode replacement during the held logical/canonical join, and descriptor closure on refusal. No temporary socket connects to a daemon.

The integration test passes the actual measured group/context through the existing child call and independently exercises the real fixture measurement; the credential syscall boundary is substituted and is explicitly not a privileged drop witness. Another test takes a real final-symlink refusal, routes its complete bounded diagnostic through the ordinary runner's existing failure path, then reads and compares the retained JSON byte content after error-prefix/truncation handling. Root execution itself is substituted as a refusal, never mocked as successful qualification.

Final `05-covering`: `python3 -B -m unittest discover -s scripts/numeric/tests -p test_candidate_capture_qualification.py -v` runs57 tests:56 PASS, one unchanged real cross-UID fixture SKIP because this environment has no sudo. The existing bridge, clock, complete-inventory and failure-retention checks continue to pass. `06-syntax-preservation` verifies Python AST, exact unchanged workflow bytes, protected probe/subject/snapshot bytes, all173 prior indexed evidence files, and unchanged clean source463/tree0990/index b57cc2bd2190d7e5fa1cbb941b29eb22160d41aab91e63a4fdf48a601b3a9fb1. `07-scoped-whitespace` passes on the two owned paths. No unchanged workflow/source test suite or restoration was repeated. Recorded precommit free9,028,984,832 bytes, above8GiB.

Independent scoped review and the actual hosted preflight remain required before any execution claim. If the hosted final socket has an extra alias or another unsupported layout, the fixed admission must refuse with its measured predicate; it must not silently widen the allowlist. The parent alone controls later publication and launch.

## Fix3 isolated commit and release

Commit `a37db958cbed291f215cf034069ffddfbd1fee44`, tree `e8056a0d2286c7e46ba49de158ab2ba50c2d8180`, parent `75bba7c018893bafc8bd234cb11c1f797927fe90`. Exactly driver and focused tests; committed Git bytes equal the tested preservation-proof bytes. `09-commit-verification` confirms clean owned paths, unchanged source and all prior173 indexed files/indexes. Final recorded free9,028,849,664 bytes. Distinct host-socket/evidence-index.json indexes this round's commands, complete streams, reproduction, proofs and updated report copy, excluding itself. No active process, Docker, build, push or launch. Implementation slot released for independent review and the parent's other authorized implementation.

# Fix round4 — measured host source access

2026-11-17. Implements the fresh host-access diagnosis, the parent's explicit conditional group ruling and independent READY design review. The implementation baseline remains `a37db958cbed291f215cf034069ffddfbd1fee44`; parent documentation advanced to `7d746f1035abc41ad6165880cdb88ef20ce223a8`. Exactly two implementation paths change: the game qualification driver and its focused tests. Workflow integration was not required; the workflow, source-cache action, source463, fixed qualification snapshot f292/d48, probe, subject adapter, restorer and all action/SDK pins remain unchanged.

Run44092790586 remains a failed early preflight, with source cache/image work and qualification skipped. Its actual UID1000 child passed the socket identity join but received EACCES reading absolute source preparation. The precise denied ancestor and hosted socket layout were not retained. This round does not claim that the hosted ancestor was0750, that the chosen group will support every hosted layout, or that any privileged handoff, SDK scenario or original OC10 succeeded.

## One explicit access plan across all source-reading host operations

Root derives all paths from the authenticated workspace and requires `partial.host_source` to equal the original fixed source location. A shared bounded measurement covers the full ancestry, source-private preparation/inventory/copied authorities, source and game Git HEAD/config/object roots, and the fixed original game authorities. Existing operation parents are included when present. Root holds O_PATH/no-follow descriptors, checks identities/owners/modes, requires the private source directory0700 and single-link bounded regular leaves, and rechecks held identities before closing every descriptor. It does not inspect or redefine the complete tracked-source alias policy.

Supported ACL state is explicitly **absent access ACL and, for directories, absent default ACL**. Only actual ENODATA establishes absence. Present ACLs and inspection failures, including EOPNOTSUPP, refuse with the measured state/errno. No ACL, owner or mode is changed outside isolated test fixtures. An owner-only ancestor, unsafe ancestry, alias, missing member or unsupported access layout refuses; no namespace, root-reader or permission-change fallback exists.

Permission selection obeys POSIX precedence: UID1000 owner bits first; otherwise matching primary/supplementary group bits; otherwise other bits. A denying owner/group class never falls through to other bits. The baseline includes only the measured socket group for the two preflights and image collection. When baseline access fails, the only candidate addition is authenticated SUDO_GID. The candidate must satisfy **every** required access, including paths where joining that group removes access previously supplied by other bits. If baseline access suffices, no traversal group is added. Duplicate groups are removed; socket/traversal provenance and the process-wide authority scope are recorded.

The same plan is used for preflight-image, preflight-qualification, image-collect, pull-budget, setup-budget and qualification-collect. Only the existing three socket-using operations receive the socket role. Primary UID/GID remain1000, groups are replaced before GID/UID drop, and the actual resulting real/effective IDs and exact supplementary list are checked. No runner account groups, arbitrary GID/path/program, secrets, account edits or global membership changes enter the child. Metadata/raw guards remain control-only and receive no source child or group transition.

The dropped child independently remeasures/rejoins the complete held plan and performs the unchanged owned source reader/readback, copied-authority byte/hash joins, actual fixed game Git commit/blob reads and no-follow original game file reads. A second plan check follows those reads. Root's metadata and mode arithmetic never stand in for the child's kernel access. The child's ordinary filesystem failures retain their actual errno; predicted mode refusal has no fabricated syscall errno. Nullable actual credentials mean no child credential witness was received, not a claim that root's planned identity ran.

## Runner readiness and durable early diagnostics

After actual preflight copy transfer and runner inventory admission, the ordinary runner reads exactly `.dockerignore` and the four fixed devcontainer build/cache inputs, under its own credentials and the original deadline. Each file remains source-owned1000 and must satisfy bounded no-follow/single-link identity checks. The resulting fixed path/length/hash rows and actual runner UID/GID join preflight admission; subsequent root operations authenticate this small control record and include it in retained bridge context. They do not reopen source inputs for later upload guards. This avoids changing the cache action or exposing the private driver directory.

The new closed `cs1618/host-source-access/1` record contains operation, fixed workspace, status, root observer identity, runner identity, planned group roles/scope, nullable actual child credentials, the available socket measurement, indexed ancestry/leaf rows, failure, explicit omission counts and a focused denied-component observation. Each row records parent index/name, device/inode/UID/GID/mode, ACL state, required permission mask and baseline/selected permission class. Failure records identify stage, predicate, path, syscall and actual errno when one exists. Root's full measurements survive a child lookup failure before the source leaf; the focused later observation is kept distinct from root's earlier measurement.

The access record is limited to40 measured objects and6500 encoded bytes. Overflow is explicit and incomplete, retaining credential/failure facts plus the focused component and omission counts. The complete child pipe, root result and runner status wrappers remain under the existing8192-byte bounds. An access-bearing human error string is at most512 characters; the structured access data travels in its own field, not inside the old2048-character error string. A hosted-shaped component fixture with29 measured rows and a real temporary socket produced5659 bytes of access data,6202 bytes for the child wrapper,5858 for the root wrapper and6328 for the runner failure record.

Root/runner result and status records now carry `access`; control-only results use null. The preflight admission record adds `runner_build_inputs`. Bridge context includes both access and runner build-input evidence. These bytes are retained and counted through the existing metadata inventory/mapping/cap logic; the existing8192-byte runner-record reserve covers the added small readiness rows. Source preparation/scenario/collection contracts remain unchanged. Early source/socket/access refusal can reach the existing runner-readable failure artifact before any child export exists, retaining the real nonzero exit and nonacceptance flag.

Original current-owner/no-follow/single-link source validation, private original custody, descriptor closure, supervised deadlines/reap, same-device no-replace copy relocation, enumerated owner transfer, actual runner hash/read admission and GITHUB_OUTPUT ownership remain intact. No raw re-copy, source chmod/chown, extra daemon call or budget renewal was added. Image240 minutes; qualification360 with45+240+65+10; collection7+1+1+1; five-second guards; original2400/420/18/2;32MiB metadata/4GiB combined and8GiB local floor are unchanged.

## Evidence, test chronology and limits

New evidence is confined to `/workspace/diagnostic-tools/candidate-capture-qualification/host-access/`. All207 prior indexed files and all four prior index files verify byte-for-byte unchanged. The original failed hosted log/metadata/422-byte artifact also verify unchanged. An environment outage interrupted the first attempted test-file edit before it persisted; the parent confirmed clean tracked code on recovery. The same fix round resumed from its saved baseline evidence, without claiming a pre-outage RED or implementation.

1. `01-access-red` records six intended assertion failures for the missing shared traversal plan and one explicit privileged skip. These tests cover all six operation roles, POSIX precedence, whole-plan group recheck, owner-only/ACL refusal, held filesystem changes and bounded diagnostics. This is component RED, not an actual cross-UID denial witness.
2. `02-access-first` passes those six component tests with the same skip. `03-child-route-red` then records a real temporary source-file read error losing its structured child access result through the old child route. Only the unavailable credential-syscall boundary is substituted; no privileged success is simulated. `04-child-route` passes eight plus one skip, including retention of that actual early child refusal through a nonzero root-response fixture and the ordinary runner's real failure file.
3. `05-covering-first` runs66 tests and exposes two old socket-test assumptions after the child/export split (one assertion failure, one missing-context error). Those fixtures were updated to exercise the new structured child result while preserving socket/group and source-boundary assertions. `06-covering` passes64 with two explicit skips.
4. Additional postimplementation coverage was added honestly as such. `07-expanded-access` passes10 with one skip, including real unprivileged EACCES after removing directory search permission, preservation of root leaf measurements, and actual temporary Git/authority reads and byte-substitution refusal. This kernel permission test is not the distinct1001/1000 witness.
5. Final `08-final-components`: `python3 -B -m unittest discover -s scripts/numeric/tests -p test_candidate_capture_qualification.py -v` runs70 tests:68 PASS, two SKIP. Coverage additionally includes full wrapper size, present/uninspectable ACL refusal, in-measurement inode replacement and descriptor closure, exact runner public-input reads and alias refusal. Existing custody/export/partial-transfer/clock/control-only guard checks remain passing. The new real restricted-ancestor two-identity fixture measures the actual plan and checks group-enabled kernel access and unchanged private leaf metadata, but is explicitly skipped locally alongside the prior privileged handoff fixture: actual local UID/GID are1000 and sudo is absent.
6. `09-syntax-preservation` passes Python AST, all207 old evidence hashes, source clean/head/tree/index, nine protected workflow/cache/authority/snapshot files and failed-run preservation. AST comparison establishes90 original functions unchanged; only bridge_drop, bridge_child, bridge_admission, bridge_privileged and bridge_runner change, with new fixed host-access helpers. `10-scoped-whitespace` passes on the two owned paths. No unrelated project build, Docker, SDK, network, installation, privileged test, source edit, push or subagent was used.

Source remains clean463177a/tree0990, with index SHA256 `b57cc2bd2190d7e5fa1cbb941b29eb22160d41aab91e63a4fdf48a601b3a9fb1`; immutable snapshot f292 and d6 remain fixed. Recorded precommit free space is8,989,609,984 bytes, above8GiB. The final commit/proof/index are recorded below. Independent implementation review and the next exact hosted preflight remain required. Unsupported hosted ancestry or ACLs must fail with this evidence; no actual hosted handoff, source-image, six-scenario, OC10 or application acceptance is claimed.

## Fix4 isolated commit and slot release

Commit `5e066e55e9d4ee2fc0090b848d00761414525aec`, tree `cc97d98ace3e4c6cdd62a25b04b1e80eeb3fa17d`, parent `7d746f1035abc41ad6165880cdb88ef20ce223a8`. Exactly the driver and focused tests were committed using `git commit --only`. `12-commit-verification` establishes committed Git bytes equal the tested working bytes and preservation proof, owned paths/index are clean, all207 prior indexed files remain unchanged and source463 stays clean with its unchanged index. Final proof free space is8,989,466,624 bytes, above8GiB.

The separate `host-access/evidence-index.json` indexes only this round's command records, complete bounded streams, scripts, preservation/commit proofs and this updated report copy; it excludes itself. No process from this implementation remains active, and no push or hosted launch occurred. The sole implementation slot is released for independent review and the parent's next authorized work.


# Fix round5 — R4-1 restricted-ancestor fixture repair

2026-11-17. The sole Important finding R4-1 is repaired only in `scripts/numeric/tests/test_candidate_capture_qualification.py`. Prior production implementation 5e066e55 is unchanged. The dispatch parent was c36b9e83; parent documentation advanced through ab78e680 to 42a87d4 while this worker read the contract. Those parent changes were preserved. No source, workflow, policy, SDK/action pin, production reader or permission-selection relaxation was made.

The fixture's five public runner-owned game leaves (.git/HEAD, .git/config and the three fixed authorities) now receive explicit0644. Temporary public game directories receive their already-intended0755 explicitly: the new regression exposed that local umask077 otherwise narrowed mkdir(mode=0755) to0700. The parent explicitly accepted this fixture-only normalization. The source leaves remain0400, the private source directory0700 and the restricted runner ancestor0750. No real host ancestor, account, group, sudo installation or global permission was changed.

Both checks now use the same restricted-ancestor preparation helper. The new unprivileged regression records that helper's proposed chowns, verifies complete1001:1001 game/ancestor and1000:1000 source ownership, measures real fixture modes/ACL state through the existing production measurement, and projects only the captured proposed owners into the plan. It asserts the exact public/private modes, the full measured path set, no-group mode denial at the0750 ancestor, selection of only GID1001, and actual=null. Each of the five public leaves independently restored to0400, and the ancestor changed to0700, must produce the production permission_denied predicate at that exact path. These are planned-access assertions, not actual kernel two-identity evidence.

The existing privileged fixture still performs the actual no-group read denial, conditional-group child read/recheck, owner-only0700 refusal, private bytes check and unchanged leaf identity/owner/mode/size comparison. Its skip decorator is unchanged. Local UID/GID1000 and absent sudo remain recorded; neither privileged fixture was executed. Actual hosted two-identity preflight remains required after independent review and cannot be replaced by this unprivileged regression.

## Exact commands, full output and honest chronology

New evidence is confined to `/workspace/diagnostic-tools/candidate-capture-qualification/host-access-fix-5/`. The evidence runner retains exact argv/cwd, complete stdout/stderr, exit, elapsed time, stream hashes and free-space measurements. First baseline setup attempted to assert the dispatch HEAD and stopped when the parent advanced documentation; no code/evidence was overwritten and the current parent was then recorded. This was an environment-snapshot assertion, not a test failure or RED claim.

01-fixture-plan-red is an actual assertion failure before the repair: real umask077 produced additional unreadable game directories/leaves. After explicit intended public-directory modes and before leaf correction, 02-public-leaf-red is the actual production HostAccessError(permission_denied) at game/.git/HEAD. 03-fixture-plan-green passes the new planned check and explicitly skips the actual privileged witness. 04-covering-components runs71 tests:69 PASS and two SKIP. The latter remain the original cross-UID handoff and restricted-ancestor witnesses; no hosted success is inferred. 05-syntax-preservation and06-scoped-whitespace pass. All250 previously indexed files and five old indexes remain byte-for-byte unchanged, as do five parent untracked files. Production runtime files and source463/tree0990/clean index b57cc2bd remain unchanged. The parent's separately committed tracker update is recorded distinctly. Free space stayed above8GiB; precommit proof reports8,984,264,704 bytes.

### 01-fixture-plan-red

Command (cwd `/workspace/scratch/cs-numeric-kernels`), exit `1`:

```sh
python3 -B scripts/numeric/tests/test_candidate_capture_qualification.py HostAccessControls.test_restricted_fixture_planned_owners_and_real_modes_allow_required_reads -v
```

Full stdout (0 bytes):

```text
```

Full stderr (1283 bytes):

```text
test_restricted_fixture_planned_owners_and_real_modes_allow_required_reads (__main__.HostAccessControls.test_restricted_fixture_planned_owners_and_real_modes_allow_required_reads) ... FAIL

======================================================================
FAIL: test_restricted_fixture_planned_owners_and_real_modes_allow_required_reads (__main__.HostAccessControls.test_restricted_fixture_planned_owners_and_real_modes_allow_required_reads)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/workspace/scratch/cs-numeric-kernels/scripts/numeric/tests/test_candidate_capture_qualification.py", line 1182, in test_restricted_fixture_planned_owners_and_real_modes_allow_required_reads
    self.assertEqual([path for path,row in rows.items() if not d.bridge_access_permission(row,[])[1]],[root])
AssertionError: Lists differ: [Posi[25 chars]ork'), PosixPath('/tmp/tmp5dt7uyxa/work/game')[569 chars]js')] != [Posi[25 chars]ork')]

First list contains 10 additional elements.
First extra element 1:
PosixPath('/tmp/tmp5dt7uyxa/work/game')

Diff is 802 characters long. Set self.maxDiff to None to see it.

----------------------------------------------------------------------
Ran 1 test in 0.107s

FAILED (failures=1)
```
### 02-public-leaf-red

Command (cwd `/workspace/scratch/cs-numeric-kernels`), exit `1`:

```sh
python3 -B scripts/numeric/tests/test_candidate_capture_qualification.py HostAccessControls.test_restricted_fixture_planned_owners_and_real_modes_allow_required_reads -v
```

Full stdout (0 bytes):

```text
```

Full stderr (1530 bytes):

```text
test_restricted_fixture_planned_owners_and_real_modes_allow_required_reads (__main__.HostAccessControls.test_restricted_fixture_planned_owners_and_real_modes_allow_required_reads) ... ERROR

======================================================================
ERROR: test_restricted_fixture_planned_owners_and_real_modes_allow_required_reads (__main__.HostAccessControls.test_restricted_fixture_planned_owners_and_real_modes_allow_required_reads)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/workspace/scratch/cs-numeric-kernels/scripts/numeric/tests/test_candidate_capture_qualification.py", line 1185, in test_restricted_fixture_planned_owners_and_real_modes_allow_required_reads
    d.bridge_access_choose(value)
  File "/workspace/scratch/cs-numeric-kernels/scripts/numeric/candidate-capture-qualification.py", line 2169, in bridge_access_choose
    if not allowed:bridge_access_fail(record,'permission_denied',bridge_access_path(record,i),'mode-admission')
                   ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/workspace/scratch/cs-numeric-kernels/scripts/numeric/candidate-capture-qualification.py", line 2139, in bridge_access_fail
    raise HostAccessError(record)
qualification_driver.HostAccessError: host access permission_denied: /tmp/tmpb40z_4cz/work/game/.git/HEAD

----------------------------------------------------------------------
Ran 1 test in 0.106s

FAILED (errors=1)
```
### 03-fixture-plan-green

Command (cwd `/workspace/scratch/cs-numeric-kernels`), exit `0`:

```sh
python3 -B scripts/numeric/tests/test_candidate_capture_qualification.py HostAccessControls.test_restricted_fixture_planned_owners_and_real_modes_allow_required_reads HostAccessControls.test_real_restricted_ancestor_group_read_preserves_private_leaf -v
```

Full stdout (0 bytes):

```text
```

Full stderr (553 bytes):

```text
test_restricted_fixture_planned_owners_and_real_modes_allow_required_reads (__main__.HostAccessControls.test_restricted_fixture_planned_owners_and_real_modes_allow_required_reads) ... ok
test_real_restricted_ancestor_group_read_preserves_private_leaf (__main__.HostAccessControls.test_real_restricted_ancestor_group_read_preserves_private_leaf) ... skipped 'actual restricted-ancestor two-identity witness unavailable: local UID1000, no sudo'

----------------------------------------------------------------------
Ran 2 tests in 0.101s

OK (skipped=1)
```
### 04-covering-components

Command (cwd `/workspace/scratch/cs-numeric-kernels`), exit `0`:

```sh
python3 -B -m unittest discover -s scripts/numeric/tests -p test_candidate_capture_qualification.py -v
```

Full stdout (110 bytes):

```text
{"host_sized_rows": 29, "access_bytes": 5659, "child_bytes": 6202, "root_bytes": 5858, "failure_bytes": 6328}
```

Full stderr (15897 bytes):

```text
test_closed_schedule_preserves_all_remaining_budgets (test_candidate_capture_qualification.DriverContracts.test_closed_schedule_preserves_all_remaining_budgets) ... ok
test_real_files_reject_alias_hardlink_and_truncation (test_candidate_capture_qualification.DriverContracts.test_real_files_reject_alias_hardlink_and_truncation) ... ok
test_truncated_or_duplicate_records_are_never_admitted (test_candidate_capture_qualification.DriverContracts.test_truncated_or_duplicate_records_are_never_admitted) ... ok
test_actual_collection_timer_reuses_clock_and_marks_exhaustion_incomplete (test_candidate_capture_qualification.EvidenceBoundaryControls.test_actual_collection_timer_reuses_clock_and_marks_exhaustion_incomplete) ... ok
test_actual_original_summary_requires_full_untruncated_numeric_result (test_candidate_capture_qualification.EvidenceBoundaryControls.test_actual_original_summary_requires_full_untruncated_numeric_result) ... ok
test_all_six_closed_outcomes_refuse_unknown_ownership_missing_endpoints_and_overbudget (test_candidate_capture_qualification.EvidenceBoundaryControls.test_all_six_closed_outcomes_refuse_unknown_ownership_missing_endpoints_and_overbudget) ... ok
test_always_collector_resets_stale_complete_and_requires_every_phase_endpoint (test_candidate_capture_qualification.EvidenceBoundaryControls.test_always_collector_resets_stale_complete_and_requires_every_phase_endpoint) ... ok
test_archive_preserves_real_direct_alias_and_refuses_missing_or_added_member (test_candidate_capture_qualification.EvidenceBoundaryControls.test_archive_preserves_real_direct_alias_and_refuses_missing_or_added_member) ... ok
test_artifact_overflow_and_local_copy_accounting (test_candidate_capture_qualification.EvidenceBoundaryControls.test_artifact_overflow_and_local_copy_accounting) ... ok
test_collection_clock_caps_early_and_late_failures_without_renewal (test_candidate_capture_qualification.EvidenceBoundaryControls.test_collection_clock_caps_early_and_late_failures_without_renewal) ... ok
test_early_and_attachment_failures_retain_available_observations_and_typed_spool (test_candidate_capture_qualification.EvidenceBoundaryControls.test_early_and_attachment_failures_retain_available_observations_and_typed_spool) ... ok
test_exact_gate_survivors_are_required_and_custody_bound (test_candidate_capture_qualification.EvidenceBoundaryControls.test_exact_gate_survivors_are_required_and_custody_bound) ... ok
test_fresh_subject_requires_actual_cargo_root_inode_listing_and_elf_joins (test_candidate_capture_qualification.EvidenceBoundaryControls.test_fresh_subject_requires_actual_cargo_root_inode_listing_and_elf_joins) ... ok
test_host_bridge_actual_two_identity_drop_and_export (test_candidate_capture_qualification.EvidenceBoundaryControls.test_host_bridge_actual_two_identity_drop_and_export) ... skipped 'real two-identity fixture unavailable: local UID1000 and sudo absent'
test_host_bridge_child_closes_unrelated_descriptors (test_candidate_capture_qualification.EvidenceBoundaryControls.test_host_bridge_child_closes_unrelated_descriptors) ... ok
test_host_bridge_control_output_is_closed_and_preserves_runner_file (test_candidate_capture_qualification.EvidenceBoundaryControls.test_host_bridge_control_output_is_closed_and_preserves_runner_file) ... ok
test_host_bridge_export_inventory_and_one_time_noreplace_transfer (test_candidate_capture_qualification.EvidenceBoundaryControls.test_host_bridge_export_inventory_and_one_time_noreplace_transfer) ... ok
test_host_bridge_fixed_invocation_environment_and_privileged_deadline_structure (test_candidate_capture_qualification.EvidenceBoundaryControls.test_host_bridge_fixed_invocation_environment_and_privileged_deadline_structure) ... ok
test_host_bridge_inventory_rejects_missing_ownership_cap_and_cross_device (test_candidate_capture_qualification.EvidenceBoundaryControls.test_host_bridge_inventory_rejects_missing_ownership_cap_and_cross_device) ... ok
test_host_bridge_later_guards_are_control_only_and_keep_original_clock (test_candidate_capture_qualification.EvidenceBoundaryControls.test_host_bridge_later_guards_are_control_only_and_keep_original_clock) ... ok
test_host_bridge_missing_root_entry_retains_actual_failure_and_runner_output (test_candidate_capture_qualification.EvidenceBoundaryControls.test_host_bridge_missing_root_entry_retains_actual_failure_and_runner_output) ... host bridge incomplete: root bridge did not return: planted sudo refusal
host bridge incomplete: root bridge did not return: planted image refusal
ok
test_host_bridge_partial_image_export_never_sets_upload_safe (test_candidate_capture_qualification.EvidenceBoundaryControls.test_host_bridge_partial_image_export_never_sets_upload_safe) ... host bridge incomplete: root bridge did not return: planted transfer interruption
ok
test_host_bridge_partial_transfer_raises_without_replacement_or_admission (test_candidate_capture_qualification.EvidenceBoundaryControls.test_host_bridge_partial_transfer_raises_without_replacement_or_admission) ... ok
test_host_bridge_real_child_signal_and_oversized_control_refuse (test_candidate_capture_qualification.EvidenceBoundaryControls.test_host_bridge_real_child_signal_and_oversized_control_refuse) ... ok
test_host_bridge_runner_verification_obeys_shortened_absolute_deadline (test_candidate_capture_qualification.EvidenceBoundaryControls.test_host_bridge_runner_verification_obeys_shortened_absolute_deadline) ... host bridge incomplete: host handoff deadline exhausted
ok
test_host_bridge_supervisor_reaps_timeout_and_preserves_child_failure (test_candidate_capture_qualification.EvidenceBoundaryControls.test_host_bridge_supervisor_reaps_timeout_and_preserves_child_failure) ... ok
test_host_bridge_unsafe_export_members_and_expired_transfer_refuse (test_candidate_capture_qualification.EvidenceBoundaryControls.test_host_bridge_unsafe_export_members_and_expired_transfer_refuse) ... ok
test_host_bridge_workflow_keeps_runner_output_and_uses_early_real_preflight (test_candidate_capture_qualification.EvidenceBoundaryControls.test_host_bridge_workflow_keeps_runner_output_and_uses_early_real_preflight) ... ok
test_host_upload_admission_reuses_source_clock_and_refuses_late_raw_upload (test_candidate_capture_qualification.EvidenceBoundaryControls.test_host_upload_admission_reuses_source_clock_and_refuses_late_raw_upload) ... ok
test_later_forward_receipt_requires_original_typed_reverse_location (test_candidate_capture_qualification.EvidenceBoundaryControls.test_later_forward_receipt_requires_original_typed_reverse_location) ... ok
test_mutant_inventory_omissions_never_redefine_complete_source_evidence (test_candidate_capture_qualification.EvidenceBoundaryControls.test_mutant_inventory_omissions_never_redefine_complete_source_evidence) ... ok
test_mutant_receipts_join_same_inputs_compiler_and_only_selected_source_change (test_candidate_capture_qualification.EvidenceBoundaryControls.test_mutant_receipts_join_same_inputs_compiler_and_only_selected_source_change) ... ok
test_no_ambient_route_build_profile_or_tool_override (test_candidate_capture_qualification.EvidenceBoundaryControls.test_no_ambient_route_build_profile_or_tool_override) ... ok
test_only_fully_validated_named_fault_can_finish_a_negative_scenario (test_candidate_capture_qualification.EvidenceBoundaryControls.test_only_fully_validated_named_fault_can_finish_a_negative_scenario) ... ok
test_original_cache_retirement_requires_both_receipts_and_each_surviving_copy (test_candidate_capture_qualification.EvidenceBoundaryControls.test_original_cache_retirement_requires_both_receipts_and_each_surviving_copy) ... ok
test_probe_result_requires_all_ordered_mutations_actual_errno_and_full_closure (test_candidate_capture_qualification.EvidenceBoundaryControls.test_probe_result_requires_all_ordered_mutations_actual_errno_and_full_closure) ... ok
test_raw_cleanup_observation_suffix_loss_does_not_change_expected_count (test_candidate_capture_qualification.EvidenceBoundaryControls.test_raw_cleanup_observation_suffix_loss_does_not_change_expected_count) ... ok
test_registry_count_bound_is_checked_before_arbitrary_discovery (test_candidate_capture_qualification.EvidenceBoundaryControls.test_registry_count_bound_is_checked_before_arbitrary_discovery) ... ok
test_typed_registry_real_files_missing_alias_stale_and_cross_kind (test_candidate_capture_qualification.EvidenceBoundaryControls.test_typed_registry_real_files_missing_alias_stale_and_cross_kind) ... ok
test_uncertain_retirement_never_satisfies_negative_qualification (test_candidate_capture_qualification.EvidenceBoundaryControls.test_uncertain_retirement_never_satisfies_negative_qualification) ... ok
test_workflow_collection_host_and_uploads_have_fixed_same_clock_bounds (test_candidate_capture_qualification.EvidenceBoundaryControls.test_workflow_collection_host_and_uploads_have_fixed_same_clock_bounds) ... ok
test_workflow_exact_pins_narrow_trigger_and_always_bounded_exports (test_candidate_capture_qualification.EvidenceBoundaryControls.test_workflow_exact_pins_narrow_trigger_and_always_bounded_exports) ... ok
test_workflow_host_cleanup_exact_original_allowlist_after_absolute_clock (test_candidate_capture_qualification.EvidenceBoundaryControls.test_workflow_host_cleanup_exact_original_allowlist_after_absolute_clock) ... ok
test_added_group_must_not_mask_other_access_elsewhere_in_the_plan (test_candidate_capture_qualification.HostAccessControls.test_added_group_must_not_mask_other_access_elsewhere_in_the_plan) ... ok
test_all_six_operations_select_only_a_necessary_runner_group (test_candidate_capture_qualification.HostAccessControls.test_all_six_operations_select_only_a_necessary_runner_group) ... ok
test_early_child_read_refusal_is_structured_and_runner_retains_it (test_candidate_capture_qualification.HostAccessControls.test_early_child_read_refusal_is_structured_and_runner_retains_it) ... host bridge incomplete: host access read_join_refusal: /tmp/tmpoh23uokm/work/prismpm/target/candidate-qualification-driver/preparation-partial.json
ok
test_fixed_game_git_and_copied_authority_reads_are_real_and_detect_changes (test_candidate_capture_qualification.HostAccessControls.test_fixed_game_git_and_copied_authority_reads_are_real_and_detect_changes) ... ok
test_host_sized_ancestry_socket_and_failure_wrapper_fit_existing_pipe (test_candidate_capture_qualification.HostAccessControls.test_host_sized_ancestry_socket_and_failure_wrapper_fit_existing_pipe) ... ok
test_overflow_keeps_the_denied_prefix_and_actual_credential_facts (test_candidate_capture_qualification.HostAccessControls.test_overflow_keeps_the_denied_prefix_and_actual_credential_facts) ... ok
test_owner_only_missing_search_and_unsupported_acl_refuse (test_candidate_capture_qualification.HostAccessControls.test_owner_only_missing_search_and_unsupported_acl_refuse) ... ok
test_posix_owner_and_matching_group_never_fall_back_to_other_bits (test_candidate_capture_qualification.HostAccessControls.test_posix_owner_and_matching_group_never_fall_back_to_other_bits) ... ok
test_present_acl_and_in_measurement_replacement_refuse_and_close_descriptors (test_candidate_capture_qualification.HostAccessControls.test_present_acl_and_in_measurement_replacement_refuse_and_close_descriptors) ... ok
test_real_child_lookup_denial_keeps_root_leaf_measurement_and_errno (test_candidate_capture_qualification.HostAccessControls.test_real_child_lookup_denial_keeps_root_leaf_measurement_and_errno) ... ok
test_real_measurement_rechecks_replaced_inode_and_refuses_alias_or_unknown_acl (test_candidate_capture_qualification.HostAccessControls.test_real_measurement_rechecks_replaced_inode_and_refuses_alias_or_unknown_acl) ... ok
test_real_restricted_ancestor_group_read_preserves_private_leaf (test_candidate_capture_qualification.HostAccessControls.test_real_restricted_ancestor_group_read_preserves_private_leaf) ... skipped 'actual restricted-ancestor two-identity witness unavailable: local UID1000, no sudo'
test_restricted_fixture_planned_owners_and_real_modes_allow_required_reads (test_candidate_capture_qualification.HostAccessControls.test_restricted_fixture_planned_owners_and_real_modes_allow_required_reads) ... ok
test_runner_build_readiness_reads_exact_public_files_and_refuses_alias (test_candidate_capture_qualification.HostAccessControls.test_runner_build_readiness_reads_exact_public_files_and_refuses_alias) ... ok
test_host_socket_actual_failure_measurement_survives_runner_status_bound (test_candidate_capture_qualification.HostSocketLayoutControls.test_host_socket_actual_failure_measurement_survives_runner_status_bound) ... host bridge incomplete: root bridge did not return: candidate capture qualification incomplete: host socket {"canonical":"/run/docker.sock","layout":"os-run-alias","logical":"/var/run/docker.sock","logical_socket":null,"parents":{"/":{"dev":27,"gid":1000,"ino":1086398,"kind":"directory","mode":16832,"uid":1000},"/run":{"dev":27,"gid":1000,"ino":1086400,"kind":"directory","mode":16832,"uid":1000},"/var":{"dev":27,"gid":1000,"ino":1086399,"kind":"directory","mode":16832,"uid":1000}},"predicate":"final_not_socket","schema":"cs1618/host-docker-socket/1","socket":{"dev":27,"gid":1000,"ino":1086403,"kind":"symlink","mode":41471,"uid":1000},"status":"incomplete","var_run":{"dev":27,"gid":1000,"ino":1086401,"kind":"symlink","link":"../run","link_bytes":6,"link_truncated":false,"mode":41471,"uid":1000}}

ok
test_host_socket_actual_replacement_during_held_measurement_and_descriptor_closure (test_candidate_capture_qualification.HostSocketLayoutControls.test_host_socket_actual_replacement_during_held_measurement_and_descriptor_closure) ... ok
test_host_socket_deadline_and_fixed_production_wrapper (test_candidate_capture_qualification.HostSocketLayoutControls.test_host_socket_deadline_and_fixed_production_wrapper) ... ok
test_host_socket_group_and_identity_reach_existing_child_before_source_access (test_candidate_capture_qualification.HostSocketLayoutControls.test_host_socket_group_and_identity_reach_existing_child_before_source_access) ... ok
test_host_socket_held_identity_and_child_remeasurement_refuse_changes (test_candidate_capture_qualification.HostSocketLayoutControls.test_host_socket_held_identity_and_child_remeasurement_refuse_changes) ... ok
test_host_socket_real_parent_alias_regression_and_closed_positive_layouts (test_candidate_capture_qualification.HostSocketLayoutControls.test_host_socket_real_parent_alias_regression_and_closed_positive_layouts) ... ok
test_host_socket_rejects_extra_aliases_types_ownership_and_writable_parents (test_candidate_capture_qualification.HostSocketLayoutControls.test_host_socket_rejects_extra_aliases_types_ownership_and_writable_parents) ... ok
test_attachment_is_separate_noncompletion_mode (test_candidate_capture_qualification.ProbeContract.test_attachment_is_separate_noncompletion_mode) ... ok
test_closed_mode_argv_deadline_and_capsules (test_candidate_capture_qualification.ProbeContract.test_closed_mode_argv_deadline_and_capsules) ... ok
test_exact_actual_code_and_capsule_binding (test_candidate_capture_qualification.ProbeContract.test_exact_actual_code_and_capsule_binding) ... ok
test_sdk_environment_is_actual_and_closed (test_candidate_capture_qualification.ProbeContract.test_sdk_environment_is_actual_and_closed) ... ok
test_path_inventory_comes_from_descriptor_not_surviving_files (test_candidate_capture_qualification.RealFileProbeControls.test_path_inventory_comes_from_descriptor_not_surviving_files) ... ok
test_real_writable_operations_never_qualify (test_candidate_capture_qualification.RealFileProbeControls.test_real_writable_operations_never_qualify) ... ok
test_regular_refuses_aliases_links_and_oversize (test_candidate_capture_qualification.RealFileProbeControls.test_regular_refuses_aliases_links_and_oversize) ... ok

----------------------------------------------------------------------
Ran 71 tests in 1.080s

OK (skipped=2)
```
### 05-syntax-preservation

Command (cwd `/workspace/scratch/cs-numeric-kernels`), exit `0`:

```sh
python3 -B /workspace/diagnostic-tools/candidate-capture-qualification/host-access-fix-5/verify.py 05-preservation-proof
```

Full stdout (977 bytes):

```text
{
  "scope": "fixture-planned-access-only-no-actual-cross-identity-or-hosted-success",
  "game_head": "42a87d4b3ffdf6689a5a6582da1a7a506ccc0084",
  "owned": {
    "path": "scripts/numeric/tests/test_candidate_capture_qualification.py",
    "bytes": 108025,
    "sha256": "3d5e74caa9b7fd63304a6b82a2dd7d0f5e538f49c5d75939f25755ff2fb97e97"
  },
  "prior_indexed_files_unchanged": 250,
  "prior_indexes_unchanged": 5,
  "parent_untracked_files_unchanged": 5,
  "parent_doc_changes": [
    "docs/research/NUMERIC-EXPORT-TRACKER.md"
  ],
  "nonowned_runtime_unchanged": true,
  "source_head": "463177a0971d95e112e10ed5da39c8cbaf0a4c96",
  "source_tree": "0990e900cf1cb5bb4a481bba781a86cc3fcf0999",
  "source_index_sha256": "b57cc2bd2190d7e5fa1cbb941b29eb22160d41aab91e63a4fdf48a601b3a9fb1",
  "source_clean": true,
  "python_ast": "PASS",
  "canonical_report_prefix_unchanged": true,
  "local_uid": 1000,
  "local_gid": 1000,
  "sudo_available": false,
  "free_bytes": 8984264704
}
```

Full stderr (0 bytes):

```text
```
### 06-scoped-whitespace

Command (cwd `/workspace/scratch/cs-numeric-kernels`), exit `0`:

```sh
git diff --check -- scripts/numeric/tests/test_candidate_capture_qualification.py
```

Full stdout (0 bytes):

```text
```

Full stderr (0 bytes):

```text
```

## Fix5 isolated commit and slot release

Commit `1243d59531541ab1117539d37a48a1675fe318e0`, tree `d62955dcb04891f2548faa9f6f87609848088a6c`, parent `c8f12efa84731dfcbbb6e39e57e53af0a1a879cd`. Exactly the owned test file was committed using `git commit --only`. Committed bytes equal tested working bytes, AST and whitespace checks pass, owned index/worktree are clean, all250 prior indexed files/five indexes and five parent untracked files remain unchanged. Source stays clean463177a with its original index. Final proof records8,984,104,960 free bytes, above8GiB.

The scoped `review.patch` and this updated canonical report copy are indexed only in the separate `host-access-fix-5/evidence-index.json`, alongside exact command records and complete streams. No production edits, subagents, pushes, network, Docker, builds, installs or privileged tests occurred. No worker process remains active. Implementation slot released for independent review. Actual hosted two-identity preflight, source-image/scenarios/OC10 and artifact gates remain unproved.

### 07-isolated-commit

Command (cwd `/workspace/scratch/cs-numeric-kernels`), exit `0`:

```sh
git commit --only -m 'test: correct restricted host access fixture permissions' -- scripts/numeric/tests/test_candidate_capture_qualification.py
```

Full stdout (133 bytes):

```text
[numeric-kernels 1243d59] test: correct restricted host access fixture permissions
 1 file changed, 60 insertions(+), 4 deletions(-)
```

Full stderr (0 bytes):

```text
```

### 08-commit-verification

Command (cwd `/workspace/scratch/cs-numeric-kernels`), exit `0`:

```sh
python3 -B /workspace/diagnostic-tools/candidate-capture-qualification/host-access-fix-5/verify.py 08-commit-proof
```

Full stdout (1137 bytes):

```text
{
  "scope": "fixture-planned-access-only-no-actual-cross-identity-or-hosted-success",
  "game_head": "1243d59531541ab1117539d37a48a1675fe318e0",
  "owned": {
    "path": "scripts/numeric/tests/test_candidate_capture_qualification.py",
    "bytes": 108025,
    "sha256": "3d5e74caa9b7fd63304a6b82a2dd7d0f5e538f49c5d75939f25755ff2fb97e97"
  },
  "prior_indexed_files_unchanged": 250,
  "prior_indexes_unchanged": 5,
  "parent_untracked_files_unchanged": 5,
  "parent_doc_changes": [
    "docs/research/NUMERIC-EXPORT-TRACKER.md"
  ],
  "nonowned_runtime_unchanged": true,
  "source_head": "463177a0971d95e112e10ed5da39c8cbaf0a4c96",
  "source_tree": "0990e900cf1cb5bb4a481bba781a86cc3fcf0999",
  "source_index_sha256": "b57cc2bd2190d7e5fa1cbb941b29eb22160d41aab91e63a4fdf48a601b3a9fb1",
  "source_clean": true,
  "python_ast": "PASS",
  "canonical_report_prefix_unchanged": true,
  "local_uid": 1000,
  "local_gid": 1000,
  "sudo_available": false,
  "free_bytes": 8984104960,
  "committed_tested_bytes_equal": true,
  "game_tree": "d62955dcb04891f2548faa9f6f87609848088a6c",
  "game_parent": "c8f12efa84731dfcbbb6e39e57e53af0a1a879cd"
}
```

Full stderr (0 bytes):

```text
```

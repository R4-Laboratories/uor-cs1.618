import ast,hashlib,json,os,pathlib,shutil,subprocess,sys
folder=pathlib.Path(__file__).resolve().parent
game=pathlib.Path('/workspace/scratch/cs-numeric-kernels')
source=pathlib.Path('/workspace/scratch/prismpm-numeric')
owned='scripts/numeric/tests/test_candidate_capture_qualification.py'
baseline=json.loads((folder/'00-baseline.json').read_text())
def sha(data):return hashlib.sha256(data).hexdigest()
def git(root,*args):
    return subprocess.check_output(['git','-C',str(root),*args],env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'})
count=0
for item in baseline['indexes']:
    directory=pathlib.Path(item['directory']);body=(directory/'evidence-index.json').read_bytes()
    assert sha(body)==item['sha256']
    rows=json.loads(body)['files'];assert len(rows)==item['files']
    for row in rows:
        raw=(directory/row['path']).read_bytes()
        assert len(raw)==row['bytes'] and sha(raw)==row['sha256'];count+=1
assert count==250
parent_doc_changes=[]
for path,digest in baseline['tracked'].items():
    if path==owned:continue
    if sha((game/path).read_bytes())!=digest:
        assert path.startswith('docs/'),path
        parent_doc_changes.append(path)
for path,digest in baseline['parent_untracked'].items():
    assert sha((game/path).read_bytes())==digest,path
assert git(source,'rev-parse','HEAD').decode().strip()==baseline['source_head']
assert git(source,'rev-parse','HEAD^{tree}').decode().strip()==baseline['source_tree']
assert sha((source/'.git/index').read_bytes())==baseline['source_index_sha256']
assert not git(source,'status','--porcelain=v1','--untracked-files=all').strip()
assert not git(game,'diff','--cached','--name-only','--',owned).strip()
changed=git(game,'diff','--name-only').decode().splitlines()
assert not set(changed)-{owned},changed
ast.parse((game/owned).read_bytes(),filename=owned)
report=game/'.superpowers/sdd/candidate-source-capture/task-4b-report.md'
assert report.read_bytes().startswith((folder/'00-report-before.md').read_bytes())
free=shutil.disk_usage(game).free;assert free>=8*1024**3
result={'scope':'fixture-planned-access-only-no-actual-cross-identity-or-hosted-success',
        'game_head':git(game,'rev-parse','HEAD').decode().strip(),
        'owned':{'path':owned,'bytes':(game/owned).stat().st_size,'sha256':sha((game/owned).read_bytes())},
        'prior_indexed_files_unchanged':count,'prior_indexes_unchanged':len(baseline['indexes']),
        'parent_untracked_files_unchanged':len(baseline['parent_untracked']),
        'parent_doc_changes':parent_doc_changes,'nonowned_runtime_unchanged':True,
        'source_head':baseline['source_head'],'source_tree':baseline['source_tree'],
        'source_index_sha256':baseline['source_index_sha256'],'source_clean':True,
        'python_ast':'PASS','canonical_report_prefix_unchanged':True,
        'local_uid':os.getuid(),'local_gid':os.getgid(),'sudo_available':shutil.which('sudo') is not None,
        'free_bytes':free}
if sys.argv[1]=='08-commit-proof':
    assert git(game,'diff-tree','--no-commit-id','--name-only','-r','HEAD').decode().splitlines()==[owned]
    assert git(game,'show','HEAD:'+owned)==(game/owned).read_bytes()
    assert not changed
    result['committed_tested_bytes_equal']=True
    result['game_tree']=git(game,'rev-parse','HEAD^{tree}').decode().strip()
    result['game_parent']=git(game,'rev-parse','HEAD^').decode().strip()
(folder/(sys.argv[1]+'.json')).write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))

python3 -I -B /workspace/diagnostic-tools/candidate-capture-protocol/fix-1/07-probes.py

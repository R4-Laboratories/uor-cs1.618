import copy, importlib.util, json, os, pathlib, subprocess, time
path = pathlib.Path('/workspace/scratch/prismpm-numeric/scripts/conditional-capture-candidate.test.py')
spec = importlib.util.spec_from_file_location('fix_controls', path)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
m.ProtocolControls.setUpClass()
case = m.ProtocolControls()
case.setUp()
try:
    descriptor = copy.deepcopy(case.descriptor)
    next(r for r in descriptor['union'] if r['path'] == 'tool')['executable'] = 1
    descriptor['authority'][0]['executable'] = 0
    try:
        case.materialize(payload=case.payload(descriptor), descriptor=descriptor)
        raise AssertionError('malformed descriptor admitted')
    except RuntimeError as error:
        assert not case.destination.exists()
        print('TYPE_PROBE: refused before destination creation:', error)
    source, executable, calls = case.root / 'slow.c', case.root / 'slow', case.root / 'calls'
    source.write_text('#include <unistd.h>\n#include <stdio.h>\nint main(void){FILE *f=fopen('
                      + json.dumps(str(calls)) + ',"a");fprintf(f,"%d\\n",getpid());fclose(f);'
                      'fputs("slow-listing-started\\n",stderr);fflush(stderr);puts("'
                      + m.legacy.TEST + ': test");fflush(stdout);sleep(2);return 0;}\n')
    subprocess.run(['/usr/bin/cc', str(source), '-o', str(executable)], check=True, capture_output=True)
    started = time.monotonic()
    try:
        m.candidate.measure_inputs(case.source, executable, 1)
        raise AssertionError('expired listing admitted')
    except RuntimeError as error:
        elapsed = time.monotonic() - started
        pids = calls.read_text().splitlines()
        assert elapsed < 1.8 and len(pids) == 1
        absent = reaped = False
        try:
            os.kill(int(pids[0]), 0)
        except ProcessLookupError:
            absent = True
        try:
            os.waitpid(int(pids[0]), os.WNOHANG)
        except ChildProcessError:
            reaped = True
        assert absent and reaped
        print('DEADLINE_PROBE: remaining_seconds=1; elapsed=%.6fs; calls=%d; absent=%s; reaped=%s; refusal=%s'
              % (elapsed, len(pids), absent, reaped, error))
        print('RETAINED_STDOUT:', repr(error.stdout))
        print('RETAINED_STDERR:', repr(error.stderr))
finally:
    case.doCleanups()
    m.ProtocolControls.tearDownClass()

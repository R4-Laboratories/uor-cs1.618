python3 -I -B scripts/conditional-capture-candidate.test.py

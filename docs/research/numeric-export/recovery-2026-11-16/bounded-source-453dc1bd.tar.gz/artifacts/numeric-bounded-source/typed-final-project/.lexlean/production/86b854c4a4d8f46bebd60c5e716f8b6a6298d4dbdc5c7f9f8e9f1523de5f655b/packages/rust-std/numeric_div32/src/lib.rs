#![forbid(unsafe_code)]
use core::cmp::Ordering;

use core::sync::atomic::{AtomicU64, Ordering as Memory};

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub struct Overflow;

pub type R<T> = Result<T, Overflow>;

static WORK: AtomicU64 = AtomicU64::new(0);

pub fn tick(units: u64) { WORK.fetch_add(units, Memory::Relaxed); }

pub fn work() -> u64 { WORK.load(Memory::Relaxed) }

pub trait Same {
    fn same(&self, other: &Self) -> bool;
}

pub trait Key {
    fn key(&self, other: &Self) -> Ordering;
}

impl Same for bool {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for bool {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u8 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u8 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u16 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u16 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u32 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u32 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u64 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u64 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i8 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i8 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i16 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i16 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i32 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i32 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i64 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i64 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for Ordering {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl<A: Key, B: Key> Key for (A, B) {
    fn key(&self, other: &Self) -> Ordering { match self.0.key(&other.0) { Ordering::Equal => self.1.key(&other.1), decided => decided, } }
}

pub fn equal<T: Same>(a: T, b: T) -> bool { a.same(&b) }

pub fn compare<T: Key>(a: T, b: T) -> Ordering { a.key(&b) }

pub fn nat_add(p0: u64, p1: u64) -> R<u64> {
    match u64::checked_add(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<u64, Overflow>(Overflow)
        }
    }
}

pub fn nat_sub(p0: u64, p1: u64) -> u64 {
    u64::saturating_sub(p0, p1)
}

pub fn nat_mul(p0: u64, p1: u64) -> R<u64> {
    match u64::checked_mul(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<u64, Overflow>(Overflow)
        }
    }
}

pub fn nat_quot(p0: u64, p1: u64, p2: u64) -> u64 {
    u64::checked_div(p0, p1).unwrap_or(p2)
}

pub fn nat_rem(p0: u64, p1: u64, p2: u64) -> u64 {
    u64::checked_rem(p0, p1).unwrap_or(p2)
}

pub fn nat_eq(p0: u64, p1: u64) -> bool {
    core::cmp::PartialEq::eq(&p0, &p1)
}

pub fn nat_le(p0: u64, p1: u64) -> bool {
    core::cmp::PartialOrd::le(&p0, &p1)
}

pub fn nat_lt(p0: u64, p1: u64) -> bool {
    core::cmp::PartialOrd::lt(&p0, &p1)
}

pub fn nat_succ(p0: u64) -> R<u64> {
    match u64::checked_add(p0, 1u64) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<u64, Overflow>(Overflow)
        }
    }
}

pub fn int_add(p0: i64, p1: i64) -> R<i64> {
    match i64::checked_add(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_sub(p0: i64, p1: i64) -> R<i64> {
    match i64::checked_sub(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_mul(p0: i64, p1: i64) -> R<i64> {
    match i64::checked_mul(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_neg(p0: i64) -> R<i64> {
    match i64::checked_neg(p0) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_quot(p0: i64, p1: i64, p2: i64) -> R<i64> {
    { let value = { let (a, b, z): (i64, i64, i64) = (p0, p1, p2); if b == 0 { Some(z) } else { a.checked_div(b) } }; match value {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    } }
}

pub fn int_rem(p0: i64, p1: i64, p2: i64) -> i64 {
    { let (a, b, z): (i64, i64, i64) = (p0, p1, p2); if b == 0 { z } else { a.wrapping_rem(b) } }
}

pub fn bool_not(p0: bool) -> bool {
    !p0
}

pub fn bool_and(p0: bool, p1: bool) -> bool {
    if p0 {
        p1
    } else {
        false
    }
}

pub fn bool_or(p0: bool, p1: bool) -> bool {
    if p0 {
        true
    } else {
        p1
    }
}

pub mod fixed_u8 {
    pub fn checked_add(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u8, p1: u8) -> u8 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u8, p1: u8) -> u8 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u8, p1: u8) -> u8 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u8) -> u8 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u8, p1: u32) -> Option<u8> {
        u8::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u8, p1: u32) -> Option<u8> {
        u8::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u8> {
        u8::try_from(p0).ok()
    }
}

pub mod fixed_u16 {
    pub fn checked_add(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u16, p1: u16) -> u16 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u16, p1: u16) -> u16 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u16, p1: u16) -> u16 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u16) -> u16 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u16, p1: u32) -> Option<u16> {
        u16::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u16, p1: u32) -> Option<u16> {
        u16::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u16> {
        u16::try_from(p0).ok()
    }
}

pub mod fixed_u32 {
    pub fn checked_add(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u32, p1: u32) -> u32 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u32, p1: u32) -> u32 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u32, p1: u32) -> u32 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u32) -> u32 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u32> {
        u32::try_from(p0).ok()
    }
}

pub mod fixed_u64 {
    pub fn checked_add(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u64, p1: u64) -> u64 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u64, p1: u64) -> u64 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u64, p1: u64) -> u64 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u64) -> u64 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u64, p1: u32) -> Option<u64> {
        u64::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u64, p1: u32) -> Option<u64> {
        u64::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u64> {
        u64::try_from(p0).ok()
    }
}

pub mod fixed_i8 {
    pub fn checked_add(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i8, p1: i8) -> i8 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i8, p1: i8) -> i8 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i8, p1: i8) -> i8 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i8) -> i8 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i8, p1: u32) -> Option<i8> {
        i8::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i8, p1: u32) -> Option<i8> {
        i8::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i8> {
        i8::try_from(p0).ok()
    }
}

pub fn checked_neg_i8(p0: i8) -> Option<i8> {
    i8::checked_neg(p0)
}

pub mod fixed_i16 {
    pub fn checked_add(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i16, p1: i16) -> i16 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i16, p1: i16) -> i16 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i16, p1: i16) -> i16 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i16) -> i16 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i16, p1: u32) -> Option<i16> {
        i16::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i16, p1: u32) -> Option<i16> {
        i16::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i16> {
        i16::try_from(p0).ok()
    }
}

pub fn checked_neg_i16(p0: i16) -> Option<i16> {
    i16::checked_neg(p0)
}

pub mod fixed_i32 {
    pub fn checked_add(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i32, p1: i32) -> i32 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i32, p1: i32) -> i32 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i32, p1: i32) -> i32 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i32) -> i32 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i32, p1: u32) -> Option<i32> {
        i32::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i32, p1: u32) -> Option<i32> {
        i32::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i32> {
        i32::try_from(p0).ok()
    }
}

pub fn checked_neg_i32(p0: i32) -> Option<i32> {
    i32::checked_neg(p0)
}

pub mod fixed_i64 {
    pub fn checked_add(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i64, p1: i64) -> i64 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i64, p1: i64) -> i64 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i64, p1: i64) -> i64 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i64) -> i64 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i64, p1: u32) -> Option<i64> {
        i64::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i64, p1: u32) -> Option<i64> {
        i64::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i64> {
        i64::try_from(p0).ok()
    }
}

pub fn checked_neg_i64(p0: i64) -> Option<i64> {
    i64::checked_neg(p0)
}
use core::str;

use std::mem;

use std::rc::Rc;

#[derive(Clone)]
pub struct Str(Rc<str>);

impl Str {
    pub fn lit(text: &str) -> Str { Str(Rc::from(text)) }
    pub fn text(&self) -> &str { &self.0 }
    pub fn length(&self) -> u64 { chars(&self.0) }
    pub fn utf8_encode(&self) -> Bytes { tick(self.0.len() as u64); Bytes::lit(self.0.as_bytes()) }
    pub fn split_exact(&self, delimiter: &Str, maximum: u32) -> Option<List<Str>> { if delimiter.0.is_empty() { return None; }; chars(&self.0); let mut fields: Vec<Str> = Vec::new(); for piece in self.0.split(&*delimiter.0) { fields.push(Str::lit(piece)); }; if fields.len() as u128 > u128::from(maximum) { return None; }; Some(List::onto(fields, List::nil())) }
    pub fn join(texts: List<Str>, delimiter: &Str) -> Str { let mut out = String::new(); let mut first = true; let mut cursor = &texts; while let Repr::Cell(cell) = &cursor.0 { tick(1); if !first { chars(&delimiter.0); out.push_str(&delimiter.0); }; first = false; chars(&cell.head.0); out.push_str(&cell.head.0); cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for text in buffer[..*len].iter().rev() { tick(1); if !first { chars(&delimiter.0); out.push_str(&delimiter.0); }; first = false; chars(&text.0); out.push_str(&text.0); } }, _ => { }, }; Str::lit(&out) }
}

#[derive(Clone)]
pub struct Bytes(Rc<[u8]>);

impl Bytes {
    pub fn lit(octets: &[u8]) -> Bytes { Bytes(Rc::from(octets)) }
    pub fn octets(&self) -> &[u8] { &self.0 }
    pub fn append(a: Bytes, b: Bytes) -> Bytes { tick((a.0.len() + b.0.len()) as u64); let mut out = Vec::with_capacity(a.0.len() + b.0.len()); out.extend_from_slice(&a.0); out.extend_from_slice(&b.0); Bytes(Rc::from(out)) }
    pub fn length(&self) -> u64 { self.0.len() as u64 }
    pub fn index(&self, i: u64) -> Option<u8> { match usize::try_from(i) { Ok(at) => self.0.get(at).copied(), Err(_) => None, } }
    pub fn slice(&self, start: u64, count: u64) -> Option<Bytes> { let end = u128::from(start) + u128::from(count); if end > self.0.len() as u128 { return None; }; tick(count); Some(Bytes::lit(&self.0[start as usize..end as usize])) }
    pub fn utf8_decode(&self) -> Option<Str> { tick(self.0.len() as u64); match str::from_utf8(&self.0) { Ok(text) => Some(Str::lit(text)), Err(_) => None, } }
    pub fn compare(&self, other: &Bytes) -> Ordering { tick(1 + self.0.len().min(other.0.len()) as u64); self.0.cmp(&other.0) }
}

pub struct Node<T> { head: T, tail: List<T> }

pub enum Repr<T> { Nil, Run { buffer: Rc<Vec<T>>, len: usize }, Cell(Rc<Node<T>>) }

pub struct List<T>(Repr<T>);

impl<T> Clone for List<T> {
    fn clone(&self) -> Self { List(match &self.0 { Repr::Nil => Repr::Nil, Repr::Run { buffer, len } => Repr::Run { buffer: buffer.clone(), len: *len }, Repr::Cell(cell) => Repr::Cell(cell.clone()), }) }
}

impl<T> List<T> {
    fn take(&mut self) -> Repr<T> { mem::replace(&mut self.0, Repr::Nil) }
}

impl<T> Drop for Node<T> {
    fn drop(&mut self) { let mut next = match self.tail.take() { Repr::Cell(cell) => Some(cell), _ => None, }; while let Some(cell) = next { match Rc::try_unwrap(cell) { Ok(mut node) => next = match node.tail.take() { Repr::Cell(cell) => Some(cell), _ => None, }, Err(_) => break, } } }
}

impl<T: Clone> List<T> {
    pub fn nil() -> Self { List(Repr::Nil) }
    pub fn cons(head: T, mut tail: List<T>) -> Self { List(match tail.take() { Repr::Nil => { let mut buffer = Vec::with_capacity(16); buffer.push(head); Repr::Run { buffer: Rc::new(buffer), len: 1 } }, Repr::Run { mut buffer, len } => { match Rc::get_mut(&mut buffer) { Some(cells) => { cells.truncate(len); cells.push(head); Repr::Run { buffer, len: len + 1 } }, None => Repr::Cell(Rc::new(Node { head, tail: List(Repr::Run { buffer, len }) })), } }, rest => Repr::Cell(Rc::new(Node { head, tail: List(rest) })), }) }
    pub fn uncons(&self) -> Option<(T, List<T>)> { match &self.0 { Repr::Nil => None, Repr::Run { buffer, len } => { let head = buffer[len - 1].clone(); Some((head, List(if *len == 1 { Repr::Nil } else { Repr::Run { buffer: buffer.clone(), len: len - 1 } }))) }, Repr::Cell(cell) => Some((cell.head.clone(), cell.tail.clone())), } }
    pub fn length(&self) -> u64 { let mut count = 0; let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); count += 1; cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for _ in buffer[..*len].iter().rev() { tick(1); count += 1; } }, _ => { }, }; count }
    pub fn append(a: List<T>, b: List<T>) -> List<T> { List::onto(a.items(), b) }
    pub fn index(&self, i: u64) -> Option<T> { let mut position = 0; let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); if position == i { return Some(cell.head.clone()); }; position += 1; cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for item in buffer[..*len].iter().rev() { tick(1); if position == i { return Some(item.clone()); }; position += 1; } }, _ => { }, }; None }
    pub fn slice(&self, start: u64, count: u64) -> Option<List<T>> { let end = u128::from(start) + u128::from(count); let mut part = Vec::new(); let mut position: u128 = 0; let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); if position >= end { return Some(List::onto(part, List::nil())); }; if position >= u128::from(start) { part.push(cell.head.clone()); }; position += 1; cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for item in buffer[..*len].iter().rev() { tick(1); if position >= end { return Some(List::onto(part, List::nil())); }; if position >= u128::from(start) { part.push(item.clone()); }; position += 1; } }, _ => { }, }; if position < end { None } else { Some(List::onto(part, List::nil())) } }
    fn items(&self) -> Vec<T> { let mut out = Vec::new(); let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); out.push(cell.head.clone()); cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for item in buffer[..*len].iter().rev() { tick(1); out.push(item.clone()); } }, _ => { }, }; out }
    fn onto(mut items: Vec<T>, tail: List<T>) -> List<T> { let mut out = tail; while let Some(item) = items.pop() { tick(1); out = List::cons(item, out); }; out }
}

pub fn chars(text: &str) -> u64 { let mut count = 0; for _ in text.chars() { tick(1); count += 1; }; count }

impl Same for Str {
    fn same(&self, other: &Self) -> bool { let mut left = self.0.chars(); let mut right = other.0.chars(); loop { tick(1); match (left.next(), right.next()) { (None, None) => return true, (a, b) if a != b => return false, _ => { }, } } }
}

impl Same for Bytes {
    fn same(&self, other: &Self) -> bool { tick(1 + self.0.len().min(other.0.len()) as u64); self.0 == other.0 }
}

impl Key for Str {
    fn key(&self, other: &Self) -> Ordering { let mut left = self.0.chars(); let mut right = other.0.chars(); loop { tick(1); match (left.next(), right.next()) { (None, None) => return Ordering::Equal, (None, Some(_)) => return Ordering::Less, (Some(_), None) => return Ordering::Greater, (Some(a), Some(b)) => match a.cmp(&b) { Ordering::Equal => { }, decided => return decided, }, } } }
}

pub fn canonical_decimal(text: &str) -> Option<Option<i128>> { let digits = match text.strip_prefix('-') { Some(rest) => rest, None => text, }; let mut canonical = !digits.is_empty() && (digits == "0" || !digits.starts_with('0')) && text != "-0"; for c in digits.chars() { tick(1); canonical = canonical && c.is_ascii_digit(); }; if !canonical { return None; }; Some(text.parse::<i128>().ok()) }

pub fn parse_int(text: Str) -> R<Option<i64>> { match canonical_decimal(&text.0) { None => Ok(None), Some(Some(n)) => match i64::try_from(n) { Ok(value) => Ok(Some(value)), Err(_) => Err(Overflow), }, Some(None) => Err(Overflow), } }

pub fn format_u8(a: u8) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u8(text: Str) -> Option<u8> { match canonical_decimal(&text.0) { Some(Some(n)) => u8::try_from(n).ok(), _ => None, } }

pub fn format_u16(a: u16) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u16(text: Str) -> Option<u16> { match canonical_decimal(&text.0) { Some(Some(n)) => u16::try_from(n).ok(), _ => None, } }

pub fn format_u32(a: u32) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u32(text: Str) -> Option<u32> { match canonical_decimal(&text.0) { Some(Some(n)) => u32::try_from(n).ok(), _ => None, } }

pub fn format_u64(a: u64) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u64(text: Str) -> Option<u64> { match canonical_decimal(&text.0) { Some(Some(n)) => u64::try_from(n).ok(), _ => None, } }

pub fn format_i8(a: i8) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i8(text: Str) -> Option<i8> { match canonical_decimal(&text.0) { Some(Some(n)) => i8::try_from(n).ok(), _ => None, } }

pub fn format_i16(a: i16) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i16(text: Str) -> Option<i16> { match canonical_decimal(&text.0) { Some(Some(n)) => i16::try_from(n).ok(), _ => None, } }

pub fn format_i32(a: i32) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i32(text: Str) -> Option<i32> { match canonical_decimal(&text.0) { Some(Some(n)) => i32::try_from(n).ok(), _ => None, } }

pub fn format_i64(a: i64) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i64(text: Str) -> Option<i64> { match canonical_decimal(&text.0) { Some(Some(n)) => i64::try_from(n).ok(), _ => None, } }

pub fn append_list<T: Clone>(p0: List<T>, p1: List<T>) -> List<T> {
    List::append(p0, p1)
}

pub fn length_list<T: Clone>(p0: List<T>) -> u64 {
    List::length(&p0)
}

pub fn index_list<T: Clone>(p0: List<T>, p1: u64) -> Option<T> {
    List::index(&p0, p1)
}

pub fn slice_list<T: Clone>(p0: List<T>, p1: u64, p2: u64) -> Option<List<T>> {
    List::slice(&p0, p1, p2)
}

pub fn append_bytes(p0: Bytes, p1: Bytes) -> Bytes {
    Bytes::append(p0, p1)
}

pub fn length_bytes(p0: Bytes) -> u64 {
    Bytes::length(&p0)
}

pub fn length_string(p0: Str) -> u64 {
    Str::length(&p0)
}

pub fn index_bytes(p0: Bytes, p1: u64) -> Option<u8> {
    Bytes::index(&p0, p1)
}

pub fn slice_bytes(p0: Bytes, p1: u64, p2: u64) -> Option<Bytes> {
    Bytes::slice(&p0, p1, p2)
}

pub fn utf8_encode(p0: Str) -> Bytes {
    Str::utf8_encode(&p0)
}

pub fn utf8_decode(p0: Bytes) -> Option<Str> {
    Bytes::utf8_decode(&p0)
}

pub fn compare_bytes(p0: Bytes, p1: Bytes) -> Ordering {
    Bytes::compare(&p0, &p1)
}

pub fn split_exact(p0: Str, p1: Str, p2: u32) -> Option<List<Str>> {
    Str::split_exact(&p0, &p1, p2)
}

pub fn join(p0: List<Str>, p1: Str) -> Str {
    Str::join(p0, &p1)
}

#[derive(Clone)]
pub enum Adt0 {
    C0(u32, u32, u32, u32),
}

#[derive(Clone)]
pub enum Adt1 {
    C0(u64, u64, u64),
}

#[derive(Clone)]
pub enum Adt2 {
    C0(Adt0, bool, bool),
}

#[derive(Clone)]
pub enum Adt3 {
    C0(u32, i16),
}

pub fn f0(v0: u32, v1: u32) -> Option<u32> {
    let m1 = f1(v0);
    match m1 {
        None => {
            None::<u32>
        }
        Some(v2) => {
            let m2 = f1(v1);
            match m2 {
                None => {
                    None::<u32>
                }
                Some(v3) => {
                    let m3 = f2(v2, v3);
                    match m3 {
                        None => {
                            None::<u32>
                        }
                        Some(v4) => {
                            f3(v4)
                        }
                    }
                }
            }
        }
    }
}

pub fn f1(v0: u32) -> Option<u64> {
    let a4 = v0;
    fixed_u64::convert(i128::from(a4))
}

pub fn f2(v0: u64, v1: u64) -> Option<u64> {
    let v2: u64 = {
        let a7 = {
            let a5 = v0;
            let a6 = v1;
            fixed_u64::bit_xor(a5, a6)
        };
        let a8 = 2147483648u64;
        fixed_u64::bit_and(a7, a8)
    };
    let v3: u64 = {
        let a9 = v0;
        let a10 = 8388607u64;
        fixed_u64::bit_and(a9, a10)
    };
    let v4: u64 = {
        let a11 = v1;
        let a12 = 8388607u64;
        fixed_u64::bit_and(a11, a12)
    };
    let m15 = {
        let a13 = v0;
        let a14 = 23u32;
        fixed_u64::shift_right(a13, a14)
    };
    match m15 {
        None => {
            None::<u64>
        }
        Some(v5) => {
            let m18 = {
                let a16 = v1;
                let a17 = 23u32;
                fixed_u64::shift_right(a16, a17)
            };
            match m18 {
                None => {
                    None::<u64>
                }
                Some(v6) => {
                    let v7: u64 = {
                        let a19 = v5;
                        let a20 = 255u64;
                        fixed_u64::bit_and(a19, a20)
                    };
                    let v8: u64 = {
                        let a21 = v6;
                        let a22 = 255u64;
                        fixed_u64::bit_and(a21, a22)
                    };
                    let a23 = v7;
                    let a24 = 255u64;
                    if if equal(a23, a24) {
                        let a27 = {
                            let a25 = v3;
                            let a26 = 0u64;
                            equal(a25, a26)
                        };
                        bool_not(a27)
                    } else {
                        false
                    } {
                        Some({
                            let a28 = v0;
                            let a29 = 4194304u64;
                            fixed_u64::bit_or(a28, a29)
                        })
                    } else {
                        let a30 = v8;
                        let a31 = 255u64;
                        if if equal(a30, a31) {
                            let a34 = {
                                let a32 = v4;
                                let a33 = 0u64;
                                equal(a32, a33)
                            };
                            bool_not(a34)
                        } else {
                            false
                        } {
                            Some({
                                let a35 = v1;
                                let a36 = 4194304u64;
                                fixed_u64::bit_or(a35, a36)
                            })
                        } else {
                            let a39 = {
                                let a37 = v0;
                                let a38 = 2147483647u64;
                                fixed_u64::bit_and(a37, a38)
                            };
                            let a40 = 0u64;
                            if if if equal(a39, a40) {
                                let a43 = {
                                    let a41 = v1;
                                    let a42 = 2147483647u64;
                                    fixed_u64::bit_and(a41, a42)
                                };
                                let a44 = 0u64;
                                equal(a43, a44)
                            } else {
                                false
                            } {
                                true
                            } else {
                                let a45 = v7;
                                let a46 = 255u64;
                                if equal(a45, a46) {
                                    let a47 = v8;
                                    let a48 = 255u64;
                                    equal(a47, a48)
                                } else {
                                    false
                                }
                            } {
                                Some(2143289344u64)
                            } else {
                                let a49 = v7;
                                let a50 = 255u64;
                                if if equal(a49, a50) {
                                    true
                                } else {
                                    let a53 = {
                                        let a51 = v1;
                                        let a52 = 2147483647u64;
                                        fixed_u64::bit_and(a51, a52)
                                    };
                                    let a54 = 0u64;
                                    equal(a53, a54)
                                } {
                                    Some({
                                        let a55 = v2;
                                        let a56 = 2139095040u64;
                                        fixed_u64::bit_or(a55, a56)
                                    })
                                } else {
                                    let a57 = v8;
                                    let a58 = 255u64;
                                    if if equal(a57, a58) {
                                        true
                                    } else {
                                        let a61 = {
                                            let a59 = v0;
                                            let a60 = 2147483647u64;
                                            fixed_u64::bit_and(a59, a60)
                                        };
                                        let a62 = 0u64;
                                        equal(a61, a62)
                                    } {
                                        Some(v2)
                                    } else {
                                        let v9: u64 = {
                                            let a63 = v7;
                                            let a64 = 0u64;
                                            if equal(a63, a64) {
                                                v3
                                            } else {
                                                let a65 = v3;
                                                let a66 = 8388608u64;
                                                fixed_u64::bit_or(a65, a66)
                                            }
                                        };
                                        let v10: u64 = {
                                            let a67 = v8;
                                            let a68 = 0u64;
                                            if equal(a67, a68) {
                                                v4
                                            } else {
                                                let a69 = v4;
                                                let a70 = 8388608u64;
                                                fixed_u64::bit_or(a69, a70)
                                            }
                                        };
                                        let m71 = f4(v7);
                                        match m71 {
                                            None => {
                                                None::<u64>
                                            }
                                            Some(v11) => {
                                                let m72 = f4(v8);
                                                match m72 {
                                                    None => {
                                                        None::<u64>
                                                    }
                                                    Some(v12) => {
                                                        let m75 = {
                                                            let a73 = v7;
                                                            let a74 = 0u64;
                                                            if equal(a73, a74) {
                                                                Some(1i16)
                                                            } else {
                                                                f5(v11)
                                                            }
                                                        };
                                                        match m75 {
                                                            None => {
                                                                None::<u64>
                                                            }
                                                            Some(v13) => {
                                                                let m78 = {
                                                                    let a76 = v8;
                                                                    let a77 = 0u64;
                                                                    if equal(a76, a77) {
                                                                        Some(1i16)
                                                                    } else {
                                                                        f5(v12)
                                                                    }
                                                                };
                                                                match m78 {
                                                                    None => {
                                                                        None::<u64>
                                                                    }
                                                                    Some(v14) => {
                                                                        let m79 = f6(v9);
                                                                        match m79 {
                                                                            None => {
                                                                                None::<u64>
                                                                            }
                                                                            Some(v15) => {
                                                                                let m80 = f6(v10);
                                                                                match m80 {
                                                                                    None => {
                                                                                        None::<u64>
                                                                                    }
                                                                                    Some(v16) => {
                                                                                        let m81 = f7(v15);
                                                                                        match m81 {
                                                                                            None => {
                                                                                                None::<u64>
                                                                                            }
                                                                                            Some(v17) => {
                                                                                                let m82 = f7(v16);
                                                                                                match m82 {
                                                                                                    None => {
                                                                                                        None::<u64>
                                                                                                    }
                                                                                                    Some(v18) => {
                                                                                                        let m83 = f8(24i16, v17);
                                                                                                        match m83 {
                                                                                                            None => {
                                                                                                                None::<u64>
                                                                                                            }
                                                                                                            Some(v19) => {
                                                                                                                let m84 = f8(24i16, v18);
                                                                                                                match m84 {
                                                                                                                    None => {
                                                                                                                        None::<u64>
                                                                                                                    }
                                                                                                                    Some(v20) => {
                                                                                                                        let m85 = f9(v19);
                                                                                                                        match m85 {
                                                                                                                            None => {
                                                                                                                                None::<u64>
                                                                                                                            }
                                                                                                                            Some(v21) => {
                                                                                                                                let m86 = f9(v20);
                                                                                                                                match m86 {
                                                                                                                                    None => {
                                                                                                                                        None::<u64>
                                                                                                                                    }
                                                                                                                                    Some(v22) => {
                                                                                                                                        let m89 = {
                                                                                                                                            let a87 = v9;
                                                                                                                                            let a88 = v21;
                                                                                                                                            fixed_u64::shift_left(a87, a88)
                                                                                                                                        };
                                                                                                                                        match m89 {
                                                                                                                                            None => {
                                                                                                                                                None::<u64>
                                                                                                                                            }
                                                                                                                                            Some(v23) => {
                                                                                                                                                let m92 = {
                                                                                                                                                    let a90 = v10;
                                                                                                                                                    let a91 = v22;
                                                                                                                                                    fixed_u64::shift_left(a90, a91)
                                                                                                                                                };
                                                                                                                                                match m92 {
                                                                                                                                                    None => {
                                                                                                                                                        None::<u64>
                                                                                                                                                    }
                                                                                                                                                    Some(v24) => {
                                                                                                                                                        let v25: bool = f10(v23, v24);
                                                                                                                                                        let m93 = f8(v13, v14);
                                                                                                                                                        match m93 {
                                                                                                                                                            None => {
                                                                                                                                                                None::<u64>
                                                                                                                                                            }
                                                                                                                                                            Some(v26) => {
                                                                                                                                                                let m94 = f8(v18, v17);
                                                                                                                                                                match m94 {
                                                                                                                                                                    None => {
                                                                                                                                                                        None::<u64>
                                                                                                                                                                    }
                                                                                                                                                                    Some(v27) => {
                                                                                                                                                                        let m95 = f8(v26, v27);
                                                                                                                                                                        match m95 {
                                                                                                                                                                            None => {
                                                                                                                                                                                None::<u64>
                                                                                                                                                                            }
                                                                                                                                                                            Some(v28) => {
                                                                                                                                                                                let m96 = if v25 {
                                                                                                                                                                                    f8(v28, 1i16)
                                                                                                                                                                                } else {
                                                                                                                                                                                    Some(v28)
                                                                                                                                                                                };
                                                                                                                                                                                match m96 {
                                                                                                                                                                                    None => {
                                                                                                                                                                                        None::<u64>
                                                                                                                                                                                    }
                                                                                                                                                                                    Some(v29) => {
                                                                                                                                                                                        let m97 = f8(-124i16, v29);
                                                                                                                                                                                        match m97 {
                                                                                                                                                                                            None => {
                                                                                                                                                                                                None::<u64>
                                                                                                                                                                                            }
                                                                                                                                                                                            Some(v30) => {
                                                                                                                                                                                                let v31: i16 = if f11(2i16, v30) {
                                                                                                                                                                                                    v30
                                                                                                                                                                                                } else {
                                                                                                                                                                                                    2i16
                                                                                                                                                                                                };
                                                                                                                                                                                                let m100 = if v25 {
                                                                                                                                                                                                    let a98 = v23;
                                                                                                                                                                                                    let a99 = 1u32;
                                                                                                                                                                                                    fixed_u64::shift_left(a98, a99)
                                                                                                                                                                                                } else {
                                                                                                                                                                                                    Some(v23)
                                                                                                                                                                                                };
                                                                                                                                                                                                match m100 {
                                                                                                                                                                                                    None => {
                                                                                                                                                                                                        None::<u64>
                                                                                                                                                                                                    }
                                                                                                                                                                                                    Some(v32) => {
                                                                                                                                                                                                        let m101 = f12(v32, v24);
                                                                                                                                                                                                        match m101 {
                                                                                                                                                                                                            None => {
                                                                                                                                                                                                                None::<u64>
                                                                                                                                                                                                            }
                                                                                                                                                                                                            Some(v33) => {
                                                                                                                                                                                                                let m102 = f6(v33);
                                                                                                                                                                                                                match m102 {
                                                                                                                                                                                                                    None => {
                                                                                                                                                                                                                        None::<u64>
                                                                                                                                                                                                                    }
                                                                                                                                                                                                                    Some(v34) => {
                                                                                                                                                                                                                        let m103 = f13(v34, v31);
                                                                                                                                                                                                                        match m103 {
                                                                                                                                                                                                                            None => {
                                                                                                                                                                                                                                None::<u64>
                                                                                                                                                                                                                            }
                                                                                                                                                                                                                            Some(v35) => {
                                                                                                                                                                                                                                f14(v2, v35, v29)
                                                                                                                                                                                                                            }
                                                                                                                                                                                                                        }
                                                                                                                                                                                                                    }
                                                                                                                                                                                                                }
                                                                                                                                                                                                            }
                                                                                                                                                                                                        }
                                                                                                                                                                                                    }
                                                                                                                                                                                                }
                                                                                                                                                                                            }
                                                                                                                                                                                        }
                                                                                                                                                                                    }
                                                                                                                                                                                }
                                                                                                                                                                            }
                                                                                                                                                                        }
                                                                                                                                                                    }
                                                                                                                                                                }
                                                                                                                                                            }
                                                                                                                                                        }
                                                                                                                                                    }
                                                                                                                                                }
                                                                                                                                            }
                                                                                                                                        }
                                                                                                                                    }
                                                                                                                                }
                                                                                                                            }
                                                                                                                        }
                                                                                                                    }
                                                                                                                }
                                                                                                            }
                                                                                                        }
                                                                                                    }
                                                                                                }
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

pub fn f3(v0: u64) -> Option<u32> {
    let a104 = v0;
    fixed_u32::convert(i128::from(a104))
}

pub fn f4(v0: u64) -> Option<u8> {
    let a105 = v0;
    fixed_u8::convert(i128::from(a105))
}

pub fn f5(v0: u8) -> Option<i16> {
    let a106 = v0;
    fixed_i16::convert(i128::from(a106))
}

pub fn f6(v0: u64) -> Option<Adt0> {
    let m109 = f3({
        let a107 = v0;
        let a108 = 4294967295u64;
        fixed_u64::bit_and(a107, a108)
    });
    match m109 {
        None => {
            None::<Adt0>
        }
        Some(v1) => {
            let m112 = {
                let a110 = v0;
                let a111 = 32u32;
                fixed_u64::shift_right(a110, a111)
            };
            match m112 {
                None => {
                    None::<Adt0>
                }
                Some(v2) => {
                    let m113 = f3(v2);
                    match m113 {
                        None => {
                            None::<Adt0>
                        }
                        Some(v3) => {
                            Some(Adt0::C0(v1, v3, 0u32, 0u32))
                        }
                    }
                }
            }
        }
    }
}

pub fn f7(v0: Adt0) -> Option<i16> {
    let a115 = match v0.clone() {
        Adt0::C0(_, _, _, h114) => {
            h114
        }
    };
    let a116 = 0u32;
    if equal(a115, a116) {
        let a118 = match v0.clone() {
            Adt0::C0(_, _, h117, _) => {
                h117
            }
        };
        let a119 = 0u32;
        if equal(a118, a119) {
            let a121 = match v0.clone() {
                Adt0::C0(_, h120, _, _) => {
                    h120
                }
            };
            let a122 = 0u32;
            if equal(a121, a122) {
                f15(match v0 {
                    Adt0::C0(h123, _, _, _) => {
                        h123
                    }
                })
            } else {
                let m125 = f15(match v0 {
                    Adt0::C0(_, h124, _, _) => {
                        h124
                    }
                });
                match m125 {
                    None => {
                        None::<i16>
                    }
                    Some(v1) => {
                        f16(v1, 32i16)
                    }
                }
            }
        } else {
            let m127 = f15(match v0 {
                Adt0::C0(_, _, h126, _) => {
                    h126
                }
            });
            match m127 {
                None => {
                    None::<i16>
                }
                Some(v2) => {
                    f16(v2, 64i16)
                }
            }
        }
    } else {
        let m129 = f15(match v0 {
            Adt0::C0(_, _, _, h128) => {
                h128
            }
        });
        match m129 {
            None => {
                None::<i16>
            }
            Some(v3) => {
                f16(v3, 96i16)
            }
        }
    }
}

pub fn f8(v0: i16, v1: i16) -> Option<i16> {
    let a130 = v0;
    let a131 = v1;
    fixed_i16::checked_sub(a130, a131)
}

pub fn f9(v0: i16) -> Option<u32> {
    let a132 = v0;
    fixed_u32::convert(i128::from(a132))
}

pub fn f10(v0: u64, v1: u64) -> bool {
    let m135 = {
        let a133 = v0;
        let a134 = v1;
        fixed_u64::checked_sub(a133, a134)
    };
    match m135 {
        None => {
            true
        }
        Some(_) => {
            false
        }
    }
}

pub fn f11(v0: i16, v1: i16) -> bool {
    let m136 = f8(v0, v1);
    match m136 {
        None => {
            f17(v0)
        }
        Some(v2) => {
            f17(v2)
        }
    }
}

pub fn f12(v0: u64, v1: u64) -> Option<u64> {
    let m139 = {
        let a137 = v0;
        let a138 = v1;
        fixed_u64::checked_sub(a137, a138)
    };
    match m139 {
        None => {
            None::<u64>
        }
        Some(v2) => {
            let m140 = f18(f19(f20(Some(Adt1::C0(1u64, v2, v1)))));
            match m140 {
                None => {
                    None::<u64>
                }
                Some(v3) => {
                    Some({
                        let a145 = match v3.clone() {
                            Adt1::C0(h141, _, _) => {
                                h141
                            }
                        };
                        let a146 = {
                            let a143 = match v3 {
                                Adt1::C0(_, h142, _) => {
                                    h142
                                }
                            };
                            let a144 = 0u64;
                            if equal(a143, a144) {
                                0u64
                            } else {
                                1u64
                            }
                        };
                        fixed_u64::bit_or(a145, a146)
                    })
                }
            }
        }
    }
}

pub fn f13(v0: Adt0, v1: i16) -> Option<u64> {
    if f17(v1) {
        let m147 = f21(v1);
        match m147 {
            None => {
                None::<u64>
            }
            Some(v2) => {
                let m148 = f9(v2);
                match m148 {
                    None => {
                        None::<u64>
                    }
                    Some(v3) => {
                        let m149 = f22(v0);
                        match m149 {
                            None => {
                                None::<u64>
                            }
                            Some(v4) => {
                                let a150 = v4;
                                let a151 = v3;
                                fixed_u64::shift_left(a150, a151)
                            }
                        }
                    }
                }
            }
        }
    } else {
        if f11(128i16, v1) {
            Some(0u64)
        } else {
            let m152 = f23(v1);
            match m152 {
                None => {
                    None::<u64>
                }
                Some(v5) => {
                    let m194 = {
                        let m153 = Some(Adt2::C0(v0, false, false));
                        match m153 {
                            None => {
                                None::<Adt2>
                            }
                            Some(v6) => {
                                let m158 = {
                                    let a156 = {
                                        let a154 = v5;
                                        let a155 = 1u8;
                                        fixed_u8::bit_and(a154, a155)
                                    };
                                    let a157 = 0u8;
                                    if equal(a156, a157) {
                                        Some(v6)
                                    } else {
                                        f24(Some(v6))
                                    }
                                };
                                match m158 {
                                    None => {
                                        None::<Adt2>
                                    }
                                    Some(v7) => {
                                        let m163 = {
                                            let a161 = {
                                                let a159 = v5;
                                                let a160 = 2u8;
                                                fixed_u8::bit_and(a159, a160)
                                            };
                                            let a162 = 0u8;
                                            if equal(a161, a162) {
                                                Some(v7)
                                            } else {
                                                f25(Some(v7))
                                            }
                                        };
                                        match m163 {
                                            None => {
                                                None::<Adt2>
                                            }
                                            Some(v8) => {
                                                let m168 = {
                                                    let a166 = {
                                                        let a164 = v5;
                                                        let a165 = 4u8;
                                                        fixed_u8::bit_and(a164, a165)
                                                    };
                                                    let a167 = 0u8;
                                                    if equal(a166, a167) {
                                                        Some(v8)
                                                    } else {
                                                        f26(Some(v8))
                                                    }
                                                };
                                                match m168 {
                                                    None => {
                                                        None::<Adt2>
                                                    }
                                                    Some(v9) => {
                                                        let m173 = {
                                                            let a171 = {
                                                                let a169 = v5;
                                                                let a170 = 8u8;
                                                                fixed_u8::bit_and(a169, a170)
                                                            };
                                                            let a172 = 0u8;
                                                            if equal(a171, a172) {
                                                                Some(v9)
                                                            } else {
                                                                f27(Some(v9))
                                                            }
                                                        };
                                                        match m173 {
                                                            None => {
                                                                None::<Adt2>
                                                            }
                                                            Some(v10) => {
                                                                let m178 = {
                                                                    let a176 = {
                                                                        let a174 = v5;
                                                                        let a175 = 16u8;
                                                                        fixed_u8::bit_and(a174, a175)
                                                                    };
                                                                    let a177 = 0u8;
                                                                    if equal(a176, a177) {
                                                                        Some(v10)
                                                                    } else {
                                                                        f28(Some(v10))
                                                                    }
                                                                };
                                                                match m178 {
                                                                    None => {
                                                                        None::<Adt2>
                                                                    }
                                                                    Some(v11) => {
                                                                        let m183 = {
                                                                            let a181 = {
                                                                                let a179 = v5;
                                                                                let a180 = 32u8;
                                                                                fixed_u8::bit_and(a179, a180)
                                                                            };
                                                                            let a182 = 0u8;
                                                                            if equal(a181, a182) {
                                                                                Some(v11)
                                                                            } else {
                                                                                f29(Some(v11))
                                                                            }
                                                                        };
                                                                        match m183 {
                                                                            None => {
                                                                                None::<Adt2>
                                                                            }
                                                                            Some(v12) => {
                                                                                let m188 = {
                                                                                    let a186 = {
                                                                                        let a184 = v5;
                                                                                        let a185 = 64u8;
                                                                                        fixed_u8::bit_and(a184, a185)
                                                                                    };
                                                                                    let a187 = 0u8;
                                                                                    if equal(a186, a187) {
                                                                                        Some(v12)
                                                                                    } else {
                                                                                        f30(Some(v12))
                                                                                    }
                                                                                };
                                                                                match m188 {
                                                                                    None => {
                                                                                        None::<Adt2>
                                                                                    }
                                                                                    Some(v13) => {
                                                                                        let m193 = {
                                                                                            let a191 = {
                                                                                                let a189 = v5;
                                                                                                let a190 = 128u8;
                                                                                                fixed_u8::bit_and(a189, a190)
                                                                                            };
                                                                                            let a192 = 0u8;
                                                                                            if equal(a191, a192) {
                                                                                                Some(v13)
                                                                                            } else {
                                                                                                f31(Some(v13))
                                                                                            }
                                                                                        };
                                                                                        match m193 {
                                                                                            None => {
                                                                                                None::<Adt2>
                                                                                            }
                                                                                            Some(v14) => {
                                                                                                Some(v14)
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    };
                    match m194 {
                        None => {
                            None::<u64>
                        }
                        Some(v15) => {
                            let m196 = f22(match v15.clone() {
                                Adt2::C0(h195, _, _) => {
                                    h195
                                }
                            });
                            match m196 {
                                None => {
                                    None::<u64>
                                }
                                Some(v16) => {
                                    if if match v15.clone() {
                                        Adt2::C0(_, h197, _) => {
                                            h197
                                        }
                                    } {
                                        if match v15 {
                                            Adt2::C0(_, _, h198) => {
                                                h198
                                            }
                                        } {
                                            true
                                        } else {
                                            let a201 = {
                                                let a199 = v16;
                                                let a200 = 1u64;
                                                fixed_u64::bit_and(a199, a200)
                                            };
                                            let a202 = 1u64;
                                            equal(a201, a202)
                                        }
                                    } else {
                                        false
                                    } {
                                        let a203 = v16;
                                        let a204 = 1u64;
                                        fixed_u64::checked_add(a203, a204)
                                    } else {
                                        Some(v16)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

pub fn f14(v0: u64, v1: u64, v2: i16) -> Option<u64> {
    let v3: bool = {
        let a205 = v1;
        let a206 = 16777216u64;
        equal(a205, a206)
    };
    let m207 = if v3 {
        f16(v2, 1i16)
    } else {
        Some(v2)
    };
    match m207 {
        None => {
            None::<u64>
        }
        Some(v4) => {
            let m208 = if f11(v4, -126i16) {
                Some(if f10(v1, 8388608u64) {
                    0i16
                } else {
                    1i16
                })
            } else {
                f16(v4, 127i16)
            };
            match m208 {
                None => {
                    None::<u64>
                }
                Some(v5) => {
                    if f11(254i16, v5) {
                        Some({
                            let a209 = v0;
                            let a210 = 2139095040u64;
                            fixed_u64::bit_or(a209, a210)
                        })
                    } else {
                        let m213 = if v3 {
                            let a211 = v1;
                            let a212 = 1u32;
                            fixed_u64::shift_right(a211, a212)
                        } else {
                            Some(v1)
                        };
                        match m213 {
                            None => {
                                None::<u64>
                            }
                            Some(v6) => {
                                let m214 = f32(v5);
                                match m214 {
                                    None => {
                                        None::<u64>
                                    }
                                    Some(v7) => {
                                        let m217 = {
                                            let a215 = v7;
                                            let a216 = 23u32;
                                            fixed_u64::shift_left(a215, a216)
                                        };
                                        match m217 {
                                            None => {
                                                None::<u64>
                                            }
                                            Some(v8) => {
                                                Some({
                                                    let a222 = v0;
                                                    let a223 = {
                                                        let a220 = v8;
                                                        let a221 = {
                                                            let a218 = v6;
                                                            let a219 = 8388607u64;
                                                            fixed_u64::bit_and(a218, a219)
                                                        };
                                                        fixed_u64::bit_or(a220, a221)
                                                    };
                                                    fixed_u64::bit_or(a222, a223)
                                                })
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

pub fn f15(v0: u32) -> Option<i16> {
    let m224 = f33(Some(Adt3::C0(v0, 0i16)));
    match m224 {
        None => {
            None::<i16>
        }
        Some(v1) => {
            Some(match v1 {
                Adt3::C0(_, h225) => {
                    h225
                }
            })
        }
    }
}

pub fn f16(v0: i16, v1: i16) -> Option<i16> {
    let a226 = v0;
    let a227 = v1;
    fixed_i16::checked_add(a226, a227)
}

pub fn f17(v0: i16) -> bool {
    let m228 = f34(v0);
    match m228 {
        None => {
            true
        }
        Some(_) => {
            false
        }
    }
}

pub fn f18(v0: Option<Adt1>) -> Option<Adt1> {
    f19(f19(v0))
}

pub fn f19(v0: Option<Adt1>) -> Option<Adt1> {
    f35(f35(v0))
}

pub fn f20(v0: Option<Adt1>) -> Option<Adt1> {
    let m229 = v0;
    match m229 {
        None => {
            None::<Adt1>
        }
        Some(v1) => {
            let m233 = {
                let a231 = match v1.clone() {
                    Adt1::C0(_, h230, _) => {
                        h230
                    }
                };
                let a232 = 2u64;
                fixed_u64::checked_mul(a231, a232)
            };
            match m233 {
                None => {
                    None::<Adt1>
                }
                Some(v2) => {
                    let m237 = {
                        let a235 = match v1.clone() {
                            Adt1::C0(h234, _, _) => {
                                h234
                            }
                        };
                        let a236 = 2u64;
                        fixed_u64::checked_mul(a235, a236)
                    };
                    match m237 {
                        None => {
                            None::<Adt1>
                        }
                        Some(v3) => {
                            let m241 = {
                                let a239 = v2;
                                let a240 = match v1.clone() {
                                    Adt1::C0(_, _, h238) => {
                                        h238
                                    }
                                };
                                fixed_u64::checked_sub(a239, a240)
                            };
                            match m241 {
                                None => {
                                    Some(Adt1::C0(v3, v2, match v1 {
                                        Adt1::C0(_, _, h246) => {
                                            h246
                                        }
                                    }))
                                }
                                Some(v4) => {
                                    let m244 = {
                                        let a242 = v3;
                                        let a243 = 1u64;
                                        fixed_u64::checked_add(a242, a243)
                                    };
                                    match m244 {
                                        None => {
                                            None::<Adt1>
                                        }
                                        Some(v5) => {
                                            Some(Adt1::C0(v5, v4, match v1 {
                                                Adt1::C0(_, _, h245) => {
                                                    h245
                                                }
                                            }))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

pub fn f21(v0: i16) -> Option<i16> {
    let a247 = v0;
    checked_neg_i16(a247)
}

pub fn f22(v0: Adt0) -> Option<u64> {
    let a249 = match v0.clone() {
        Adt0::C0(_, _, h248, _) => {
            h248
        }
    };
    let a250 = 0u32;
    if if equal(a249, a250) {
        let a252 = match v0.clone() {
            Adt0::C0(_, _, _, h251) => {
                h251
            }
        };
        let a253 = 0u32;
        equal(a252, a253)
    } else {
        false
    } {
        let m255 = f1(match v0.clone() {
            Adt0::C0(h254, _, _, _) => {
                h254
            }
        });
        match m255 {
            None => {
                None::<u64>
            }
            Some(v1) => {
                let m257 = f1(match v0 {
                    Adt0::C0(_, h256, _, _) => {
                        h256
                    }
                });
                match m257 {
                    None => {
                        None::<u64>
                    }
                    Some(v2) => {
                        let m260 = {
                            let a258 = v2;
                            let a259 = 32u32;
                            fixed_u64::shift_left(a258, a259)
                        };
                        match m260 {
                            None => {
                                None::<u64>
                            }
                            Some(v3) => {
                                Some({
                                    let a261 = v1;
                                    let a262 = v3;
                                    fixed_u64::bit_or(a261, a262)
                                })
                            }
                        }
                    }
                }
            }
        }
    } else {
        None::<u64>
    }
}

pub fn f23(v0: i16) -> Option<u8> {
    let a263 = v0;
    fixed_u8::convert(i128::from(a263))
}

pub fn f24(v0: Option<Adt2>) -> Option<Adt2> {
    let m264 = v0;
    match m264 {
        None => {
            None::<Adt2>
        }
        Some(v1) => {
            let m266 = f36(match v1.clone() {
                Adt2::C0(h265, _, _) => {
                    h265
                }
            });
            match m266 {
                None => {
                    None::<Adt2>
                }
                Some(v2) => {
                    Some(Adt2::C0(v2, {
                        let a272 = {
                            let a270 = {
                                let m269 = match v1.clone() {
                                    Adt2::C0(h268, _, _) => {
                                        h268
                                    }
                                };
                                match m269 {
                                    Adt0::C0(h267, _, _, _) => {
                                        h267
                                    }
                                }
                            };
                            let a271 = 1u32;
                            fixed_u32::bit_and(a270, a271)
                        };
                        let a273 = 1u32;
                        equal(a272, a273)
                    }, if match v1.clone() {
                        Adt2::C0(_, _, h274) => {
                            h274
                        }
                    } {
                        true
                    } else {
                        match v1 {
                            Adt2::C0(_, h275, _) => {
                                h275
                            }
                        }
                    }))
                }
            }
        }
    }
}

pub fn f25(v0: Option<Adt2>) -> Option<Adt2> {
    f24(f24(v0))
}

pub fn f26(v0: Option<Adt2>) -> Option<Adt2> {
    f25(f25(v0))
}

pub fn f27(v0: Option<Adt2>) -> Option<Adt2> {
    f26(f26(v0))
}

pub fn f28(v0: Option<Adt2>) -> Option<Adt2> {
    f27(f27(v0))
}

pub fn f29(v0: Option<Adt2>) -> Option<Adt2> {
    f28(f28(v0))
}

pub fn f30(v0: Option<Adt2>) -> Option<Adt2> {
    f29(f29(v0))
}

pub fn f31(v0: Option<Adt2>) -> Option<Adt2> {
    f30(f30(v0))
}

pub fn f32(v0: i16) -> Option<u64> {
    let a276 = v0;
    fixed_u64::convert(i128::from(a276))
}

pub fn f33(v0: Option<Adt3>) -> Option<Adt3> {
    f37(f37(v0))
}

pub fn f34(v0: i16) -> Option<u16> {
    let a277 = v0;
    fixed_u16::convert(i128::from(a277))
}

pub fn f35(v0: Option<Adt1>) -> Option<Adt1> {
    f38(f38(v0))
}

pub fn f36(v0: Adt0) -> Option<Adt0> {
    let m281 = {
        let a279 = match v0.clone() {
            Adt0::C0(h278, _, _, _) => {
                h278
            }
        };
        let a280 = 1u32;
        fixed_u32::shift_right(a279, a280)
    };
    match m281 {
        None => {
            None::<Adt0>
        }
        Some(v1) => {
            let m285 = {
                let a283 = match v0.clone() {
                    Adt0::C0(_, h282, _, _) => {
                        h282
                    }
                };
                let a284 = 1u32;
                fixed_u32::shift_right(a283, a284)
            };
            match m285 {
                None => {
                    None::<Adt0>
                }
                Some(v2) => {
                    let m289 = {
                        let a287 = match v0.clone() {
                            Adt0::C0(_, _, h286, _) => {
                                h286
                            }
                        };
                        let a288 = 1u32;
                        fixed_u32::shift_right(a287, a288)
                    };
                    match m289 {
                        None => {
                            None::<Adt0>
                        }
                        Some(v3) => {
                            let m293 = {
                                let a291 = match v0.clone() {
                                    Adt0::C0(_, _, _, h290) => {
                                        h290
                                    }
                                };
                                let a292 = 1u32;
                                fixed_u32::shift_right(a291, a292)
                            };
                            match m293 {
                                None => {
                                    None::<Adt0>
                                }
                                Some(v4) => {
                                    let m299 = {
                                        let a297 = {
                                            let a295 = match v0.clone() {
                                                Adt0::C0(_, h294, _, _) => {
                                                    h294
                                                }
                                            };
                                            let a296 = 1u32;
                                            fixed_u32::bit_and(a295, a296)
                                        };
                                        let a298 = 31u32;
                                        fixed_u32::shift_left(a297, a298)
                                    };
                                    match m299 {
                                        None => {
                                            None::<Adt0>
                                        }
                                        Some(v5) => {
                                            let m305 = {
                                                let a303 = {
                                                    let a301 = match v0.clone() {
                                                        Adt0::C0(_, _, h300, _) => {
                                                            h300
                                                        }
                                                    };
                                                    let a302 = 1u32;
                                                    fixed_u32::bit_and(a301, a302)
                                                };
                                                let a304 = 31u32;
                                                fixed_u32::shift_left(a303, a304)
                                            };
                                            match m305 {
                                                None => {
                                                    None::<Adt0>
                                                }
                                                Some(v6) => {
                                                    let m311 = {
                                                        let a309 = {
                                                            let a307 = match v0 {
                                                                Adt0::C0(_, _, _, h306) => {
                                                                    h306
                                                                }
                                                            };
                                                            let a308 = 1u32;
                                                            fixed_u32::bit_and(a307, a308)
                                                        };
                                                        let a310 = 31u32;
                                                        fixed_u32::shift_left(a309, a310)
                                                    };
                                                    match m311 {
                                                        None => {
                                                            None::<Adt0>
                                                        }
                                                        Some(v7) => {
                                                            Some(Adt0::C0({
                                                                let a312 = v1;
                                                                let a313 = v5;
                                                                fixed_u32::bit_or(a312, a313)
                                                            }, {
                                                                let a314 = v2;
                                                                let a315 = v6;
                                                                fixed_u32::bit_or(a314, a315)
                                                            }, {
                                                                let a316 = v3;
                                                                let a317 = v7;
                                                                fixed_u32::bit_or(a316, a317)
                                                            }, v4))
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

pub fn f37(v0: Option<Adt3>) -> Option<Adt3> {
    f39(f39(v0))
}

pub fn f38(v0: Option<Adt1>) -> Option<Adt1> {
    f20(f20(v0))
}

pub fn f39(v0: Option<Adt3>) -> Option<Adt3> {
    f40(f40(v0))
}

pub fn f40(v0: Option<Adt3>) -> Option<Adt3> {
    f41(f41(v0))
}

pub fn f41(v0: Option<Adt3>) -> Option<Adt3> {
    f42(f42(v0))
}

pub fn f42(v0: Option<Adt3>) -> Option<Adt3> {
    let m318 = v0;
    match m318 {
        None => {
            None::<Adt3>
        }
        Some(v1) => {
            let m322 = {
                let a320 = match v1.clone() {
                    Adt3::C0(h319, _) => {
                        h319
                    }
                };
                let a321 = 1u32;
                fixed_u32::shift_right(a320, a321)
            };
            match m322 {
                None => {
                    None::<Adt3>
                }
                Some(v2) => {
                    let a324 = match v1.clone() {
                        Adt3::C0(h323, _) => {
                            h323
                        }
                    };
                    let a325 = 0u32;
                    if equal(a324, a325) {
                        Some(Adt3::C0(v2, match v1 {
                            Adt3::C0(_, h326) => {
                                h326
                            }
                        }))
                    } else {
                        let m328 = f16(match v1 {
                            Adt3::C0(_, h327) => {
                                h327
                            }
                        }, 1i16);
                        match m328 {
                            None => {
                                None::<Adt3>
                            }
                            Some(v3) => {
                                Some(Adt3::C0(v2, v3))
                            }
                        }
                    }
                }
            }
        }
    }
}

pub fn run(p0: u32, p1: u32) -> Option<u32> {
    f0(p0, p1)
}

module
import BoundedNumeric.Bounds
#print axioms BoundedNumeric.Bounds.cellAddBound
#print axioms BoundedNumeric.Bounds.divDoubleRemainderBound
#print axioms BoundedNumeric.Bounds.divQuotientStepBound
#print axioms BoundedNumeric.Bounds.divReducedRemainderBound
#print axioms BoundedNumeric.Bounds.limbAddBound

#![forbid(unsafe_code)]
use core::cmp::Ordering;

use core::sync::atomic::{AtomicU64, Ordering as Memory};

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub struct Overflow;

pub type R<T> = Result<T, Overflow>;

static WORK: AtomicU64 = AtomicU64::new(0);

pub fn tick(units: u64) { WORK.fetch_add(units, Memory::Relaxed); }

pub fn work() -> u64 { WORK.load(Memory::Relaxed) }

pub trait Same {
    fn same(&self, other: &Self) -> bool;
}

pub trait Key {
    fn key(&self, other: &Self) -> Ordering;
}

impl Same for bool {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for bool {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u8 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u8 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u16 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u16 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u32 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u32 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u64 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u64 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i8 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i8 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i16 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i16 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i32 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i32 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i64 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i64 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for Ordering {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl<A: Key, B: Key> Key for (A, B) {
    fn key(&self, other: &Self) -> Ordering { match self.0.key(&other.0) { Ordering::Equal => self.1.key(&other.1), decided => decided, } }
}

pub fn equal<T: Same>(a: T, b: T) -> bool { a.same(&b) }

pub fn compare<T: Key>(a: T, b: T) -> Ordering { a.key(&b) }

pub fn nat_add(p0: u64, p1: u64) -> R<u64> {
    match u64::checked_add(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<u64, Overflow>(Overflow)
        }
    }
}

pub fn nat_sub(p0: u64, p1: u64) -> u64 {
    u64::saturating_sub(p0, p1)
}

pub fn nat_mul(p0: u64, p1: u64) -> R<u64> {
    match u64::checked_mul(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<u64, Overflow>(Overflow)
        }
    }
}

pub fn nat_quot(p0: u64, p1: u64, p2: u64) -> u64 {
    u64::checked_div(p0, p1).unwrap_or(p2)
}

pub fn nat_rem(p0: u64, p1: u64, p2: u64) -> u64 {
    u64::checked_rem(p0, p1).unwrap_or(p2)
}

pub fn nat_eq(p0: u64, p1: u64) -> bool {
    core::cmp::PartialEq::eq(&p0, &p1)
}

pub fn nat_le(p0: u64, p1: u64) -> bool {
    core::cmp::PartialOrd::le(&p0, &p1)
}

pub fn nat_lt(p0: u64, p1: u64) -> bool {
    core::cmp::PartialOrd::lt(&p0, &p1)
}

pub fn nat_succ(p0: u64) -> R<u64> {
    match u64::checked_add(p0, 1u64) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<u64, Overflow>(Overflow)
        }
    }
}

pub fn int_add(p0: i64, p1: i64) -> R<i64> {
    match i64::checked_add(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_sub(p0: i64, p1: i64) -> R<i64> {
    match i64::checked_sub(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_mul(p0: i64, p1: i64) -> R<i64> {
    match i64::checked_mul(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_neg(p0: i64) -> R<i64> {
    match i64::checked_neg(p0) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_quot(p0: i64, p1: i64, p2: i64) -> R<i64> {
    { let value = { let (a, b, z): (i64, i64, i64) = (p0, p1, p2); if b == 0 { Some(z) } else { a.checked_div(b) } }; match value {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    } }
}

pub fn int_rem(p0: i64, p1: i64, p2: i64) -> i64 {
    { let (a, b, z): (i64, i64, i64) = (p0, p1, p2); if b == 0 { z } else { a.wrapping_rem(b) } }
}

pub fn bool_not(p0: bool) -> bool {
    !p0
}

pub fn bool_and(p0: bool, p1: bool) -> bool {
    if p0 {
        p1
    } else {
        false
    }
}

pub fn bool_or(p0: bool, p1: bool) -> bool {
    if p0 {
        true
    } else {
        p1
    }
}

pub mod fixed_u8 {
    pub fn checked_add(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u8, p1: u8) -> u8 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u8, p1: u8) -> u8 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u8, p1: u8) -> u8 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u8) -> u8 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u8, p1: u32) -> Option<u8> {
        u8::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u8, p1: u32) -> Option<u8> {
        u8::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u8> {
        u8::try_from(p0).ok()
    }
}

pub mod fixed_u16 {
    pub fn checked_add(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u16, p1: u16) -> u16 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u16, p1: u16) -> u16 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u16, p1: u16) -> u16 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u16) -> u16 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u16, p1: u32) -> Option<u16> {
        u16::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u16, p1: u32) -> Option<u16> {
        u16::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u16> {
        u16::try_from(p0).ok()
    }
}

pub mod fixed_u32 {
    pub fn checked_add(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u32, p1: u32) -> u32 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u32, p1: u32) -> u32 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u32, p1: u32) -> u32 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u32) -> u32 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u32> {
        u32::try_from(p0).ok()
    }
}

pub mod fixed_u64 {
    pub fn checked_add(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u64, p1: u64) -> u64 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u64, p1: u64) -> u64 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u64, p1: u64) -> u64 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u64) -> u64 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u64, p1: u32) -> Option<u64> {
        u64::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u64, p1: u32) -> Option<u64> {
        u64::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u64> {
        u64::try_from(p0).ok()
    }
}

pub mod fixed_i8 {
    pub fn checked_add(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i8, p1: i8) -> i8 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i8, p1: i8) -> i8 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i8, p1: i8) -> i8 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i8) -> i8 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i8, p1: u32) -> Option<i8> {
        i8::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i8, p1: u32) -> Option<i8> {
        i8::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i8> {
        i8::try_from(p0).ok()
    }
}

pub fn checked_neg_i8(p0: i8) -> Option<i8> {
    i8::checked_neg(p0)
}

pub mod fixed_i16 {
    pub fn checked_add(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i16, p1: i16) -> i16 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i16, p1: i16) -> i16 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i16, p1: i16) -> i16 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i16) -> i16 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i16, p1: u32) -> Option<i16> {
        i16::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i16, p1: u32) -> Option<i16> {
        i16::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i16> {
        i16::try_from(p0).ok()
    }
}

pub fn checked_neg_i16(p0: i16) -> Option<i16> {
    i16::checked_neg(p0)
}

pub mod fixed_i32 {
    pub fn checked_add(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i32, p1: i32) -> i32 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i32, p1: i32) -> i32 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i32, p1: i32) -> i32 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i32) -> i32 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i32, p1: u32) -> Option<i32> {
        i32::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i32, p1: u32) -> Option<i32> {
        i32::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i32> {
        i32::try_from(p0).ok()
    }
}

pub fn checked_neg_i32(p0: i32) -> Option<i32> {
    i32::checked_neg(p0)
}

pub mod fixed_i64 {
    pub fn checked_add(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i64, p1: i64) -> i64 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i64, p1: i64) -> i64 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i64, p1: i64) -> i64 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i64) -> i64 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i64, p1: u32) -> Option<i64> {
        i64::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i64, p1: u32) -> Option<i64> {
        i64::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i64> {
        i64::try_from(p0).ok()
    }
}

pub fn checked_neg_i64(p0: i64) -> Option<i64> {
    i64::checked_neg(p0)
}
use core::str;

use std::mem;

use std::rc::Rc;

#[derive(Clone)]
pub struct Str(Rc<str>);

impl Str {
    pub fn lit(text: &str) -> Str { Str(Rc::from(text)) }
    pub fn text(&self) -> &str { &self.0 }
    pub fn length(&self) -> u64 { chars(&self.0) }
    pub fn utf8_encode(&self) -> Bytes { tick(self.0.len() as u64); Bytes::lit(self.0.as_bytes()) }
    pub fn split_exact(&self, delimiter: &Str, maximum: u32) -> Option<List<Str>> { if delimiter.0.is_empty() { return None; }; chars(&self.0); let mut fields: Vec<Str> = Vec::new(); for piece in self.0.split(&*delimiter.0) { fields.push(Str::lit(piece)); }; if fields.len() as u128 > u128::from(maximum) { return None; }; Some(List::onto(fields, List::nil())) }
    pub fn join(texts: List<Str>, delimiter: &Str) -> Str { let mut out = String::new(); let mut first = true; let mut cursor = &texts; while let Repr::Cell(cell) = &cursor.0 { tick(1); if !first { chars(&delimiter.0); out.push_str(&delimiter.0); }; first = false; chars(&cell.head.0); out.push_str(&cell.head.0); cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for text in buffer[..*len].iter().rev() { tick(1); if !first { chars(&delimiter.0); out.push_str(&delimiter.0); }; first = false; chars(&text.0); out.push_str(&text.0); } }, _ => { }, }; Str::lit(&out) }
}

#[derive(Clone)]
pub struct Bytes(Rc<[u8]>);

impl Bytes {
    pub fn lit(octets: &[u8]) -> Bytes { Bytes(Rc::from(octets)) }
    pub fn octets(&self) -> &[u8] { &self.0 }
    pub fn append(a: Bytes, b: Bytes) -> Bytes { tick((a.0.len() + b.0.len()) as u64); let mut out = Vec::with_capacity(a.0.len() + b.0.len()); out.extend_from_slice(&a.0); out.extend_from_slice(&b.0); Bytes(Rc::from(out)) }
    pub fn length(&self) -> u64 { self.0.len() as u64 }
    pub fn index(&self, i: u64) -> Option<u8> { match usize::try_from(i) { Ok(at) => self.0.get(at).copied(), Err(_) => None, } }
    pub fn slice(&self, start: u64, count: u64) -> Option<Bytes> { let end = u128::from(start) + u128::from(count); if end > self.0.len() as u128 { return None; }; tick(count); Some(Bytes::lit(&self.0[start as usize..end as usize])) }
    pub fn utf8_decode(&self) -> Option<Str> { tick(self.0.len() as u64); match str::from_utf8(&self.0) { Ok(text) => Some(Str::lit(text)), Err(_) => None, } }
    pub fn compare(&self, other: &Bytes) -> Ordering { tick(1 + self.0.len().min(other.0.len()) as u64); self.0.cmp(&other.0) }
}

pub struct Node<T> { head: T, tail: List<T> }

pub enum Repr<T> { Nil, Run { buffer: Rc<Vec<T>>, len: usize }, Cell(Rc<Node<T>>) }

pub struct List<T>(Repr<T>);

impl<T> Clone for List<T> {
    fn clone(&self) -> Self { List(match &self.0 { Repr::Nil => Repr::Nil, Repr::Run { buffer, len } => Repr::Run { buffer: buffer.clone(), len: *len }, Repr::Cell(cell) => Repr::Cell(cell.clone()), }) }
}

impl<T> List<T> {
    fn take(&mut self) -> Repr<T> { mem::replace(&mut self.0, Repr::Nil) }
}

impl<T> Drop for Node<T> {
    fn drop(&mut self) { let mut next = match self.tail.take() { Repr::Cell(cell) => Some(cell), _ => None, }; while let Some(cell) = next { match Rc::try_unwrap(cell) { Ok(mut node) => next = match node.tail.take() { Repr::Cell(cell) => Some(cell), _ => None, }, Err(_) => break, } } }
}

impl<T: Clone> List<T> {
    pub fn nil() -> Self { List(Repr::Nil) }
    pub fn cons(head: T, mut tail: List<T>) -> Self { List(match tail.take() { Repr::Nil => { let mut buffer = Vec::with_capacity(16); buffer.push(head); Repr::Run { buffer: Rc::new(buffer), len: 1 } }, Repr::Run { mut buffer, len } => { match Rc::get_mut(&mut buffer) { Some(cells) => { cells.truncate(len); cells.push(head); Repr::Run { buffer, len: len + 1 } }, None => Repr::Cell(Rc::new(Node { head, tail: List(Repr::Run { buffer, len }) })), } }, rest => Repr::Cell(Rc::new(Node { head, tail: List(rest) })), }) }
    pub fn uncons(&self) -> Option<(T, List<T>)> { match &self.0 { Repr::Nil => None, Repr::Run { buffer, len } => { let head = buffer[len - 1].clone(); Some((head, List(if *len == 1 { Repr::Nil } else { Repr::Run { buffer: buffer.clone(), len: len - 1 } }))) }, Repr::Cell(cell) => Some((cell.head.clone(), cell.tail.clone())), } }
    pub fn length(&self) -> u64 { let mut count = 0; let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); count += 1; cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for _ in buffer[..*len].iter().rev() { tick(1); count += 1; } }, _ => { }, }; count }
    pub fn append(a: List<T>, b: List<T>) -> List<T> { List::onto(a.items(), b) }
    pub fn index(&self, i: u64) -> Option<T> { let mut position = 0; let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); if position == i { return Some(cell.head.clone()); }; position += 1; cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for item in buffer[..*len].iter().rev() { tick(1); if position == i { return Some(item.clone()); }; position += 1; } }, _ => { }, }; None }
    pub fn slice(&self, start: u64, count: u64) -> Option<List<T>> { let end = u128::from(start) + u128::from(count); let mut part = Vec::new(); let mut position: u128 = 0; let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); if position >= end { return Some(List::onto(part, List::nil())); }; if position >= u128::from(start) { part.push(cell.head.clone()); }; position += 1; cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for item in buffer[..*len].iter().rev() { tick(1); if position >= end { return Some(List::onto(part, List::nil())); }; if position >= u128::from(start) { part.push(item.clone()); }; position += 1; } }, _ => { }, }; if position < end { None } else { Some(List::onto(part, List::nil())) } }
    fn items(&self) -> Vec<T> { let mut out = Vec::new(); let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); out.push(cell.head.clone()); cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for item in buffer[..*len].iter().rev() { tick(1); out.push(item.clone()); } }, _ => { }, }; out }
    fn onto(mut items: Vec<T>, tail: List<T>) -> List<T> { let mut out = tail; while let Some(item) = items.pop() { tick(1); out = List::cons(item, out); }; out }
}

pub fn chars(text: &str) -> u64 { let mut count = 0; for _ in text.chars() { tick(1); count += 1; }; count }

impl Same for Str {
    fn same(&self, other: &Self) -> bool { let mut left = self.0.chars(); let mut right = other.0.chars(); loop { tick(1); match (left.next(), right.next()) { (None, None) => return true, (a, b) if a != b => return false, _ => { }, } } }
}

impl Same for Bytes {
    fn same(&self, other: &Self) -> bool { tick(1 + self.0.len().min(other.0.len()) as u64); self.0 == other.0 }
}

impl Key for Str {
    fn key(&self, other: &Self) -> Ordering { let mut left = self.0.chars(); let mut right = other.0.chars(); loop { tick(1); match (left.next(), right.next()) { (None, None) => return Ordering::Equal, (None, Some(_)) => return Ordering::Less, (Some(_), None) => return Ordering::Greater, (Some(a), Some(b)) => match a.cmp(&b) { Ordering::Equal => { }, decided => return decided, }, } } }
}

pub fn canonical_decimal(text: &str) -> Option<Option<i128>> { let digits = match text.strip_prefix('-') { Some(rest) => rest, None => text, }; let mut canonical = !digits.is_empty() && (digits == "0" || !digits.starts_with('0')) && text != "-0"; for c in digits.chars() { tick(1); canonical = canonical && c.is_ascii_digit(); }; if !canonical { return None; }; Some(text.parse::<i128>().ok()) }

pub fn parse_int(text: Str) -> R<Option<i64>> { match canonical_decimal(&text.0) { None => Ok(None), Some(Some(n)) => match i64::try_from(n) { Ok(value) => Ok(Some(value)), Err(_) => Err(Overflow), }, Some(None) => Err(Overflow), } }

pub fn format_u8(a: u8) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u8(text: Str) -> Option<u8> { match canonical_decimal(&text.0) { Some(Some(n)) => u8::try_from(n).ok(), _ => None, } }

pub fn format_u16(a: u16) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u16(text: Str) -> Option<u16> { match canonical_decimal(&text.0) { Some(Some(n)) => u16::try_from(n).ok(), _ => None, } }

pub fn format_u32(a: u32) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u32(text: Str) -> Option<u32> { match canonical_decimal(&text.0) { Some(Some(n)) => u32::try_from(n).ok(), _ => None, } }

pub fn format_u64(a: u64) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u64(text: Str) -> Option<u64> { match canonical_decimal(&text.0) { Some(Some(n)) => u64::try_from(n).ok(), _ => None, } }

pub fn format_i8(a: i8) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i8(text: Str) -> Option<i8> { match canonical_decimal(&text.0) { Some(Some(n)) => i8::try_from(n).ok(), _ => None, } }

pub fn format_i16(a: i16) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i16(text: Str) -> Option<i16> { match canonical_decimal(&text.0) { Some(Some(n)) => i16::try_from(n).ok(), _ => None, } }

pub fn format_i32(a: i32) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i32(text: Str) -> Option<i32> { match canonical_decimal(&text.0) { Some(Some(n)) => i32::try_from(n).ok(), _ => None, } }

pub fn format_i64(a: i64) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i64(text: Str) -> Option<i64> { match canonical_decimal(&text.0) { Some(Some(n)) => i64::try_from(n).ok(), _ => None, } }

pub fn append_list<T: Clone>(p0: List<T>, p1: List<T>) -> List<T> {
    List::append(p0, p1)
}

pub fn length_list<T: Clone>(p0: List<T>) -> u64 {
    List::length(&p0)
}

pub fn index_list<T: Clone>(p0: List<T>, p1: u64) -> Option<T> {
    List::index(&p0, p1)
}

pub fn slice_list<T: Clone>(p0: List<T>, p1: u64, p2: u64) -> Option<List<T>> {
    List::slice(&p0, p1, p2)
}

pub fn append_bytes(p0: Bytes, p1: Bytes) -> Bytes {
    Bytes::append(p0, p1)
}

pub fn length_bytes(p0: Bytes) -> u64 {
    Bytes::length(&p0)
}

pub fn length_string(p0: Str) -> u64 {
    Str::length(&p0)
}

pub fn index_bytes(p0: Bytes, p1: u64) -> Option<u8> {
    Bytes::index(&p0, p1)
}

pub fn slice_bytes(p0: Bytes, p1: u64, p2: u64) -> Option<Bytes> {
    Bytes::slice(&p0, p1, p2)
}

pub fn utf8_encode(p0: Str) -> Bytes {
    Str::utf8_encode(&p0)
}

pub fn utf8_decode(p0: Bytes) -> Option<Str> {
    Bytes::utf8_decode(&p0)
}

pub fn compare_bytes(p0: Bytes, p1: Bytes) -> Ordering {
    Bytes::compare(&p0, &p1)
}

pub fn split_exact(p0: Str, p1: Str, p2: u32) -> Option<List<Str>> {
    Str::split_exact(&p0, &p1, p2)
}

pub fn join(p0: List<Str>, p1: Str) -> Str {
    Str::join(p0, &p1)
}

#[derive(Clone)]
pub enum Adt0 {
    C0(u32, u32, u32, u32),
}

#[derive(Clone)]
pub enum Adt1 {
    C0(Adt0, bool, bool),
}

#[derive(Clone)]
pub enum Adt2 {
    C0(u32, i16),
}

pub fn f0(v0: u64, v1: u64) -> Option<u64> {
    f1(v0, v1)
}

pub fn f1(v0: u64, v1: u64) -> Option<u64> {
    let v2: u64 = {
        let a3 = {
            let a1 = v0;
            let a2 = v1;
            fixed_u64::bit_xor(a1, a2)
        };
        let a4 = 9223372036854775808u64;
        fixed_u64::bit_and(a3, a4)
    };
    let v3: u64 = {
        let a5 = v0;
        let a6 = 4503599627370495u64;
        fixed_u64::bit_and(a5, a6)
    };
    let v4: u64 = {
        let a7 = v1;
        let a8 = 4503599627370495u64;
        fixed_u64::bit_and(a7, a8)
    };
    let m11 = {
        let a9 = v0;
        let a10 = 52u32;
        fixed_u64::shift_right(a9, a10)
    };
    match m11 {
        None => {
            None::<u64>
        }
        Some(v5) => {
            let m14 = {
                let a12 = v1;
                let a13 = 52u32;
                fixed_u64::shift_right(a12, a13)
            };
            match m14 {
                None => {
                    None::<u64>
                }
                Some(v6) => {
                    let v7: u64 = {
                        let a15 = v5;
                        let a16 = 2047u64;
                        fixed_u64::bit_and(a15, a16)
                    };
                    let v8: u64 = {
                        let a17 = v6;
                        let a18 = 2047u64;
                        fixed_u64::bit_and(a17, a18)
                    };
                    let a19 = v7;
                    let a20 = 2047u64;
                    if if equal(a19, a20) {
                        let a23 = {
                            let a21 = v3;
                            let a22 = 0u64;
                            equal(a21, a22)
                        };
                        bool_not(a23)
                    } else {
                        false
                    } {
                        Some({
                            let a24 = v0;
                            let a25 = 2251799813685248u64;
                            fixed_u64::bit_or(a24, a25)
                        })
                    } else {
                        let a26 = v8;
                        let a27 = 2047u64;
                        if if equal(a26, a27) {
                            let a30 = {
                                let a28 = v4;
                                let a29 = 0u64;
                                equal(a28, a29)
                            };
                            bool_not(a30)
                        } else {
                            false
                        } {
                            Some({
                                let a31 = v1;
                                let a32 = 2251799813685248u64;
                                fixed_u64::bit_or(a31, a32)
                            })
                        } else {
                            let a33 = v7;
                            let a34 = 2047u64;
                            if if equal(a33, a34) {
                                true
                            } else {
                                let a35 = v8;
                                let a36 = 2047u64;
                                equal(a35, a36)
                            } {
                                Some({
                                    let a39 = {
                                        let a37 = v0;
                                        let a38 = 9223372036854775807u64;
                                        fixed_u64::bit_and(a37, a38)
                                    };
                                    let a40 = 0u64;
                                    if if equal(a39, a40) {
                                        true
                                    } else {
                                        let a43 = {
                                            let a41 = v1;
                                            let a42 = 9223372036854775807u64;
                                            fixed_u64::bit_and(a41, a42)
                                        };
                                        let a44 = 0u64;
                                        equal(a43, a44)
                                    } {
                                        9221120237041090560u64
                                    } else {
                                        let a45 = v2;
                                        let a46 = 9218868437227405312u64;
                                        fixed_u64::bit_or(a45, a46)
                                    }
                                })
                            } else {
                                let a49 = {
                                    let a47 = v0;
                                    let a48 = 9223372036854775807u64;
                                    fixed_u64::bit_and(a47, a48)
                                };
                                let a50 = 0u64;
                                if if equal(a49, a50) {
                                    true
                                } else {
                                    let a53 = {
                                        let a51 = v1;
                                        let a52 = 9223372036854775807u64;
                                        fixed_u64::bit_and(a51, a52)
                                    };
                                    let a54 = 0u64;
                                    equal(a53, a54)
                                } {
                                    Some(v2)
                                } else {
                                    let v9: u64 = {
                                        let a55 = v7;
                                        let a56 = 0u64;
                                        if equal(a55, a56) {
                                            v3
                                        } else {
                                            let a57 = v3;
                                            let a58 = 4503599627370496u64;
                                            fixed_u64::bit_or(a57, a58)
                                        }
                                    };
                                    let v10: u64 = {
                                        let a59 = v8;
                                        let a60 = 0u64;
                                        if equal(a59, a60) {
                                            v4
                                        } else {
                                            let a61 = v4;
                                            let a62 = 4503599627370496u64;
                                            fixed_u64::bit_or(a61, a62)
                                        }
                                    };
                                    let m63 = f2(v7);
                                    match m63 {
                                        None => {
                                            None::<u64>
                                        }
                                        Some(v11) => {
                                            let m64 = f2(v8);
                                            match m64 {
                                                None => {
                                                    None::<u64>
                                                }
                                                Some(v12) => {
                                                    let m67 = {
                                                        let a65 = v7;
                                                        let a66 = 0u64;
                                                        if equal(a65, a66) {
                                                            Some(1i16)
                                                        } else {
                                                            f3(v11)
                                                        }
                                                    };
                                                    match m67 {
                                                        None => {
                                                            None::<u64>
                                                        }
                                                        Some(v13) => {
                                                            let m70 = {
                                                                let a68 = v8;
                                                                let a69 = 0u64;
                                                                if equal(a68, a69) {
                                                                    Some(1i16)
                                                                } else {
                                                                    f3(v12)
                                                                }
                                                            };
                                                            match m70 {
                                                                None => {
                                                                    None::<u64>
                                                                }
                                                                Some(v14) => {
                                                                    let m71 = f4(v13, v14);
                                                                    match m71 {
                                                                        None => {
                                                                            None::<u64>
                                                                        }
                                                                        Some(v15) => {
                                                                            let m72 = f5(v15, 2150i16);
                                                                            match m72 {
                                                                                None => {
                                                                                    None::<u64>
                                                                                }
                                                                                Some(v16) => {
                                                                                    let m73 = f6(v9, v10);
                                                                                    match m73 {
                                                                                        None => {
                                                                                            None::<u64>
                                                                                        }
                                                                                        Some(v17) => {
                                                                                            let m74 = f7(v17.clone());
                                                                                            match m74 {
                                                                                                None => {
                                                                                                    None::<u64>
                                                                                                }
                                                                                                Some(v18) => {
                                                                                                    let m75 = f5(v18, 1i16);
                                                                                                    match m75 {
                                                                                                        None => {
                                                                                                            None::<u64>
                                                                                                        }
                                                                                                        Some(v19) => {
                                                                                                            let m76 = f4(v19, v16);
                                                                                                            match m76 {
                                                                                                                None => {
                                                                                                                    None::<u64>
                                                                                                                }
                                                                                                                Some(v20) => {
                                                                                                                    let m77 = f5(v19, 52i16);
                                                                                                                    match m77 {
                                                                                                                        None => {
                                                                                                                            None::<u64>
                                                                                                                        }
                                                                                                                        Some(v21) => {
                                                                                                                            let m78 = f5(-1074i16, v16);
                                                                                                                            match m78 {
                                                                                                                                None => {
                                                                                                                                    None::<u64>
                                                                                                                                }
                                                                                                                                Some(v22) => {
                                                                                                                                    let v23: i16 = if f8(v21, v22) {
                                                                                                                                        v22
                                                                                                                                    } else {
                                                                                                                                        v21
                                                                                                                                    };
                                                                                                                                    let m79 = f9(v17, v23);
                                                                                                                                    match m79 {
                                                                                                                                        None => {
                                                                                                                                            None::<u64>
                                                                                                                                        }
                                                                                                                                        Some(v24) => {
                                                                                                                                            f10(v2, v24, v20)
                                                                                                                                        }
                                                                                                                                    }
                                                                                                                                }
                                                                                                                            }
                                                                                                                        }
                                                                                                                    }
                                                                                                                }
                                                                                                            }
                                                                                                        }
                                                                                                    }
                                                                                                }
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

pub fn f2(v0: u64) -> Option<u16> {
    let a80 = v0;
    fixed_u16::convert(i128::from(a80))
}

pub fn f3(v0: u16) -> Option<i16> {
    let a81 = v0;
    fixed_i16::convert(i128::from(a81))
}

pub fn f4(v0: i16, v1: i16) -> Option<i16> {
    let a82 = v0;
    let a83 = v1;
    fixed_i16::checked_add(a82, a83)
}

pub fn f5(v0: i16, v1: i16) -> Option<i16> {
    let a84 = v0;
    let a85 = v1;
    fixed_i16::checked_sub(a84, a85)
}

pub fn f6(v0: u64, v1: u64) -> Option<Adt0> {
    let m88 = Some({
        let a86 = v0;
        let a87 = 4294967295u64;
        fixed_u64::bit_and(a86, a87)
    });
    match m88 {
        None => {
            None::<Adt0>
        }
        Some(v2) => {
            let m91 = {
                let a89 = v0;
                let a90 = 32u32;
                fixed_u64::shift_right(a89, a90)
            };
            match m91 {
                None => {
                    None::<Adt0>
                }
                Some(v3) => {
                    let m94 = Some({
                        let a92 = v1;
                        let a93 = 4294967295u64;
                        fixed_u64::bit_and(a92, a93)
                    });
                    match m94 {
                        None => {
                            None::<Adt0>
                        }
                        Some(v4) => {
                            let m97 = {
                                let a95 = v1;
                                let a96 = 32u32;
                                fixed_u64::shift_right(a95, a96)
                            };
                            match m97 {
                                None => {
                                    None::<Adt0>
                                }
                                Some(v5) => {
                                    let m100 = {
                                        let a98 = v2;
                                        let a99 = v4;
                                        fixed_u64::checked_mul(a98, a99)
                                    };
                                    match m100 {
                                        None => {
                                            None::<Adt0>
                                        }
                                        Some(v6) => {
                                            let m103 = {
                                                let a101 = v6;
                                                let a102 = 32u32;
                                                fixed_u64::shift_right(a101, a102)
                                            };
                                            match m103 {
                                                None => {
                                                    None::<Adt0>
                                                }
                                                Some(v7) => {
                                                    let m106 = {
                                                        let a104 = v3;
                                                        let a105 = v4;
                                                        fixed_u64::checked_mul(a104, a105)
                                                    };
                                                    match m106 {
                                                        None => {
                                                            None::<Adt0>
                                                        }
                                                        Some(v8) => {
                                                            let m109 = {
                                                                let a107 = v8;
                                                                let a108 = v7;
                                                                fixed_u64::checked_add(a107, a108)
                                                            };
                                                            match m109 {
                                                                None => {
                                                                    None::<Adt0>
                                                                }
                                                                Some(v9) => {
                                                                    let m112 = {
                                                                        let a110 = v2;
                                                                        let a111 = v5;
                                                                        fixed_u64::checked_mul(a110, a111)
                                                                    };
                                                                    match m112 {
                                                                        None => {
                                                                            None::<Adt0>
                                                                        }
                                                                        Some(v10) => {
                                                                            let m117 = {
                                                                                let a115 = v10;
                                                                                let a116 = {
                                                                                    let a113 = v9;
                                                                                    let a114 = 4294967295u64;
                                                                                    fixed_u64::bit_and(a113, a114)
                                                                                };
                                                                                fixed_u64::checked_add(a115, a116)
                                                                            };
                                                                            match m117 {
                                                                                None => {
                                                                                    None::<Adt0>
                                                                                }
                                                                                Some(v11) => {
                                                                                    let m120 = {
                                                                                        let a118 = v9;
                                                                                        let a119 = 32u32;
                                                                                        fixed_u64::shift_right(a118, a119)
                                                                                    };
                                                                                    match m120 {
                                                                                        None => {
                                                                                            None::<Adt0>
                                                                                        }
                                                                                        Some(v12) => {
                                                                                            let m123 = {
                                                                                                let a121 = v11;
                                                                                                let a122 = 32u32;
                                                                                                fixed_u64::shift_right(a121, a122)
                                                                                            };
                                                                                            match m123 {
                                                                                                None => {
                                                                                                    None::<Adt0>
                                                                                                }
                                                                                                Some(v13) => {
                                                                                                    let m126 = {
                                                                                                        let a124 = v3;
                                                                                                        let a125 = v5;
                                                                                                        fixed_u64::checked_mul(a124, a125)
                                                                                                    };
                                                                                                    match m126 {
                                                                                                        None => {
                                                                                                            None::<Adt0>
                                                                                                        }
                                                                                                        Some(v14) => {
                                                                                                            let m129 = {
                                                                                                                let a127 = v14;
                                                                                                                let a128 = v12;
                                                                                                                fixed_u64::checked_add(a127, a128)
                                                                                                            };
                                                                                                            match m129 {
                                                                                                                None => {
                                                                                                                    None::<Adt0>
                                                                                                                }
                                                                                                                Some(v15) => {
                                                                                                                    let m132 = {
                                                                                                                        let a130 = v15;
                                                                                                                        let a131 = v13;
                                                                                                                        fixed_u64::checked_add(a130, a131)
                                                                                                                    };
                                                                                                                    match m132 {
                                                                                                                        None => {
                                                                                                                            None::<Adt0>
                                                                                                                        }
                                                                                                                        Some(v16) => {
                                                                                                                            let m135 = {
                                                                                                                                let a133 = v16;
                                                                                                                                let a134 = 32u32;
                                                                                                                                fixed_u64::shift_right(a133, a134)
                                                                                                                            };
                                                                                                                            match m135 {
                                                                                                                                None => {
                                                                                                                                    None::<Adt0>
                                                                                                                                }
                                                                                                                                Some(v17) => {
                                                                                                                                    let m138 = f11({
                                                                                                                                        let a136 = v6;
                                                                                                                                        let a137 = 4294967295u64;
                                                                                                                                        fixed_u64::bit_and(a136, a137)
                                                                                                                                    });
                                                                                                                                    match m138 {
                                                                                                                                        None => {
                                                                                                                                            None::<Adt0>
                                                                                                                                        }
                                                                                                                                        Some(v18) => {
                                                                                                                                            let m141 = f11({
                                                                                                                                                let a139 = v11;
                                                                                                                                                let a140 = 4294967295u64;
                                                                                                                                                fixed_u64::bit_and(a139, a140)
                                                                                                                                            });
                                                                                                                                            match m141 {
                                                                                                                                                None => {
                                                                                                                                                    None::<Adt0>
                                                                                                                                                }
                                                                                                                                                Some(v19) => {
                                                                                                                                                    let m144 = f11({
                                                                                                                                                        let a142 = v16;
                                                                                                                                                        let a143 = 4294967295u64;
                                                                                                                                                        fixed_u64::bit_and(a142, a143)
                                                                                                                                                    });
                                                                                                                                                    match m144 {
                                                                                                                                                        None => {
                                                                                                                                                            None::<Adt0>
                                                                                                                                                        }
                                                                                                                                                        Some(v20) => {
                                                                                                                                                            let m147 = f11({
                                                                                                                                                                let a145 = v17;
                                                                                                                                                                let a146 = 4294967295u64;
                                                                                                                                                                fixed_u64::bit_and(a145, a146)
                                                                                                                                                            });
                                                                                                                                                            match m147 {
                                                                                                                                                                None => {
                                                                                                                                                                    None::<Adt0>
                                                                                                                                                                }
                                                                                                                                                                Some(v21) => {
                                                                                                                                                                    Some(Adt0::C0(v18, v19, v20, v21))
                                                                                                                                                                }
                                                                                                                                                            }
                                                                                                                                                        }
                                                                                                                                                    }
                                                                                                                                                }
                                                                                                                                            }
                                                                                                                                        }
                                                                                                                                    }
                                                                                                                                }
                                                                                                                            }
                                                                                                                        }
                                                                                                                    }
                                                                                                                }
                                                                                                            }
                                                                                                        }
                                                                                                    }
                                                                                                }
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

pub fn f7(v0: Adt0) -> Option<i16> {
    let a149 = match v0.clone() {
        Adt0::C0(_, _, _, h148) => {
            h148
        }
    };
    let a150 = 0u32;
    if equal(a149, a150) {
        let a152 = match v0.clone() {
            Adt0::C0(_, _, h151, _) => {
                h151
            }
        };
        let a153 = 0u32;
        if equal(a152, a153) {
            let a155 = match v0.clone() {
                Adt0::C0(_, h154, _, _) => {
                    h154
                }
            };
            let a156 = 0u32;
            if equal(a155, a156) {
                f12(match v0 {
                    Adt0::C0(h157, _, _, _) => {
                        h157
                    }
                })
            } else {
                let m159 = f12(match v0 {
                    Adt0::C0(_, h158, _, _) => {
                        h158
                    }
                });
                match m159 {
                    None => {
                        None::<i16>
                    }
                    Some(v1) => {
                        f4(v1, 32i16)
                    }
                }
            }
        } else {
            let m161 = f12(match v0 {
                Adt0::C0(_, _, h160, _) => {
                    h160
                }
            });
            match m161 {
                None => {
                    None::<i16>
                }
                Some(v2) => {
                    f4(v2, 64i16)
                }
            }
        }
    } else {
        let m163 = f12(match v0 {
            Adt0::C0(_, _, _, h162) => {
                h162
            }
        });
        match m163 {
            None => {
                None::<i16>
            }
            Some(v3) => {
                f4(v3, 96i16)
            }
        }
    }
}

pub fn f8(v0: i16, v1: i16) -> bool {
    let m164 = f5(v0, v1);
    match m164 {
        None => {
            f13(v0)
        }
        Some(v2) => {
            f13(v2)
        }
    }
}

pub fn f9(v0: Adt0, v1: i16) -> Option<u64> {
    if f13(v1) {
        let m165 = f14(v1);
        match m165 {
            None => {
                None::<u64>
            }
            Some(v2) => {
                let m166 = f15(v2);
                match m166 {
                    None => {
                        None::<u64>
                    }
                    Some(v3) => {
                        let m167 = f16(v0);
                        match m167 {
                            None => {
                                None::<u64>
                            }
                            Some(v4) => {
                                let a168 = v4;
                                let a169 = v3;
                                fixed_u64::shift_left(a168, a169)
                            }
                        }
                    }
                }
            }
        }
    } else {
        if f8(128i16, v1) {
            Some(0u64)
        } else {
            let m170 = f17(v1);
            match m170 {
                None => {
                    None::<u64>
                }
                Some(v5) => {
                    let m212 = {
                        let m171 = Some(Adt1::C0(v0, false, false));
                        match m171 {
                            None => {
                                None::<Adt1>
                            }
                            Some(v6) => {
                                let m176 = {
                                    let a174 = {
                                        let a172 = v5;
                                        let a173 = 1u8;
                                        fixed_u8::bit_and(a172, a173)
                                    };
                                    let a175 = 0u8;
                                    if equal(a174, a175) {
                                        Some(v6)
                                    } else {
                                        f18(Some(v6))
                                    }
                                };
                                match m176 {
                                    None => {
                                        None::<Adt1>
                                    }
                                    Some(v7) => {
                                        let m181 = {
                                            let a179 = {
                                                let a177 = v5;
                                                let a178 = 2u8;
                                                fixed_u8::bit_and(a177, a178)
                                            };
                                            let a180 = 0u8;
                                            if equal(a179, a180) {
                                                Some(v7)
                                            } else {
                                                f19(Some(v7))
                                            }
                                        };
                                        match m181 {
                                            None => {
                                                None::<Adt1>
                                            }
                                            Some(v8) => {
                                                let m186 = {
                                                    let a184 = {
                                                        let a182 = v5;
                                                        let a183 = 4u8;
                                                        fixed_u8::bit_and(a182, a183)
                                                    };
                                                    let a185 = 0u8;
                                                    if equal(a184, a185) {
                                                        Some(v8)
                                                    } else {
                                                        f20(Some(v8))
                                                    }
                                                };
                                                match m186 {
                                                    None => {
                                                        None::<Adt1>
                                                    }
                                                    Some(v9) => {
                                                        let m191 = {
                                                            let a189 = {
                                                                let a187 = v5;
                                                                let a188 = 8u8;
                                                                fixed_u8::bit_and(a187, a188)
                                                            };
                                                            let a190 = 0u8;
                                                            if equal(a189, a190) {
                                                                Some(v9)
                                                            } else {
                                                                f21(Some(v9))
                                                            }
                                                        };
                                                        match m191 {
                                                            None => {
                                                                None::<Adt1>
                                                            }
                                                            Some(v10) => {
                                                                let m196 = {
                                                                    let a194 = {
                                                                        let a192 = v5;
                                                                        let a193 = 16u8;
                                                                        fixed_u8::bit_and(a192, a193)
                                                                    };
                                                                    let a195 = 0u8;
                                                                    if equal(a194, a195) {
                                                                        Some(v10)
                                                                    } else {
                                                                        f22(Some(v10))
                                                                    }
                                                                };
                                                                match m196 {
                                                                    None => {
                                                                        None::<Adt1>
                                                                    }
                                                                    Some(v11) => {
                                                                        let m201 = {
                                                                            let a199 = {
                                                                                let a197 = v5;
                                                                                let a198 = 32u8;
                                                                                fixed_u8::bit_and(a197, a198)
                                                                            };
                                                                            let a200 = 0u8;
                                                                            if equal(a199, a200) {
                                                                                Some(v11)
                                                                            } else {
                                                                                f23(Some(v11))
                                                                            }
                                                                        };
                                                                        match m201 {
                                                                            None => {
                                                                                None::<Adt1>
                                                                            }
                                                                            Some(v12) => {
                                                                                let m206 = {
                                                                                    let a204 = {
                                                                                        let a202 = v5;
                                                                                        let a203 = 64u8;
                                                                                        fixed_u8::bit_and(a202, a203)
                                                                                    };
                                                                                    let a205 = 0u8;
                                                                                    if equal(a204, a205) {
                                                                                        Some(v12)
                                                                                    } else {
                                                                                        f24(Some(v12))
                                                                                    }
                                                                                };
                                                                                match m206 {
                                                                                    None => {
                                                                                        None::<Adt1>
                                                                                    }
                                                                                    Some(v13) => {
                                                                                        let m211 = {
                                                                                            let a209 = {
                                                                                                let a207 = v5;
                                                                                                let a208 = 128u8;
                                                                                                fixed_u8::bit_and(a207, a208)
                                                                                            };
                                                                                            let a210 = 0u8;
                                                                                            if equal(a209, a210) {
                                                                                                Some(v13)
                                                                                            } else {
                                                                                                f25(Some(v13))
                                                                                            }
                                                                                        };
                                                                                        match m211 {
                                                                                            None => {
                                                                                                None::<Adt1>
                                                                                            }
                                                                                            Some(v14) => {
                                                                                                Some(v14)
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    };
                    match m212 {
                        None => {
                            None::<u64>
                        }
                        Some(v15) => {
                            let m214 = f16(match v15.clone() {
                                Adt1::C0(h213, _, _) => {
                                    h213
                                }
                            });
                            match m214 {
                                None => {
                                    None::<u64>
                                }
                                Some(v16) => {
                                    if if match v15.clone() {
                                        Adt1::C0(_, h215, _) => {
                                            h215
                                        }
                                    } {
                                        if match v15 {
                                            Adt1::C0(_, _, h216) => {
                                                h216
                                            }
                                        } {
                                            true
                                        } else {
                                            let a219 = {
                                                let a217 = v16;
                                                let a218 = 1u64;
                                                fixed_u64::bit_and(a217, a218)
                                            };
                                            let a220 = 1u64;
                                            equal(a219, a220)
                                        }
                                    } else {
                                        false
                                    } {
                                        let a221 = v16;
                                        let a222 = 1u64;
                                        fixed_u64::checked_add(a221, a222)
                                    } else {
                                        Some(v16)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

pub fn f10(v0: u64, v1: u64, v2: i16) -> Option<u64> {
    let v3: bool = {
        let a223 = v1;
        let a224 = 9007199254740992u64;
        equal(a223, a224)
    };
    let m225 = if v3 {
        f4(v2, 1i16)
    } else {
        Some(v2)
    };
    match m225 {
        None => {
            None::<u64>
        }
        Some(v4) => {
            let m226 = if f8(v4, -1022i16) {
                Some(if f26(v1, 4503599627370496u64) {
                    0i16
                } else {
                    1i16
                })
            } else {
                f4(v4, 1023i16)
            };
            match m226 {
                None => {
                    None::<u64>
                }
                Some(v5) => {
                    if f8(2046i16, v5) {
                        Some({
                            let a227 = v0;
                            let a228 = 9218868437227405312u64;
                            fixed_u64::bit_or(a227, a228)
                        })
                    } else {
                        let m231 = if v3 {
                            let a229 = v1;
                            let a230 = 1u32;
                            fixed_u64::shift_right(a229, a230)
                        } else {
                            Some(v1)
                        };
                        match m231 {
                            None => {
                                None::<u64>
                            }
                            Some(v6) => {
                                let m232 = f27(v5);
                                match m232 {
                                    None => {
                                        None::<u64>
                                    }
                                    Some(v7) => {
                                        let m235 = {
                                            let a233 = v7;
                                            let a234 = 52u32;
                                            fixed_u64::shift_left(a233, a234)
                                        };
                                        match m235 {
                                            None => {
                                                None::<u64>
                                            }
                                            Some(v8) => {
                                                Some({
                                                    let a240 = v0;
                                                    let a241 = {
                                                        let a238 = v8;
                                                        let a239 = {
                                                            let a236 = v6;
                                                            let a237 = 4503599627370495u64;
                                                            fixed_u64::bit_and(a236, a237)
                                                        };
                                                        fixed_u64::bit_or(a238, a239)
                                                    };
                                                    fixed_u64::bit_or(a240, a241)
                                                })
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

pub fn f11(v0: u64) -> Option<u32> {
    let a242 = v0;
    fixed_u32::convert(i128::from(a242))
}

pub fn f12(v0: u32) -> Option<i16> {
    let m243 = f28(Some(Adt2::C0(v0, 0i16)));
    match m243 {
        None => {
            None::<i16>
        }
        Some(v1) => {
            Some(match v1 {
                Adt2::C0(_, h244) => {
                    h244
                }
            })
        }
    }
}

pub fn f13(v0: i16) -> bool {
    let m245 = f29(v0);
    match m245 {
        None => {
            true
        }
        Some(_) => {
            false
        }
    }
}

pub fn f14(v0: i16) -> Option<i16> {
    let a246 = v0;
    checked_neg_i16(a246)
}

pub fn f15(v0: i16) -> Option<u32> {
    let a247 = v0;
    fixed_u32::convert(i128::from(a247))
}

pub fn f16(v0: Adt0) -> Option<u64> {
    let a249 = match v0.clone() {
        Adt0::C0(_, _, h248, _) => {
            h248
        }
    };
    let a250 = 0u32;
    if if equal(a249, a250) {
        let a252 = match v0.clone() {
            Adt0::C0(_, _, _, h251) => {
                h251
            }
        };
        let a253 = 0u32;
        equal(a252, a253)
    } else {
        false
    } {
        let m255 = f30(match v0.clone() {
            Adt0::C0(h254, _, _, _) => {
                h254
            }
        });
        match m255 {
            None => {
                None::<u64>
            }
            Some(v1) => {
                let m257 = f30(match v0 {
                    Adt0::C0(_, h256, _, _) => {
                        h256
                    }
                });
                match m257 {
                    None => {
                        None::<u64>
                    }
                    Some(v2) => {
                        let m260 = {
                            let a258 = v2;
                            let a259 = 32u32;
                            fixed_u64::shift_left(a258, a259)
                        };
                        match m260 {
                            None => {
                                None::<u64>
                            }
                            Some(v3) => {
                                Some({
                                    let a261 = v1;
                                    let a262 = v3;
                                    fixed_u64::bit_or(a261, a262)
                                })
                            }
                        }
                    }
                }
            }
        }
    } else {
        None::<u64>
    }
}

pub fn f17(v0: i16) -> Option<u8> {
    let a263 = v0;
    fixed_u8::convert(i128::from(a263))
}

pub fn f18(v0: Option<Adt1>) -> Option<Adt1> {
    let m264 = v0;
    match m264 {
        None => {
            None::<Adt1>
        }
        Some(v1) => {
            let m266 = f31(match v1.clone() {
                Adt1::C0(h265, _, _) => {
                    h265
                }
            });
            match m266 {
                None => {
                    None::<Adt1>
                }
                Some(v2) => {
                    Some(Adt1::C0(v2, {
                        let a272 = {
                            let a270 = {
                                let m269 = match v1.clone() {
                                    Adt1::C0(h268, _, _) => {
                                        h268
                                    }
                                };
                                match m269 {
                                    Adt0::C0(h267, _, _, _) => {
                                        h267
                                    }
                                }
                            };
                            let a271 = 1u32;
                            fixed_u32::bit_and(a270, a271)
                        };
                        let a273 = 1u32;
                        equal(a272, a273)
                    }, if match v1.clone() {
                        Adt1::C0(_, _, h274) => {
                            h274
                        }
                    } {
                        true
                    } else {
                        match v1 {
                            Adt1::C0(_, h275, _) => {
                                h275
                            }
                        }
                    }))
                }
            }
        }
    }
}

pub fn f19(v0: Option<Adt1>) -> Option<Adt1> {
    f18(f18(v0))
}

pub fn f20(v0: Option<Adt1>) -> Option<Adt1> {
    f19(f19(v0))
}

pub fn f21(v0: Option<Adt1>) -> Option<Adt1> {
    f20(f20(v0))
}

pub fn f22(v0: Option<Adt1>) -> Option<Adt1> {
    f21(f21(v0))
}

pub fn f23(v0: Option<Adt1>) -> Option<Adt1> {
    f22(f22(v0))
}

pub fn f24(v0: Option<Adt1>) -> Option<Adt1> {
    f23(f23(v0))
}

pub fn f25(v0: Option<Adt1>) -> Option<Adt1> {
    f24(f24(v0))
}

pub fn f26(v0: u64, v1: u64) -> bool {
    let m278 = {
        let a276 = v0;
        let a277 = v1;
        fixed_u64::checked_sub(a276, a277)
    };
    match m278 {
        None => {
            true
        }
        Some(_) => {
            false
        }
    }
}

pub fn f27(v0: i16) -> Option<u64> {
    let a279 = v0;
    fixed_u64::convert(i128::from(a279))
}

pub fn f28(v0: Option<Adt2>) -> Option<Adt2> {
    f32(f32(v0))
}

pub fn f29(v0: i16) -> Option<u16> {
    let a280 = v0;
    fixed_u16::convert(i128::from(a280))
}

pub fn f30(v0: u32) -> Option<u64> {
    let a281 = v0;
    fixed_u64::convert(i128::from(a281))
}

pub fn f31(v0: Adt0) -> Option<Adt0> {
    let m285 = {
        let a283 = match v0.clone() {
            Adt0::C0(h282, _, _, _) => {
                h282
            }
        };
        let a284 = 1u32;
        fixed_u32::shift_right(a283, a284)
    };
    match m285 {
        None => {
            None::<Adt0>
        }
        Some(v1) => {
            let m289 = {
                let a287 = match v0.clone() {
                    Adt0::C0(_, h286, _, _) => {
                        h286
                    }
                };
                let a288 = 1u32;
                fixed_u32::shift_right(a287, a288)
            };
            match m289 {
                None => {
                    None::<Adt0>
                }
                Some(v2) => {
                    let m293 = {
                        let a291 = match v0.clone() {
                            Adt0::C0(_, _, h290, _) => {
                                h290
                            }
                        };
                        let a292 = 1u32;
                        fixed_u32::shift_right(a291, a292)
                    };
                    match m293 {
                        None => {
                            None::<Adt0>
                        }
                        Some(v3) => {
                            let m297 = {
                                let a295 = match v0.clone() {
                                    Adt0::C0(_, _, _, h294) => {
                                        h294
                                    }
                                };
                                let a296 = 1u32;
                                fixed_u32::shift_right(a295, a296)
                            };
                            match m297 {
                                None => {
                                    None::<Adt0>
                                }
                                Some(v4) => {
                                    let m303 = {
                                        let a301 = {
                                            let a299 = match v0.clone() {
                                                Adt0::C0(_, h298, _, _) => {
                                                    h298
                                                }
                                            };
                                            let a300 = 1u32;
                                            fixed_u32::bit_and(a299, a300)
                                        };
                                        let a302 = 31u32;
                                        fixed_u32::shift_left(a301, a302)
                                    };
                                    match m303 {
                                        None => {
                                            None::<Adt0>
                                        }
                                        Some(v5) => {
                                            let m309 = {
                                                let a307 = {
                                                    let a305 = match v0.clone() {
                                                        Adt0::C0(_, _, h304, _) => {
                                                            h304
                                                        }
                                                    };
                                                    let a306 = 1u32;
                                                    fixed_u32::bit_and(a305, a306)
                                                };
                                                let a308 = 31u32;
                                                fixed_u32::shift_left(a307, a308)
                                            };
                                            match m309 {
                                                None => {
                                                    None::<Adt0>
                                                }
                                                Some(v6) => {
                                                    let m315 = {
                                                        let a313 = {
                                                            let a311 = match v0 {
                                                                Adt0::C0(_, _, _, h310) => {
                                                                    h310
                                                                }
                                                            };
                                                            let a312 = 1u32;
                                                            fixed_u32::bit_and(a311, a312)
                                                        };
                                                        let a314 = 31u32;
                                                        fixed_u32::shift_left(a313, a314)
                                                    };
                                                    match m315 {
                                                        None => {
                                                            None::<Adt0>
                                                        }
                                                        Some(v7) => {
                                                            Some(Adt0::C0({
                                                                let a316 = v1;
                                                                let a317 = v5;
                                                                fixed_u32::bit_or(a316, a317)
                                                            }, {
                                                                let a318 = v2;
                                                                let a319 = v6;
                                                                fixed_u32::bit_or(a318, a319)
                                                            }, {
                                                                let a320 = v3;
                                                                let a321 = v7;
                                                                fixed_u32::bit_or(a320, a321)
                                                            }, v4))
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

pub fn f32(v0: Option<Adt2>) -> Option<Adt2> {
    f33(f33(v0))
}

pub fn f33(v0: Option<Adt2>) -> Option<Adt2> {
    f34(f34(v0))
}

pub fn f34(v0: Option<Adt2>) -> Option<Adt2> {
    f35(f35(v0))
}

pub fn f35(v0: Option<Adt2>) -> Option<Adt2> {
    f36(f36(v0))
}

pub fn f36(v0: Option<Adt2>) -> Option<Adt2> {
    let m322 = v0;
    match m322 {
        None => {
            None::<Adt2>
        }
        Some(v1) => {
            let m326 = {
                let a324 = match v1.clone() {
                    Adt2::C0(h323, _) => {
                        h323
                    }
                };
                let a325 = 1u32;
                fixed_u32::shift_right(a324, a325)
            };
            match m326 {
                None => {
                    None::<Adt2>
                }
                Some(v2) => {
                    let a328 = match v1.clone() {
                        Adt2::C0(h327, _) => {
                            h327
                        }
                    };
                    let a329 = 0u32;
                    if equal(a328, a329) {
                        Some(Adt2::C0(v2, match v1 {
                            Adt2::C0(_, h330) => {
                                h330
                            }
                        }))
                    } else {
                        let m332 = f4(match v1 {
                            Adt2::C0(_, h331) => {
                                h331
                            }
                        }, 1i16);
                        match m332 {
                            None => {
                                None::<Adt2>
                            }
                            Some(v3) => {
                                Some(Adt2::C0(v2, v3))
                            }
                        }
                    }
                }
            }
        }
    }
}

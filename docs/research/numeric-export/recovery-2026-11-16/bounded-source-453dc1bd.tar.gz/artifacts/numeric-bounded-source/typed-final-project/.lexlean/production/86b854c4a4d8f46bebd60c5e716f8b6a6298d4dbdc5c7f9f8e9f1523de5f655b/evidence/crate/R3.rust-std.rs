#![forbid(unsafe_code)]
use core::cmp::Ordering;

use core::sync::atomic::{AtomicU64, Ordering as Memory};

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub struct Overflow;

pub type R<T> = Result<T, Overflow>;

static WORK: AtomicU64 = AtomicU64::new(0);

pub fn tick(units: u64) { WORK.fetch_add(units, Memory::Relaxed); }

pub fn work() -> u64 { WORK.load(Memory::Relaxed) }

pub trait Same {
    fn same(&self, other: &Self) -> bool;
}

pub trait Key {
    fn key(&self, other: &Self) -> Ordering;
}

impl Same for bool {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for bool {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u8 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u8 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u16 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u16 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u32 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u32 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u64 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u64 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i8 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i8 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i16 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i16 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i32 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i32 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i64 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i64 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for Ordering {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl<A: Key, B: Key> Key for (A, B) {
    fn key(&self, other: &Self) -> Ordering { match self.0.key(&other.0) { Ordering::Equal => self.1.key(&other.1), decided => decided, } }
}

pub fn equal<T: Same>(a: T, b: T) -> bool { a.same(&b) }

pub fn compare<T: Key>(a: T, b: T) -> Ordering { a.key(&b) }

pub fn nat_add(p0: u64, p1: u64) -> R<u64> {
    match u64::checked_add(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<u64, Overflow>(Overflow)
        }
    }
}

pub fn nat_sub(p0: u64, p1: u64) -> u64 {
    u64::saturating_sub(p0, p1)
}

pub fn nat_mul(p0: u64, p1: u64) -> R<u64> {
    match u64::checked_mul(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<u64, Overflow>(Overflow)
        }
    }
}

pub fn nat_quot(p0: u64, p1: u64, p2: u64) -> u64 {
    u64::checked_div(p0, p1).unwrap_or(p2)
}

pub fn nat_rem(p0: u64, p1: u64, p2: u64) -> u64 {
    u64::checked_rem(p0, p1).unwrap_or(p2)
}

pub fn nat_eq(p0: u64, p1: u64) -> bool {
    core::cmp::PartialEq::eq(&p0, &p1)
}

pub fn nat_le(p0: u64, p1: u64) -> bool {
    core::cmp::PartialOrd::le(&p0, &p1)
}

pub fn nat_lt(p0: u64, p1: u64) -> bool {
    core::cmp::PartialOrd::lt(&p0, &p1)
}

pub fn nat_succ(p0: u64) -> R<u64> {
    match u64::checked_add(p0, 1u64) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<u64, Overflow>(Overflow)
        }
    }
}

pub fn int_add(p0: i64, p1: i64) -> R<i64> {
    match i64::checked_add(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_sub(p0: i64, p1: i64) -> R<i64> {
    match i64::checked_sub(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_mul(p0: i64, p1: i64) -> R<i64> {
    match i64::checked_mul(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_neg(p0: i64) -> R<i64> {
    match i64::checked_neg(p0) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_quot(p0: i64, p1: i64, p2: i64) -> R<i64> {
    { let value = { let (a, b, z): (i64, i64, i64) = (p0, p1, p2); if b == 0 { Some(z) } else { a.checked_div(b) } }; match value {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    } }
}

pub fn int_rem(p0: i64, p1: i64, p2: i64) -> i64 {
    { let (a, b, z): (i64, i64, i64) = (p0, p1, p2); if b == 0 { z } else { a.wrapping_rem(b) } }
}

pub fn bool_not(p0: bool) -> bool {
    !p0
}

pub fn bool_and(p0: bool, p1: bool) -> bool {
    if p0 {
        p1
    } else {
        false
    }
}

pub fn bool_or(p0: bool, p1: bool) -> bool {
    if p0 {
        true
    } else {
        p1
    }
}

pub mod fixed_u8 {
    pub fn checked_add(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u8, p1: u8) -> u8 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u8, p1: u8) -> u8 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u8, p1: u8) -> u8 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u8) -> u8 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u8, p1: u32) -> Option<u8> {
        u8::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u8, p1: u32) -> Option<u8> {
        u8::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u8> {
        u8::try_from(p0).ok()
    }
}

pub mod fixed_u16 {
    pub fn checked_add(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u16, p1: u16) -> u16 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u16, p1: u16) -> u16 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u16, p1: u16) -> u16 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u16) -> u16 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u16, p1: u32) -> Option<u16> {
        u16::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u16, p1: u32) -> Option<u16> {
        u16::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u16> {
        u16::try_from(p0).ok()
    }
}

pub mod fixed_u32 {
    pub fn checked_add(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u32, p1: u32) -> u32 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u32, p1: u32) -> u32 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u32, p1: u32) -> u32 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u32) -> u32 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u32> {
        u32::try_from(p0).ok()
    }
}

pub mod fixed_u64 {
    pub fn checked_add(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u64, p1: u64) -> u64 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u64, p1: u64) -> u64 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u64, p1: u64) -> u64 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u64) -> u64 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u64, p1: u32) -> Option<u64> {
        u64::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u64, p1: u32) -> Option<u64> {
        u64::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u64> {
        u64::try_from(p0).ok()
    }
}

pub mod fixed_i8 {
    pub fn checked_add(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i8, p1: i8) -> i8 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i8, p1: i8) -> i8 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i8, p1: i8) -> i8 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i8) -> i8 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i8, p1: u32) -> Option<i8> {
        i8::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i8, p1: u32) -> Option<i8> {
        i8::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i8> {
        i8::try_from(p0).ok()
    }
}

pub fn checked_neg_i8(p0: i8) -> Option<i8> {
    i8::checked_neg(p0)
}

pub mod fixed_i16 {
    pub fn checked_add(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i16, p1: i16) -> i16 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i16, p1: i16) -> i16 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i16, p1: i16) -> i16 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i16) -> i16 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i16, p1: u32) -> Option<i16> {
        i16::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i16, p1: u32) -> Option<i16> {
        i16::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i16> {
        i16::try_from(p0).ok()
    }
}

pub fn checked_neg_i16(p0: i16) -> Option<i16> {
    i16::checked_neg(p0)
}

pub mod fixed_i32 {
    pub fn checked_add(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i32, p1: i32) -> i32 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i32, p1: i32) -> i32 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i32, p1: i32) -> i32 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i32) -> i32 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i32, p1: u32) -> Option<i32> {
        i32::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i32, p1: u32) -> Option<i32> {
        i32::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i32> {
        i32::try_from(p0).ok()
    }
}

pub fn checked_neg_i32(p0: i32) -> Option<i32> {
    i32::checked_neg(p0)
}

pub mod fixed_i64 {
    pub fn checked_add(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i64, p1: i64) -> i64 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i64, p1: i64) -> i64 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i64, p1: i64) -> i64 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i64) -> i64 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i64, p1: u32) -> Option<i64> {
        i64::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i64, p1: u32) -> Option<i64> {
        i64::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i64> {
        i64::try_from(p0).ok()
    }
}

pub fn checked_neg_i64(p0: i64) -> Option<i64> {
    i64::checked_neg(p0)
}
use core::str;

use std::mem;

use std::rc::Rc;

#[derive(Clone)]
pub struct Str(Rc<str>);

impl Str {
    pub fn lit(text: &str) -> Str { Str(Rc::from(text)) }
    pub fn text(&self) -> &str { &self.0 }
    pub fn length(&self) -> u64 { chars(&self.0) }
    pub fn utf8_encode(&self) -> Bytes { tick(self.0.len() as u64); Bytes::lit(self.0.as_bytes()) }
    pub fn split_exact(&self, delimiter: &Str, maximum: u32) -> Option<List<Str>> { if delimiter.0.is_empty() { return None; }; chars(&self.0); let mut fields: Vec<Str> = Vec::new(); for piece in self.0.split(&*delimiter.0) { fields.push(Str::lit(piece)); }; if fields.len() as u128 > u128::from(maximum) { return None; }; Some(List::onto(fields, List::nil())) }
    pub fn join(texts: List<Str>, delimiter: &Str) -> Str { let mut out = String::new(); let mut first = true; let mut cursor = &texts; while let Repr::Cell(cell) = &cursor.0 { tick(1); if !first { chars(&delimiter.0); out.push_str(&delimiter.0); }; first = false; chars(&cell.head.0); out.push_str(&cell.head.0); cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for text in buffer[..*len].iter().rev() { tick(1); if !first { chars(&delimiter.0); out.push_str(&delimiter.0); }; first = false; chars(&text.0); out.push_str(&text.0); } }, _ => { }, }; Str::lit(&out) }
}

#[derive(Clone)]
pub struct Bytes(Rc<[u8]>);

impl Bytes {
    pub fn lit(octets: &[u8]) -> Bytes { Bytes(Rc::from(octets)) }
    pub fn octets(&self) -> &[u8] { &self.0 }
    pub fn append(a: Bytes, b: Bytes) -> Bytes { tick((a.0.len() + b.0.len()) as u64); let mut out = Vec::with_capacity(a.0.len() + b.0.len()); out.extend_from_slice(&a.0); out.extend_from_slice(&b.0); Bytes(Rc::from(out)) }
    pub fn length(&self) -> u64 { self.0.len() as u64 }
    pub fn index(&self, i: u64) -> Option<u8> { match usize::try_from(i) { Ok(at) => self.0.get(at).copied(), Err(_) => None, } }
    pub fn slice(&self, start: u64, count: u64) -> Option<Bytes> { let end = u128::from(start) + u128::from(count); if end > self.0.len() as u128 { return None; }; tick(count); Some(Bytes::lit(&self.0[start as usize..end as usize])) }
    pub fn utf8_decode(&self) -> Option<Str> { tick(self.0.len() as u64); match str::from_utf8(&self.0) { Ok(text) => Some(Str::lit(text)), Err(_) => None, } }
    pub fn compare(&self, other: &Bytes) -> Ordering { tick(1 + self.0.len().min(other.0.len()) as u64); self.0.cmp(&other.0) }
}

pub struct Node<T> { head: T, tail: List<T> }

pub enum Repr<T> { Nil, Run { buffer: Rc<Vec<T>>, len: usize }, Cell(Rc<Node<T>>) }

pub struct List<T>(Repr<T>);

impl<T> Clone for List<T> {
    fn clone(&self) -> Self { List(match &self.0 { Repr::Nil => Repr::Nil, Repr::Run { buffer, len } => Repr::Run { buffer: buffer.clone(), len: *len }, Repr::Cell(cell) => Repr::Cell(cell.clone()), }) }
}

impl<T> List<T> {
    fn take(&mut self) -> Repr<T> { mem::replace(&mut self.0, Repr::Nil) }
}

impl<T> Drop for Node<T> {
    fn drop(&mut self) { let mut next = match self.tail.take() { Repr::Cell(cell) => Some(cell), _ => None, }; while let Some(cell) = next { match Rc::try_unwrap(cell) { Ok(mut node) => next = match node.tail.take() { Repr::Cell(cell) => Some(cell), _ => None, }, Err(_) => break, } } }
}

impl<T: Clone> List<T> {
    pub fn nil() -> Self { List(Repr::Nil) }
    pub fn cons(head: T, mut tail: List<T>) -> Self { List(match tail.take() { Repr::Nil => { let mut buffer = Vec::with_capacity(16); buffer.push(head); Repr::Run { buffer: Rc::new(buffer), len: 1 } }, Repr::Run { mut buffer, len } => { match Rc::get_mut(&mut buffer) { Some(cells) => { cells.truncate(len); cells.push(head); Repr::Run { buffer, len: len + 1 } }, None => Repr::Cell(Rc::new(Node { head, tail: List(Repr::Run { buffer, len }) })), } }, rest => Repr::Cell(Rc::new(Node { head, tail: List(rest) })), }) }
    pub fn uncons(&self) -> Option<(T, List<T>)> { match &self.0 { Repr::Nil => None, Repr::Run { buffer, len } => { let head = buffer[len - 1].clone(); Some((head, List(if *len == 1 { Repr::Nil } else { Repr::Run { buffer: buffer.clone(), len: len - 1 } }))) }, Repr::Cell(cell) => Some((cell.head.clone(), cell.tail.clone())), } }
    pub fn length(&self) -> u64 { let mut count = 0; let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); count += 1; cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for _ in buffer[..*len].iter().rev() { tick(1); count += 1; } }, _ => { }, }; count }
    pub fn append(a: List<T>, b: List<T>) -> List<T> { List::onto(a.items(), b) }
    pub fn index(&self, i: u64) -> Option<T> { let mut position = 0; let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); if position == i { return Some(cell.head.clone()); }; position += 1; cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for item in buffer[..*len].iter().rev() { tick(1); if position == i { return Some(item.clone()); }; position += 1; } }, _ => { }, }; None }
    pub fn slice(&self, start: u64, count: u64) -> Option<List<T>> { let end = u128::from(start) + u128::from(count); let mut part = Vec::new(); let mut position: u128 = 0; let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); if position >= end { return Some(List::onto(part, List::nil())); }; if position >= u128::from(start) { part.push(cell.head.clone()); }; position += 1; cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for item in buffer[..*len].iter().rev() { tick(1); if position >= end { return Some(List::onto(part, List::nil())); }; if position >= u128::from(start) { part.push(item.clone()); }; position += 1; } }, _ => { }, }; if position < end { None } else { Some(List::onto(part, List::nil())) } }
    fn items(&self) -> Vec<T> { let mut out = Vec::new(); let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); out.push(cell.head.clone()); cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for item in buffer[..*len].iter().rev() { tick(1); out.push(item.clone()); } }, _ => { }, }; out }
    fn onto(mut items: Vec<T>, tail: List<T>) -> List<T> { let mut out = tail; while let Some(item) = items.pop() { tick(1); out = List::cons(item, out); }; out }
}

pub fn chars(text: &str) -> u64 { let mut count = 0; for _ in text.chars() { tick(1); count += 1; }; count }

impl Same for Str {
    fn same(&self, other: &Self) -> bool { let mut left = self.0.chars(); let mut right = other.0.chars(); loop { tick(1); match (left.next(), right.next()) { (None, None) => return true, (a, b) if a != b => return false, _ => { }, } } }
}

impl Same for Bytes {
    fn same(&self, other: &Self) -> bool { tick(1 + self.0.len().min(other.0.len()) as u64); self.0 == other.0 }
}

impl Key for Str {
    fn key(&self, other: &Self) -> Ordering { let mut left = self.0.chars(); let mut right = other.0.chars(); loop { tick(1); match (left.next(), right.next()) { (None, None) => return Ordering::Equal, (None, Some(_)) => return Ordering::Less, (Some(_), None) => return Ordering::Greater, (Some(a), Some(b)) => match a.cmp(&b) { Ordering::Equal => { }, decided => return decided, }, } } }
}

pub fn canonical_decimal(text: &str) -> Option<Option<i128>> { let digits = match text.strip_prefix('-') { Some(rest) => rest, None => text, }; let mut canonical = !digits.is_empty() && (digits == "0" || !digits.starts_with('0')) && text != "-0"; for c in digits.chars() { tick(1); canonical = canonical && c.is_ascii_digit(); }; if !canonical { return None; }; Some(text.parse::<i128>().ok()) }

pub fn parse_int(text: Str) -> R<Option<i64>> { match canonical_decimal(&text.0) { None => Ok(None), Some(Some(n)) => match i64::try_from(n) { Ok(value) => Ok(Some(value)), Err(_) => Err(Overflow), }, Some(None) => Err(Overflow), } }

pub fn format_u8(a: u8) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u8(text: Str) -> Option<u8> { match canonical_decimal(&text.0) { Some(Some(n)) => u8::try_from(n).ok(), _ => None, } }

pub fn format_u16(a: u16) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u16(text: Str) -> Option<u16> { match canonical_decimal(&text.0) { Some(Some(n)) => u16::try_from(n).ok(), _ => None, } }

pub fn format_u32(a: u32) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u32(text: Str) -> Option<u32> { match canonical_decimal(&text.0) { Some(Some(n)) => u32::try_from(n).ok(), _ => None, } }

pub fn format_u64(a: u64) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u64(text: Str) -> Option<u64> { match canonical_decimal(&text.0) { Some(Some(n)) => u64::try_from(n).ok(), _ => None, } }

pub fn format_i8(a: i8) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i8(text: Str) -> Option<i8> { match canonical_decimal(&text.0) { Some(Some(n)) => i8::try_from(n).ok(), _ => None, } }

pub fn format_i16(a: i16) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i16(text: Str) -> Option<i16> { match canonical_decimal(&text.0) { Some(Some(n)) => i16::try_from(n).ok(), _ => None, } }

pub fn format_i32(a: i32) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i32(text: Str) -> Option<i32> { match canonical_decimal(&text.0) { Some(Some(n)) => i32::try_from(n).ok(), _ => None, } }

pub fn format_i64(a: i64) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i64(text: Str) -> Option<i64> { match canonical_decimal(&text.0) { Some(Some(n)) => i64::try_from(n).ok(), _ => None, } }

pub fn append_list<T: Clone>(p0: List<T>, p1: List<T>) -> List<T> {
    List::append(p0, p1)
}

pub fn length_list<T: Clone>(p0: List<T>) -> u64 {
    List::length(&p0)
}

pub fn index_list<T: Clone>(p0: List<T>, p1: u64) -> Option<T> {
    List::index(&p0, p1)
}

pub fn slice_list<T: Clone>(p0: List<T>, p1: u64, p2: u64) -> Option<List<T>> {
    List::slice(&p0, p1, p2)
}

pub fn append_bytes(p0: Bytes, p1: Bytes) -> Bytes {
    Bytes::append(p0, p1)
}

pub fn length_bytes(p0: Bytes) -> u64 {
    Bytes::length(&p0)
}

pub fn length_string(p0: Str) -> u64 {
    Str::length(&p0)
}

pub fn index_bytes(p0: Bytes, p1: u64) -> Option<u8> {
    Bytes::index(&p0, p1)
}

pub fn slice_bytes(p0: Bytes, p1: u64, p2: u64) -> Option<Bytes> {
    Bytes::slice(&p0, p1, p2)
}

pub fn utf8_encode(p0: Str) -> Bytes {
    Str::utf8_encode(&p0)
}

pub fn utf8_decode(p0: Bytes) -> Option<Str> {
    Bytes::utf8_decode(&p0)
}

pub fn compare_bytes(p0: Bytes, p1: Bytes) -> Ordering {
    Bytes::compare(&p0, &p1)
}

pub fn split_exact(p0: Str, p1: Str, p2: u32) -> Option<List<Str>> {
    Str::split_exact(&p0, &p1, p2)
}

pub fn join(p0: List<Str>, p1: Str) -> Str {
    Str::join(p0, &p1)
}

#[derive(Clone)]
pub enum Adt0 {
    C0(u32, u32, u32, u32),
}

#[derive(Clone)]
pub enum Adt1 {
    C0(u64, u64, u64),
}

#[derive(Clone)]
pub enum Adt2 {
    C0(Adt0, bool, bool),
}

#[derive(Clone)]
pub enum Adt3 {
    C0(u32, i16),
}

pub fn f0(v0: u64, v1: u64) -> Option<u64> {
    f1(v0, v1)
}

pub fn f1(v0: u64, v1: u64) -> Option<u64> {
    let v2: u64 = {
        let a3 = {
            let a1 = v0;
            let a2 = v1;
            fixed_u64::bit_xor(a1, a2)
        };
        let a4 = 9223372036854775808u64;
        fixed_u64::bit_and(a3, a4)
    };
    let v3: u64 = {
        let a5 = v0;
        let a6 = 4503599627370495u64;
        fixed_u64::bit_and(a5, a6)
    };
    let v4: u64 = {
        let a7 = v1;
        let a8 = 4503599627370495u64;
        fixed_u64::bit_and(a7, a8)
    };
    let m11 = {
        let a9 = v0;
        let a10 = 52u32;
        fixed_u64::shift_right(a9, a10)
    };
    match m11 {
        None => {
            None::<u64>
        }
        Some(v5) => {
            let m14 = {
                let a12 = v1;
                let a13 = 52u32;
                fixed_u64::shift_right(a12, a13)
            };
            match m14 {
                None => {
                    None::<u64>
                }
                Some(v6) => {
                    let v7: u64 = {
                        let a15 = v5;
                        let a16 = 2047u64;
                        fixed_u64::bit_and(a15, a16)
                    };
                    let v8: u64 = {
                        let a17 = v6;
                        let a18 = 2047u64;
                        fixed_u64::bit_and(a17, a18)
                    };
                    let a19 = v7;
                    let a20 = 2047u64;
                    if if equal(a19, a20) {
                        let a23 = {
                            let a21 = v3;
                            let a22 = 0u64;
                            equal(a21, a22)
                        };
                        bool_not(a23)
                    } else {
                        false
                    } {
                        Some({
                            let a24 = v0;
                            let a25 = 2251799813685248u64;
                            fixed_u64::bit_or(a24, a25)
                        })
                    } else {
                        let a26 = v8;
                        let a27 = 2047u64;
                        if if equal(a26, a27) {
                            let a30 = {
                                let a28 = v4;
                                let a29 = 0u64;
                                equal(a28, a29)
                            };
                            bool_not(a30)
                        } else {
                            false
                        } {
                            Some({
                                let a31 = v1;
                                let a32 = 2251799813685248u64;
                                fixed_u64::bit_or(a31, a32)
                            })
                        } else {
                            let a35 = {
                                let a33 = v0;
                                let a34 = 9223372036854775807u64;
                                fixed_u64::bit_and(a33, a34)
                            };
                            let a36 = 0u64;
                            if if if equal(a35, a36) {
                                let a39 = {
                                    let a37 = v1;
                                    let a38 = 9223372036854775807u64;
                                    fixed_u64::bit_and(a37, a38)
                                };
                                let a40 = 0u64;
                                equal(a39, a40)
                            } else {
                                false
                            } {
                                true
                            } else {
                                let a41 = v7;
                                let a42 = 2047u64;
                                if equal(a41, a42) {
                                    let a43 = v8;
                                    let a44 = 2047u64;
                                    equal(a43, a44)
                                } else {
                                    false
                                }
                            } {
                                Some(9221120237041090560u64)
                            } else {
                                let a45 = v7;
                                let a46 = 2047u64;
                                if if equal(a45, a46) {
                                    true
                                } else {
                                    let a49 = {
                                        let a47 = v1;
                                        let a48 = 9223372036854775807u64;
                                        fixed_u64::bit_and(a47, a48)
                                    };
                                    let a50 = 0u64;
                                    equal(a49, a50)
                                } {
                                    Some({
                                        let a51 = v2;
                                        let a52 = 9218868437227405312u64;
                                        fixed_u64::bit_or(a51, a52)
                                    })
                                } else {
                                    let a53 = v8;
                                    let a54 = 2047u64;
                                    if if equal(a53, a54) {
                                        true
                                    } else {
                                        let a57 = {
                                            let a55 = v0;
                                            let a56 = 9223372036854775807u64;
                                            fixed_u64::bit_and(a55, a56)
                                        };
                                        let a58 = 0u64;
                                        equal(a57, a58)
                                    } {
                                        Some(v2)
                                    } else {
                                        let v9: u64 = {
                                            let a59 = v7;
                                            let a60 = 0u64;
                                            if equal(a59, a60) {
                                                v3
                                            } else {
                                                let a61 = v3;
                                                let a62 = 4503599627370496u64;
                                                fixed_u64::bit_or(a61, a62)
                                            }
                                        };
                                        let v10: u64 = {
                                            let a63 = v8;
                                            let a64 = 0u64;
                                            if equal(a63, a64) {
                                                v4
                                            } else {
                                                let a65 = v4;
                                                let a66 = 4503599627370496u64;
                                                fixed_u64::bit_or(a65, a66)
                                            }
                                        };
                                        let m67 = f2(v7);
                                        match m67 {
                                            None => {
                                                None::<u64>
                                            }
                                            Some(v11) => {
                                                let m68 = f2(v8);
                                                match m68 {
                                                    None => {
                                                        None::<u64>
                                                    }
                                                    Some(v12) => {
                                                        let m71 = {
                                                            let a69 = v7;
                                                            let a70 = 0u64;
                                                            if equal(a69, a70) {
                                                                Some(1i16)
                                                            } else {
                                                                f3(v11)
                                                            }
                                                        };
                                                        match m71 {
                                                            None => {
                                                                None::<u64>
                                                            }
                                                            Some(v13) => {
                                                                let m74 = {
                                                                    let a72 = v8;
                                                                    let a73 = 0u64;
                                                                    if equal(a72, a73) {
                                                                        Some(1i16)
                                                                    } else {
                                                                        f3(v12)
                                                                    }
                                                                };
                                                                match m74 {
                                                                    None => {
                                                                        None::<u64>
                                                                    }
                                                                    Some(v14) => {
                                                                        let m75 = f4(v9);
                                                                        match m75 {
                                                                            None => {
                                                                                None::<u64>
                                                                            }
                                                                            Some(v15) => {
                                                                                let m76 = f4(v10);
                                                                                match m76 {
                                                                                    None => {
                                                                                        None::<u64>
                                                                                    }
                                                                                    Some(v16) => {
                                                                                        let m77 = f5(v15);
                                                                                        match m77 {
                                                                                            None => {
                                                                                                None::<u64>
                                                                                            }
                                                                                            Some(v17) => {
                                                                                                let m78 = f5(v16);
                                                                                                match m78 {
                                                                                                    None => {
                                                                                                        None::<u64>
                                                                                                    }
                                                                                                    Some(v18) => {
                                                                                                        let m79 = f6(53i16, v17);
                                                                                                        match m79 {
                                                                                                            None => {
                                                                                                                None::<u64>
                                                                                                            }
                                                                                                            Some(v19) => {
                                                                                                                let m80 = f6(53i16, v18);
                                                                                                                match m80 {
                                                                                                                    None => {
                                                                                                                        None::<u64>
                                                                                                                    }
                                                                                                                    Some(v20) => {
                                                                                                                        let m81 = f7(v19);
                                                                                                                        match m81 {
                                                                                                                            None => {
                                                                                                                                None::<u64>
                                                                                                                            }
                                                                                                                            Some(v21) => {
                                                                                                                                let m82 = f7(v20);
                                                                                                                                match m82 {
                                                                                                                                    None => {
                                                                                                                                        None::<u64>
                                                                                                                                    }
                                                                                                                                    Some(v22) => {
                                                                                                                                        let m85 = {
                                                                                                                                            let a83 = v9;
                                                                                                                                            let a84 = v21;
                                                                                                                                            fixed_u64::shift_left(a83, a84)
                                                                                                                                        };
                                                                                                                                        match m85 {
                                                                                                                                            None => {
                                                                                                                                                None::<u64>
                                                                                                                                            }
                                                                                                                                            Some(v23) => {
                                                                                                                                                let m88 = {
                                                                                                                                                    let a86 = v10;
                                                                                                                                                    let a87 = v22;
                                                                                                                                                    fixed_u64::shift_left(a86, a87)
                                                                                                                                                };
                                                                                                                                                match m88 {
                                                                                                                                                    None => {
                                                                                                                                                        None::<u64>
                                                                                                                                                    }
                                                                                                                                                    Some(v24) => {
                                                                                                                                                        let v25: bool = f8(v23, v24);
                                                                                                                                                        let m89 = f6(v13, v14);
                                                                                                                                                        match m89 {
                                                                                                                                                            None => {
                                                                                                                                                                None::<u64>
                                                                                                                                                            }
                                                                                                                                                            Some(v26) => {
                                                                                                                                                                let m90 = f6(v18, v17);
                                                                                                                                                                match m90 {
                                                                                                                                                                    None => {
                                                                                                                                                                        None::<u64>
                                                                                                                                                                    }
                                                                                                                                                                    Some(v27) => {
                                                                                                                                                                        let m91 = f6(v26, v27);
                                                                                                                                                                        match m91 {
                                                                                                                                                                            None => {
                                                                                                                                                                                None::<u64>
                                                                                                                                                                            }
                                                                                                                                                                            Some(v28) => {
                                                                                                                                                                                let m92 = if v25 {
                                                                                                                                                                                    f6(v28, 1i16)
                                                                                                                                                                                } else {
                                                                                                                                                                                    Some(v28)
                                                                                                                                                                                };
                                                                                                                                                                                match m92 {
                                                                                                                                                                                    None => {
                                                                                                                                                                                        None::<u64>
                                                                                                                                                                                    }
                                                                                                                                                                                    Some(v29) => {
                                                                                                                                                                                        let m93 = f6(-1020i16, v29);
                                                                                                                                                                                        match m93 {
                                                                                                                                                                                            None => {
                                                                                                                                                                                                None::<u64>
                                                                                                                                                                                            }
                                                                                                                                                                                            Some(v30) => {
                                                                                                                                                                                                let v31: i16 = if f9(2i16, v30) {
                                                                                                                                                                                                    v30
                                                                                                                                                                                                } else {
                                                                                                                                                                                                    2i16
                                                                                                                                                                                                };
                                                                                                                                                                                                let m96 = if v25 {
                                                                                                                                                                                                    let a94 = v23;
                                                                                                                                                                                                    let a95 = 1u32;
                                                                                                                                                                                                    fixed_u64::shift_left(a94, a95)
                                                                                                                                                                                                } else {
                                                                                                                                                                                                    Some(v23)
                                                                                                                                                                                                };
                                                                                                                                                                                                match m96 {
                                                                                                                                                                                                    None => {
                                                                                                                                                                                                        None::<u64>
                                                                                                                                                                                                    }
                                                                                                                                                                                                    Some(v32) => {
                                                                                                                                                                                                        let m97 = f10(v32, v24);
                                                                                                                                                                                                        match m97 {
                                                                                                                                                                                                            None => {
                                                                                                                                                                                                                None::<u64>
                                                                                                                                                                                                            }
                                                                                                                                                                                                            Some(v33) => {
                                                                                                                                                                                                                let m98 = f4(v33);
                                                                                                                                                                                                                match m98 {
                                                                                                                                                                                                                    None => {
                                                                                                                                                                                                                        None::<u64>
                                                                                                                                                                                                                    }
                                                                                                                                                                                                                    Some(v34) => {
                                                                                                                                                                                                                        let m99 = f11(v34, v31);
                                                                                                                                                                                                                        match m99 {
                                                                                                                                                                                                                            None => {
                                                                                                                                                                                                                                None::<u64>
                                                                                                                                                                                                                            }
                                                                                                                                                                                                                            Some(v35) => {
                                                                                                                                                                                                                                f12(v2, v35, v29)
                                                                                                                                                                                                                            }
                                                                                                                                                                                                                        }
                                                                                                                                                                                                                    }
                                                                                                                                                                                                                }
                                                                                                                                                                                                            }
                                                                                                                                                                                                        }
                                                                                                                                                                                                    }
                                                                                                                                                                                                }
                                                                                                                                                                                            }
                                                                                                                                                                                        }
                                                                                                                                                                                    }
                                                                                                                                                                                }
                                                                                                                                                                            }
                                                                                                                                                                        }
                                                                                                                                                                    }
                                                                                                                                                                }
                                                                                                                                                            }
                                                                                                                                                        }
                                                                                                                                                    }
                                                                                                                                                }
                                                                                                                                            }
                                                                                                                                        }
                                                                                                                                    }
                                                                                                                                }
                                                                                                                            }
                                                                                                                        }
                                                                                                                    }
                                                                                                                }
                                                                                                            }
                                                                                                        }
                                                                                                    }
                                                                                                }
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

pub fn f2(v0: u64) -> Option<u16> {
    let a100 = v0;
    fixed_u16::convert(i128::from(a100))
}

pub fn f3(v0: u16) -> Option<i16> {
    let a101 = v0;
    fixed_i16::convert(i128::from(a101))
}

pub fn f4(v0: u64) -> Option<Adt0> {
    let m104 = f13({
        let a102 = v0;
        let a103 = 4294967295u64;
        fixed_u64::bit_and(a102, a103)
    });
    match m104 {
        None => {
            None::<Adt0>
        }
        Some(v1) => {
            let m107 = {
                let a105 = v0;
                let a106 = 32u32;
                fixed_u64::shift_right(a105, a106)
            };
            match m107 {
                None => {
                    None::<Adt0>
                }
                Some(v2) => {
                    let m108 = f13(v2);
                    match m108 {
                        None => {
                            None::<Adt0>
                        }
                        Some(v3) => {
                            Some(Adt0::C0(v1, v3, 0u32, 0u32))
                        }
                    }
                }
            }
        }
    }
}

pub fn f5(v0: Adt0) -> Option<i16> {
    let a110 = match v0.clone() {
        Adt0::C0(_, _, _, h109) => {
            h109
        }
    };
    let a111 = 0u32;
    if equal(a110, a111) {
        let a113 = match v0.clone() {
            Adt0::C0(_, _, h112, _) => {
                h112
            }
        };
        let a114 = 0u32;
        if equal(a113, a114) {
            let a116 = match v0.clone() {
                Adt0::C0(_, h115, _, _) => {
                    h115
                }
            };
            let a117 = 0u32;
            if equal(a116, a117) {
                f14(match v0 {
                    Adt0::C0(h118, _, _, _) => {
                        h118
                    }
                })
            } else {
                let m120 = f14(match v0 {
                    Adt0::C0(_, h119, _, _) => {
                        h119
                    }
                });
                match m120 {
                    None => {
                        None::<i16>
                    }
                    Some(v1) => {
                        f15(v1, 32i16)
                    }
                }
            }
        } else {
            let m122 = f14(match v0 {
                Adt0::C0(_, _, h121, _) => {
                    h121
                }
            });
            match m122 {
                None => {
                    None::<i16>
                }
                Some(v2) => {
                    f15(v2, 64i16)
                }
            }
        }
    } else {
        let m124 = f14(match v0 {
            Adt0::C0(_, _, _, h123) => {
                h123
            }
        });
        match m124 {
            None => {
                None::<i16>
            }
            Some(v3) => {
                f15(v3, 96i16)
            }
        }
    }
}

pub fn f6(v0: i16, v1: i16) -> Option<i16> {
    let a125 = v0;
    let a126 = v1;
    fixed_i16::checked_sub(a125, a126)
}

pub fn f7(v0: i16) -> Option<u32> {
    let a127 = v0;
    fixed_u32::convert(i128::from(a127))
}

pub fn f8(v0: u64, v1: u64) -> bool {
    let m130 = {
        let a128 = v0;
        let a129 = v1;
        fixed_u64::checked_sub(a128, a129)
    };
    match m130 {
        None => {
            true
        }
        Some(_) => {
            false
        }
    }
}

pub fn f9(v0: i16, v1: i16) -> bool {
    let m131 = f6(v0, v1);
    match m131 {
        None => {
            f16(v0)
        }
        Some(v2) => {
            f16(v2)
        }
    }
}

pub fn f10(v0: u64, v1: u64) -> Option<u64> {
    let m134 = {
        let a132 = v0;
        let a133 = v1;
        fixed_u64::checked_sub(a132, a133)
    };
    match m134 {
        None => {
            None::<u64>
        }
        Some(v2) => {
            let m135 = f17(f18(f19(f20(Some(Adt1::C0(1u64, v2, v1))))));
            match m135 {
                None => {
                    None::<u64>
                }
                Some(v3) => {
                    Some({
                        let a140 = match v3.clone() {
                            Adt1::C0(h136, _, _) => {
                                h136
                            }
                        };
                        let a141 = {
                            let a138 = match v3 {
                                Adt1::C0(_, h137, _) => {
                                    h137
                                }
                            };
                            let a139 = 0u64;
                            if equal(a138, a139) {
                                0u64
                            } else {
                                1u64
                            }
                        };
                        fixed_u64::bit_or(a140, a141)
                    })
                }
            }
        }
    }
}

pub fn f11(v0: Adt0, v1: i16) -> Option<u64> {
    if f16(v1) {
        let m142 = f21(v1);
        match m142 {
            None => {
                None::<u64>
            }
            Some(v2) => {
                let m143 = f7(v2);
                match m143 {
                    None => {
                        None::<u64>
                    }
                    Some(v3) => {
                        let m144 = f22(v0);
                        match m144 {
                            None => {
                                None::<u64>
                            }
                            Some(v4) => {
                                let a145 = v4;
                                let a146 = v3;
                                fixed_u64::shift_left(a145, a146)
                            }
                        }
                    }
                }
            }
        }
    } else {
        if f9(128i16, v1) {
            Some(0u64)
        } else {
            let m147 = f23(v1);
            match m147 {
                None => {
                    None::<u64>
                }
                Some(v5) => {
                    let m189 = {
                        let m148 = Some(Adt2::C0(v0, false, false));
                        match m148 {
                            None => {
                                None::<Adt2>
                            }
                            Some(v6) => {
                                let m153 = {
                                    let a151 = {
                                        let a149 = v5;
                                        let a150 = 1u8;
                                        fixed_u8::bit_and(a149, a150)
                                    };
                                    let a152 = 0u8;
                                    if equal(a151, a152) {
                                        Some(v6)
                                    } else {
                                        f24(Some(v6))
                                    }
                                };
                                match m153 {
                                    None => {
                                        None::<Adt2>
                                    }
                                    Some(v7) => {
                                        let m158 = {
                                            let a156 = {
                                                let a154 = v5;
                                                let a155 = 2u8;
                                                fixed_u8::bit_and(a154, a155)
                                            };
                                            let a157 = 0u8;
                                            if equal(a156, a157) {
                                                Some(v7)
                                            } else {
                                                f25(Some(v7))
                                            }
                                        };
                                        match m158 {
                                            None => {
                                                None::<Adt2>
                                            }
                                            Some(v8) => {
                                                let m163 = {
                                                    let a161 = {
                                                        let a159 = v5;
                                                        let a160 = 4u8;
                                                        fixed_u8::bit_and(a159, a160)
                                                    };
                                                    let a162 = 0u8;
                                                    if equal(a161, a162) {
                                                        Some(v8)
                                                    } else {
                                                        f26(Some(v8))
                                                    }
                                                };
                                                match m163 {
                                                    None => {
                                                        None::<Adt2>
                                                    }
                                                    Some(v9) => {
                                                        let m168 = {
                                                            let a166 = {
                                                                let a164 = v5;
                                                                let a165 = 8u8;
                                                                fixed_u8::bit_and(a164, a165)
                                                            };
                                                            let a167 = 0u8;
                                                            if equal(a166, a167) {
                                                                Some(v9)
                                                            } else {
                                                                f27(Some(v9))
                                                            }
                                                        };
                                                        match m168 {
                                                            None => {
                                                                None::<Adt2>
                                                            }
                                                            Some(v10) => {
                                                                let m173 = {
                                                                    let a171 = {
                                                                        let a169 = v5;
                                                                        let a170 = 16u8;
                                                                        fixed_u8::bit_and(a169, a170)
                                                                    };
                                                                    let a172 = 0u8;
                                                                    if equal(a171, a172) {
                                                                        Some(v10)
                                                                    } else {
                                                                        f28(Some(v10))
                                                                    }
                                                                };
                                                                match m173 {
                                                                    None => {
                                                                        None::<Adt2>
                                                                    }
                                                                    Some(v11) => {
                                                                        let m178 = {
                                                                            let a176 = {
                                                                                let a174 = v5;
                                                                                let a175 = 32u8;
                                                                                fixed_u8::bit_and(a174, a175)
                                                                            };
                                                                            let a177 = 0u8;
                                                                            if equal(a176, a177) {
                                                                                Some(v11)
                                                                            } else {
                                                                                f29(Some(v11))
                                                                            }
                                                                        };
                                                                        match m178 {
                                                                            None => {
                                                                                None::<Adt2>
                                                                            }
                                                                            Some(v12) => {
                                                                                let m183 = {
                                                                                    let a181 = {
                                                                                        let a179 = v5;
                                                                                        let a180 = 64u8;
                                                                                        fixed_u8::bit_and(a179, a180)
                                                                                    };
                                                                                    let a182 = 0u8;
                                                                                    if equal(a181, a182) {
                                                                                        Some(v12)
                                                                                    } else {
                                                                                        f30(Some(v12))
                                                                                    }
                                                                                };
                                                                                match m183 {
                                                                                    None => {
                                                                                        None::<Adt2>
                                                                                    }
                                                                                    Some(v13) => {
                                                                                        let m188 = {
                                                                                            let a186 = {
                                                                                                let a184 = v5;
                                                                                                let a185 = 128u8;
                                                                                                fixed_u8::bit_and(a184, a185)
                                                                                            };
                                                                                            let a187 = 0u8;
                                                                                            if equal(a186, a187) {
                                                                                                Some(v13)
                                                                                            } else {
                                                                                                f31(Some(v13))
                                                                                            }
                                                                                        };
                                                                                        match m188 {
                                                                                            None => {
                                                                                                None::<Adt2>
                                                                                            }
                                                                                            Some(v14) => {
                                                                                                Some(v14)
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    };
                    match m189 {
                        None => {
                            None::<u64>
                        }
                        Some(v15) => {
                            let m191 = f22(match v15.clone() {
                                Adt2::C0(h190, _, _) => {
                                    h190
                                }
                            });
                            match m191 {
                                None => {
                                    None::<u64>
                                }
                                Some(v16) => {
                                    if if match v15.clone() {
                                        Adt2::C0(_, h192, _) => {
                                            h192
                                        }
                                    } {
                                        if match v15 {
                                            Adt2::C0(_, _, h193) => {
                                                h193
                                            }
                                        } {
                                            true
                                        } else {
                                            let a196 = {
                                                let a194 = v16;
                                                let a195 = 1u64;
                                                fixed_u64::bit_and(a194, a195)
                                            };
                                            let a197 = 1u64;
                                            equal(a196, a197)
                                        }
                                    } else {
                                        false
                                    } {
                                        let a198 = v16;
                                        let a199 = 1u64;
                                        fixed_u64::checked_add(a198, a199)
                                    } else {
                                        Some(v16)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

pub fn f12(v0: u64, v1: u64, v2: i16) -> Option<u64> {
    let v3: bool = {
        let a200 = v1;
        let a201 = 9007199254740992u64;
        equal(a200, a201)
    };
    let m202 = if v3 {
        f15(v2, 1i16)
    } else {
        Some(v2)
    };
    match m202 {
        None => {
            None::<u64>
        }
        Some(v4) => {
            let m203 = if f9(v4, -1022i16) {
                Some(if f8(v1, 4503599627370496u64) {
                    0i16
                } else {
                    1i16
                })
            } else {
                f15(v4, 1023i16)
            };
            match m203 {
                None => {
                    None::<u64>
                }
                Some(v5) => {
                    if f9(2046i16, v5) {
                        Some({
                            let a204 = v0;
                            let a205 = 9218868437227405312u64;
                            fixed_u64::bit_or(a204, a205)
                        })
                    } else {
                        let m208 = if v3 {
                            let a206 = v1;
                            let a207 = 1u32;
                            fixed_u64::shift_right(a206, a207)
                        } else {
                            Some(v1)
                        };
                        match m208 {
                            None => {
                                None::<u64>
                            }
                            Some(v6) => {
                                let m209 = f32(v5);
                                match m209 {
                                    None => {
                                        None::<u64>
                                    }
                                    Some(v7) => {
                                        let m212 = {
                                            let a210 = v7;
                                            let a211 = 52u32;
                                            fixed_u64::shift_left(a210, a211)
                                        };
                                        match m212 {
                                            None => {
                                                None::<u64>
                                            }
                                            Some(v8) => {
                                                Some({
                                                    let a217 = v0;
                                                    let a218 = {
                                                        let a215 = v8;
                                                        let a216 = {
                                                            let a213 = v6;
                                                            let a214 = 4503599627370495u64;
                                                            fixed_u64::bit_and(a213, a214)
                                                        };
                                                        fixed_u64::bit_or(a215, a216)
                                                    };
                                                    fixed_u64::bit_or(a217, a218)
                                                })
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

pub fn f13(v0: u64) -> Option<u32> {
    let a219 = v0;
    fixed_u32::convert(i128::from(a219))
}

pub fn f14(v0: u32) -> Option<i16> {
    let m220 = f33(Some(Adt3::C0(v0, 0i16)));
    match m220 {
        None => {
            None::<i16>
        }
        Some(v1) => {
            Some(match v1 {
                Adt3::C0(_, h221) => {
                    h221
                }
            })
        }
    }
}

pub fn f15(v0: i16, v1: i16) -> Option<i16> {
    let a222 = v0;
    let a223 = v1;
    fixed_i16::checked_add(a222, a223)
}

pub fn f16(v0: i16) -> bool {
    let m224 = f34(v0);
    match m224 {
        None => {
            true
        }
        Some(_) => {
            false
        }
    }
}

pub fn f17(v0: Option<Adt1>) -> Option<Adt1> {
    f18(f18(v0))
}

pub fn f18(v0: Option<Adt1>) -> Option<Adt1> {
    f35(f35(v0))
}

pub fn f19(v0: Option<Adt1>) -> Option<Adt1> {
    f20(f20(v0))
}

pub fn f20(v0: Option<Adt1>) -> Option<Adt1> {
    f36(f36(v0))
}

pub fn f21(v0: i16) -> Option<i16> {
    let a225 = v0;
    checked_neg_i16(a225)
}

pub fn f22(v0: Adt0) -> Option<u64> {
    let a227 = match v0.clone() {
        Adt0::C0(_, _, h226, _) => {
            h226
        }
    };
    let a228 = 0u32;
    if if equal(a227, a228) {
        let a230 = match v0.clone() {
            Adt0::C0(_, _, _, h229) => {
                h229
            }
        };
        let a231 = 0u32;
        equal(a230, a231)
    } else {
        false
    } {
        let m233 = f37(match v0.clone() {
            Adt0::C0(h232, _, _, _) => {
                h232
            }
        });
        match m233 {
            None => {
                None::<u64>
            }
            Some(v1) => {
                let m235 = f37(match v0 {
                    Adt0::C0(_, h234, _, _) => {
                        h234
                    }
                });
                match m235 {
                    None => {
                        None::<u64>
                    }
                    Some(v2) => {
                        let m238 = {
                            let a236 = v2;
                            let a237 = 32u32;
                            fixed_u64::shift_left(a236, a237)
                        };
                        match m238 {
                            None => {
                                None::<u64>
                            }
                            Some(v3) => {
                                Some({
                                    let a239 = v1;
                                    let a240 = v3;
                                    fixed_u64::bit_or(a239, a240)
                                })
                            }
                        }
                    }
                }
            }
        }
    } else {
        None::<u64>
    }
}

pub fn f23(v0: i16) -> Option<u8> {
    let a241 = v0;
    fixed_u8::convert(i128::from(a241))
}

pub fn f24(v0: Option<Adt2>) -> Option<Adt2> {
    let m242 = v0;
    match m242 {
        None => {
            None::<Adt2>
        }
        Some(v1) => {
            let m244 = f38(match v1.clone() {
                Adt2::C0(h243, _, _) => {
                    h243
                }
            });
            match m244 {
                None => {
                    None::<Adt2>
                }
                Some(v2) => {
                    Some(Adt2::C0(v2, {
                        let a250 = {
                            let a248 = {
                                let m247 = match v1.clone() {
                                    Adt2::C0(h246, _, _) => {
                                        h246
                                    }
                                };
                                match m247 {
                                    Adt0::C0(h245, _, _, _) => {
                                        h245
                                    }
                                }
                            };
                            let a249 = 1u32;
                            fixed_u32::bit_and(a248, a249)
                        };
                        let a251 = 1u32;
                        equal(a250, a251)
                    }, if match v1.clone() {
                        Adt2::C0(_, _, h252) => {
                            h252
                        }
                    } {
                        true
                    } else {
                        match v1 {
                            Adt2::C0(_, h253, _) => {
                                h253
                            }
                        }
                    }))
                }
            }
        }
    }
}

pub fn f25(v0: Option<Adt2>) -> Option<Adt2> {
    f24(f24(v0))
}

pub fn f26(v0: Option<Adt2>) -> Option<Adt2> {
    f25(f25(v0))
}

pub fn f27(v0: Option<Adt2>) -> Option<Adt2> {
    f26(f26(v0))
}

pub fn f28(v0: Option<Adt2>) -> Option<Adt2> {
    f27(f27(v0))
}

pub fn f29(v0: Option<Adt2>) -> Option<Adt2> {
    f28(f28(v0))
}

pub fn f30(v0: Option<Adt2>) -> Option<Adt2> {
    f29(f29(v0))
}

pub fn f31(v0: Option<Adt2>) -> Option<Adt2> {
    f30(f30(v0))
}

pub fn f32(v0: i16) -> Option<u64> {
    let a254 = v0;
    fixed_u64::convert(i128::from(a254))
}

pub fn f33(v0: Option<Adt3>) -> Option<Adt3> {
    f39(f39(v0))
}

pub fn f34(v0: i16) -> Option<u16> {
    let a255 = v0;
    fixed_u16::convert(i128::from(a255))
}

pub fn f35(v0: Option<Adt1>) -> Option<Adt1> {
    f19(f19(v0))
}

pub fn f36(v0: Option<Adt1>) -> Option<Adt1> {
    let m256 = v0;
    match m256 {
        None => {
            None::<Adt1>
        }
        Some(v1) => {
            let m260 = {
                let a258 = match v1.clone() {
                    Adt1::C0(_, h257, _) => {
                        h257
                    }
                };
                let a259 = 2u64;
                fixed_u64::checked_mul(a258, a259)
            };
            match m260 {
                None => {
                    None::<Adt1>
                }
                Some(v2) => {
                    let m264 = {
                        let a262 = match v1.clone() {
                            Adt1::C0(h261, _, _) => {
                                h261
                            }
                        };
                        let a263 = 2u64;
                        fixed_u64::checked_mul(a262, a263)
                    };
                    match m264 {
                        None => {
                            None::<Adt1>
                        }
                        Some(v3) => {
                            let m268 = {
                                let a266 = v2;
                                let a267 = match v1.clone() {
                                    Adt1::C0(_, _, h265) => {
                                        h265
                                    }
                                };
                                fixed_u64::checked_sub(a266, a267)
                            };
                            match m268 {
                                None => {
                                    Some(Adt1::C0(v3, v2, match v1 {
                                        Adt1::C0(_, _, h273) => {
                                            h273
                                        }
                                    }))
                                }
                                Some(v4) => {
                                    let m271 = {
                                        let a269 = v3;
                                        let a270 = 1u64;
                                        fixed_u64::checked_add(a269, a270)
                                    };
                                    match m271 {
                                        None => {
                                            None::<Adt1>
                                        }
                                        Some(v5) => {
                                            Some(Adt1::C0(v5, v4, match v1 {
                                                Adt1::C0(_, _, h272) => {
                                                    h272
                                                }
                                            }))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

pub fn f37(v0: u32) -> Option<u64> {
    let a274 = v0;
    fixed_u64::convert(i128::from(a274))
}

pub fn f38(v0: Adt0) -> Option<Adt0> {
    let m278 = {
        let a276 = match v0.clone() {
            Adt0::C0(h275, _, _, _) => {
                h275
            }
        };
        let a277 = 1u32;
        fixed_u32::shift_right(a276, a277)
    };
    match m278 {
        None => {
            None::<Adt0>
        }
        Some(v1) => {
            let m282 = {
                let a280 = match v0.clone() {
                    Adt0::C0(_, h279, _, _) => {
                        h279
                    }
                };
                let a281 = 1u32;
                fixed_u32::shift_right(a280, a281)
            };
            match m282 {
                None => {
                    None::<Adt0>
                }
                Some(v2) => {
                    let m286 = {
                        let a284 = match v0.clone() {
                            Adt0::C0(_, _, h283, _) => {
                                h283
                            }
                        };
                        let a285 = 1u32;
                        fixed_u32::shift_right(a284, a285)
                    };
                    match m286 {
                        None => {
                            None::<Adt0>
                        }
                        Some(v3) => {
                            let m290 = {
                                let a288 = match v0.clone() {
                                    Adt0::C0(_, _, _, h287) => {
                                        h287
                                    }
                                };
                                let a289 = 1u32;
                                fixed_u32::shift_right(a288, a289)
                            };
                            match m290 {
                                None => {
                                    None::<Adt0>
                                }
                                Some(v4) => {
                                    let m296 = {
                                        let a294 = {
                                            let a292 = match v0.clone() {
                                                Adt0::C0(_, h291, _, _) => {
                                                    h291
                                                }
                                            };
                                            let a293 = 1u32;
                                            fixed_u32::bit_and(a292, a293)
                                        };
                                        let a295 = 31u32;
                                        fixed_u32::shift_left(a294, a295)
                                    };
                                    match m296 {
                                        None => {
                                            None::<Adt0>
                                        }
                                        Some(v5) => {
                                            let m302 = {
                                                let a300 = {
                                                    let a298 = match v0.clone() {
                                                        Adt0::C0(_, _, h297, _) => {
                                                            h297
                                                        }
                                                    };
                                                    let a299 = 1u32;
                                                    fixed_u32::bit_and(a298, a299)
                                                };
                                                let a301 = 31u32;
                                                fixed_u32::shift_left(a300, a301)
                                            };
                                            match m302 {
                                                None => {
                                                    None::<Adt0>
                                                }
                                                Some(v6) => {
                                                    let m308 = {
                                                        let a306 = {
                                                            let a304 = match v0 {
                                                                Adt0::C0(_, _, _, h303) => {
                                                                    h303
                                                                }
                                                            };
                                                            let a305 = 1u32;
                                                            fixed_u32::bit_and(a304, a305)
                                                        };
                                                        let a307 = 31u32;
                                                        fixed_u32::shift_left(a306, a307)
                                                    };
                                                    match m308 {
                                                        None => {
                                                            None::<Adt0>
                                                        }
                                                        Some(v7) => {
                                                            Some(Adt0::C0({
                                                                let a309 = v1;
                                                                let a310 = v5;
                                                                fixed_u32::bit_or(a309, a310)
                                                            }, {
                                                                let a311 = v2;
                                                                let a312 = v6;
                                                                fixed_u32::bit_or(a311, a312)
                                                            }, {
                                                                let a313 = v3;
                                                                let a314 = v7;
                                                                fixed_u32::bit_or(a313, a314)
                                                            }, v4))
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

pub fn f39(v0: Option<Adt3>) -> Option<Adt3> {
    f40(f40(v0))
}

pub fn f40(v0: Option<Adt3>) -> Option<Adt3> {
    f41(f41(v0))
}

pub fn f41(v0: Option<Adt3>) -> Option<Adt3> {
    f42(f42(v0))
}

pub fn f42(v0: Option<Adt3>) -> Option<Adt3> {
    f43(f43(v0))
}

pub fn f43(v0: Option<Adt3>) -> Option<Adt3> {
    let m315 = v0;
    match m315 {
        None => {
            None::<Adt3>
        }
        Some(v1) => {
            let m319 = {
                let a317 = match v1.clone() {
                    Adt3::C0(h316, _) => {
                        h316
                    }
                };
                let a318 = 1u32;
                fixed_u32::shift_right(a317, a318)
            };
            match m319 {
                None => {
                    None::<Adt3>
                }
                Some(v2) => {
                    let a321 = match v1.clone() {
                        Adt3::C0(h320, _) => {
                            h320
                        }
                    };
                    let a322 = 0u32;
                    if equal(a321, a322) {
                        Some(Adt3::C0(v2, match v1 {
                            Adt3::C0(_, h323) => {
                                h323
                            }
                        }))
                    } else {
                        let m325 = f15(match v1 {
                            Adt3::C0(_, h324) => {
                                h324
                            }
                        }, 1i16);
                        match m325 {
                            None => {
                                None::<Adt3>
                            }
                            Some(v3) => {
                                Some(Adt3::C0(v2, v3))
                            }
                        }
                    }
                }
            }
        }
    }
}

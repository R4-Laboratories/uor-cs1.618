module
import BoundedNumeric.Float
#print axioms BoundedNumeric.Float.bits32
#print axioms BoundedNumeric.Float.bits64
#print axioms BoundedNumeric.Float.div32
#print axioms BoundedNumeric.Float.div64
#print axioms BoundedNumeric.Float.divBits32
#print axioms BoundedNumeric.Float.divBits64
#print axioms BoundedNumeric.Float.mul32
#print axioms BoundedNumeric.Float.mul64
#print axioms BoundedNumeric.Float.pack32
#print axioms BoundedNumeric.Float.pack64

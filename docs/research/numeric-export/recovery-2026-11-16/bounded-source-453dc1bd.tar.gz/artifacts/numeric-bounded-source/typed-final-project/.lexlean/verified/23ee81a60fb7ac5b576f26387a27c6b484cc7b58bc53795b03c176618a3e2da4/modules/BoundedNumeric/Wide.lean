module
public import Init
public import LexLeanRuntime.Portable
set_option autoImplicit false
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000000
set_option linter.constructorNameAsVariable false
namespace BoundedNumeric.Wide

@[expose] public def convertUInt64ToUInt8 (value : UInt64) : Option (UInt8) := (LexLeanRuntime.checkedConvert (value) : Option (UInt8))

@[expose] public def convertUInt64ToUInt16 (value : UInt64) : Option (UInt16) := (LexLeanRuntime.checkedConvert (value) : Option (UInt16))

@[expose] public def convertUInt64ToUInt32 (value : UInt64) : Option (UInt32) := (LexLeanRuntime.checkedConvert (value) : Option (UInt32))

@[expose] public def convertUInt32ToUInt64 (value : UInt32) : Option (UInt64) := (LexLeanRuntime.checkedConvert (value) : Option (UInt64))

@[expose] public def convertUInt8ToInt16 (value : UInt8) : Option (Int16) := (LexLeanRuntime.checkedConvert (value) : Option (Int16))

@[expose] public def convertUInt16ToInt16 (value : UInt16) : Option (Int16) := (LexLeanRuntime.checkedConvert (value) : Option (Int16))

@[expose] public def convertInt16ToUInt8 (value : Int16) : Option (UInt8) := (LexLeanRuntime.checkedConvert (value) : Option (UInt8))

@[expose] public def convertInt16ToUInt16 (value : Int16) : Option (UInt16) := (LexLeanRuntime.checkedConvert (value) : Option (UInt16))

@[expose] public def convertInt16ToUInt32 (value : Int16) : Option (UInt32) := (LexLeanRuntime.checkedConvert (value) : Option (UInt32))

@[expose] public def convertInt16ToUInt64 (value : Int16) : Option (UInt64) := (LexLeanRuntime.checkedConvert (value) : Option (UInt64))

@[expose] public def int16Add (a : Int16) (b : Int16) : Option (Int16) := (LexLeanRuntime.checkedAdd (a) (b) : Option (Int16))

@[expose] public def int16Subtract (a : Int16) (b : Int16) : Option (Int16) := (LexLeanRuntime.checkedSubtract (a) (b) : Option (Int16))

@[expose] public def int16Negate (a : Int16) : Option (Int16) := (LexLeanRuntime.checkedNegate (a) : Option (Int16))

public structure Limbs where
  l0 : UInt32
  l1 : UInt32
  l2 : UInt32
  l3 : UInt32

@[expose] public def multiply (a : UInt64) (b : UInt64) : Option (Limbs) := (match Option.some ((LexLeanRuntime.bitAnd (a) ((4294967295 : UInt64)) : UInt64)) with | Option.some a0 => (match (LexLeanRuntime.shiftRight (a) ((32 : UInt32)) : Option (UInt64)) with | Option.some a1 => (match Option.some ((LexLeanRuntime.bitAnd (b) ((4294967295 : UInt64)) : UInt64)) with | Option.some b0 => (match (LexLeanRuntime.shiftRight (b) ((32 : UInt32)) : Option (UInt64)) with | Option.some b1 => (match (LexLeanRuntime.checkedMultiply (a0) (b0) : Option (UInt64)) with | Option.some t0 => (match (LexLeanRuntime.shiftRight (t0) ((32 : UInt32)) : Option (UInt64)) with | Option.some c0 => (match (LexLeanRuntime.checkedMultiply (a1) (b0) : Option (UInt64)) with | Option.some m1 => (match (LexLeanRuntime.checkedAdd (m1) (c0) : Option (UInt64)) with | Option.some t1 => (match (LexLeanRuntime.checkedMultiply (a0) (b1) : Option (UInt64)) with | Option.some m2 => (match (LexLeanRuntime.checkedAdd (m2) ((LexLeanRuntime.bitAnd (t1) ((4294967295 : UInt64)) : UInt64)) : Option (UInt64)) with | Option.some t2 => (match (LexLeanRuntime.shiftRight (t1) ((32 : UInt32)) : Option (UInt64)) with | Option.some c1 => (match (LexLeanRuntime.shiftRight (t2) ((32 : UInt32)) : Option (UInt64)) with | Option.some c2 => (match (LexLeanRuntime.checkedMultiply (a1) (b1) : Option (UInt64)) with | Option.some m3 => (match (LexLeanRuntime.checkedAdd (m3) (c1) : Option (UInt64)) with | Option.some u3 => (match (LexLeanRuntime.checkedAdd (u3) (c2) : Option (UInt64)) with | Option.some t3 => (match (LexLeanRuntime.shiftRight (t3) ((32 : UInt32)) : Option (UInt64)) with | Option.some top => (match convertUInt64ToUInt32 ((LexLeanRuntime.bitAnd (t0) ((4294967295 : UInt64)) : UInt64)) with | Option.some r0 => (match convertUInt64ToUInt32 ((LexLeanRuntime.bitAnd (t2) ((4294967295 : UInt64)) : UInt64)) with | Option.some r1 => (match convertUInt64ToUInt32 ((LexLeanRuntime.bitAnd (t3) ((4294967295 : UInt64)) : UInt64)) with | Option.some r2 => (match convertUInt64ToUInt32 ((LexLeanRuntime.bitAnd (top) ((4294967295 : UInt64)) : UInt64)) with | Option.some r3 => Option.some (({ l0 := r0, l1 := r1, l2 := r2, l3 := r3 } : Limbs)) | Option.none => Option.none) | Option.none => Option.none) | Option.none => Option.none) | Option.none => Option.none) | Option.none => Option.none) | Option.none => Option.none) | Option.none => Option.none) | Option.none => Option.none) | Option.none => Option.none) | Option.none => Option.none) | Option.none => Option.none) | Option.none => Option.none) | Option.none => Option.none) | Option.none => Option.none) | Option.none => Option.none) | Option.none => Option.none) | Option.none => Option.none) | Option.none => Option.none) | Option.none => Option.none) | Option.none => Option.none)

@[expose] public def right (w : Limbs) : Option (Limbs) := (match (LexLeanRuntime.shiftRight ((w).l0) ((1 : UInt32)) : Option (UInt32)) with | Option.some q0 => (match (LexLeanRuntime.shiftRight ((w).l1) ((1 : UInt32)) : Option (UInt32)) with | Option.some q1 => (match (LexLeanRuntime.shiftRight ((w).l2) ((1 : UInt32)) : Option (UInt32)) with | Option.some q2 => (match (LexLeanRuntime.shiftRight ((w).l3) ((1 : UInt32)) : Option (UInt32)) with | Option.some q3 => (match (LexLeanRuntime.shiftLeft ((LexLeanRuntime.bitAnd ((w).l1) ((1 : UInt32)) : UInt32)) ((31 : UInt32)) : Option (UInt32)) with | Option.some c0 => (match (LexLeanRuntime.shiftLeft ((LexLeanRuntime.bitAnd ((w).l2) ((1 : UInt32)) : UInt32)) ((31 : UInt32)) : Option (UInt32)) with | Option.some c1 => (match (LexLeanRuntime.shiftLeft ((LexLeanRuntime.bitAnd ((w).l3) ((1 : UInt32)) : UInt32)) ((31 : UInt32)) : Option (UInt32)) with | Option.some c2 => Option.some (({ l0 := (LexLeanRuntime.bitOr (q0) (c0) : UInt32), l1 := (LexLeanRuntime.bitOr (q1) (c1) : UInt32), l2 := (LexLeanRuntime.bitOr (q2) (c2) : UInt32), l3 := q3 } : Limbs)) | Option.none => Option.none) | Option.none => Option.none) | Option.none => Option.none) | Option.none => Option.none) | Option.none => Option.none) | Option.none => Option.none) | Option.none => Option.none)

@[expose] public def low64 (w : Limbs) : Option (UInt64) := (if ((LexLeanRuntime.equal ((w).l2) ((0 : UInt32)) : Bool) && (LexLeanRuntime.equal ((w).l3) ((0 : UInt32)) : Bool)) then (match convertUInt32ToUInt64 ((w).l0) with | Option.some lo => (match convertUInt32ToUInt64 ((w).l1) with | Option.some hi => (match (LexLeanRuntime.shiftLeft (hi) ((32 : UInt32)) : Option (UInt64)) with | Option.some sh => Option.some ((LexLeanRuntime.bitOr (lo) (sh) : UInt64)) | Option.none => Option.none) | Option.none => Option.none) | Option.none => Option.none) else Option.none)

@[expose] public def unsignedLess (a : UInt64) (b : UInt64) : Bool := (match (LexLeanRuntime.checkedSubtract (a) (b) : Option (UInt64)) with | Option.some _ => false | Option.none => true)

@[expose] public def negative (a : Int16) : Bool := (match convertInt16ToUInt16 (a) with | Option.some _ => false | Option.none => true)

@[expose] public def signedLess (a : Int16) (b : Int16) : Bool := (match int16Subtract (a) (b) with | Option.some difference => negative (difference) | Option.none => negative (a))

public structure LengthState where
  word : UInt32
  count : Int16

@[expose] public def lengthStep (state : Option (LengthState)) : Option (LengthState) := (match state with | Option.some st => (match (LexLeanRuntime.shiftRight ((st).word) ((1 : UInt32)) : Option (UInt32)) with | Option.some next => (if (LexLeanRuntime.equal ((st).word) ((0 : UInt32)) : Bool) then Option.some (({ word := next, count := (st).count } : LengthState)) else (match int16Add ((st).count) ((1 : Int16)) with | Option.some count => Option.some (({ word := next, count := count } : LengthState)) | Option.none => Option.none)) | Option.none => Option.none) | Option.none => Option.none)

@[expose] public def length2 (state : Option (LengthState)) : Option (LengthState) := lengthStep (lengthStep (state))

@[expose] public def length4 (state : Option (LengthState)) : Option (LengthState) := length2 (length2 (state))

@[expose] public def length8 (state : Option (LengthState)) : Option (LengthState) := length4 (length4 (state))

@[expose] public def length16 (state : Option (LengthState)) : Option (LengthState) := length8 (length8 (state))

@[expose] public def length32Steps (state : Option (LengthState)) : Option (LengthState) := length16 (length16 (state))

@[expose] public def length32 (v : UInt32) : Option (Int16) := (match length32Steps (Option.some (({ word := v, count := (0 : Int16) } : LengthState))) with | Option.some st => Option.some ((st).count) | Option.none => Option.none)

@[expose] public def length (w : Limbs) : Option (Int16) := (if (LexLeanRuntime.equal ((w).l3) ((0 : UInt32)) : Bool) then (if (LexLeanRuntime.equal ((w).l2) ((0 : UInt32)) : Bool) then (if (LexLeanRuntime.equal ((w).l1) ((0 : UInt32)) : Bool) then length32 ((w).l0) else (match length32 ((w).l1) with | Option.some n => int16Add (n) ((32 : Int16)) | Option.none => Option.none)) else (match length32 ((w).l2) with | Option.some n => int16Add (n) ((64 : Int16)) | Option.none => Option.none)) else (match length32 ((w).l3) with | Option.some n => int16Add (n) ((96 : Int16)) | Option.none => Option.none))

public structure Rounding where
  value : Limbs
  guard : Bool
  sticky : Bool

@[expose] public def roundStep (state : Option (Rounding)) : Option (Rounding) := (match state with | Option.some st => (match right ((st).value) with | Option.some next => Option.some (({ value := next, guard := (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (((st).value).l0) ((1 : UInt32)) : UInt32)) ((1 : UInt32)) : Bool), sticky := ((st).sticky || (st).guard) } : Rounding)) | Option.none => Option.none) | Option.none => Option.none)

@[expose] public def round2 (state : Option (Rounding)) : Option (Rounding) := roundStep (roundStep (state))

@[expose] public def round4 (state : Option (Rounding)) : Option (Rounding) := round2 (round2 (state))

@[expose] public def round8 (state : Option (Rounding)) : Option (Rounding) := round4 (round4 (state))

@[expose] public def round16 (state : Option (Rounding)) : Option (Rounding) := round8 (round8 (state))

@[expose] public def round32 (state : Option (Rounding)) : Option (Rounding) := round16 (round16 (state))

@[expose] public def round64 (state : Option (Rounding)) : Option (Rounding) := round32 (round32 (state))

@[expose] public def round128 (state : Option (Rounding)) : Option (Rounding) := round64 (round64 (state))

@[expose] public def round (w : Limbs) (amount : Int16) : Option (UInt64) := (if negative (amount) then (match int16Negate (amount) with | Option.some positive => (match convertInt16ToUInt32 (positive) with | Option.some count => (match low64 (w) with | Option.some bits => (LexLeanRuntime.shiftLeft (bits) (count) : Option (UInt64)) | Option.none => Option.none) | Option.none => Option.none) | Option.none => Option.none) else (if signedLess ((128 : Int16)) (amount) then Option.some ((0 : UInt64)) else (match convertInt16ToUInt8 (amount) with | Option.some count => (match (match Option.some (({ value := w, guard := false, sticky := false } : Rounding)) with | Option.some state0 => (match (if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (count) ((1 : UInt8)) : UInt8)) ((0 : UInt8)) : Bool) then Option.some (state0) else roundStep (Option.some (state0))) with | Option.some state1 => (match (if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (count) ((2 : UInt8)) : UInt8)) ((0 : UInt8)) : Bool) then Option.some (state1) else round2 (Option.some (state1))) with | Option.some state2 => (match (if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (count) ((4 : UInt8)) : UInt8)) ((0 : UInt8)) : Bool) then Option.some (state2) else round4 (Option.some (state2))) with | Option.some state3 => (match (if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (count) ((8 : UInt8)) : UInt8)) ((0 : UInt8)) : Bool) then Option.some (state3) else round8 (Option.some (state3))) with | Option.some state4 => (match (if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (count) ((16 : UInt8)) : UInt8)) ((0 : UInt8)) : Bool) then Option.some (state4) else round16 (Option.some (state4))) with | Option.some state5 => (match (if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (count) ((32 : UInt8)) : UInt8)) ((0 : UInt8)) : Bool) then Option.some (state5) else round32 (Option.some (state5))) with | Option.some state6 => (match (if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (count) ((64 : UInt8)) : UInt8)) ((0 : UInt8)) : Bool) then Option.some (state6) else round64 (Option.some (state6))) with | Option.some state7 => (match (if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (count) ((128 : UInt8)) : UInt8)) ((0 : UInt8)) : Bool) then Option.some (state7) else round128 (Option.some (state7))) with | Option.some state8 => Option.some (state8) | Option.none => Option.none) | Option.none => Option.none) | Option.none => Option.none) | Option.none => Option.none) | Option.none => Option.none) | Option.none => Option.none) | Option.none => Option.none) | Option.none => Option.none) | Option.none => Option.none) with | Option.some st => (match low64 ((st).value) with | Option.some bits => (if ((st).guard && ((st).sticky || (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (bits) ((1 : UInt64)) : UInt64)) ((1 : UInt64)) : Bool))) then (LexLeanRuntime.checkedAdd (bits) ((1 : UInt64)) : Option (UInt64)) else Option.some (bits)) | Option.none => Option.none) | Option.none => Option.none) | Option.none => Option.none)))

@[expose] public def from64 (v : UInt64) : Option (Limbs) := (match convertUInt64ToUInt32 ((LexLeanRuntime.bitAnd (v) ((4294967295 : UInt64)) : UInt64)) with | Option.some lo => (match (LexLeanRuntime.shiftRight (v) ((32 : UInt32)) : Option (UInt64)) with | Option.some upper => (match convertUInt64ToUInt32 (upper) with | Option.some hi => Option.some (({ l0 := lo, l1 := hi, l2 := (0 : UInt32), l3 := (0 : UInt32) } : Limbs)) | Option.none => Option.none) | Option.none => Option.none) | Option.none => Option.none)

public structure Division where
  quotient : UInt64
  remainder : UInt64
  divisor : UInt64

@[expose] public def divideStep (state : Option (Division)) : Option (Division) := (match state with | Option.some st => (match (LexLeanRuntime.checkedMultiply ((st).remainder) ((2 : UInt64)) : Option (UInt64)) with | Option.some twice => (match (LexLeanRuntime.checkedMultiply ((st).quotient) ((2 : UInt64)) : Option (UInt64)) with | Option.some q2 => (match (LexLeanRuntime.checkedSubtract (twice) ((st).divisor) : Option (UInt64)) with | Option.some reduced => (match (LexLeanRuntime.checkedAdd (q2) ((1 : UInt64)) : Option (UInt64)) with | Option.some nextq => Option.some (({ quotient := nextq, remainder := reduced, divisor := (st).divisor } : Division)) | Option.none => Option.none) | Option.none => Option.some (({ quotient := q2, remainder := twice, divisor := (st).divisor } : Division))) | Option.none => Option.none) | Option.none => Option.none) | Option.none => Option.none)

@[expose] public def divide2 (state : Option (Division)) : Option (Division) := divideStep (divideStep (state))

@[expose] public def divide4 (state : Option (Division)) : Option (Division) := divide2 (divide2 (state))

@[expose] public def divide8 (state : Option (Division)) : Option (Division) := divide4 (divide4 (state))

@[expose] public def divide16 (state : Option (Division)) : Option (Division) := divide8 (divide8 (state))

@[expose] public def divide32 (state : Option (Division)) : Option (Division) := divide16 (divide16 (state))

@[expose] public def quotient32 (a : UInt64) (b : UInt64) : Option (UInt64) := (match (LexLeanRuntime.checkedSubtract (a) (b) : Option (UInt64)) with | Option.some initial => (match divide16 (divide8 (divideStep (Option.some (({ quotient := (1 : UInt64), remainder := initial, divisor := b } : Division))))) with | Option.some st => Option.some ((LexLeanRuntime.bitOr ((st).quotient) ((if (LexLeanRuntime.equal ((st).remainder) ((0 : UInt64)) : Bool) then (0 : UInt64) else (1 : UInt64))) : UInt64)) | Option.none => Option.none) | Option.none => Option.none)

@[expose] public def quotient64 (a : UInt64) (b : UInt64) : Option (UInt64) := (match (LexLeanRuntime.checkedSubtract (a) (b) : Option (UInt64)) with | Option.some initial => (match divide32 (divide16 (divide4 (divide2 (Option.some (({ quotient := (1 : UInt64), remainder := initial, divisor := b } : Division)))))) with | Option.some st => Option.some ((LexLeanRuntime.bitOr ((st).quotient) ((if (LexLeanRuntime.equal ((st).remainder) ((0 : UInt64)) : Bool) then (0 : UInt64) else (1 : UInt64))) : UInt64)) | Option.none => Option.none) | Option.none => Option.none)

end BoundedNumeric.Wide

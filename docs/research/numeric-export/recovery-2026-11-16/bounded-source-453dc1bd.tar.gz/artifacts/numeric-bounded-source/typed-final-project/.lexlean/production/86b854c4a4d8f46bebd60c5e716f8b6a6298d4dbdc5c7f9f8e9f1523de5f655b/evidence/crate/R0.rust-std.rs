#![forbid(unsafe_code)]
use core::cmp::Ordering;

use core::sync::atomic::{AtomicU64, Ordering as Memory};

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub struct Overflow;

pub type R<T> = Result<T, Overflow>;

static WORK: AtomicU64 = AtomicU64::new(0);

pub fn tick(units: u64) { WORK.fetch_add(units, Memory::Relaxed); }

pub fn work() -> u64 { WORK.load(Memory::Relaxed) }

pub trait Same {
    fn same(&self, other: &Self) -> bool;
}

pub trait Key {
    fn key(&self, other: &Self) -> Ordering;
}

impl Same for bool {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for bool {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u8 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u8 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u16 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u16 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u32 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u32 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u64 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u64 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i8 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i8 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i16 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i16 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i32 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i32 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i64 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i64 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for Ordering {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl<A: Key, B: Key> Key for (A, B) {
    fn key(&self, other: &Self) -> Ordering { match self.0.key(&other.0) { Ordering::Equal => self.1.key(&other.1), decided => decided, } }
}

pub fn equal<T: Same>(a: T, b: T) -> bool { a.same(&b) }

pub fn compare<T: Key>(a: T, b: T) -> Ordering { a.key(&b) }

pub fn nat_add(p0: u64, p1: u64) -> R<u64> {
    match u64::checked_add(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<u64, Overflow>(Overflow)
        }
    }
}

pub fn nat_sub(p0: u64, p1: u64) -> u64 {
    u64::saturating_sub(p0, p1)
}

pub fn nat_mul(p0: u64, p1: u64) -> R<u64> {
    match u64::checked_mul(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<u64, Overflow>(Overflow)
        }
    }
}

pub fn nat_quot(p0: u64, p1: u64, p2: u64) -> u64 {
    u64::checked_div(p0, p1).unwrap_or(p2)
}

pub fn nat_rem(p0: u64, p1: u64, p2: u64) -> u64 {
    u64::checked_rem(p0, p1).unwrap_or(p2)
}

pub fn nat_eq(p0: u64, p1: u64) -> bool {
    core::cmp::PartialEq::eq(&p0, &p1)
}

pub fn nat_le(p0: u64, p1: u64) -> bool {
    core::cmp::PartialOrd::le(&p0, &p1)
}

pub fn nat_lt(p0: u64, p1: u64) -> bool {
    core::cmp::PartialOrd::lt(&p0, &p1)
}

pub fn nat_succ(p0: u64) -> R<u64> {
    match u64::checked_add(p0, 1u64) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<u64, Overflow>(Overflow)
        }
    }
}

pub fn int_add(p0: i64, p1: i64) -> R<i64> {
    match i64::checked_add(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_sub(p0: i64, p1: i64) -> R<i64> {
    match i64::checked_sub(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_mul(p0: i64, p1: i64) -> R<i64> {
    match i64::checked_mul(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_neg(p0: i64) -> R<i64> {
    match i64::checked_neg(p0) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_quot(p0: i64, p1: i64, p2: i64) -> R<i64> {
    { let value = { let (a, b, z): (i64, i64, i64) = (p0, p1, p2); if b == 0 { Some(z) } else { a.checked_div(b) } }; match value {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    } }
}

pub fn int_rem(p0: i64, p1: i64, p2: i64) -> i64 {
    { let (a, b, z): (i64, i64, i64) = (p0, p1, p2); if b == 0 { z } else { a.wrapping_rem(b) } }
}

pub fn bool_not(p0: bool) -> bool {
    !p0
}

pub fn bool_and(p0: bool, p1: bool) -> bool {
    if p0 {
        p1
    } else {
        false
    }
}

pub fn bool_or(p0: bool, p1: bool) -> bool {
    if p0 {
        true
    } else {
        p1
    }
}

pub mod fixed_u8 {
    pub fn checked_add(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u8, p1: u8) -> u8 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u8, p1: u8) -> u8 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u8, p1: u8) -> u8 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u8) -> u8 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u8, p1: u32) -> Option<u8> {
        u8::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u8, p1: u32) -> Option<u8> {
        u8::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u8> {
        u8::try_from(p0).ok()
    }
}

pub mod fixed_u16 {
    pub fn checked_add(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u16, p1: u16) -> u16 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u16, p1: u16) -> u16 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u16, p1: u16) -> u16 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u16) -> u16 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u16, p1: u32) -> Option<u16> {
        u16::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u16, p1: u32) -> Option<u16> {
        u16::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u16> {
        u16::try_from(p0).ok()
    }
}

pub mod fixed_u32 {
    pub fn checked_add(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u32, p1: u32) -> u32 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u32, p1: u32) -> u32 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u32, p1: u32) -> u32 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u32) -> u32 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u32> {
        u32::try_from(p0).ok()
    }
}

pub mod fixed_u64 {
    pub fn checked_add(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u64, p1: u64) -> u64 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u64, p1: u64) -> u64 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u64, p1: u64) -> u64 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u64) -> u64 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u64, p1: u32) -> Option<u64> {
        u64::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u64, p1: u32) -> Option<u64> {
        u64::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u64> {
        u64::try_from(p0).ok()
    }
}

pub mod fixed_i8 {
    pub fn checked_add(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i8, p1: i8) -> i8 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i8, p1: i8) -> i8 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i8, p1: i8) -> i8 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i8) -> i8 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i8, p1: u32) -> Option<i8> {
        i8::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i8, p1: u32) -> Option<i8> {
        i8::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i8> {
        i8::try_from(p0).ok()
    }
}

pub fn checked_neg_i8(p0: i8) -> Option<i8> {
    i8::checked_neg(p0)
}

pub mod fixed_i16 {
    pub fn checked_add(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i16, p1: i16) -> i16 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i16, p1: i16) -> i16 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i16, p1: i16) -> i16 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i16) -> i16 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i16, p1: u32) -> Option<i16> {
        i16::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i16, p1: u32) -> Option<i16> {
        i16::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i16> {
        i16::try_from(p0).ok()
    }
}

pub fn checked_neg_i16(p0: i16) -> Option<i16> {
    i16::checked_neg(p0)
}

pub mod fixed_i32 {
    pub fn checked_add(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i32, p1: i32) -> i32 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i32, p1: i32) -> i32 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i32, p1: i32) -> i32 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i32) -> i32 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i32, p1: u32) -> Option<i32> {
        i32::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i32, p1: u32) -> Option<i32> {
        i32::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i32> {
        i32::try_from(p0).ok()
    }
}

pub fn checked_neg_i32(p0: i32) -> Option<i32> {
    i32::checked_neg(p0)
}

pub mod fixed_i64 {
    pub fn checked_add(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i64, p1: i64) -> i64 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i64, p1: i64) -> i64 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i64, p1: i64) -> i64 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i64) -> i64 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i64, p1: u32) -> Option<i64> {
        i64::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i64, p1: u32) -> Option<i64> {
        i64::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i64> {
        i64::try_from(p0).ok()
    }
}

pub fn checked_neg_i64(p0: i64) -> Option<i64> {
    i64::checked_neg(p0)
}
use core::str;

use std::mem;

use std::rc::Rc;

#[derive(Clone)]
pub struct Str(Rc<str>);

impl Str {
    pub fn lit(text: &str) -> Str { Str(Rc::from(text)) }
    pub fn text(&self) -> &str { &self.0 }
    pub fn length(&self) -> u64 { chars(&self.0) }
    pub fn utf8_encode(&self) -> Bytes { tick(self.0.len() as u64); Bytes::lit(self.0.as_bytes()) }
    pub fn split_exact(&self, delimiter: &Str, maximum: u32) -> Option<List<Str>> { if delimiter.0.is_empty() { return None; }; chars(&self.0); let mut fields: Vec<Str> = Vec::new(); for piece in self.0.split(&*delimiter.0) { fields.push(Str::lit(piece)); }; if fields.len() as u128 > u128::from(maximum) { return None; }; Some(List::onto(fields, List::nil())) }
    pub fn join(texts: List<Str>, delimiter: &Str) -> Str { let mut out = String::new(); let mut first = true; let mut cursor = &texts; while let Repr::Cell(cell) = &cursor.0 { tick(1); if !first { chars(&delimiter.0); out.push_str(&delimiter.0); }; first = false; chars(&cell.head.0); out.push_str(&cell.head.0); cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for text in buffer[..*len].iter().rev() { tick(1); if !first { chars(&delimiter.0); out.push_str(&delimiter.0); }; first = false; chars(&text.0); out.push_str(&text.0); } }, _ => { }, }; Str::lit(&out) }
}

#[derive(Clone)]
pub struct Bytes(Rc<[u8]>);

impl Bytes {
    pub fn lit(octets: &[u8]) -> Bytes { Bytes(Rc::from(octets)) }
    pub fn octets(&self) -> &[u8] { &self.0 }
    pub fn append(a: Bytes, b: Bytes) -> Bytes { tick((a.0.len() + b.0.len()) as u64); let mut out = Vec::with_capacity(a.0.len() + b.0.len()); out.extend_from_slice(&a.0); out.extend_from_slice(&b.0); Bytes(Rc::from(out)) }
    pub fn length(&self) -> u64 { self.0.len() as u64 }
    pub fn index(&self, i: u64) -> Option<u8> { match usize::try_from(i) { Ok(at) => self.0.get(at).copied(), Err(_) => None, } }
    pub fn slice(&self, start: u64, count: u64) -> Option<Bytes> { let end = u128::from(start) + u128::from(count); if end > self.0.len() as u128 { return None; }; tick(count); Some(Bytes::lit(&self.0[start as usize..end as usize])) }
    pub fn utf8_decode(&self) -> Option<Str> { tick(self.0.len() as u64); match str::from_utf8(&self.0) { Ok(text) => Some(Str::lit(text)), Err(_) => None, } }
    pub fn compare(&self, other: &Bytes) -> Ordering { tick(1 + self.0.len().min(other.0.len()) as u64); self.0.cmp(&other.0) }
}

pub struct Node<T> { head: T, tail: List<T> }

pub enum Repr<T> { Nil, Run { buffer: Rc<Vec<T>>, len: usize }, Cell(Rc<Node<T>>) }

pub struct List<T>(Repr<T>);

impl<T> Clone for List<T> {
    fn clone(&self) -> Self { List(match &self.0 { Repr::Nil => Repr::Nil, Repr::Run { buffer, len } => Repr::Run { buffer: buffer.clone(), len: *len }, Repr::Cell(cell) => Repr::Cell(cell.clone()), }) }
}

impl<T> List<T> {
    fn take(&mut self) -> Repr<T> { mem::replace(&mut self.0, Repr::Nil) }
}

impl<T> Drop for Node<T> {
    fn drop(&mut self) { let mut next = match self.tail.take() { Repr::Cell(cell) => Some(cell), _ => None, }; while let Some(cell) = next { match Rc::try_unwrap(cell) { Ok(mut node) => next = match node.tail.take() { Repr::Cell(cell) => Some(cell), _ => None, }, Err(_) => break, } } }
}

impl<T: Clone> List<T> {
    pub fn nil() -> Self { List(Repr::Nil) }
    pub fn cons(head: T, mut tail: List<T>) -> Self { List(match tail.take() { Repr::Nil => { let mut buffer = Vec::with_capacity(16); buffer.push(head); Repr::Run { buffer: Rc::new(buffer), len: 1 } }, Repr::Run { mut buffer, len } => { match Rc::get_mut(&mut buffer) { Some(cells) => { cells.truncate(len); cells.push(head); Repr::Run { buffer, len: len + 1 } }, None => Repr::Cell(Rc::new(Node { head, tail: List(Repr::Run { buffer, len }) })), } }, rest => Repr::Cell(Rc::new(Node { head, tail: List(rest) })), }) }
    pub fn uncons(&self) -> Option<(T, List<T>)> { match &self.0 { Repr::Nil => None, Repr::Run { buffer, len } => { let head = buffer[len - 1].clone(); Some((head, List(if *len == 1 { Repr::Nil } else { Repr::Run { buffer: buffer.clone(), len: len - 1 } }))) }, Repr::Cell(cell) => Some((cell.head.clone(), cell.tail.clone())), } }
    pub fn length(&self) -> u64 { let mut count = 0; let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); count += 1; cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for _ in buffer[..*len].iter().rev() { tick(1); count += 1; } }, _ => { }, }; count }
    pub fn append(a: List<T>, b: List<T>) -> List<T> { List::onto(a.items(), b) }
    pub fn index(&self, i: u64) -> Option<T> { let mut position = 0; let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); if position == i { return Some(cell.head.clone()); }; position += 1; cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for item in buffer[..*len].iter().rev() { tick(1); if position == i { return Some(item.clone()); }; position += 1; } }, _ => { }, }; None }
    pub fn slice(&self, start: u64, count: u64) -> Option<List<T>> { let end = u128::from(start) + u128::from(count); let mut part = Vec::new(); let mut position: u128 = 0; let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); if position >= end { return Some(List::onto(part, List::nil())); }; if position >= u128::from(start) { part.push(cell.head.clone()); }; position += 1; cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for item in buffer[..*len].iter().rev() { tick(1); if position >= end { return Some(List::onto(part, List::nil())); }; if position >= u128::from(start) { part.push(item.clone()); }; position += 1; } }, _ => { }, }; if position < end { None } else { Some(List::onto(part, List::nil())) } }
    fn items(&self) -> Vec<T> { let mut out = Vec::new(); let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); out.push(cell.head.clone()); cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for item in buffer[..*len].iter().rev() { tick(1); out.push(item.clone()); } }, _ => { }, }; out }
    fn onto(mut items: Vec<T>, tail: List<T>) -> List<T> { let mut out = tail; while let Some(item) = items.pop() { tick(1); out = List::cons(item, out); }; out }
}

pub fn chars(text: &str) -> u64 { let mut count = 0; for _ in text.chars() { tick(1); count += 1; }; count }

impl Same for Str {
    fn same(&self, other: &Self) -> bool { let mut left = self.0.chars(); let mut right = other.0.chars(); loop { tick(1); match (left.next(), right.next()) { (None, None) => return true, (a, b) if a != b => return false, _ => { }, } } }
}

impl Same for Bytes {
    fn same(&self, other: &Self) -> bool { tick(1 + self.0.len().min(other.0.len()) as u64); self.0 == other.0 }
}

impl Key for Str {
    fn key(&self, other: &Self) -> Ordering { let mut left = self.0.chars(); let mut right = other.0.chars(); loop { tick(1); match (left.next(), right.next()) { (None, None) => return Ordering::Equal, (None, Some(_)) => return Ordering::Less, (Some(_), None) => return Ordering::Greater, (Some(a), Some(b)) => match a.cmp(&b) { Ordering::Equal => { }, decided => return decided, }, } } }
}

pub fn canonical_decimal(text: &str) -> Option<Option<i128>> { let digits = match text.strip_prefix('-') { Some(rest) => rest, None => text, }; let mut canonical = !digits.is_empty() && (digits == "0" || !digits.starts_with('0')) && text != "-0"; for c in digits.chars() { tick(1); canonical = canonical && c.is_ascii_digit(); }; if !canonical { return None; }; Some(text.parse::<i128>().ok()) }

pub fn parse_int(text: Str) -> R<Option<i64>> { match canonical_decimal(&text.0) { None => Ok(None), Some(Some(n)) => match i64::try_from(n) { Ok(value) => Ok(Some(value)), Err(_) => Err(Overflow), }, Some(None) => Err(Overflow), } }

pub fn format_u8(a: u8) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u8(text: Str) -> Option<u8> { match canonical_decimal(&text.0) { Some(Some(n)) => u8::try_from(n).ok(), _ => None, } }

pub fn format_u16(a: u16) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u16(text: Str) -> Option<u16> { match canonical_decimal(&text.0) { Some(Some(n)) => u16::try_from(n).ok(), _ => None, } }

pub fn format_u32(a: u32) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u32(text: Str) -> Option<u32> { match canonical_decimal(&text.0) { Some(Some(n)) => u32::try_from(n).ok(), _ => None, } }

pub fn format_u64(a: u64) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u64(text: Str) -> Option<u64> { match canonical_decimal(&text.0) { Some(Some(n)) => u64::try_from(n).ok(), _ => None, } }

pub fn format_i8(a: i8) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i8(text: Str) -> Option<i8> { match canonical_decimal(&text.0) { Some(Some(n)) => i8::try_from(n).ok(), _ => None, } }

pub fn format_i16(a: i16) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i16(text: Str) -> Option<i16> { match canonical_decimal(&text.0) { Some(Some(n)) => i16::try_from(n).ok(), _ => None, } }

pub fn format_i32(a: i32) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i32(text: Str) -> Option<i32> { match canonical_decimal(&text.0) { Some(Some(n)) => i32::try_from(n).ok(), _ => None, } }

pub fn format_i64(a: i64) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i64(text: Str) -> Option<i64> { match canonical_decimal(&text.0) { Some(Some(n)) => i64::try_from(n).ok(), _ => None, } }

pub fn append_list<T: Clone>(p0: List<T>, p1: List<T>) -> List<T> {
    List::append(p0, p1)
}

pub fn length_list<T: Clone>(p0: List<T>) -> u64 {
    List::length(&p0)
}

pub fn index_list<T: Clone>(p0: List<T>, p1: u64) -> Option<T> {
    List::index(&p0, p1)
}

pub fn slice_list<T: Clone>(p0: List<T>, p1: u64, p2: u64) -> Option<List<T>> {
    List::slice(&p0, p1, p2)
}

pub fn append_bytes(p0: Bytes, p1: Bytes) -> Bytes {
    Bytes::append(p0, p1)
}

pub fn length_bytes(p0: Bytes) -> u64 {
    Bytes::length(&p0)
}

pub fn length_string(p0: Str) -> u64 {
    Str::length(&p0)
}

pub fn index_bytes(p0: Bytes, p1: u64) -> Option<u8> {
    Bytes::index(&p0, p1)
}

pub fn slice_bytes(p0: Bytes, p1: u64, p2: u64) -> Option<Bytes> {
    Bytes::slice(&p0, p1, p2)
}

pub fn utf8_encode(p0: Str) -> Bytes {
    Str::utf8_encode(&p0)
}

pub fn utf8_decode(p0: Bytes) -> Option<Str> {
    Bytes::utf8_decode(&p0)
}

pub fn compare_bytes(p0: Bytes, p1: Bytes) -> Ordering {
    Bytes::compare(&p0, &p1)
}

pub fn split_exact(p0: Str, p1: Str, p2: u32) -> Option<List<Str>> {
    Str::split_exact(&p0, &p1, p2)
}

pub fn join(p0: List<Str>, p1: Str) -> Str {
    Str::join(p0, &p1)
}

#[derive(Clone)]
pub enum Adt0 {
    C0(u32, u32, u32, u32),
}

#[derive(Clone)]
pub enum Adt1 {
    C0(Adt0, bool, bool),
}

#[derive(Clone)]
pub enum Adt2 {
    C0(u32, i16),
}

pub fn f0(v0: u32, v1: u32) -> Option<u32> {
    let m1 = f1(v0);
    match m1 {
        None => {
            None::<u32>
        }
        Some(v2) => {
            let m2 = f1(v1);
            match m2 {
                None => {
                    None::<u32>
                }
                Some(v3) => {
                    let m3 = f2(v2, v3);
                    match m3 {
                        None => {
                            None::<u32>
                        }
                        Some(v4) => {
                            f3(v4)
                        }
                    }
                }
            }
        }
    }
}

pub fn f1(v0: u32) -> Option<u64> {
    let a4 = v0;
    fixed_u64::convert(i128::from(a4))
}

pub fn f2(v0: u64, v1: u64) -> Option<u64> {
    let v2: u64 = {
        let a7 = {
            let a5 = v0;
            let a6 = v1;
            fixed_u64::bit_xor(a5, a6)
        };
        let a8 = 2147483648u64;
        fixed_u64::bit_and(a7, a8)
    };
    let v3: u64 = {
        let a9 = v0;
        let a10 = 8388607u64;
        fixed_u64::bit_and(a9, a10)
    };
    let v4: u64 = {
        let a11 = v1;
        let a12 = 8388607u64;
        fixed_u64::bit_and(a11, a12)
    };
    let m15 = {
        let a13 = v0;
        let a14 = 23u32;
        fixed_u64::shift_right(a13, a14)
    };
    match m15 {
        None => {
            None::<u64>
        }
        Some(v5) => {
            let m18 = {
                let a16 = v1;
                let a17 = 23u32;
                fixed_u64::shift_right(a16, a17)
            };
            match m18 {
                None => {
                    None::<u64>
                }
                Some(v6) => {
                    let v7: u64 = {
                        let a19 = v5;
                        let a20 = 255u64;
                        fixed_u64::bit_and(a19, a20)
                    };
                    let v8: u64 = {
                        let a21 = v6;
                        let a22 = 255u64;
                        fixed_u64::bit_and(a21, a22)
                    };
                    let a23 = v7;
                    let a24 = 255u64;
                    if if equal(a23, a24) {
                        let a27 = {
                            let a25 = v3;
                            let a26 = 0u64;
                            equal(a25, a26)
                        };
                        bool_not(a27)
                    } else {
                        false
                    } {
                        Some({
                            let a28 = v0;
                            let a29 = 4194304u64;
                            fixed_u64::bit_or(a28, a29)
                        })
                    } else {
                        let a30 = v8;
                        let a31 = 255u64;
                        if if equal(a30, a31) {
                            let a34 = {
                                let a32 = v4;
                                let a33 = 0u64;
                                equal(a32, a33)
                            };
                            bool_not(a34)
                        } else {
                            false
                        } {
                            Some({
                                let a35 = v1;
                                let a36 = 4194304u64;
                                fixed_u64::bit_or(a35, a36)
                            })
                        } else {
                            let a37 = v7;
                            let a38 = 255u64;
                            if if equal(a37, a38) {
                                true
                            } else {
                                let a39 = v8;
                                let a40 = 255u64;
                                equal(a39, a40)
                            } {
                                Some({
                                    let a43 = {
                                        let a41 = v0;
                                        let a42 = 2147483647u64;
                                        fixed_u64::bit_and(a41, a42)
                                    };
                                    let a44 = 0u64;
                                    if if equal(a43, a44) {
                                        true
                                    } else {
                                        let a47 = {
                                            let a45 = v1;
                                            let a46 = 2147483647u64;
                                            fixed_u64::bit_and(a45, a46)
                                        };
                                        let a48 = 0u64;
                                        equal(a47, a48)
                                    } {
                                        2143289344u64
                                    } else {
                                        let a49 = v2;
                                        let a50 = 2139095040u64;
                                        fixed_u64::bit_or(a49, a50)
                                    }
                                })
                            } else {
                                let a53 = {
                                    let a51 = v0;
                                    let a52 = 2147483647u64;
                                    fixed_u64::bit_and(a51, a52)
                                };
                                let a54 = 0u64;
                                if if equal(a53, a54) {
                                    true
                                } else {
                                    let a57 = {
                                        let a55 = v1;
                                        let a56 = 2147483647u64;
                                        fixed_u64::bit_and(a55, a56)
                                    };
                                    let a58 = 0u64;
                                    equal(a57, a58)
                                } {
                                    Some(v2)
                                } else {
                                    let v9: u64 = {
                                        let a59 = v7;
                                        let a60 = 0u64;
                                        if equal(a59, a60) {
                                            v3
                                        } else {
                                            let a61 = v3;
                                            let a62 = 8388608u64;
                                            fixed_u64::bit_or(a61, a62)
                                        }
                                    };
                                    let v10: u64 = {
                                        let a63 = v8;
                                        let a64 = 0u64;
                                        if equal(a63, a64) {
                                            v4
                                        } else {
                                            let a65 = v4;
                                            let a66 = 8388608u64;
                                            fixed_u64::bit_or(a65, a66)
                                        }
                                    };
                                    let m67 = f4(v7);
                                    match m67 {
                                        None => {
                                            None::<u64>
                                        }
                                        Some(v11) => {
                                            let m68 = f4(v8);
                                            match m68 {
                                                None => {
                                                    None::<u64>
                                                }
                                                Some(v12) => {
                                                    let m71 = {
                                                        let a69 = v7;
                                                        let a70 = 0u64;
                                                        if equal(a69, a70) {
                                                            Some(1i16)
                                                        } else {
                                                            f5(v11)
                                                        }
                                                    };
                                                    match m71 {
                                                        None => {
                                                            None::<u64>
                                                        }
                                                        Some(v13) => {
                                                            let m74 = {
                                                                let a72 = v8;
                                                                let a73 = 0u64;
                                                                if equal(a72, a73) {
                                                                    Some(1i16)
                                                                } else {
                                                                    f5(v12)
                                                                }
                                                            };
                                                            match m74 {
                                                                None => {
                                                                    None::<u64>
                                                                }
                                                                Some(v14) => {
                                                                    let m75 = f6(v13, v14);
                                                                    match m75 {
                                                                        None => {
                                                                            None::<u64>
                                                                        }
                                                                        Some(v15) => {
                                                                            let m76 = f7(v15, 300i16);
                                                                            match m76 {
                                                                                None => {
                                                                                    None::<u64>
                                                                                }
                                                                                Some(v16) => {
                                                                                    let m77 = f8(v9, v10);
                                                                                    match m77 {
                                                                                        None => {
                                                                                            None::<u64>
                                                                                        }
                                                                                        Some(v17) => {
                                                                                            let m78 = f9(v17.clone());
                                                                                            match m78 {
                                                                                                None => {
                                                                                                    None::<u64>
                                                                                                }
                                                                                                Some(v18) => {
                                                                                                    let m79 = f7(v18, 1i16);
                                                                                                    match m79 {
                                                                                                        None => {
                                                                                                            None::<u64>
                                                                                                        }
                                                                                                        Some(v19) => {
                                                                                                            let m80 = f6(v19, v16);
                                                                                                            match m80 {
                                                                                                                None => {
                                                                                                                    None::<u64>
                                                                                                                }
                                                                                                                Some(v20) => {
                                                                                                                    let m81 = f7(v19, 23i16);
                                                                                                                    match m81 {
                                                                                                                        None => {
                                                                                                                            None::<u64>
                                                                                                                        }
                                                                                                                        Some(v21) => {
                                                                                                                            let m82 = f7(-149i16, v16);
                                                                                                                            match m82 {
                                                                                                                                None => {
                                                                                                                                    None::<u64>
                                                                                                                                }
                                                                                                                                Some(v22) => {
                                                                                                                                    let v23: i16 = if f10(v21, v22) {
                                                                                                                                        v22
                                                                                                                                    } else {
                                                                                                                                        v21
                                                                                                                                    };
                                                                                                                                    let m83 = f11(v17, v23);
                                                                                                                                    match m83 {
                                                                                                                                        None => {
                                                                                                                                            None::<u64>
                                                                                                                                        }
                                                                                                                                        Some(v24) => {
                                                                                                                                            f12(v2, v24, v20)
                                                                                                                                        }
                                                                                                                                    }
                                                                                                                                }
                                                                                                                            }
                                                                                                                        }
                                                                                                                    }
                                                                                                                }
                                                                                                            }
                                                                                                        }
                                                                                                    }
                                                                                                }
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

pub fn f3(v0: u64) -> Option<u32> {
    let a84 = v0;
    fixed_u32::convert(i128::from(a84))
}

pub fn f4(v0: u64) -> Option<u8> {
    let a85 = v0;
    fixed_u8::convert(i128::from(a85))
}

pub fn f5(v0: u8) -> Option<i16> {
    let a86 = v0;
    fixed_i16::convert(i128::from(a86))
}

pub fn f6(v0: i16, v1: i16) -> Option<i16> {
    let a87 = v0;
    let a88 = v1;
    fixed_i16::checked_add(a87, a88)
}

pub fn f7(v0: i16, v1: i16) -> Option<i16> {
    let a89 = v0;
    let a90 = v1;
    fixed_i16::checked_sub(a89, a90)
}

pub fn f8(v0: u64, v1: u64) -> Option<Adt0> {
    let m93 = Some({
        let a91 = v0;
        let a92 = 4294967295u64;
        fixed_u64::bit_and(a91, a92)
    });
    match m93 {
        None => {
            None::<Adt0>
        }
        Some(v2) => {
            let m96 = {
                let a94 = v0;
                let a95 = 32u32;
                fixed_u64::shift_right(a94, a95)
            };
            match m96 {
                None => {
                    None::<Adt0>
                }
                Some(v3) => {
                    let m99 = Some({
                        let a97 = v1;
                        let a98 = 4294967295u64;
                        fixed_u64::bit_and(a97, a98)
                    });
                    match m99 {
                        None => {
                            None::<Adt0>
                        }
                        Some(v4) => {
                            let m102 = {
                                let a100 = v1;
                                let a101 = 32u32;
                                fixed_u64::shift_right(a100, a101)
                            };
                            match m102 {
                                None => {
                                    None::<Adt0>
                                }
                                Some(v5) => {
                                    let m105 = {
                                        let a103 = v2;
                                        let a104 = v4;
                                        fixed_u64::checked_mul(a103, a104)
                                    };
                                    match m105 {
                                        None => {
                                            None::<Adt0>
                                        }
                                        Some(v6) => {
                                            let m108 = {
                                                let a106 = v6;
                                                let a107 = 32u32;
                                                fixed_u64::shift_right(a106, a107)
                                            };
                                            match m108 {
                                                None => {
                                                    None::<Adt0>
                                                }
                                                Some(v7) => {
                                                    let m111 = {
                                                        let a109 = v3;
                                                        let a110 = v4;
                                                        fixed_u64::checked_mul(a109, a110)
                                                    };
                                                    match m111 {
                                                        None => {
                                                            None::<Adt0>
                                                        }
                                                        Some(v8) => {
                                                            let m114 = {
                                                                let a112 = v8;
                                                                let a113 = v7;
                                                                fixed_u64::checked_add(a112, a113)
                                                            };
                                                            match m114 {
                                                                None => {
                                                                    None::<Adt0>
                                                                }
                                                                Some(v9) => {
                                                                    let m117 = {
                                                                        let a115 = v2;
                                                                        let a116 = v5;
                                                                        fixed_u64::checked_mul(a115, a116)
                                                                    };
                                                                    match m117 {
                                                                        None => {
                                                                            None::<Adt0>
                                                                        }
                                                                        Some(v10) => {
                                                                            let m122 = {
                                                                                let a120 = v10;
                                                                                let a121 = {
                                                                                    let a118 = v9;
                                                                                    let a119 = 4294967295u64;
                                                                                    fixed_u64::bit_and(a118, a119)
                                                                                };
                                                                                fixed_u64::checked_add(a120, a121)
                                                                            };
                                                                            match m122 {
                                                                                None => {
                                                                                    None::<Adt0>
                                                                                }
                                                                                Some(v11) => {
                                                                                    let m125 = {
                                                                                        let a123 = v9;
                                                                                        let a124 = 32u32;
                                                                                        fixed_u64::shift_right(a123, a124)
                                                                                    };
                                                                                    match m125 {
                                                                                        None => {
                                                                                            None::<Adt0>
                                                                                        }
                                                                                        Some(v12) => {
                                                                                            let m128 = {
                                                                                                let a126 = v11;
                                                                                                let a127 = 32u32;
                                                                                                fixed_u64::shift_right(a126, a127)
                                                                                            };
                                                                                            match m128 {
                                                                                                None => {
                                                                                                    None::<Adt0>
                                                                                                }
                                                                                                Some(v13) => {
                                                                                                    let m131 = {
                                                                                                        let a129 = v3;
                                                                                                        let a130 = v5;
                                                                                                        fixed_u64::checked_mul(a129, a130)
                                                                                                    };
                                                                                                    match m131 {
                                                                                                        None => {
                                                                                                            None::<Adt0>
                                                                                                        }
                                                                                                        Some(v14) => {
                                                                                                            let m134 = {
                                                                                                                let a132 = v14;
                                                                                                                let a133 = v12;
                                                                                                                fixed_u64::checked_add(a132, a133)
                                                                                                            };
                                                                                                            match m134 {
                                                                                                                None => {
                                                                                                                    None::<Adt0>
                                                                                                                }
                                                                                                                Some(v15) => {
                                                                                                                    let m137 = {
                                                                                                                        let a135 = v15;
                                                                                                                        let a136 = v13;
                                                                                                                        fixed_u64::checked_add(a135, a136)
                                                                                                                    };
                                                                                                                    match m137 {
                                                                                                                        None => {
                                                                                                                            None::<Adt0>
                                                                                                                        }
                                                                                                                        Some(v16) => {
                                                                                                                            let m140 = {
                                                                                                                                let a138 = v16;
                                                                                                                                let a139 = 32u32;
                                                                                                                                fixed_u64::shift_right(a138, a139)
                                                                                                                            };
                                                                                                                            match m140 {
                                                                                                                                None => {
                                                                                                                                    None::<Adt0>
                                                                                                                                }
                                                                                                                                Some(v17) => {
                                                                                                                                    let m143 = f3({
                                                                                                                                        let a141 = v6;
                                                                                                                                        let a142 = 4294967295u64;
                                                                                                                                        fixed_u64::bit_and(a141, a142)
                                                                                                                                    });
                                                                                                                                    match m143 {
                                                                                                                                        None => {
                                                                                                                                            None::<Adt0>
                                                                                                                                        }
                                                                                                                                        Some(v18) => {
                                                                                                                                            let m146 = f3({
                                                                                                                                                let a144 = v11;
                                                                                                                                                let a145 = 4294967295u64;
                                                                                                                                                fixed_u64::bit_and(a144, a145)
                                                                                                                                            });
                                                                                                                                            match m146 {
                                                                                                                                                None => {
                                                                                                                                                    None::<Adt0>
                                                                                                                                                }
                                                                                                                                                Some(v19) => {
                                                                                                                                                    let m149 = f3({
                                                                                                                                                        let a147 = v16;
                                                                                                                                                        let a148 = 4294967295u64;
                                                                                                                                                        fixed_u64::bit_and(a147, a148)
                                                                                                                                                    });
                                                                                                                                                    match m149 {
                                                                                                                                                        None => {
                                                                                                                                                            None::<Adt0>
                                                                                                                                                        }
                                                                                                                                                        Some(v20) => {
                                                                                                                                                            let m152 = f3({
                                                                                                                                                                let a150 = v17;
                                                                                                                                                                let a151 = 4294967295u64;
                                                                                                                                                                fixed_u64::bit_and(a150, a151)
                                                                                                                                                            });
                                                                                                                                                            match m152 {
                                                                                                                                                                None => {
                                                                                                                                                                    None::<Adt0>
                                                                                                                                                                }
                                                                                                                                                                Some(v21) => {
                                                                                                                                                                    Some(Adt0::C0(v18, v19, v20, v21))
                                                                                                                                                                }
                                                                                                                                                            }
                                                                                                                                                        }
                                                                                                                                                    }
                                                                                                                                                }
                                                                                                                                            }
                                                                                                                                        }
                                                                                                                                    }
                                                                                                                                }
                                                                                                                            }
                                                                                                                        }
                                                                                                                    }
                                                                                                                }
                                                                                                            }
                                                                                                        }
                                                                                                    }
                                                                                                }
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

pub fn f9(v0: Adt0) -> Option<i16> {
    let a154 = match v0.clone() {
        Adt0::C0(_, _, _, h153) => {
            h153
        }
    };
    let a155 = 0u32;
    if equal(a154, a155) {
        let a157 = match v0.clone() {
            Adt0::C0(_, _, h156, _) => {
                h156
            }
        };
        let a158 = 0u32;
        if equal(a157, a158) {
            let a160 = match v0.clone() {
                Adt0::C0(_, h159, _, _) => {
                    h159
                }
            };
            let a161 = 0u32;
            if equal(a160, a161) {
                f13(match v0 {
                    Adt0::C0(h162, _, _, _) => {
                        h162
                    }
                })
            } else {
                let m164 = f13(match v0 {
                    Adt0::C0(_, h163, _, _) => {
                        h163
                    }
                });
                match m164 {
                    None => {
                        None::<i16>
                    }
                    Some(v1) => {
                        f6(v1, 32i16)
                    }
                }
            }
        } else {
            let m166 = f13(match v0 {
                Adt0::C0(_, _, h165, _) => {
                    h165
                }
            });
            match m166 {
                None => {
                    None::<i16>
                }
                Some(v2) => {
                    f6(v2, 64i16)
                }
            }
        }
    } else {
        let m168 = f13(match v0 {
            Adt0::C0(_, _, _, h167) => {
                h167
            }
        });
        match m168 {
            None => {
                None::<i16>
            }
            Some(v3) => {
                f6(v3, 96i16)
            }
        }
    }
}

pub fn f10(v0: i16, v1: i16) -> bool {
    let m169 = f7(v0, v1);
    match m169 {
        None => {
            f14(v0)
        }
        Some(v2) => {
            f14(v2)
        }
    }
}

pub fn f11(v0: Adt0, v1: i16) -> Option<u64> {
    if f14(v1) {
        let m170 = f15(v1);
        match m170 {
            None => {
                None::<u64>
            }
            Some(v2) => {
                let m171 = f16(v2);
                match m171 {
                    None => {
                        None::<u64>
                    }
                    Some(v3) => {
                        let m172 = f17(v0);
                        match m172 {
                            None => {
                                None::<u64>
                            }
                            Some(v4) => {
                                let a173 = v4;
                                let a174 = v3;
                                fixed_u64::shift_left(a173, a174)
                            }
                        }
                    }
                }
            }
        }
    } else {
        if f10(128i16, v1) {
            Some(0u64)
        } else {
            let m175 = f18(v1);
            match m175 {
                None => {
                    None::<u64>
                }
                Some(v5) => {
                    let m217 = {
                        let m176 = Some(Adt1::C0(v0, false, false));
                        match m176 {
                            None => {
                                None::<Adt1>
                            }
                            Some(v6) => {
                                let m181 = {
                                    let a179 = {
                                        let a177 = v5;
                                        let a178 = 1u8;
                                        fixed_u8::bit_and(a177, a178)
                                    };
                                    let a180 = 0u8;
                                    if equal(a179, a180) {
                                        Some(v6)
                                    } else {
                                        f19(Some(v6))
                                    }
                                };
                                match m181 {
                                    None => {
                                        None::<Adt1>
                                    }
                                    Some(v7) => {
                                        let m186 = {
                                            let a184 = {
                                                let a182 = v5;
                                                let a183 = 2u8;
                                                fixed_u8::bit_and(a182, a183)
                                            };
                                            let a185 = 0u8;
                                            if equal(a184, a185) {
                                                Some(v7)
                                            } else {
                                                f20(Some(v7))
                                            }
                                        };
                                        match m186 {
                                            None => {
                                                None::<Adt1>
                                            }
                                            Some(v8) => {
                                                let m191 = {
                                                    let a189 = {
                                                        let a187 = v5;
                                                        let a188 = 4u8;
                                                        fixed_u8::bit_and(a187, a188)
                                                    };
                                                    let a190 = 0u8;
                                                    if equal(a189, a190) {
                                                        Some(v8)
                                                    } else {
                                                        f21(Some(v8))
                                                    }
                                                };
                                                match m191 {
                                                    None => {
                                                        None::<Adt1>
                                                    }
                                                    Some(v9) => {
                                                        let m196 = {
                                                            let a194 = {
                                                                let a192 = v5;
                                                                let a193 = 8u8;
                                                                fixed_u8::bit_and(a192, a193)
                                                            };
                                                            let a195 = 0u8;
                                                            if equal(a194, a195) {
                                                                Some(v9)
                                                            } else {
                                                                f22(Some(v9))
                                                            }
                                                        };
                                                        match m196 {
                                                            None => {
                                                                None::<Adt1>
                                                            }
                                                            Some(v10) => {
                                                                let m201 = {
                                                                    let a199 = {
                                                                        let a197 = v5;
                                                                        let a198 = 16u8;
                                                                        fixed_u8::bit_and(a197, a198)
                                                                    };
                                                                    let a200 = 0u8;
                                                                    if equal(a199, a200) {
                                                                        Some(v10)
                                                                    } else {
                                                                        f23(Some(v10))
                                                                    }
                                                                };
                                                                match m201 {
                                                                    None => {
                                                                        None::<Adt1>
                                                                    }
                                                                    Some(v11) => {
                                                                        let m206 = {
                                                                            let a204 = {
                                                                                let a202 = v5;
                                                                                let a203 = 32u8;
                                                                                fixed_u8::bit_and(a202, a203)
                                                                            };
                                                                            let a205 = 0u8;
                                                                            if equal(a204, a205) {
                                                                                Some(v11)
                                                                            } else {
                                                                                f24(Some(v11))
                                                                            }
                                                                        };
                                                                        match m206 {
                                                                            None => {
                                                                                None::<Adt1>
                                                                            }
                                                                            Some(v12) => {
                                                                                let m211 = {
                                                                                    let a209 = {
                                                                                        let a207 = v5;
                                                                                        let a208 = 64u8;
                                                                                        fixed_u8::bit_and(a207, a208)
                                                                                    };
                                                                                    let a210 = 0u8;
                                                                                    if equal(a209, a210) {
                                                                                        Some(v12)
                                                                                    } else {
                                                                                        f25(Some(v12))
                                                                                    }
                                                                                };
                                                                                match m211 {
                                                                                    None => {
                                                                                        None::<Adt1>
                                                                                    }
                                                                                    Some(v13) => {
                                                                                        let m216 = {
                                                                                            let a214 = {
                                                                                                let a212 = v5;
                                                                                                let a213 = 128u8;
                                                                                                fixed_u8::bit_and(a212, a213)
                                                                                            };
                                                                                            let a215 = 0u8;
                                                                                            if equal(a214, a215) {
                                                                                                Some(v13)
                                                                                            } else {
                                                                                                f26(Some(v13))
                                                                                            }
                                                                                        };
                                                                                        match m216 {
                                                                                            None => {
                                                                                                None::<Adt1>
                                                                                            }
                                                                                            Some(v14) => {
                                                                                                Some(v14)
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    };
                    match m217 {
                        None => {
                            None::<u64>
                        }
                        Some(v15) => {
                            let m219 = f17(match v15.clone() {
                                Adt1::C0(h218, _, _) => {
                                    h218
                                }
                            });
                            match m219 {
                                None => {
                                    None::<u64>
                                }
                                Some(v16) => {
                                    if if match v15.clone() {
                                        Adt1::C0(_, h220, _) => {
                                            h220
                                        }
                                    } {
                                        if match v15 {
                                            Adt1::C0(_, _, h221) => {
                                                h221
                                            }
                                        } {
                                            true
                                        } else {
                                            let a224 = {
                                                let a222 = v16;
                                                let a223 = 1u64;
                                                fixed_u64::bit_and(a222, a223)
                                            };
                                            let a225 = 1u64;
                                            equal(a224, a225)
                                        }
                                    } else {
                                        false
                                    } {
                                        let a226 = v16;
                                        let a227 = 1u64;
                                        fixed_u64::checked_add(a226, a227)
                                    } else {
                                        Some(v16)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

pub fn f12(v0: u64, v1: u64, v2: i16) -> Option<u64> {
    let v3: bool = {
        let a228 = v1;
        let a229 = 16777216u64;
        equal(a228, a229)
    };
    let m230 = if v3 {
        f6(v2, 1i16)
    } else {
        Some(v2)
    };
    match m230 {
        None => {
            None::<u64>
        }
        Some(v4) => {
            let m231 = if f10(v4, -126i16) {
                Some(if f27(v1, 8388608u64) {
                    0i16
                } else {
                    1i16
                })
            } else {
                f6(v4, 127i16)
            };
            match m231 {
                None => {
                    None::<u64>
                }
                Some(v5) => {
                    if f10(254i16, v5) {
                        Some({
                            let a232 = v0;
                            let a233 = 2139095040u64;
                            fixed_u64::bit_or(a232, a233)
                        })
                    } else {
                        let m236 = if v3 {
                            let a234 = v1;
                            let a235 = 1u32;
                            fixed_u64::shift_right(a234, a235)
                        } else {
                            Some(v1)
                        };
                        match m236 {
                            None => {
                                None::<u64>
                            }
                            Some(v6) => {
                                let m237 = f28(v5);
                                match m237 {
                                    None => {
                                        None::<u64>
                                    }
                                    Some(v7) => {
                                        let m240 = {
                                            let a238 = v7;
                                            let a239 = 23u32;
                                            fixed_u64::shift_left(a238, a239)
                                        };
                                        match m240 {
                                            None => {
                                                None::<u64>
                                            }
                                            Some(v8) => {
                                                Some({
                                                    let a245 = v0;
                                                    let a246 = {
                                                        let a243 = v8;
                                                        let a244 = {
                                                            let a241 = v6;
                                                            let a242 = 8388607u64;
                                                            fixed_u64::bit_and(a241, a242)
                                                        };
                                                        fixed_u64::bit_or(a243, a244)
                                                    };
                                                    fixed_u64::bit_or(a245, a246)
                                                })
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

pub fn f13(v0: u32) -> Option<i16> {
    let m247 = f29(Some(Adt2::C0(v0, 0i16)));
    match m247 {
        None => {
            None::<i16>
        }
        Some(v1) => {
            Some(match v1 {
                Adt2::C0(_, h248) => {
                    h248
                }
            })
        }
    }
}

pub fn f14(v0: i16) -> bool {
    let m249 = f30(v0);
    match m249 {
        None => {
            true
        }
        Some(_) => {
            false
        }
    }
}

pub fn f15(v0: i16) -> Option<i16> {
    let a250 = v0;
    checked_neg_i16(a250)
}

pub fn f16(v0: i16) -> Option<u32> {
    let a251 = v0;
    fixed_u32::convert(i128::from(a251))
}

pub fn f17(v0: Adt0) -> Option<u64> {
    let a253 = match v0.clone() {
        Adt0::C0(_, _, h252, _) => {
            h252
        }
    };
    let a254 = 0u32;
    if if equal(a253, a254) {
        let a256 = match v0.clone() {
            Adt0::C0(_, _, _, h255) => {
                h255
            }
        };
        let a257 = 0u32;
        equal(a256, a257)
    } else {
        false
    } {
        let m259 = f1(match v0.clone() {
            Adt0::C0(h258, _, _, _) => {
                h258
            }
        });
        match m259 {
            None => {
                None::<u64>
            }
            Some(v1) => {
                let m261 = f1(match v0 {
                    Adt0::C0(_, h260, _, _) => {
                        h260
                    }
                });
                match m261 {
                    None => {
                        None::<u64>
                    }
                    Some(v2) => {
                        let m264 = {
                            let a262 = v2;
                            let a263 = 32u32;
                            fixed_u64::shift_left(a262, a263)
                        };
                        match m264 {
                            None => {
                                None::<u64>
                            }
                            Some(v3) => {
                                Some({
                                    let a265 = v1;
                                    let a266 = v3;
                                    fixed_u64::bit_or(a265, a266)
                                })
                            }
                        }
                    }
                }
            }
        }
    } else {
        None::<u64>
    }
}

pub fn f18(v0: i16) -> Option<u8> {
    let a267 = v0;
    fixed_u8::convert(i128::from(a267))
}

pub fn f19(v0: Option<Adt1>) -> Option<Adt1> {
    let m268 = v0;
    match m268 {
        None => {
            None::<Adt1>
        }
        Some(v1) => {
            let m270 = f31(match v1.clone() {
                Adt1::C0(h269, _, _) => {
                    h269
                }
            });
            match m270 {
                None => {
                    None::<Adt1>
                }
                Some(v2) => {
                    Some(Adt1::C0(v2, {
                        let a276 = {
                            let a274 = {
                                let m273 = match v1.clone() {
                                    Adt1::C0(h272, _, _) => {
                                        h272
                                    }
                                };
                                match m273 {
                                    Adt0::C0(h271, _, _, _) => {
                                        h271
                                    }
                                }
                            };
                            let a275 = 1u32;
                            fixed_u32::bit_and(a274, a275)
                        };
                        let a277 = 1u32;
                        equal(a276, a277)
                    }, if match v1.clone() {
                        Adt1::C0(_, _, h278) => {
                            h278
                        }
                    } {
                        true
                    } else {
                        match v1 {
                            Adt1::C0(_, h279, _) => {
                                h279
                            }
                        }
                    }))
                }
            }
        }
    }
}

pub fn f20(v0: Option<Adt1>) -> Option<Adt1> {
    f19(f19(v0))
}

pub fn f21(v0: Option<Adt1>) -> Option<Adt1> {
    f20(f20(v0))
}

pub fn f22(v0: Option<Adt1>) -> Option<Adt1> {
    f21(f21(v0))
}

pub fn f23(v0: Option<Adt1>) -> Option<Adt1> {
    f22(f22(v0))
}

pub fn f24(v0: Option<Adt1>) -> Option<Adt1> {
    f23(f23(v0))
}

pub fn f25(v0: Option<Adt1>) -> Option<Adt1> {
    f24(f24(v0))
}

pub fn f26(v0: Option<Adt1>) -> Option<Adt1> {
    f25(f25(v0))
}

pub fn f27(v0: u64, v1: u64) -> bool {
    let m282 = {
        let a280 = v0;
        let a281 = v1;
        fixed_u64::checked_sub(a280, a281)
    };
    match m282 {
        None => {
            true
        }
        Some(_) => {
            false
        }
    }
}

pub fn f28(v0: i16) -> Option<u64> {
    let a283 = v0;
    fixed_u64::convert(i128::from(a283))
}

pub fn f29(v0: Option<Adt2>) -> Option<Adt2> {
    f32(f32(v0))
}

pub fn f30(v0: i16) -> Option<u16> {
    let a284 = v0;
    fixed_u16::convert(i128::from(a284))
}

pub fn f31(v0: Adt0) -> Option<Adt0> {
    let m288 = {
        let a286 = match v0.clone() {
            Adt0::C0(h285, _, _, _) => {
                h285
            }
        };
        let a287 = 1u32;
        fixed_u32::shift_right(a286, a287)
    };
    match m288 {
        None => {
            None::<Adt0>
        }
        Some(v1) => {
            let m292 = {
                let a290 = match v0.clone() {
                    Adt0::C0(_, h289, _, _) => {
                        h289
                    }
                };
                let a291 = 1u32;
                fixed_u32::shift_right(a290, a291)
            };
            match m292 {
                None => {
                    None::<Adt0>
                }
                Some(v2) => {
                    let m296 = {
                        let a294 = match v0.clone() {
                            Adt0::C0(_, _, h293, _) => {
                                h293
                            }
                        };
                        let a295 = 1u32;
                        fixed_u32::shift_right(a294, a295)
                    };
                    match m296 {
                        None => {
                            None::<Adt0>
                        }
                        Some(v3) => {
                            let m300 = {
                                let a298 = match v0.clone() {
                                    Adt0::C0(_, _, _, h297) => {
                                        h297
                                    }
                                };
                                let a299 = 1u32;
                                fixed_u32::shift_right(a298, a299)
                            };
                            match m300 {
                                None => {
                                    None::<Adt0>
                                }
                                Some(v4) => {
                                    let m306 = {
                                        let a304 = {
                                            let a302 = match v0.clone() {
                                                Adt0::C0(_, h301, _, _) => {
                                                    h301
                                                }
                                            };
                                            let a303 = 1u32;
                                            fixed_u32::bit_and(a302, a303)
                                        };
                                        let a305 = 31u32;
                                        fixed_u32::shift_left(a304, a305)
                                    };
                                    match m306 {
                                        None => {
                                            None::<Adt0>
                                        }
                                        Some(v5) => {
                                            let m312 = {
                                                let a310 = {
                                                    let a308 = match v0.clone() {
                                                        Adt0::C0(_, _, h307, _) => {
                                                            h307
                                                        }
                                                    };
                                                    let a309 = 1u32;
                                                    fixed_u32::bit_and(a308, a309)
                                                };
                                                let a311 = 31u32;
                                                fixed_u32::shift_left(a310, a311)
                                            };
                                            match m312 {
                                                None => {
                                                    None::<Adt0>
                                                }
                                                Some(v6) => {
                                                    let m318 = {
                                                        let a316 = {
                                                            let a314 = match v0 {
                                                                Adt0::C0(_, _, _, h313) => {
                                                                    h313
                                                                }
                                                            };
                                                            let a315 = 1u32;
                                                            fixed_u32::bit_and(a314, a315)
                                                        };
                                                        let a317 = 31u32;
                                                        fixed_u32::shift_left(a316, a317)
                                                    };
                                                    match m318 {
                                                        None => {
                                                            None::<Adt0>
                                                        }
                                                        Some(v7) => {
                                                            Some(Adt0::C0({
                                                                let a319 = v1;
                                                                let a320 = v5;
                                                                fixed_u32::bit_or(a319, a320)
                                                            }, {
                                                                let a321 = v2;
                                                                let a322 = v6;
                                                                fixed_u32::bit_or(a321, a322)
                                                            }, {
                                                                let a323 = v3;
                                                                let a324 = v7;
                                                                fixed_u32::bit_or(a323, a324)
                                                            }, v4))
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

pub fn f32(v0: Option<Adt2>) -> Option<Adt2> {
    f33(f33(v0))
}

pub fn f33(v0: Option<Adt2>) -> Option<Adt2> {
    f34(f34(v0))
}

pub fn f34(v0: Option<Adt2>) -> Option<Adt2> {
    f35(f35(v0))
}

pub fn f35(v0: Option<Adt2>) -> Option<Adt2> {
    f36(f36(v0))
}

pub fn f36(v0: Option<Adt2>) -> Option<Adt2> {
    let m325 = v0;
    match m325 {
        None => {
            None::<Adt2>
        }
        Some(v1) => {
            let m329 = {
                let a327 = match v1.clone() {
                    Adt2::C0(h326, _) => {
                        h326
                    }
                };
                let a328 = 1u32;
                fixed_u32::shift_right(a327, a328)
            };
            match m329 {
                None => {
                    None::<Adt2>
                }
                Some(v2) => {
                    let a331 = match v1.clone() {
                        Adt2::C0(h330, _) => {
                            h330
                        }
                    };
                    let a332 = 0u32;
                    if equal(a331, a332) {
                        Some(Adt2::C0(v2, match v1 {
                            Adt2::C0(_, h333) => {
                                h333
                            }
                        }))
                    } else {
                        let m335 = f6(match v1 {
                            Adt2::C0(_, h334) => {
                                h334
                            }
                        }, 1i16);
                        match m335 {
                            None => {
                                None::<Adt2>
                            }
                            Some(v3) => {
                                Some(Adt2::C0(v2, v3))
                            }
                        }
                    }
                }
            }
        }
    }
}

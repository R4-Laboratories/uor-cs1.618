module
public import Init
public import BoundedNumeric.Wide
set_option autoImplicit false
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000000
set_option linter.constructorNameAsVariable false
namespace BoundedNumeric.HelperControls

@[expose] public def signedLess (a : Int16) (b : Int16) : Bool := BoundedNumeric.Wide.signedLess (a) (b)

@[expose] public def lengthStep (state : Option (BoundedNumeric.Wide.LengthState)) : Option (BoundedNumeric.Wide.LengthState) := BoundedNumeric.Wide.lengthStep (state)

@[expose] public def length (a : UInt32) (b : UInt32) (c : UInt32) (d : UInt32) : Option (Int16) := BoundedNumeric.Wide.length (({ l0 := a, l1 := b, l2 := c, l3 := d } : BoundedNumeric.Wide.Limbs))

@[expose] public def round (a : UInt32) (b : UInt32) (c : UInt32) (d : UInt32) (amount : Int16) : Option (UInt64) := BoundedNumeric.Wide.round (({ l0 := a, l1 := b, l2 := c, l3 := d } : BoundedNumeric.Wide.Limbs)) (amount)

@[expose] public def multiply (a : UInt64) (b : UInt64) : Option (BoundedNumeric.Wide.Limbs) := BoundedNumeric.Wide.multiply (a) (b)

@[expose] public def unsignedLess (a : UInt64) (b : UInt64) : Bool := BoundedNumeric.Wide.unsignedLess (a) (b)

@[expose] public def convertUInt64ToUInt8 (value : UInt64) : Option (UInt8) := BoundedNumeric.Wide.convertUInt64ToUInt8 (value)

@[expose] public def convertUInt64ToUInt16 (value : UInt64) : Option (UInt16) := BoundedNumeric.Wide.convertUInt64ToUInt16 (value)

@[expose] public def convertUInt64ToUInt32 (value : UInt64) : Option (UInt32) := BoundedNumeric.Wide.convertUInt64ToUInt32 (value)

@[expose] public def convertUInt32ToUInt64 (value : UInt32) : Option (UInt64) := BoundedNumeric.Wide.convertUInt32ToUInt64 (value)

@[expose] public def convertUInt8ToInt16 (value : UInt8) : Option (Int16) := BoundedNumeric.Wide.convertUInt8ToInt16 (value)

@[expose] public def convertUInt16ToInt16 (value : UInt16) : Option (Int16) := BoundedNumeric.Wide.convertUInt16ToInt16 (value)

@[expose] public def convertInt16ToUInt8 (value : Int16) : Option (UInt8) := BoundedNumeric.Wide.convertInt16ToUInt8 (value)

@[expose] public def convertInt16ToUInt16 (value : Int16) : Option (UInt16) := BoundedNumeric.Wide.convertInt16ToUInt16 (value)

@[expose] public def convertInt16ToUInt32 (value : Int16) : Option (UInt32) := BoundedNumeric.Wide.convertInt16ToUInt32 (value)

@[expose] public def convertInt16ToUInt64 (value : Int16) : Option (UInt64) := BoundedNumeric.Wide.convertInt16ToUInt64 (value)

end BoundedNumeric.HelperControls

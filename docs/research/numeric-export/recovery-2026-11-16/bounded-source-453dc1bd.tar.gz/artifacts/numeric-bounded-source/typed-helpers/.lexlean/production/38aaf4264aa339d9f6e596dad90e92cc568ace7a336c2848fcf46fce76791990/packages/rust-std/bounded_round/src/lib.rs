#![forbid(unsafe_code)]
use core::cmp::Ordering;

use core::sync::atomic::{AtomicU64, Ordering as Memory};

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub struct Overflow;

pub type R<T> = Result<T, Overflow>;

static WORK: AtomicU64 = AtomicU64::new(0);

pub fn tick(units: u64) { WORK.fetch_add(units, Memory::Relaxed); }

pub fn work() -> u64 { WORK.load(Memory::Relaxed) }

pub trait Same {
    fn same(&self, other: &Self) -> bool;
}

pub trait Key {
    fn key(&self, other: &Self) -> Ordering;
}

impl Same for bool {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for bool {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u8 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u8 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u16 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u16 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u32 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u32 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u64 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u64 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i8 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i8 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i16 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i16 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i32 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i32 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i64 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i64 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for Ordering {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl<A: Key, B: Key> Key for (A, B) {
    fn key(&self, other: &Self) -> Ordering { match self.0.key(&other.0) { Ordering::Equal => self.1.key(&other.1), decided => decided, } }
}

pub fn equal<T: Same>(a: T, b: T) -> bool { a.same(&b) }

pub fn compare<T: Key>(a: T, b: T) -> Ordering { a.key(&b) }

pub fn nat_add(p0: u64, p1: u64) -> R<u64> {
    match u64::checked_add(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<u64, Overflow>(Overflow)
        }
    }
}

pub fn nat_sub(p0: u64, p1: u64) -> u64 {
    u64::saturating_sub(p0, p1)
}

pub fn nat_mul(p0: u64, p1: u64) -> R<u64> {
    match u64::checked_mul(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<u64, Overflow>(Overflow)
        }
    }
}

pub fn nat_quot(p0: u64, p1: u64, p2: u64) -> u64 {
    u64::checked_div(p0, p1).unwrap_or(p2)
}

pub fn nat_rem(p0: u64, p1: u64, p2: u64) -> u64 {
    u64::checked_rem(p0, p1).unwrap_or(p2)
}

pub fn nat_eq(p0: u64, p1: u64) -> bool {
    core::cmp::PartialEq::eq(&p0, &p1)
}

pub fn nat_le(p0: u64, p1: u64) -> bool {
    core::cmp::PartialOrd::le(&p0, &p1)
}

pub fn nat_lt(p0: u64, p1: u64) -> bool {
    core::cmp::PartialOrd::lt(&p0, &p1)
}

pub fn nat_succ(p0: u64) -> R<u64> {
    match u64::checked_add(p0, 1u64) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<u64, Overflow>(Overflow)
        }
    }
}

pub fn int_add(p0: i64, p1: i64) -> R<i64> {
    match i64::checked_add(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_sub(p0: i64, p1: i64) -> R<i64> {
    match i64::checked_sub(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_mul(p0: i64, p1: i64) -> R<i64> {
    match i64::checked_mul(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_neg(p0: i64) -> R<i64> {
    match i64::checked_neg(p0) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_quot(p0: i64, p1: i64, p2: i64) -> R<i64> {
    { let value = { let (a, b, z): (i64, i64, i64) = (p0, p1, p2); if b == 0 { Some(z) } else { a.checked_div(b) } }; match value {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    } }
}

pub fn int_rem(p0: i64, p1: i64, p2: i64) -> i64 {
    { let (a, b, z): (i64, i64, i64) = (p0, p1, p2); if b == 0 { z } else { a.wrapping_rem(b) } }
}

pub fn bool_not(p0: bool) -> bool {
    !p0
}

pub fn bool_and(p0: bool, p1: bool) -> bool {
    if p0 {
        p1
    } else {
        false
    }
}

pub fn bool_or(p0: bool, p1: bool) -> bool {
    if p0 {
        true
    } else {
        p1
    }
}

pub mod fixed_u8 {
    pub fn checked_add(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u8, p1: u8) -> u8 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u8, p1: u8) -> u8 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u8, p1: u8) -> u8 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u8) -> u8 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u8, p1: u32) -> Option<u8> {
        u8::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u8, p1: u32) -> Option<u8> {
        u8::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u8> {
        u8::try_from(p0).ok()
    }
}

pub mod fixed_u16 {
    pub fn checked_add(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u16, p1: u16) -> u16 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u16, p1: u16) -> u16 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u16, p1: u16) -> u16 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u16) -> u16 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u16, p1: u32) -> Option<u16> {
        u16::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u16, p1: u32) -> Option<u16> {
        u16::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u16> {
        u16::try_from(p0).ok()
    }
}

pub mod fixed_u32 {
    pub fn checked_add(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u32, p1: u32) -> u32 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u32, p1: u32) -> u32 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u32, p1: u32) -> u32 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u32) -> u32 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u32> {
        u32::try_from(p0).ok()
    }
}

pub mod fixed_u64 {
    pub fn checked_add(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u64, p1: u64) -> u64 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u64, p1: u64) -> u64 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u64, p1: u64) -> u64 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u64) -> u64 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u64, p1: u32) -> Option<u64> {
        u64::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u64, p1: u32) -> Option<u64> {
        u64::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u64> {
        u64::try_from(p0).ok()
    }
}

pub mod fixed_i8 {
    pub fn checked_add(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i8, p1: i8) -> i8 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i8, p1: i8) -> i8 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i8, p1: i8) -> i8 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i8) -> i8 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i8, p1: u32) -> Option<i8> {
        i8::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i8, p1: u32) -> Option<i8> {
        i8::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i8> {
        i8::try_from(p0).ok()
    }
}

pub fn checked_neg_i8(p0: i8) -> Option<i8> {
    i8::checked_neg(p0)
}

pub mod fixed_i16 {
    pub fn checked_add(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i16, p1: i16) -> i16 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i16, p1: i16) -> i16 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i16, p1: i16) -> i16 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i16) -> i16 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i16, p1: u32) -> Option<i16> {
        i16::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i16, p1: u32) -> Option<i16> {
        i16::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i16> {
        i16::try_from(p0).ok()
    }
}

pub fn checked_neg_i16(p0: i16) -> Option<i16> {
    i16::checked_neg(p0)
}

pub mod fixed_i32 {
    pub fn checked_add(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i32, p1: i32) -> i32 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i32, p1: i32) -> i32 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i32, p1: i32) -> i32 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i32) -> i32 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i32, p1: u32) -> Option<i32> {
        i32::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i32, p1: u32) -> Option<i32> {
        i32::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i32> {
        i32::try_from(p0).ok()
    }
}

pub fn checked_neg_i32(p0: i32) -> Option<i32> {
    i32::checked_neg(p0)
}

pub mod fixed_i64 {
    pub fn checked_add(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i64, p1: i64) -> i64 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i64, p1: i64) -> i64 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i64, p1: i64) -> i64 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i64) -> i64 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i64, p1: u32) -> Option<i64> {
        i64::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i64, p1: u32) -> Option<i64> {
        i64::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i64> {
        i64::try_from(p0).ok()
    }
}

pub fn checked_neg_i64(p0: i64) -> Option<i64> {
    i64::checked_neg(p0)
}
use core::str;

use std::mem;

use std::rc::Rc;

#[derive(Clone)]
pub struct Str(Rc<str>);

impl Str {
    pub fn lit(text: &str) -> Str { Str(Rc::from(text)) }
    pub fn text(&self) -> &str { &self.0 }
    pub fn length(&self) -> u64 { chars(&self.0) }
    pub fn utf8_encode(&self) -> Bytes { tick(self.0.len() as u64); Bytes::lit(self.0.as_bytes()) }
    pub fn split_exact(&self, delimiter: &Str, maximum: u32) -> Option<List<Str>> { if delimiter.0.is_empty() { return None; }; chars(&self.0); let mut fields: Vec<Str> = Vec::new(); for piece in self.0.split(&*delimiter.0) { fields.push(Str::lit(piece)); }; if fields.len() as u128 > u128::from(maximum) { return None; }; Some(List::onto(fields, List::nil())) }
    pub fn join(texts: List<Str>, delimiter: &Str) -> Str { let mut out = String::new(); let mut first = true; let mut cursor = &texts; while let Repr::Cell(cell) = &cursor.0 { tick(1); if !first { chars(&delimiter.0); out.push_str(&delimiter.0); }; first = false; chars(&cell.head.0); out.push_str(&cell.head.0); cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for text in buffer[..*len].iter().rev() { tick(1); if !first { chars(&delimiter.0); out.push_str(&delimiter.0); }; first = false; chars(&text.0); out.push_str(&text.0); } }, _ => { }, }; Str::lit(&out) }
}

#[derive(Clone)]
pub struct Bytes(Rc<[u8]>);

impl Bytes {
    pub fn lit(octets: &[u8]) -> Bytes { Bytes(Rc::from(octets)) }
    pub fn octets(&self) -> &[u8] { &self.0 }
    pub fn append(a: Bytes, b: Bytes) -> Bytes { tick((a.0.len() + b.0.len()) as u64); let mut out = Vec::with_capacity(a.0.len() + b.0.len()); out.extend_from_slice(&a.0); out.extend_from_slice(&b.0); Bytes(Rc::from(out)) }
    pub fn length(&self) -> u64 { self.0.len() as u64 }
    pub fn index(&self, i: u64) -> Option<u8> { match usize::try_from(i) { Ok(at) => self.0.get(at).copied(), Err(_) => None, } }
    pub fn slice(&self, start: u64, count: u64) -> Option<Bytes> { let end = u128::from(start) + u128::from(count); if end > self.0.len() as u128 { return None; }; tick(count); Some(Bytes::lit(&self.0[start as usize..end as usize])) }
    pub fn utf8_decode(&self) -> Option<Str> { tick(self.0.len() as u64); match str::from_utf8(&self.0) { Ok(text) => Some(Str::lit(text)), Err(_) => None, } }
    pub fn compare(&self, other: &Bytes) -> Ordering { tick(1 + self.0.len().min(other.0.len()) as u64); self.0.cmp(&other.0) }
}

pub struct Node<T> { head: T, tail: List<T> }

pub enum Repr<T> { Nil, Run { buffer: Rc<Vec<T>>, len: usize }, Cell(Rc<Node<T>>) }

pub struct List<T>(Repr<T>);

impl<T> Clone for List<T> {
    fn clone(&self) -> Self { List(match &self.0 { Repr::Nil => Repr::Nil, Repr::Run { buffer, len } => Repr::Run { buffer: buffer.clone(), len: *len }, Repr::Cell(cell) => Repr::Cell(cell.clone()), }) }
}

impl<T> List<T> {
    fn take(&mut self) -> Repr<T> { mem::replace(&mut self.0, Repr::Nil) }
}

impl<T> Drop for Node<T> {
    fn drop(&mut self) { let mut next = match self.tail.take() { Repr::Cell(cell) => Some(cell), _ => None, }; while let Some(cell) = next { match Rc::try_unwrap(cell) { Ok(mut node) => next = match node.tail.take() { Repr::Cell(cell) => Some(cell), _ => None, }, Err(_) => break, } } }
}

impl<T: Clone> List<T> {
    pub fn nil() -> Self { List(Repr::Nil) }
    pub fn cons(head: T, mut tail: List<T>) -> Self { List(match tail.take() { Repr::Nil => { let mut buffer = Vec::with_capacity(16); buffer.push(head); Repr::Run { buffer: Rc::new(buffer), len: 1 } }, Repr::Run { mut buffer, len } => { match Rc::get_mut(&mut buffer) { Some(cells) => { cells.truncate(len); cells.push(head); Repr::Run { buffer, len: len + 1 } }, None => Repr::Cell(Rc::new(Node { head, tail: List(Repr::Run { buffer, len }) })), } }, rest => Repr::Cell(Rc::new(Node { head, tail: List(rest) })), }) }
    pub fn uncons(&self) -> Option<(T, List<T>)> { match &self.0 { Repr::Nil => None, Repr::Run { buffer, len } => { let head = buffer[len - 1].clone(); Some((head, List(if *len == 1 { Repr::Nil } else { Repr::Run { buffer: buffer.clone(), len: len - 1 } }))) }, Repr::Cell(cell) => Some((cell.head.clone(), cell.tail.clone())), } }
    pub fn length(&self) -> u64 { let mut count = 0; let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); count += 1; cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for _ in buffer[..*len].iter().rev() { tick(1); count += 1; } }, _ => { }, }; count }
    pub fn append(a: List<T>, b: List<T>) -> List<T> { List::onto(a.items(), b) }
    pub fn index(&self, i: u64) -> Option<T> { let mut position = 0; let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); if position == i { return Some(cell.head.clone()); }; position += 1; cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for item in buffer[..*len].iter().rev() { tick(1); if position == i { return Some(item.clone()); }; position += 1; } }, _ => { }, }; None }
    pub fn slice(&self, start: u64, count: u64) -> Option<List<T>> { let end = u128::from(start) + u128::from(count); let mut part = Vec::new(); let mut position: u128 = 0; let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); if position >= end { return Some(List::onto(part, List::nil())); }; if position >= u128::from(start) { part.push(cell.head.clone()); }; position += 1; cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for item in buffer[..*len].iter().rev() { tick(1); if position >= end { return Some(List::onto(part, List::nil())); }; if position >= u128::from(start) { part.push(item.clone()); }; position += 1; } }, _ => { }, }; if position < end { None } else { Some(List::onto(part, List::nil())) } }
    fn items(&self) -> Vec<T> { let mut out = Vec::new(); let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); out.push(cell.head.clone()); cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for item in buffer[..*len].iter().rev() { tick(1); out.push(item.clone()); } }, _ => { }, }; out }
    fn onto(mut items: Vec<T>, tail: List<T>) -> List<T> { let mut out = tail; while let Some(item) = items.pop() { tick(1); out = List::cons(item, out); }; out }
}

pub fn chars(text: &str) -> u64 { let mut count = 0; for _ in text.chars() { tick(1); count += 1; }; count }

impl Same for Str {
    fn same(&self, other: &Self) -> bool { let mut left = self.0.chars(); let mut right = other.0.chars(); loop { tick(1); match (left.next(), right.next()) { (None, None) => return true, (a, b) if a != b => return false, _ => { }, } } }
}

impl Same for Bytes {
    fn same(&self, other: &Self) -> bool { tick(1 + self.0.len().min(other.0.len()) as u64); self.0 == other.0 }
}

impl Key for Str {
    fn key(&self, other: &Self) -> Ordering { let mut left = self.0.chars(); let mut right = other.0.chars(); loop { tick(1); match (left.next(), right.next()) { (None, None) => return Ordering::Equal, (None, Some(_)) => return Ordering::Less, (Some(_), None) => return Ordering::Greater, (Some(a), Some(b)) => match a.cmp(&b) { Ordering::Equal => { }, decided => return decided, }, } } }
}

pub fn canonical_decimal(text: &str) -> Option<Option<i128>> { let digits = match text.strip_prefix('-') { Some(rest) => rest, None => text, }; let mut canonical = !digits.is_empty() && (digits == "0" || !digits.starts_with('0')) && text != "-0"; for c in digits.chars() { tick(1); canonical = canonical && c.is_ascii_digit(); }; if !canonical { return None; }; Some(text.parse::<i128>().ok()) }

pub fn parse_int(text: Str) -> R<Option<i64>> { match canonical_decimal(&text.0) { None => Ok(None), Some(Some(n)) => match i64::try_from(n) { Ok(value) => Ok(Some(value)), Err(_) => Err(Overflow), }, Some(None) => Err(Overflow), } }

pub fn format_u8(a: u8) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u8(text: Str) -> Option<u8> { match canonical_decimal(&text.0) { Some(Some(n)) => u8::try_from(n).ok(), _ => None, } }

pub fn format_u16(a: u16) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u16(text: Str) -> Option<u16> { match canonical_decimal(&text.0) { Some(Some(n)) => u16::try_from(n).ok(), _ => None, } }

pub fn format_u32(a: u32) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u32(text: Str) -> Option<u32> { match canonical_decimal(&text.0) { Some(Some(n)) => u32::try_from(n).ok(), _ => None, } }

pub fn format_u64(a: u64) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u64(text: Str) -> Option<u64> { match canonical_decimal(&text.0) { Some(Some(n)) => u64::try_from(n).ok(), _ => None, } }

pub fn format_i8(a: i8) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i8(text: Str) -> Option<i8> { match canonical_decimal(&text.0) { Some(Some(n)) => i8::try_from(n).ok(), _ => None, } }

pub fn format_i16(a: i16) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i16(text: Str) -> Option<i16> { match canonical_decimal(&text.0) { Some(Some(n)) => i16::try_from(n).ok(), _ => None, } }

pub fn format_i32(a: i32) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i32(text: Str) -> Option<i32> { match canonical_decimal(&text.0) { Some(Some(n)) => i32::try_from(n).ok(), _ => None, } }

pub fn format_i64(a: i64) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i64(text: Str) -> Option<i64> { match canonical_decimal(&text.0) { Some(Some(n)) => i64::try_from(n).ok(), _ => None, } }

pub fn append_list<T: Clone>(p0: List<T>, p1: List<T>) -> List<T> {
    List::append(p0, p1)
}

pub fn length_list<T: Clone>(p0: List<T>) -> u64 {
    List::length(&p0)
}

pub fn index_list<T: Clone>(p0: List<T>, p1: u64) -> Option<T> {
    List::index(&p0, p1)
}

pub fn slice_list<T: Clone>(p0: List<T>, p1: u64, p2: u64) -> Option<List<T>> {
    List::slice(&p0, p1, p2)
}

pub fn append_bytes(p0: Bytes, p1: Bytes) -> Bytes {
    Bytes::append(p0, p1)
}

pub fn length_bytes(p0: Bytes) -> u64 {
    Bytes::length(&p0)
}

pub fn length_string(p0: Str) -> u64 {
    Str::length(&p0)
}

pub fn index_bytes(p0: Bytes, p1: u64) -> Option<u8> {
    Bytes::index(&p0, p1)
}

pub fn slice_bytes(p0: Bytes, p1: u64, p2: u64) -> Option<Bytes> {
    Bytes::slice(&p0, p1, p2)
}

pub fn utf8_encode(p0: Str) -> Bytes {
    Str::utf8_encode(&p0)
}

pub fn utf8_decode(p0: Bytes) -> Option<Str> {
    Bytes::utf8_decode(&p0)
}

pub fn compare_bytes(p0: Bytes, p1: Bytes) -> Ordering {
    Bytes::compare(&p0, &p1)
}

pub fn split_exact(p0: Str, p1: Str, p2: u32) -> Option<List<Str>> {
    Str::split_exact(&p0, &p1, p2)
}

pub fn join(p0: List<Str>, p1: Str) -> Str {
    Str::join(p0, &p1)
}

#[derive(Clone)]
pub enum Adt0 {
    C0(u32, u32, u32, u32),
}

#[derive(Clone)]
pub enum Adt1 {
    C0(Adt0, bool, bool),
}

pub fn f0(v0: u32, v1: u32, v2: u32, v3: u32, v4: i16) -> Option<u64> {
    f1(Adt0::C0(v0, v1, v2, v3), v4)
}

pub fn f1(v0: Adt0, v1: i16) -> Option<u64> {
    if f2(v1) {
        let m1 = f3(v1);
        match m1 {
            None => {
                None::<u64>
            }
            Some(v2) => {
                let m2 = f4(v2);
                match m2 {
                    None => {
                        None::<u64>
                    }
                    Some(v3) => {
                        let m3 = f5(v0);
                        match m3 {
                            None => {
                                None::<u64>
                            }
                            Some(v4) => {
                                let a4 = v4;
                                let a5 = v3;
                                fixed_u64::shift_left(a4, a5)
                            }
                        }
                    }
                }
            }
        }
    } else {
        if f6(128i16, v1) {
            Some(0u64)
        } else {
            let m6 = f7(v1);
            match m6 {
                None => {
                    None::<u64>
                }
                Some(v5) => {
                    let m48 = {
                        let m7 = Some(Adt1::C0(v0, false, false));
                        match m7 {
                            None => {
                                None::<Adt1>
                            }
                            Some(v6) => {
                                let m12 = {
                                    let a10 = {
                                        let a8 = v5;
                                        let a9 = 1u8;
                                        fixed_u8::bit_and(a8, a9)
                                    };
                                    let a11 = 0u8;
                                    if equal(a10, a11) {
                                        Some(v6)
                                    } else {
                                        f8(Some(v6))
                                    }
                                };
                                match m12 {
                                    None => {
                                        None::<Adt1>
                                    }
                                    Some(v7) => {
                                        let m17 = {
                                            let a15 = {
                                                let a13 = v5;
                                                let a14 = 2u8;
                                                fixed_u8::bit_and(a13, a14)
                                            };
                                            let a16 = 0u8;
                                            if equal(a15, a16) {
                                                Some(v7)
                                            } else {
                                                f9(Some(v7))
                                            }
                                        };
                                        match m17 {
                                            None => {
                                                None::<Adt1>
                                            }
                                            Some(v8) => {
                                                let m22 = {
                                                    let a20 = {
                                                        let a18 = v5;
                                                        let a19 = 4u8;
                                                        fixed_u8::bit_and(a18, a19)
                                                    };
                                                    let a21 = 0u8;
                                                    if equal(a20, a21) {
                                                        Some(v8)
                                                    } else {
                                                        f10(Some(v8))
                                                    }
                                                };
                                                match m22 {
                                                    None => {
                                                        None::<Adt1>
                                                    }
                                                    Some(v9) => {
                                                        let m27 = {
                                                            let a25 = {
                                                                let a23 = v5;
                                                                let a24 = 8u8;
                                                                fixed_u8::bit_and(a23, a24)
                                                            };
                                                            let a26 = 0u8;
                                                            if equal(a25, a26) {
                                                                Some(v9)
                                                            } else {
                                                                f11(Some(v9))
                                                            }
                                                        };
                                                        match m27 {
                                                            None => {
                                                                None::<Adt1>
                                                            }
                                                            Some(v10) => {
                                                                let m32 = {
                                                                    let a30 = {
                                                                        let a28 = v5;
                                                                        let a29 = 16u8;
                                                                        fixed_u8::bit_and(a28, a29)
                                                                    };
                                                                    let a31 = 0u8;
                                                                    if equal(a30, a31) {
                                                                        Some(v10)
                                                                    } else {
                                                                        f12(Some(v10))
                                                                    }
                                                                };
                                                                match m32 {
                                                                    None => {
                                                                        None::<Adt1>
                                                                    }
                                                                    Some(v11) => {
                                                                        let m37 = {
                                                                            let a35 = {
                                                                                let a33 = v5;
                                                                                let a34 = 32u8;
                                                                                fixed_u8::bit_and(a33, a34)
                                                                            };
                                                                            let a36 = 0u8;
                                                                            if equal(a35, a36) {
                                                                                Some(v11)
                                                                            } else {
                                                                                f13(Some(v11))
                                                                            }
                                                                        };
                                                                        match m37 {
                                                                            None => {
                                                                                None::<Adt1>
                                                                            }
                                                                            Some(v12) => {
                                                                                let m42 = {
                                                                                    let a40 = {
                                                                                        let a38 = v5;
                                                                                        let a39 = 64u8;
                                                                                        fixed_u8::bit_and(a38, a39)
                                                                                    };
                                                                                    let a41 = 0u8;
                                                                                    if equal(a40, a41) {
                                                                                        Some(v12)
                                                                                    } else {
                                                                                        f14(Some(v12))
                                                                                    }
                                                                                };
                                                                                match m42 {
                                                                                    None => {
                                                                                        None::<Adt1>
                                                                                    }
                                                                                    Some(v13) => {
                                                                                        let m47 = {
                                                                                            let a45 = {
                                                                                                let a43 = v5;
                                                                                                let a44 = 128u8;
                                                                                                fixed_u8::bit_and(a43, a44)
                                                                                            };
                                                                                            let a46 = 0u8;
                                                                                            if equal(a45, a46) {
                                                                                                Some(v13)
                                                                                            } else {
                                                                                                f15(Some(v13))
                                                                                            }
                                                                                        };
                                                                                        match m47 {
                                                                                            None => {
                                                                                                None::<Adt1>
                                                                                            }
                                                                                            Some(v14) => {
                                                                                                Some(v14)
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    };
                    match m48 {
                        None => {
                            None::<u64>
                        }
                        Some(v15) => {
                            let m50 = f5(match v15.clone() {
                                Adt1::C0(h49, _, _) => {
                                    h49
                                }
                            });
                            match m50 {
                                None => {
                                    None::<u64>
                                }
                                Some(v16) => {
                                    if if match v15.clone() {
                                        Adt1::C0(_, h51, _) => {
                                            h51
                                        }
                                    } {
                                        if match v15 {
                                            Adt1::C0(_, _, h52) => {
                                                h52
                                            }
                                        } {
                                            true
                                        } else {
                                            let a55 = {
                                                let a53 = v16;
                                                let a54 = 1u64;
                                                fixed_u64::bit_and(a53, a54)
                                            };
                                            let a56 = 1u64;
                                            equal(a55, a56)
                                        }
                                    } else {
                                        false
                                    } {
                                        let a57 = v16;
                                        let a58 = 1u64;
                                        fixed_u64::checked_add(a57, a58)
                                    } else {
                                        Some(v16)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

pub fn f2(v0: i16) -> bool {
    let m59 = f16(v0);
    match m59 {
        None => {
            true
        }
        Some(_) => {
            false
        }
    }
}

pub fn f3(v0: i16) -> Option<i16> {
    let a60 = v0;
    checked_neg_i16(a60)
}

pub fn f4(v0: i16) -> Option<u32> {
    let a61 = v0;
    fixed_u32::convert(i128::from(a61))
}

pub fn f5(v0: Adt0) -> Option<u64> {
    let a63 = match v0.clone() {
        Adt0::C0(_, _, h62, _) => {
            h62
        }
    };
    let a64 = 0u32;
    if if equal(a63, a64) {
        let a66 = match v0.clone() {
            Adt0::C0(_, _, _, h65) => {
                h65
            }
        };
        let a67 = 0u32;
        equal(a66, a67)
    } else {
        false
    } {
        let m69 = f17(match v0.clone() {
            Adt0::C0(h68, _, _, _) => {
                h68
            }
        });
        match m69 {
            None => {
                None::<u64>
            }
            Some(v1) => {
                let m71 = f17(match v0 {
                    Adt0::C0(_, h70, _, _) => {
                        h70
                    }
                });
                match m71 {
                    None => {
                        None::<u64>
                    }
                    Some(v2) => {
                        let m74 = {
                            let a72 = v2;
                            let a73 = 32u32;
                            fixed_u64::shift_left(a72, a73)
                        };
                        match m74 {
                            None => {
                                None::<u64>
                            }
                            Some(v3) => {
                                Some({
                                    let a75 = v1;
                                    let a76 = v3;
                                    fixed_u64::bit_or(a75, a76)
                                })
                            }
                        }
                    }
                }
            }
        }
    } else {
        None::<u64>
    }
}

pub fn f6(v0: i16, v1: i16) -> bool {
    let m77 = f18(v0, v1);
    match m77 {
        None => {
            f2(v0)
        }
        Some(v2) => {
            f2(v2)
        }
    }
}

pub fn f7(v0: i16) -> Option<u8> {
    let a78 = v0;
    fixed_u8::convert(i128::from(a78))
}

pub fn f8(v0: Option<Adt1>) -> Option<Adt1> {
    let m79 = v0;
    match m79 {
        None => {
            None::<Adt1>
        }
        Some(v1) => {
            let m81 = f19(match v1.clone() {
                Adt1::C0(h80, _, _) => {
                    h80
                }
            });
            match m81 {
                None => {
                    None::<Adt1>
                }
                Some(v2) => {
                    Some(Adt1::C0(v2, {
                        let a87 = {
                            let a85 = {
                                let m84 = match v1.clone() {
                                    Adt1::C0(h83, _, _) => {
                                        h83
                                    }
                                };
                                match m84 {
                                    Adt0::C0(h82, _, _, _) => {
                                        h82
                                    }
                                }
                            };
                            let a86 = 1u32;
                            fixed_u32::bit_and(a85, a86)
                        };
                        let a88 = 1u32;
                        equal(a87, a88)
                    }, if match v1.clone() {
                        Adt1::C0(_, _, h89) => {
                            h89
                        }
                    } {
                        true
                    } else {
                        match v1 {
                            Adt1::C0(_, h90, _) => {
                                h90
                            }
                        }
                    }))
                }
            }
        }
    }
}

pub fn f9(v0: Option<Adt1>) -> Option<Adt1> {
    f8(f8(v0))
}

pub fn f10(v0: Option<Adt1>) -> Option<Adt1> {
    f9(f9(v0))
}

pub fn f11(v0: Option<Adt1>) -> Option<Adt1> {
    f10(f10(v0))
}

pub fn f12(v0: Option<Adt1>) -> Option<Adt1> {
    f11(f11(v0))
}

pub fn f13(v0: Option<Adt1>) -> Option<Adt1> {
    f12(f12(v0))
}

pub fn f14(v0: Option<Adt1>) -> Option<Adt1> {
    f13(f13(v0))
}

pub fn f15(v0: Option<Adt1>) -> Option<Adt1> {
    f14(f14(v0))
}

pub fn f16(v0: i16) -> Option<u16> {
    let a91 = v0;
    fixed_u16::convert(i128::from(a91))
}

pub fn f17(v0: u32) -> Option<u64> {
    let a92 = v0;
    fixed_u64::convert(i128::from(a92))
}

pub fn f18(v0: i16, v1: i16) -> Option<i16> {
    let a93 = v0;
    let a94 = v1;
    fixed_i16::checked_sub(a93, a94)
}

pub fn f19(v0: Adt0) -> Option<Adt0> {
    let m98 = {
        let a96 = match v0.clone() {
            Adt0::C0(h95, _, _, _) => {
                h95
            }
        };
        let a97 = 1u32;
        fixed_u32::shift_right(a96, a97)
    };
    match m98 {
        None => {
            None::<Adt0>
        }
        Some(v1) => {
            let m102 = {
                let a100 = match v0.clone() {
                    Adt0::C0(_, h99, _, _) => {
                        h99
                    }
                };
                let a101 = 1u32;
                fixed_u32::shift_right(a100, a101)
            };
            match m102 {
                None => {
                    None::<Adt0>
                }
                Some(v2) => {
                    let m106 = {
                        let a104 = match v0.clone() {
                            Adt0::C0(_, _, h103, _) => {
                                h103
                            }
                        };
                        let a105 = 1u32;
                        fixed_u32::shift_right(a104, a105)
                    };
                    match m106 {
                        None => {
                            None::<Adt0>
                        }
                        Some(v3) => {
                            let m110 = {
                                let a108 = match v0.clone() {
                                    Adt0::C0(_, _, _, h107) => {
                                        h107
                                    }
                                };
                                let a109 = 1u32;
                                fixed_u32::shift_right(a108, a109)
                            };
                            match m110 {
                                None => {
                                    None::<Adt0>
                                }
                                Some(v4) => {
                                    let m116 = {
                                        let a114 = {
                                            let a112 = match v0.clone() {
                                                Adt0::C0(_, h111, _, _) => {
                                                    h111
                                                }
                                            };
                                            let a113 = 1u32;
                                            fixed_u32::bit_and(a112, a113)
                                        };
                                        let a115 = 31u32;
                                        fixed_u32::shift_left(a114, a115)
                                    };
                                    match m116 {
                                        None => {
                                            None::<Adt0>
                                        }
                                        Some(v5) => {
                                            let m122 = {
                                                let a120 = {
                                                    let a118 = match v0.clone() {
                                                        Adt0::C0(_, _, h117, _) => {
                                                            h117
                                                        }
                                                    };
                                                    let a119 = 1u32;
                                                    fixed_u32::bit_and(a118, a119)
                                                };
                                                let a121 = 31u32;
                                                fixed_u32::shift_left(a120, a121)
                                            };
                                            match m122 {
                                                None => {
                                                    None::<Adt0>
                                                }
                                                Some(v6) => {
                                                    let m128 = {
                                                        let a126 = {
                                                            let a124 = match v0 {
                                                                Adt0::C0(_, _, _, h123) => {
                                                                    h123
                                                                }
                                                            };
                                                            let a125 = 1u32;
                                                            fixed_u32::bit_and(a124, a125)
                                                        };
                                                        let a127 = 31u32;
                                                        fixed_u32::shift_left(a126, a127)
                                                    };
                                                    match m128 {
                                                        None => {
                                                            None::<Adt0>
                                                        }
                                                        Some(v7) => {
                                                            Some(Adt0::C0({
                                                                let a129 = v1;
                                                                let a130 = v5;
                                                                fixed_u32::bit_or(a129, a130)
                                                            }, {
                                                                let a131 = v2;
                                                                let a132 = v6;
                                                                fixed_u32::bit_or(a131, a132)
                                                            }, {
                                                                let a133 = v3;
                                                                let a134 = v7;
                                                                fixed_u32::bit_or(a133, a134)
                                                            }, v4))
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

pub fn run(p0: u32, p1: u32, p2: u32, p3: u32, p4: i16) -> Option<u64> {
    f0(p0, p1, p2, p3, p4)
}

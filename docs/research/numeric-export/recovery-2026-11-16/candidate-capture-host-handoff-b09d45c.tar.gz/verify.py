import ast,hashlib,json,os,pathlib,shutil,subprocess,yaml
folder=pathlib.Path(__file__).resolve().parent;game=pathlib.Path('/workspace/scratch/cs-numeric-kernels');source=pathlib.Path('/workspace/scratch/prismpm-numeric');env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'}
def sha(body):return hashlib.sha256(body).hexdigest()
def git(root,*args):return subprocess.check_output(['git','-C',str(root),*args],env=env).decode().strip()
owned=['.github/workflows/prismpm-candidate-capture-qualification.yml','scripts/numeric/candidate-capture-qualification.py','scripts/numeric/tests/test_candidate_capture_qualification.py']
assert set(git(game,'diff','--name-only').splitlines())==set(owned)
assert not git(game,'diff','--cached','--name-only')
for name in owned:
 if name.endswith('.py'):ast.parse((game/name).read_bytes(),filename=name)
steps=0
for job in yaml.load((game/owned[0]).read_text(),Loader=yaml.BaseLoader)['jobs'].values():
 for step in job['steps']:
  if 'run' in step:subprocess.run(['bash','-n'],input=step['run'].encode(),check=True);steps+=1
indexes={}
for directory,digest,count in [(folder.parent,'dbc44ad0a35c1813d404db09933dc769127418f59b1de6e87bca14e7a1d052fa',77),(folder.parent/'fix-1','31b0122ec142a3a4d78545101fa284ef343a51cbafb636212ef59f1ef79cf69a',51)]:
 body=(directory/'evidence-index.json').read_bytes();assert sha(body)==digest
 rows=json.loads(body)['files'];assert len(rows)==count
 for row in rows:
  content=(directory/row['path']).read_bytes();assert len(content)==row['bytes'] and sha(content)==row['sha256']
 indexes[str(directory)]={'index_sha256':digest,'files_unchanged':count}
original=json.loads((folder.parent/'18-commit-proof.json').read_text())
for name,row in original['owned_files'].items():
 if name not in owned:
  body=(game/name).read_bytes();assert len(body)==row['bytes'] and sha(body)==row['sha256']
actual={'source':git(source,'rev-parse','HEAD','HEAD^{tree}')+'\n','index_sha256':sha((source/'.git/index').read_bytes())}
assert actual==original['source_unchanged'] and git(source,'status','--porcelain=v1','--untracked-files=all')==''
logs=game/'docs/research/numeric-export/recovery-2026-11-16/ci-44081334047'
failed={}
for name,expected in [('full-run.log','69d1ce0040618999810ae3b5c4904bf70fed605c322e9d84728af023b855f1fd'),('failed-steps.log','786c16e3be7015a884f0eb5d355ccaf278708e88f2ca4864db778f37e7811992'),('completed-run.json','e5b7bd676d52f0c8025d4ae22edd9719d612f8f6aa1a1fa85ef8a2d5b28d38f3')]:
 body=(logs/name).read_bytes();assert sha(body)==expected;failed[name]={'bytes':len(body),'sha256':expected}
report={'scope':'host-handoff-components-only-no-privileged-local-witness-or-SDK','parent':git(game,'rev-parse','HEAD'),'owned_files':{name:{'bytes':(game/name).stat().st_size,'sha256':sha((game/name).read_bytes())} for name in owned},'source_unchanged':actual,'indexes_unchanged':indexes,'failed_run_unchanged':failed,'python_ast':'PASS','bash_steps':steps,'free_bytes':shutil.disk_usage(game).free}
assert report['free_bytes']>=8*1024**3
(folder/'09-preservation-proof.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))

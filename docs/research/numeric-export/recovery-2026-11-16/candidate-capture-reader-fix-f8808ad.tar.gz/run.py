import subprocess,json,time,sys,pathlib
root=pathlib.Path('/workspace/diagnostic-tools/candidate-capture-reader/fix-1')
name=sys.argv[1]; command=sys.argv[2:]; start=time.time()
with (root/(name+'.stdout')).open('wb') as out,(root/(name+'.stderr')).open('wb') as err:
 p=subprocess.run(command,stdout=out,stderr=err)
(root/(name+'.json')).write_text(json.dumps({'argv':command,'cwd':str(pathlib.Path.cwd()),'status':p.returncode,'elapsed_seconds':time.time()-start},sort_keys=True)+'\n')
print(name,p.returncode)
sys.exit(p.returncode)

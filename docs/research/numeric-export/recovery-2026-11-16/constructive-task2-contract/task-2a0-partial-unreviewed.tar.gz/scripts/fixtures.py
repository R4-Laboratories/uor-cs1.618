"""Only enumerated authored fixture inputs; no generated artifact copying."""
from pathlib import Path
import json
import hashlib
ROOT = Path('/workspace/diagnostic-tools/constructive-nat-task2a0')
SOURCE = Path('/workspace/diagnostic-tools/constructive-nat-task1/fixtures')
PINS = ['lean-toolchain', 'lakefile.toml', 'lake-manifest.json']
ROSTERS = {
 'positive': ('positive-direct', ['lexlean.toml','lexlean.lock']+PINS+['src/Bounds.lex.tex','src/Compatibility.lex.tex','src/Generic.lex.tex']),
 'zero': ('compat-v5-1.2-candidate', ['lexlean.toml','lexlean.lock']+PINS+['src/Compatibility.lex.tex'])}
ORDERING = r'''\begin{lexlean}{Ordering}
\useglossary{lexlean.std.nat@1.2.0}
\title{addition}
\begin{semanticmodule}
theorem{name: zLast, parameters: [x : Nat], statement: ((x <= 7) -> (x <= 8)), proof: linear_arithmetic{}, axioms: []}
realization{name: middleIdentity, input: {name: x, type: Nat}, output: Nat, descriptor: deterministic{body: x}, axioms: []}
theorem{name: aFirst, parameters: [x : Nat], statement: ((x <= 3) -> (x <= 4)), proof: linear_arithmetic{}, axioms: []}
\end{semanticmodule}
\end{lexlean}
'''
EXPECTED = {
 'positive': {'ConstructiveComponent.Bounds':['limbAddBound','cellAddBound','divDoubleRemainderBound','divReducedRemainderBound','divQuotientStepBound'], 'ConstructiveComponent.Generic':['renamedSum','reorderedTransitive','reversedEquality','scaleThree','rightEquality','constantCancellation','directStrict','closedMaximum','cycleTie'], 'ConstructiveComponent.Compatibility':[]},
 'zero': {'ConstructiveComponent.Compatibility':[]},
 'ordering': {'ConstructiveSnapshot.Ordering':['zLast','aFirst']}}
def populate():
    for label,(source,names) in ROSTERS.items():
        target=ROOT/'fixtures'/label
        (target/'src').mkdir(parents=True)
        for name in names:
            (target/name).write_bytes((SOURCE/source/name).read_bytes())
    target=ROOT/'fixtures/ordering';(target/'src').mkdir(parents=True)
    config=(ROOT/'fixtures/zero/lexlean.toml').read_text()
    config=config.replace('name = "constructive-nat-component"','name = "constructive-snapshot-ordering"').replace('module_prefix = "ConstructiveComponent"','module_prefix = "ConstructiveSnapshot"').replace('src/Compatibility.lex.tex','src/Ordering.lex.tex')
    (target/'lexlean.toml').write_text(config)
    (target/'src/Ordering.lex.tex').write_text(ORDERING)
    for name in PINS:(target/name).write_bytes((SOURCE/'compat-v5-1.2-candidate'/name).read_bytes())

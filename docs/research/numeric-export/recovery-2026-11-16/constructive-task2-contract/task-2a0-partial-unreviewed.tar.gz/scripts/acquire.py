"""Bounded local-unadmitted snapshot acquisition. No Cargo, network or cleanup."""
import argparse
import hashlib
import json
import os
import pathlib
import resource
import signal
import stat
import subprocess
import time
T=pathlib.Path('/workspace/diagnostic-tools/constructive-nat-task2a0')
P=pathlib.Path('/workspace/diagnostic-tools/constructive-nat-task1/package')
E=P.parent/'evidence'
D=pathlib.Path('/workspace/diagnostic-tools/lexlean-target/release')
R=pathlib.Path('/workspace/diagnostic-tools/rust-1.97.1')
CLI=D/'lexlean-constructive-diagnostic'
LIB=D/'deps/liblexlean_constructive_diagnostic-910ff143c3cac728.rlib'
CAM=D/'deps/libcamino-c62529521ef7b2c7.rlib'
ENV={'LC_ALL':'C','LANG':'C','HOME':str(T/'home'),'TMPDIR':str(T/'tmp'),'PATH':str(R/'bin')+':/usr/bin:/bin'}
F={};exec(compile((T/'scripts/fixtures.py').read_text(),str(T/'scripts/fixtures.py'),'exec'),F)
COMMANDS=[];PEAK={'rss':0,'growth':0,'log_bytes':0,'min_free':2**64};BASELINES={};TOOLS={};LIVE=None

def digest(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for chunk in iter(lambda:f.read(1048576),b''):h.update(chunk)
    return h.hexdigest()

def safe_record(path):
    path=pathlib.Path(path);anc=[]
    for q in [*reversed(path.parents),path]:
        s=q.lstat()
        if q!=path and not stat.S_ISDIR(s.st_mode):raise ValueError('non-directory ancestor '+str(q))
        anc.append([str(q),s.st_dev,s.st_ino,stat.S_IFMT(s.st_mode)])
    s=path.lstat()
    if not stat.S_ISREG(s.st_mode):raise ValueError('not regular '+str(path))
    return {'path':str(path),'kind':'regular','mode':oct(stat.S_IMODE(s.st_mode)),'bytes':s.st_size,'sha256':digest(path),'identity':[s.st_dev,s.st_ino],'ancestors':anc[:-1]}

def tool_record(path):
    path=pathlib.Path(path);r=safe_record(path.resolve());r['requested_path']=str(path);return r

def dump(name,obj):
    dest=T/'evidence'/name
    data=(json.dumps(obj,sort_keys=True,indent=2)+'\n').encode()
    if growth()+len(data)>112*1024**2:raise ValueError('evidence reserve exhausted')
    dest.write_bytes(data)

def growth():
    total=0
    for root,dirs,files in os.walk(T,followlinks=False):
        for name in dirs+files:
            q=pathlib.Path(root)/name;s=q.lstat()
            if stat.S_ISLNK(s.st_mode):raise ValueError('owned symlink '+str(q))
            if stat.S_ISREG(s.st_mode):total+=s.st_size
            elif not stat.S_ISDIR(s.st_mode):raise ValueError('owned special file '+str(q))
    # Packaging copies are small but belong to this operation too.
    g=pathlib.Path('/workspace/scratch/cs-numeric-kernels/scripts/numeric/constructive-proof-candidate/snapshot-acquisition')
    if g.exists():
        for q in g.iterdir():
            if q.is_file():total+=q.stat().st_size
    return total

def budget_reason(free,used,rss,elapsed,deadline):
    if free<8589934592+16777216:return 'disk-reserve'
    if used>=112*1024**2:return 'growth-stop'
    if rss>2147483648:return 'rss-stop'
    if elapsed>deadline:return 'deadline'
    return None

def headroom():
    mem={line.split(':')[0]:line.split(':')[1].strip() for line in pathlib.Path('/proc/meminfo').read_text().splitlines()}
    if int(mem['MemAvailable'].split()[0])*1024<4*1024**3:raise ValueError('host memory headroom')
    limit=pathlib.Path('/sys/fs/cgroup/memory.max').read_text().strip();current=int(pathlib.Path('/sys/fs/cgroup/memory.current').read_text())
    if limit!='max' and int(limit)-current<4*1024**3:raise ValueError('cgroup headroom')
    return {'MemAvailable':mem['MemAvailable'],'cgroup_max':limit,'cgroup_current':current}

def processes(group):
    rows=[]
    for q in pathlib.Path('/proc').iterdir():
        if not q.name.isdigit():continue
        try:
            a=(q/'stat').read_text();fields=a[a.rfind(')')+2:].split()
            if int(fields[2])!=group:continue
            rss=int(fields[21])*os.sysconf('SC_PAGE_SIZE')
            cmd=(q/'cmdline').read_bytes().split(b'\0')[:-1]
            exe=str((q/'exe').resolve())
            rows.append({'pid':int(q.name),'ppid':int(fields[1]),'rss':rss,'exe':exe,'argv':[x.decode('utf8','strict') for x in cmd]})
        except (FileNotFoundError,ProcessLookupError):continue
    return rows

def parse_trace(raw,tools,require_success=True):
    pending={};records=[];seen=set();terminal=set();parents={};execs=[]
    for line in raw.splitlines():
        if not line:continue
        if line.startswith('[pid '):
            end=line.index(']');pid=int(line[5:end].strip());body=line[end+1:].strip()
        else:
            prefix,space,body=line.partition(' ')
            if not prefix.isdigit():raise ValueError('unaccounted stderr line '+line[:160])
            pid=int(prefix);body=body.strip()
        seen.add(pid)
        if body.startswith('<... '):
            if pid not in pending:raise ValueError('resumed without start')
            name=body[5:body.index(' resumed>')]
            old=pending.pop(pid)
            if not old.startswith(name+'('):raise ValueError('resume syscall mismatch')
            body=old+body[body.index(' resumed>')+9:]
        if body.endswith('<unfinished ...>'):
            if pid in pending:raise ValueError('duplicate unfinished')
            pending[pid]=body[:-16];continue
        if body.startswith('+++ exited with ') or body.startswith('+++ killed by '):
            if pid in terminal:raise ValueError('duplicate terminal')
            terminal.add(pid);records.append({'pid':pid,'terminal':body});continue
        if body.startswith('--- SIG'):
            records.append({'pid':pid,'signal':body});continue
        name,sep,rest=body.partition('(')
        allowed={'execve','execveat','clone','clone3','fork','vfork','wait4','waitid','exit','exit_group','unshare','setns'}
        if not sep or name not in allowed:raise ValueError('unknown process event '+body[:160])
        # Reject abbreviation outside quoted strings; tolerate literal ellipses inside argv.
        scan=body;dec=json.JSONDecoder();outside=''
        while '"' in scan:
            i=scan.index('"');outside+=scan[:i]
            _,n=dec.raw_decode(scan[i:]);scan=scan[i+n:]
        if '...' in outside+scan:raise ValueError('truncated trace')
        if ' = ' not in body:raise ValueError('missing syscall result')
        result=body.rsplit(' = ',1)[1];row={'pid':pid,'syscall':name,'record':body}
        if name in {'clone','clone3','fork','vfork'}:
            child=int(result.split()[0])
            if child>0:
                if child in parents:raise ValueError('duplicate child')
                parents[child]=pid;row['child']=child
        if name in {'execve','execveat'}:
            if name!='execve':raise ValueError('unmodeled execveat')
            path,n=dec.raw_decode(rest);remain=rest[n:].lstrip(', ')
            argv,n=dec.raw_decode(remain);remain=remain[n:].lstrip(', ')
            env,n=dec.raw_decode(remain)
            if not isinstance(argv,list) or not isinstance(env,list):raise ValueError('argv/env not complete')
            success=result=='0'
            if success and path not in tools:raise ValueError('unmeasured executable '+path)
            item={'pid':pid,'path':path,'argv':argv,'environment':env,'success':success}
            execs.append(item);row['exec']=item
        records.append(row)
    if pending:raise ValueError('unfinished trace at EOF')
    roots=seen-set(parents)
    if len(roots)!=1 or seen!=terminal or set(parents.values())-seen:raise ValueError('incomplete lineage/terminal accounting')
    if require_success and (not execs or not execs[0]['success']):raise ValueError('root exec missing')
    return {'complete':True,'pids':sorted(seen),'root':next(iter(roots)),'parents':parents,'execs':execs,'records':records}

def freeze_tools():
    paths={R/'bin/rustc',CLI,LIB,CAM,pathlib.Path('/usr/bin/strace'),pathlib.Path('/usr/bin/python3'),pathlib.Path('/usr/bin/readelf'),pathlib.Path('/usr/bin/x86_64-linux-gnu-gcc-14'),pathlib.Path('/usr/bin/ld'),pathlib.Path('/usr/bin/x86_64-linux-gnu-ld'),pathlib.Path('/usr/bin/x86_64-linux-gnu-ld.bfd')}
    # Bind conservative dependency/fingerprint/sysroot sets in place, never copy them.
    for q in (D/'deps').iterdir():
        if q.suffix in {'.rlib','.rmeta','.so','.d'}:paths.add(q)
    for q in (D/'.fingerprint').rglob('*'):
        if q.is_file():paths.add(q)
    for root in [R/'lib',pathlib.Path('/usr/libexec/gcc/x86_64-linux-gnu/14'),pathlib.Path('/usr/lib/gcc/x86_64-linux-gnu/14')]:
        for q in root.rglob('*'):
            if q.is_file():paths.add(q)
    # Exact host runtime/CRT dependency identities, including linker runtime closure.
    todo=list(paths.intersection({R/'bin/rustc',CLI,pathlib.Path('/usr/bin/strace'),pathlib.Path('/usr/bin/python3'),pathlib.Path('/usr/bin/x86_64-linux-gnu-gcc-14'),pathlib.Path('/usr/libexec/gcc/x86_64-linux-gnu/14/collect2'),pathlib.Path('/usr/bin/ld')}))
    todo += [R/'lib/librustc_driver-832cf6cfb1386559.so',R/'lib/libLLVM.so.22.1-rust-1.97.1-stable']
    visited=set()
    while todo:
        q=todo.pop()
        if q in visited:continue
        visited.add(q);paths.add(q)
        out=subprocess.run(['/usr/bin/readelf','-d',str(q)],env=ENV,cwd=T,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True).stdout.decode()
        for line in out.splitlines():
            if '(NEEDED)' not in line:continue
            name=line.split('[')[1].split(']')[0]
            choices=[R/'lib'/name,pathlib.Path('/usr/lib/x86_64-linux-gnu')/name,pathlib.Path('/lib/x86_64-linux-gnu')/name]
            found=next((x for x in choices if x.exists()),None)
            if found is None:raise ValueError('missing runtime '+name)
            todo.append(found)
    for n in ['Scrt1.o','crti.o','crtn.o','libc.so','libc_nonshared.a','libgcc_s.so.1','ld-linux-x86-64.so.2']:
        q=pathlib.Path('/usr/lib/x86_64-linux-gnu')/n
        if q.exists():paths.add(q)
    return {str(q):tool_record(q) for q in sorted(paths,key=str)}

def fixture_inventory():
    rows=[]
    for label in F['EXPECTED']:
        root=T/'fixtures'/label
        if os.path.lexists(root/'lakefile.lean'):raise ValueError('second lake config')
        for q in sorted(root.rglob('*')):
            if '.lexlean' in q.relative_to(root).parts:continue
            if q.is_file() or q.is_symlink():rows.append(safe_record(q))
    return rows

def source_inventory():
    rows=[]
    for _,(label,names) in F['ROSTERS'].items():
        if os.path.lexists(F['SOURCE']/label/'lakefile.lean'):raise ValueError('source second lake config')
        for n in names:rows.append(safe_record(F['SOURCE']/label/n))
    return rows

def same(rows,held,identities=True):
    if len(rows)!=len(held):raise ValueError('inventory roster changed')
    for a,b in zip(rows,held):
        keys=['path','kind','bytes','sha256','mode']+(['identity','ancestors'] if identities else [])
        if any(a[k]!=b[k] for k in keys):raise ValueError('changed held input '+a['path'])

def recheck():
    same(source_inventory(),BASELINES['source'])
    for label in F['EXPECTED']:
        for pin in F['PINS']:
            q=T/'fixtures'/label/pin;a=safe_record(q);b=BASELINES['pins'][str(q)]
            if a!=b:raise ValueError('workspace pin changed '+str(q))
    for name,row in TOOLS.items():
        if tool_record(name)!=row:raise ValueError('tool changed '+name)

def run(label,argv,deadline,traced=False):
    global LIVE
    headroom();recheck();before=fixture_inventory();start=time.monotonic();stop=None;tree=[]
    outer=['/usr/bin/strace','-f','--always-show-pid','-q','-v','--kill-on-exit','-e','trace=process','-s','65536','--']+argv if traced else argv
    row={'label':label,'argv':argv,'effective_argv':outer,'environment':ENV,'cwd':str(T),'start':time.time(),'inputs_before':before}
    COMMANDS.append(row);dump('commands.json',COMMANDS)
    def child_limits():
        resource.setrlimit(resource.RLIMIT_CORE,(0,0));resource.setrlimit(resource.RLIMIT_FSIZE,(112*1024**2,112*1024**2))
    p=subprocess.Popen(outer,cwd=T,env=ENV,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True,preexec_fn=child_limits)
    LIVE=p
    streams=[(p.stdout,open(T/'evidence/logs'/f'{label}.stdout','wb')),(p.stderr,open(T/'evidence/logs'/f'{label}.stderr','wb'))]
    for inp,_ in streams:os.set_blocking(inp.fileno(),False)
    open_streams=list(streams)
    try:
        while open_streams or p.poll() is None:
            for inp,out in list(open_streams):
                try:data=os.read(inp.fileno(),65536)
                except BlockingIOError:continue
                if not data:open_streams.remove((inp,out));continue
                PEAK['log_bytes']+=len(data)
                if PEAK['log_bytes']>8*1024**2:stop='aggregate-log-cap';break
                out.write(data);out.flush()
            tree=processes(p.pid);rss=sum(x['rss'] for x in tree);used=growth();v=os.statvfs(T);free=v.f_bavail*v.f_frsize
            PEAK['rss']=max(PEAK['rss'],rss);PEAK['growth']=max(PEAK['growth'],used);PEAK['min_free']=min(PEAK['min_free'],free)
            reason=budget_reason(free,used,rss,time.monotonic()-start,deadline)
            if reason:stop=reason
            # Known paths are frozen before execution. The probe is added only after the link.
            for proc in tree:
                if proc['exe'] not in {v['path'] for v in TOOLS.values()} and proc['exe']!='':stop='unknown-live-executable '+proc['exe']
            if stop:
                os.killpg(p.pid,signal.SIGKILL);break
            time.sleep(0.1)
        p.wait(timeout=5)
    finally:
        if p.poll() is None:
            os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=5)
        for inp,out in streams:inp.close();out.close()
        LIVE=None
    survivors=processes(p.pid)
    row.update({'end':time.time(),'elapsed':time.monotonic()-start,'exit':p.returncode,'stop':stop,'survivors':survivors,'peak_so_far':dict(PEAK),'logs':{k:safe_record(T/'evidence/logs'/f'{label}.{k}') for k in ['stdout','stderr']}})
    if traced and not stop:
        row['trace']=parse_trace((T/'evidence/logs'/f'{label}.stderr').read_text(),TOOLS)
        if row['trace']['execs'][0]['argv']!=argv:raise ValueError('traced root argv mismatch')
        if dict(x.split('=',1) for x in row['trace']['execs'][0]['environment'])!=ENV:raise ValueError('traced root env mismatch')
    dump('commands.json',COMMANDS)
    if stop or p.returncode or survivors:raise ValueError('command failed '+label+': '+str(stop or p.returncode))
    recheck()
    return row

def verify_package():
    inv=json.loads((E/'fix1-component-inventory.json').read_text());rows=[]
    for x in inv['files']:
        r=safe_record(P/x['path'])
        if r['sha256']!=x['sha256'] or r['bytes']!=x['bytes'] or r['mode']!=x['mode']:raise ValueError('package inventory mismatch '+x['path'])
        rows.append(r)
    if CLI.stat().st_size!=60569368 or digest(CLI)!='b34b111b19e4bb35eaaff28abd2600fa48ede3c5c1e15cfa899f13bb1fc1fcd3':raise ValueError('CLI identity')
    for q,h in [(LIB,'e6caf694cb9cd41e6990d74d6d0f68166468581ae71b7c3dea75b1c69354a5ab'),(CAM,'958f2d24b78a6c139a1fb1800584be5459861696e9b668ec2145539c6ea01c6d')]:
        if digest(q)!=h:raise ValueError('rlib identity')
    return rows

def original_state():
    root='/workspace/scratch/prismpm-numeric';env=dict(ENV,GIT_OPTIONAL_LOCKS='0')
    out={}
    for label,args in [('head',['rev-parse','HEAD']),('status',['status','--porcelain'])]:
        p=subprocess.run(['/usr/bin/git','-C',root]+args,env=env,cwd=T,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True);out[label]=p.stdout.decode()
    if out['head'].strip()!='463177a0971d95e112e10ed5da39c8cbaf0a4c96' or out['status']:raise ValueError('original source dirty/changed')
    return out

def main():
    global TOOLS
    if (T/'evidence/result.json').exists() or (T/'evidence/failure.json').exists():raise ValueError('no retry of retained acquisition')
    v=os.statvfs(T)
    if v.f_bavail*v.f_frsize<8740929536:raise ValueError('launch disk floor plus allowance')
    memory=headroom();package=verify_package();original=original_state();BASELINES['source']=source_inventory()
    retained=json.loads((E/'fix1-retained-input-output-inventory.json').read_text())['files']
    for row in BASELINES['source']:
        rel=str(pathlib.Path(row['path']).relative_to(P.parent));match=[x for x in retained if x['path']==rel]
        if len(match)!=1 or match[0]['sha256']!=row['sha256'] or match[0]['bytes']!=row['bytes']:raise ValueError('frozen fixture attribution')
    F['populate']();BASELINES['pins']={str(T/'fixtures'/label/pin):safe_record(T/'fixtures'/label/pin) for label in F['EXPECTED'] for pin in F['PINS']}
    for label in F['EXPECTED']:
        source=F['SOURCE']/('positive-direct' if label=='positive' else 'compat-v5-1.2-candidate')
        for pin in F['PINS']:
            if (source/pin).read_bytes()!=(T/'fixtures'/label/pin).read_bytes():raise ValueError('copied workspace mismatch')
        if (T/'fixtures'/label/'lean-toolchain').read_bytes()!=b'leanprover/lean4:v4.32.1\n':raise ValueError('pinned toolchain bytes')
    authored=fixture_inventory()
    for row in authored:
        rel=pathlib.Path(row['path']).relative_to(T/'fixtures');dest=T/'evidence/authored-before'/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(pathlib.Path(row['path']).read_bytes())
    BASELINES['package']=package;BASELINES['original']=original
    dump('source-before.json',dict(BASELINES,fixtures=authored,expected=F['EXPECTED']))
    TOOLS=freeze_tools();dump('tools-before.json',TOOLS)
    dump('preflight.json',{'phase':'execution-ready','memory':memory,'free':v.f_bavail*v.f_frsize,'source_commit':original['head'].strip(),'expected':F['EXPECTED'],'owned_growth':growth(),'environment':ENV,'driver':safe_record(T/'src/snapshot_probe.rs')})
    args=[str(R/'bin/rustc'),'--edition=2024','--crate-name','constructive_snapshot_probe','-C','opt-level=1','-C','debuginfo=0','-C','linker=/usr/bin/x86_64-linux-gnu-gcc-14',str(T/'src/snapshot_probe.rs'),'--extern','lexlean_constructive_diagnostic='+str(LIB),'--extern','camino='+str(CAM),'-L','dependency='+str(D/'deps'),'-o',str(T/'bin/snapshot-probe')]
    run('link',args,180,True)
    probe=tool_record(T/'bin/snapshot-probe');TOOLS[str(T/'bin/snapshot-probe')]=probe
    batch=time.monotonic()
    for label in F['EXPECTED']:
        prefix=[str(CLI),'--project',str(T/'fixtures'/label/'lexlean.toml'),'--diagnostic-format','json','--color','never']
        for suffix,tail in [('lock',['lock']),('fmt',['fmt']),('lock-check',['lock','--check']),('check',['check']),('build',['build'])]:
            run(label+'-'+suffix,prefix+tail,120-(time.monotonic()-batch))
        run(label+'-snapshot',[str(T/'bin/snapshot-probe'),str(T/'fixtures'/label/'lexlean.toml'),str(T/'snapshots'/f'{label}.json'),str(T/'configs'/f'{label}.canonical.toml')],120-(time.monotonic()-batch))
    recheck();same(verify_package(),package);assert original_state()==original
    dump('source-after.json',{'source':source_inventory(),'fixtures':fixture_inventory(),'original':original,'package':verify_package()})
    dump('tools-after.json',{k:tool_record(k) for k in TOOLS})
    # Actual artifact validation/index is deliberately a separate finalization step.
    dump('result.json',{'status':'acquired-awaiting-index-validation','component_only':True,'peak':PEAK,'retained_growth':growth(),'batch_elapsed':time.monotonic()-batch,'probe':probe,'commands':len(COMMANDS)})

if __name__=='__main__':
    try:main()
    except BaseException as e:
        if LIVE is not None:
            try:os.killpg(LIVE.pid,signal.SIGKILL);LIVE.wait(timeout=5)
            except ProcessLookupError:pass
        dump('commands.json',COMMANDS)
        dump('failure.json',{'status':'FAILED','reason':str(e),'type':type(e).__name__,'peak':PEAK,'retained_growth':growth(),'time':time.time()})
        print('FAILED:',str(e));raise SystemExit(1)

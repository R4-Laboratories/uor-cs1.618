use std::{fs, thread};
use camino::Utf8Path;
use lexlean_constructive_diagnostic::{api::{Engine, CheckRequest, Selection}, project::Project};
fn run() -> Result<(), String> {
    let args: Vec<String> = std::env::args().collect();
    if args.len() != 4 { return Err("expected project, snapshot, canonical config".into()); }
    let root = "/workspace/diagnostic-tools/constructive-nat-task2a0";
    let label = ["positive", "zero", "ordering"].into_iter().find(|label|
        args[1] == format!("{root}/fixtures/{label}/lexlean.toml") &&
        args[2] == format!("{root}/snapshots/{label}.json") &&
        args[3] == format!("{root}/configs/{label}.canonical.toml")
    ).ok_or("outside fixed acquisition paths")?;
    let project = Project::load(Utf8Path::new(&args[1])).map_err(|e| format!("{e:?}"))?;
    let stack = project.config.limits.compile_stack_plan().stack_bytes;
    let config = project.config.canonical_toml().into_bytes();
    drop(project);
    let argv = args.clone();
    thread::Builder::new().name(format!("snapshot-{label}")).stack_size(stack).spawn(move || {
        let engine = Engine::load(Utf8Path::new(&argv[1])).map_err(|e| format!("{e:?}"))?;
        let snapshot = engine.snapshot(CheckRequest { selection: Selection::Entrypoints }).map_err(|e| format!("{e:?}"))?;
        let bytes = snapshot.canonical_bytes();
        if !bytes.ends_with(b"\n") || bytes.ends_with(b"\n\n") { return Err("canonical LF mismatch".into()); }
        fs::write(&argv[2], bytes).map_err(|e| e.to_string())?;
        fs::write(&argv[3], config).map_err(|e| e.to_string())?;
        drop(snapshot); drop(engine);
        Ok::<(), String>(())
    }).map_err(|e| e.to_string())?.join().map_err(|_| "snapshot worker panic".to_string())??;
    Ok(())
}
fn main() { if let Err(e) = run() { eprintln!("snapshot acquisition failed: {e}"); std::process::exit(1); } }

from pathlib import Path
import json
T=Path('/workspace/diagnostic-tools/constructive-nat-task2a0')
p=T/'scripts/acquire.py'
assert p.exists(), 'guarded acquisition owner must exist'
n={'__name__':'diagnostic_test'};exec(compile(p.read_text(),str(p),'exec'),n)
trace='10 execve("/usr/bin/true", ["/usr/bin/true"], ["LANG=C"]) = 0\n10 clone(child_stack=NULL, flags=SIGCHLD <unfinished ...>\n11 execve("/missing", ["/missing"], ["LANG=C"]) = -1 ENOENT (No such file or directory)\n10 <... clone resumed>) = 11\n11 exit_group(1) = ?\n11 +++ exited with 1 +++\n10 wait4(11, [{WIFEXITED(s) && WEXITSTATUS(s) == 1}], 0, NULL) = 11\n10 exit_group(0) = ?\n10 +++ exited with 0 +++\n'
a=n['parse_trace'](trace,{'/usr/bin/true':{}},False)
assert a['complete'] and len(a['pids'])==2 and a['execs'][1]['success']==False
for broken in [trace.replace('11 +++ exited with 1 +++\n',''),trace+'12 +++ exited with 0 +++\n',trace.replace('["LANG=C"]','["LANG=C", ...]'),trace.replace('wait4(11','mystery(11')]:
 try:n['parse_trace'](broken,{'/usr/bin/true':{}},False)
 except ValueError:pass
 else:raise AssertionError('incomplete/unknown/truncated trace accepted')
assert n['budget_reason'](8_589_934_592+16_777_216,112*1024**2-1,1,0,1)==None
assert n['budget_reason'](8_589_934_592,1,1,0,1)=='disk-reserve'
assert n['budget_reason'](9_000_000_000,112*1024**2,1,0,1)=='growth-stop'
assert n['budget_reason'](9_000_000_000,1,2_147_483_649,0,1)=='rss-stop'
assert n['budget_reason'](9_000_000_000,1,1,2,1)=='deadline'
assert n['safe_record'](T/'evidence/preflight.json')['kind']=='regular'
try:n['safe_record'](Path('/proc/self/exe'))
except ValueError:pass
else:raise AssertionError('symlink accepted')
print('PASS trace completeness, failed exec, unknown event, resource stops, no-follow')

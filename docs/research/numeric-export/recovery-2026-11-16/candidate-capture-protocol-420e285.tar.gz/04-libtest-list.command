target/debug/deps/prismpm-e88e534b42a91ec6 --list --format=terse

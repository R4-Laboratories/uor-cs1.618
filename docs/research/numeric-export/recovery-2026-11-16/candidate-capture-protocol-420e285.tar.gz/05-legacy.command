python3 -I -B scripts/conditional-capture-sdk.test.py /workspace/scratch/prismpm-numeric/target/debug/deps/prismpm-e88e534b42a91ec6

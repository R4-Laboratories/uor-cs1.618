import json, pathlib, subprocess, sys, time
root = pathlib.Path(__file__).parent
label, *arguments = sys.argv[1:]
started = time.time()
with (root / (label + '.stdout')).open('wb') as out, (root / (label + '.stderr')).open('wb') as err:
    result = subprocess.run(arguments, stdout=out, stderr=err)
record = {'argv': arguments, 'cwd': str(pathlib.Path.cwd()), 'status': result.returncode,
          'elapsed_seconds': time.time() - started, 'stdout': label + '.stdout', 'stderr': label + '.stderr'}
(root / (label + '.json')).write_text(json.dumps(record, sort_keys=True, indent=2) + '\n')
print(json.dumps(record, sort_keys=True))
raise SystemExit(result.returncode)

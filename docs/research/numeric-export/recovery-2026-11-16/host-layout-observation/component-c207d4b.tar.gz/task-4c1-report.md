# Task4c1 host-layout diagnostic implementation

Implemented and committed exactly the three new paths in the approved brief. Implementation commit: `c207d4b1f8b1bf4db7699a60ae8e579465573b0f`. The sole implementation slot is released after this report/index handoff. Independent implementation review is still required before any hosted diagnostic execution. No hosted execution, source admission, qualification success or privileged kernel witness is claimed.

## Delivered behavior

- Separate diagnostic-only workflow, fixed branch/repository guards, exact three-path push filter, input-free dispatch, existing checkout/upload pins, ten-minute ceiling, original `prepare --phase image` and scoped source chown. No cache, SDK, Docker, build, qualification or cleanup jobs. Observer always exits1; artifact upload requires only its typed `artifact_safe` Boolean.
- Independent closed new-workflow preparation authentication and bounded fixed game Git bytes. The old preparation validator, bridge/preflight ledger and original workflow/driver are untouched. Observer reads no source payloads and performs no source writes, access/creation probes, ACL changes or credential changes.
- Fixed81-node hosted closure,96-node pre-open bound, held no-follow metadata, distinct access/default ACL records, bounded native `/proc/self/fd` xattr reads, exact byte/hash/decoding retention, independent branches, explicit missing/future/blocked/unmeasured states, conditional socket alternatives and full identity/ctime/ACL rechecks.
- All observation/probe witness fields remain null and acceptance remains false. Static creation rules bind measured parent rows and actual original creation/chmod calls. ACL table omissions retain length/hash and force incompleteness within64KiB.
- Root request descriptor remains held and rejoined through publication. Root writes only exclusive `layout.json` through held U. Private supported ACLs, owner/mode/link checks, full ancestry joins and explicit intentional-create refresh boundaries protect publication. Actual runner read/hash, exclusive status write/readback, exact two-file inventory and output append/rejoin determine upload eligibility. Invalid or partial root publication is never replaced by fallback.
- One absolute charged deadline covers setup/authentication/Git/measurement/publication/readback; measurement stops at D−3, root alarm at D−1, runner at D. Control streams/status remain8KiB, complete layout64KiB, two-file total72KiB, charged below existing metadata/combined caps.

## Verification and retained failures

Final command: `python3 -B scripts/numeric/tests/test_host_layout_diagnostic.py -v`: **44 tests,43 passed,1 explicit skip**. Staged three-path `git diff --cached --check` passed before the `git commit --only` operation.

The suite covers exact closure/count and early limits; required/future absence and blocked descendants; continued traversal after a real default ACL; ACL exact bytes/hash/decoding, malformed data, ENODATA versus denied/unsupported, native growth/oversize and procfd failure; deduplication and omission of raw plus decoded expansion; timeout, ctime/ACL/leaf/parent races; fixed socket alternatives; publication exclusivity, aliases, hard links, wrong-owner reads, unsafe ACL, parent replacement and hash mismatch; actual ordinary-runner fallback, exact inventory and sole output; independent new-workflow authentication against an owned Git fixture with no source checkout; static creation rules and workflow restrictions.

Real Linux ACL syscalls ran only on owned temporary fixtures. The socket-alias mapping test explicitly projects only the fixture symlink UID to exercise the fixed root-owner condition; it is not a privilege witness. The privileged-host fixture explicitly skips because no local authorized sudo/root fixture exists. Actual root/nonzero-runner hosted behavior remains for independent review and the separately authorized diagnostic run.

The initial red run fails on the missing new observer (before implementation). Full runs1–2 retained three runner-test failures caused by the intentional evidence-directory nlink change during exclusive control-directory creation; explicit parent identity joins/refresh fixed this. Later full runs pass. The final conformance pass added held-request lifetime, full ancestry timestamps outside intentional creates, root hash-failure refusal and output append rejoin, then reran the full owned suite. No failure evidence was overwritten; successive full/final streams and exit lines are appended, with per-invocation commands/exits in `commands.jsonl`.

## Preservation and budget

Source remains clean `463177a0971d95e112e10ed5da39c8cbaf0a4c96`, tree `0990e900cf1cb5bb4a481bba781a86cc3fcf0999`, index SHA256 `b57cc2bd2190d7e5fa1cbb941b29eb22160d41aab91e63a4fdf48a601b3a9fb1`. Eight original driver/workflow/subject/probe/snapshot files and all288 files under the previous candidate-capture-qualification runtime evidence directory match baseline lengths/hashes. No existing implementation file, pin, source snapshot or previous runtime file changed.

Final pre-report check:8,975,151,104 free bytes (above8GiB);183,903 bytes of owned new implementation/evidence growth before this small report/index (well below32MiB). No network, pushes, Docker, builds, sudo installation, global environment changes or subagents ran. The unrelated existing untracked recovery `working/` directory was left untouched.

## Evidence handoff

Owned evidence root: `/workspace/diagnostic-tools/host-layout-diagnostic/`.

- `declaration.json`: declared layout before implementation.
- `baseline.json`: original implementation, source/index and288 previous-runtime file hashes.
- `commands.jsonl`: test/staging/commit/verification commands and exits.
- `runs/red.*`, `runs/focused.*`, `runs/full.*`, `runs/final.*`: raw stdout/stderr and exits, including failed runs; final stdout also contains preservation/budget/hash results and exact commit output.
- `fixtures/`: owned ephemeral ACL/Git/publication fixtures, cleaned after tests.
- `evidence-index.json`: exact retained file lengths/SHA256, implementation and canonical-report hashes.

No additional implementation repair or automatic hosted execution is authorized by this report. Review the three-file commit and its bounded metadata/publication contract independently.

from pathlib import Path
import subprocess,tempfile,hashlib,json,shutil
root=Path('/workspace/scratch/cs-numeric-kernels');source=Path('/workspace/scratch/prismpm-numeric');dest=root/'scripts/numeric/prismpm-capture-candidate'
base='3666dc0f9da56fcf066d96ec01cd9e14ec9a2974';rev='f292c7100874c0e0b2d1e0e81b27caeec8391f77';tree='d48cdfd94e6d46925e9269e364c2b7a6eb975d8a'
assert shutil.disk_usage(root).free>8*1024**3+32*1024**2
with tempfile.TemporaryDirectory() as temp:
 repo=Path(temp)/'bare';subprocess.run(['git','init','--bare',str(repo)],check=True,capture_output=True)
 objects=subprocess.check_output(['git','-C',str(source),'rev-parse','--path-format=absolute','--git-path','objects']).decode().strip()
 (repo/'objects/info/alternates').write_text(objects+'\n')
 def git(*args):return subprocess.check_output(['git','--git-dir',str(repo),*args])
 assert git('rev-parse',rev+'^{tree}').decode().strip()==tree
 git('update-ref','refs/heads/numeric-export-backport',rev)
 git('bundle','create',str(dest/'candidate.bundle'),base+'..refs/heads/numeric-export-backport')
 (dest/'candidate.patch').write_bytes(git('diff','--binary','--full-index','--no-ext-diff','--no-textconv','--no-renames',base,rev))
meta=dict(schema='cs1618/prismpm-diagnostic/1',source='https://github.com/UOR-Foundation/prismpm',base=base,candidate=rev,tree=tree)
for name in ['bundle','patch']:meta[name+'_sha256']=hashlib.sha256((dest/('candidate.'+name)).read_bytes()).hexdigest()
(dest/'manifest.json').write_text(json.dumps(meta,indent=2)+'\n')
s=(dest/'README.md').read_text().replace('331431bc6c2b71ca06d5e145d9e6a825f6218053',rev).replace('99915b2e2002f4c7bd2cd67d433e111af3141719',tree).replace('Task4a source','Task4a2 source');(dest/'README.md').write_text(s)
print(json.dumps(meta,indent=2))

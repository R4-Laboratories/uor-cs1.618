from pathlib import Path
import subprocess,tempfile,hashlib,json,shutil,os
root=Path('/workspace/scratch/cs-numeric-kernels');source=Path('/workspace/scratch/prismpm-numeric');evidence=Path(__file__).parent
assert shutil.disk_usage(root).free>=8*1024**3+512*1024**2
root_env={**os.environ,'GIT_OPTIONAL_LOCKS':'0','GIT_CONFIG_GLOBAL':'/dev/null','GIT_CONFIG_NOSYSTEM':'1','GIT_TERMINAL_PROMPT':'0'}
def git(repo,*args):return subprocess.check_output(['git','-c','core.hooksPath=/dev/null','-C',str(repo),*args],env=root_env)
index=Path(git(source,'rev-parse','--path-format=absolute','--git-path','index').decode().strip())
before={'source':git(source,'rev-parse','HEAD','HEAD^{tree}').decode(),'index_sha256':hashlib.sha256(index.read_bytes()).hexdigest()}
minimum=shutil.disk_usage(root).free
with tempfile.TemporaryDirectory(prefix='candidate-qualification-restoration-') as temporary:
 checkout=Path(temporary)/'checkout'
 subprocess.run(['git','init',str(checkout)],env=root_env,check=True,capture_output=True)
 objects=git(source,'rev-parse','--path-format=absolute','--git-path','objects').decode().strip()
 (checkout/'.git/objects/info/alternates').write_text(objects+'\n')
 git(checkout,'checkout','--detach','3666dc0f9da56fcf066d96ec01cd9e14ec9a2974')
 command=['python3','-I','-B',str(root/'scripts/numeric/restore-prismpm-candidate.py'),str(root/'scripts/numeric/prismpm-capture-candidate'),str(checkout)]
 result=subprocess.run(command,env=root_env,capture_output=True,check=True,timeout=120)
 (evidence/'10-original-restorer.stdout').write_bytes(result.stdout);(evidence/'10-original-restorer.stderr').write_bytes(result.stderr)
 assert git(checkout,'rev-parse','HEAD','HEAD^{tree}').decode()=='f292c7100874c0e0b2d1e0e81b27caeec8391f77\nd48cdfd94e6d46925e9269e364c2b7a6eb975d8a\n'
 assert not git(checkout,'status','--porcelain=v1','--untracked-files=all')
 # Actual checked-out authority and source entries equal their reviewed objects.
 for name in ['scripts/conditional-capture-candidate.py','scripts/conditional-capture-bootstrap.py','scripts/conditional-capture-sdk.py',
              'tests/publication-context-linkage/capture-owner.mjs','tests/publication-context-linkage/compile.mjs']:
  assert (checkout/name).read_bytes()==git(source,'show','f292c7100874c0e0b2d1e0e81b27caeec8391f77:'+name)
 minimum=min(minimum,shutil.disk_usage(root).free);assert minimum>=8*1024**3
 after={'source':git(source,'rev-parse','HEAD','HEAD^{tree}').decode(),'index_sha256':hashlib.sha256(index.read_bytes()).hexdigest()}
 assert before==after,'read-only source HEAD/tree/index must stay unchanged'
record={'scope':'actual-restoration-only-no-SDK','restorer_argv':command,'source_before':before,'source_after':after,'minimum_free_bytes':minimum,
        'restored_revision':'f292c7100874c0e0b2d1e0e81b27caeec8391f77','restored_tree':'d48cdfd94e6d46925e9269e364c2b7a6eb975d8a',
        'temporary_checkout_removed':not checkout.exists(),'free_after':shutil.disk_usage(root).free}
(evidence/'10-restoration-proof.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2))

"""In-memory deliberate defects in game code; no source or working-file edits."""
import hashlib,importlib.util,json,pathlib,sys,types,unittest
root=pathlib.Path('/workspace/scratch/cs-numeric-kernels/scripts/numeric');path=root/'candidate-capture-qualification.py'
original=path.read_bytes();text=original.decode();name=sys.argv[1]
choices={
 'late-fault':(" and isinstance(error,ControlledFault) and str(error)==FAULTS[id]",'',
               'EvidenceBoundaryControls','test_only_fully_validated_named_fault_can_finish_a_negative_scenario'),
 'uncertain':("retirement['uncertain'] is False",'True',
               'EvidenceBoundaryControls','test_uncertain_retirement_never_satisfies_negative_qualification'),
 'truncated-reference':("require(actual==value,'retained reference changed')","require(True,'retained reference changed')",
               'DriverContracts','test_real_files_reject_alias_hardlink_and_truncation'),
}
old,new,cls_name,test_name=choices[name];assert text.count(old)==1
changed=text.replace(old,new);module=types.ModuleType('planted_driver');module.__file__=str(path)
exec(compile(changed,str(path)+' [in-memory deliberate defect]','exec'),module.__dict__)
spec=importlib.util.spec_from_file_location('current_component_tests',root/'tests/test_candidate_capture_qualification.py')
tests=importlib.util.module_from_spec(spec);spec.loader.exec_module(tests)
cls=getattr(tests,cls_name);cls.setUpClass=classmethod(lambda cls:setattr(cls,'driver',module))
try:
 result=unittest.TextTestRunner(verbosity=2).run(unittest.TestSuite([cls(test_name)]))
 assert result.testsRun==1 and len(result.failures)==1 and not result.errors,'intended behavioral witness must fail'
finally:
 assert path.read_bytes()==original,'no working-file mutation permitted'
 record={'scope':'in-memory-planted-component-defect-only','name':name,'source_sha256':hashlib.sha256(original).hexdigest(),
         'mutant_sha256':hashlib.sha256(changed.encode()).hexdigest(),'working_bytes_unchanged':True,'test':cls_name+'.'+test_name}
 (pathlib.Path(__file__).parent/('planted-'+name+'.json')).write_text(json.dumps(record,indent=2)+'\n')
sys.exit(1)

import ast,hashlib,json,os,pathlib,shutil,subprocess
game=pathlib.Path('/workspace/scratch/cs-numeric-kernels');source=pathlib.Path('/workspace/scratch/prismpm-numeric');folder=pathlib.Path(__file__).parent
env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'}
def git(root,*args):return subprocess.check_output(['git','-C',str(root),*args],env=env).decode().strip()
def sha(body):return hashlib.sha256(body).hexdigest()
paths=['.github/workflows/prismpm-candidate-capture-qualification.yml','scripts/numeric/candidate-capture-qualification.py',
       'scripts/numeric/candidate-capture-probe.py','scripts/numeric/candidate-capture-subject.mjs',
       'scripts/numeric/tests/test_candidate_capture_qualification.py',*[f'scripts/numeric/prismpm-capture-candidate/{name}' for name in ['README.md','manifest.json','candidate.bundle','candidate.patch']]]
for path in paths:
    if path.endswith('.py'):ast.parse((game/path).read_bytes(),filename=path)
restoration=json.loads((folder/'10-restoration-proof.json').read_text())
actual={'source':git(source,'rev-parse','HEAD','HEAD^{tree}')+'\n','index_sha256':sha((source/'.git/index').read_bytes())}
assert actual==restoration['source_after']
assert git(source,'status','--porcelain=v1','--untracked-files=all')==''
assert sha((game/'scripts/numeric/restore-prismpm-candidate.py').read_bytes())=='90b1fe176eaa8eebb4eb6648363308b512d9ebfd649ca010d429eebc8379450d'
authority={}
for path in ['AGENTS.md','SPEC.md','scripts/conditional-capture-candidate.py','scripts/conditional-capture-sdk.py',
             'tests/browser-view/compiler-owner.mjs','tests/browser-view/compiler-artifact.mjs','tests/publication-context-linkage/capture-owner.mjs',
             'tests/publication-context-linkage/compile.mjs']:
    body=subprocess.check_output(['git','-C',str(source),'show','f292c710:'+path],env=env)
    authority[path]={'bytes':len(body),'sha256':sha(body),'git_blob':git(source,'rev-parse','f292c710:'+path)}
workflow=game/'.github/workflows/prismpm-backport-full-validation.yml';body=workflow.read_bytes()
record={'scope':'syntax-authority-and-protected-source-only-no-SDK','game_parent':git(game,'rev-parse','HEAD'),
        'game_parent_tree':git(game,'rev-parse','HEAD^{tree}'),'source_unchanged':actual,'source_status':'clean',
        'source_authority':authority,'cleanup_reference':{'path':str(workflow.relative_to(game)),'sha256':sha(body),'lines':'82-91',
         'exact_lines_sha256':sha(b''.join(body.splitlines(keepends=True)[81:91]))},
        'owned_files':{path:{'bytes':(game/path).stat().st_size,'sha256':sha((game/path).read_bytes())} for path in paths},
        'free_bytes':shutil.disk_usage(game).free}
assert record['free_bytes']>=8*1024**3
(folder/'13-final-authority-proof.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'python_syntax':'PASS','source':'unchanged clean463; snapshot remains f292','owned_paths':len(paths),'free_bytes':record['free_bytes']}))

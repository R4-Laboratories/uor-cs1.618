#![cfg_attr(not(feature = "std"), no_std)]
#![allow(dead_code, non_snake_case, unused_parens, unused_variables)]
extern crate alloc;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ComputeError {
    AddOverflow,
    MulOverflow,
    ShiftExponentTooLarge,
    ShiftOverflow,
    PowExponentTooLarge,
    PowOverflow,
    OutputTooSmall,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct LengthState {
    pub word: u32,
    pub count: i16,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct PUnit {
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Rounding {
    pub value: crate::Limbs,
    pub guard: bool,
    pub sticky: bool,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Limbs {
    pub l0: u32,
    pub l1: u32,
    pub l2: u32,
    pub l3: u32,
}

pub fn bits64(a: u64, b: u64) -> Option<u64> {
    { let _x_2 = (a ^ b); { let _x_416 = 9223372036854775808; { let sg = (_x_2 & _x_416); { let _x_418 = 4503599627370495; { let fa = (a & _x_418); { let fb = (b & _x_418); { let _x_556 = 52; { let _x_409 = (a).checked_shr(_x_556); match _x_409 {
        None => _x_409,
        Some(val_412) => { let _x_1813 = 52; { let _x_1814 = (b).checked_shr(_x_1813); match _x_1814 {
        None => _x_1814,
        Some(val_1817) => { let _x_1821 = 2047; { let ea = (val_412 & _x_1821); { let eb = (val_1817 & _x_1821); { let _x_1834 = (ea == _x_1821); match _x_1834 {
        false => { let _x_2118 = crate::PUnit {  }; { let _x_2119 = { let prod_local_0 = _x_2118; { let _x_1823 = false; _x_1823 } }; { let _y_1836 = _x_2119; match _y_1836 {
        false => { let _x_3037 = (eb == _x_1821); match _x_3037 {
        false => { let _x_3190 = crate::PUnit {  }; { let _x_3191 = { let prod_local_1 = _x_3190; { let prod_local_2 = false; prod_local_2 } }; { let _y_3039 = _x_3191; match _y_3039 {
        false => { let _y_3200 = match _x_1834 {
        false => { let _x_3339 = (eb == _x_1821); _x_3339 },
        true => { let _x_3340 = crate::PUnit {  }; { let _x_3341 = { let __1 = _x_3340; { let _x_3198 = true; _x_3198 } }; _x_3341 } },
    }; match _y_3200 {
        false => { let _x_3342 = 9223372036854775807; { let _x_3343 = (a & _x_3342); { let _x_3344 = 0; { let _x_3345 = (_x_3343 == _x_3344); { let _y_3347 = match _x_3345 {
        false => { let _x_3448 = 9223372036854775807; { let _x_3449 = (b & _x_3448); { let _x_3450 = 0; { let _x_3451 = (_x_3449 == _x_3450); _x_3451 } } } },
        true => { let _x_3452 = crate::PUnit {  }; { let _x_3453 = { let prod_local_3 = _x_3452; { let prod_local_4 = true; prod_local_4 } }; _x_3453 } },
    }; match _y_3347 {
        false => { let _x_3454 = (ea == _x_3344); { let _y_3456 = match _x_3454 {
        false => { let _x_3549 = false; _x_3549 },
        true => { let _x_3550 = true; _x_3550 },
    }; { let _y_3458 = match _y_3456 {
        false => { let _x_3546 = 4503599627370496; { let _x_3547 = (fa | _x_3546); _x_3547 } },
        true => fa,
    }; { let _x_3459 = (eb == _x_3344); { let _y_3461 = match _x_3459 {
        false => { let _x_3543 = false; _x_3543 },
        true => { let _x_3544 = true; _x_3544 },
    }; { let _y_3463 = match _y_3461 {
        false => { let _x_3540 = 4503599627370496; { let _x_3541 = (fb | _x_3540); _x_3541 } },
        true => fb,
    }; { let _x_3464 = convertUInt64ToUInt16(ea); match _x_3464 {
        None => None,
        Some(val_3466) => { let _x_3467 = convertUInt64ToUInt16(eb); match _x_3467 {
        None => None,
        Some(val_3469) => match _y_3456 {
        false => { let _x_3532 = convertUInt16ToInt16(val_3466); match _x_3532 {
        None => None,
        Some(val_3535) => { let val_3473 = val_3535; match _y_3461 {
        false => { let _x_3524 = convertUInt16ToInt16(val_3469); match _x_3524 {
        None => None,
        Some(val_3527) => { let val_3477 = val_3527; { let _x_3478 = int16Add(val_3473, val_3477); match _x_3478 {
        None => None,
        Some(val_3480) => { let _x_3481 = 2150; { let _x_3482 = _x_3481; { let _x_3483 = int16Subtract(val_3480, _x_3482); match _x_3483 {
        None => None,
        Some(val_3485) => { let _x_3486 = multiply(_y_3458, _y_3463); match _x_3486 {
        None => None,
        Some(val_3488) => { let _x_3489 = length(val_3488); match _x_3489 {
        None => None,
        Some(val_3491) => { let _x_3492 = 1; { let _x_3493 = _x_3492; { let _x_3494 = int16Subtract(val_3491, _x_3493); match _x_3494 {
        None => None,
        Some(val_3496) => { let _x_3497 = int16Add(val_3496, val_3485); match _x_3497 {
        None => None,
        Some(val_3499) => { let _x_3500 = 52; { let _x_3501 = _x_3500; { let _x_3502 = int16Subtract(val_3496, _x_3501); match _x_3502 {
        None => None,
        Some(val_3504) => { let _x_3505 = 1074; { let _x_3506 = _x_3505; { let _x_3507 = -(_x_3506); { let _x_3508 = int16Subtract(_x_3507, val_3485); match _x_3508 {
        None => None,
        Some(val_3510) => { let _x_3511 = signedLess(val_3504, val_3510); { let _y_3513 = match _x_3511 {
        false => { let _x_3521 = false; _x_3521 },
        true => { let _x_3522 = true; _x_3522 },
    }; { let _y_3515 = match _y_3513 {
        false => val_3504,
        true => val_3510,
    }; { let _x_3516 = round(val_3488, _y_3515); match _x_3516 {
        None => _x_3516,
        Some(val_3517) => { let _x_3518 = pack64(sg, val_3517, val_3499); _x_3518 },
    } } } } },
    } } } } },
    } } } },
    } },
    } } } },
    } },
    } },
    } } } },
    } } },
    } },
        true => { let _x_3529 = 1; { let _x_3530 = _x_3529; { let prod_local_5 = _x_3530; { let prod_local_6 = int16Add(val_3473, prod_local_5); match prod_local_6 {
        None => None,
        Some(prod_local_8) => { let prod_local_9 = 2150; { let prod_local_10 = prod_local_9; { let prod_local_11 = int16Subtract(prod_local_8, prod_local_10); match prod_local_11 {
        None => None,
        Some(prod_local_13) => { let prod_local_14 = multiply(_y_3458, _y_3463); match prod_local_14 {
        None => None,
        Some(prod_local_16) => { let prod_local_17 = length(prod_local_16); match prod_local_17 {
        None => None,
        Some(prod_local_19) => { let prod_local_20 = 1; { let prod_local_21 = prod_local_20; { let prod_local_22 = int16Subtract(prod_local_19, prod_local_21); match prod_local_22 {
        None => None,
        Some(prod_local_24) => { let prod_local_25 = int16Add(prod_local_24, prod_local_13); match prod_local_25 {
        None => None,
        Some(prod_local_27) => { let prod_local_28 = 52; { let prod_local_29 = prod_local_28; { let prod_local_30 = int16Subtract(prod_local_24, prod_local_29); match prod_local_30 {
        None => None,
        Some(prod_local_32) => { let prod_local_33 = 1074; { let prod_local_34 = prod_local_33; { let prod_local_35 = -(prod_local_34); { let prod_local_36 = int16Subtract(prod_local_35, prod_local_13); match prod_local_36 {
        None => None,
        Some(prod_local_38) => { let prod_local_39 = signedLess(prod_local_32, prod_local_38); { let prod_local_43 = match prod_local_39 {
        false => { let prod_local_41 = false; prod_local_41 },
        true => { let prod_local_42 = true; prod_local_42 },
    }; { let prod_local_45 = match prod_local_43 {
        false => prod_local_32,
        true => prod_local_38,
    }; { let prod_local_46 = round(prod_local_16, prod_local_45); match prod_local_46 {
        None => prod_local_46,
        Some(prod_local_47) => { let prod_local_48 = pack64(sg, prod_local_47, prod_local_27); prod_local_48 },
    } } } } },
    } } } } },
    } } } },
    } },
    } } } },
    } },
    } },
    } } } },
    } } } } },
    } },
    } },
        true => { let _x_3537 = 1; { let _x_3538 = _x_3537; { let prod_local_49 = _x_3538; match _y_3461 {
        false => { let prod_local_51 = convertUInt16ToInt16(val_3469); match prod_local_51 {
        None => None,
        Some(prod_local_53) => { let prod_local_54 = prod_local_53; { let prod_local_55 = int16Add(prod_local_49, prod_local_54); match prod_local_55 {
        None => None,
        Some(prod_local_57) => { let prod_local_58 = 2150; { let prod_local_59 = prod_local_58; { let prod_local_60 = int16Subtract(prod_local_57, prod_local_59); match prod_local_60 {
        None => None,
        Some(prod_local_62) => { let prod_local_63 = multiply(_y_3458, _y_3463); match prod_local_63 {
        None => None,
        Some(prod_local_65) => { let prod_local_66 = length(prod_local_65); match prod_local_66 {
        None => None,
        Some(prod_local_68) => { let prod_local_69 = 1; { let prod_local_70 = prod_local_69; { let prod_local_71 = int16Subtract(prod_local_68, prod_local_70); match prod_local_71 {
        None => None,
        Some(prod_local_73) => { let prod_local_74 = int16Add(prod_local_73, prod_local_62); match prod_local_74 {
        None => None,
        Some(prod_local_76) => { let prod_local_77 = 52; { let prod_local_78 = prod_local_77; { let prod_local_79 = int16Subtract(prod_local_73, prod_local_78); match prod_local_79 {
        None => None,
        Some(prod_local_81) => { let prod_local_82 = 1074; { let prod_local_83 = prod_local_82; { let prod_local_84 = -(prod_local_83); { let prod_local_85 = int16Subtract(prod_local_84, prod_local_62); match prod_local_85 {
        None => None,
        Some(prod_local_87) => { let prod_local_88 = signedLess(prod_local_81, prod_local_87); { let prod_local_92 = match prod_local_88 {
        false => { let prod_local_90 = false; prod_local_90 },
        true => { let prod_local_91 = true; prod_local_91 },
    }; { let prod_local_94 = match prod_local_92 {
        false => prod_local_81,
        true => prod_local_87,
    }; { let prod_local_95 = round(prod_local_65, prod_local_94); match prod_local_95 {
        None => prod_local_95,
        Some(prod_local_96) => { let prod_local_97 = pack64(sg, prod_local_96, prod_local_76); prod_local_97 },
    } } } } },
    } } } } },
    } } } },
    } },
    } } } },
    } },
    } },
    } } } },
    } } },
    } },
        true => { let prod_local_98 = 1; { let prod_local_99 = prod_local_98; { let prod_local_100 = prod_local_99; { let prod_local_101 = int16Add(prod_local_49, prod_local_100); match prod_local_101 {
        None => None,
        Some(prod_local_103) => { let prod_local_104 = 2150; { let prod_local_105 = prod_local_104; { let prod_local_106 = int16Subtract(prod_local_103, prod_local_105); match prod_local_106 {
        None => None,
        Some(prod_local_108) => { let prod_local_109 = multiply(_y_3458, _y_3463); match prod_local_109 {
        None => None,
        Some(prod_local_111) => { let prod_local_112 = length(prod_local_111); match prod_local_112 {
        None => None,
        Some(prod_local_114) => { let prod_local_115 = 1; { let prod_local_116 = prod_local_115; { let prod_local_117 = int16Subtract(prod_local_114, prod_local_116); match prod_local_117 {
        None => None,
        Some(prod_local_119) => { let prod_local_120 = int16Add(prod_local_119, prod_local_108); match prod_local_120 {
        None => None,
        Some(prod_local_122) => { let prod_local_123 = 52; { let prod_local_124 = prod_local_123; { let prod_local_125 = int16Subtract(prod_local_119, prod_local_124); match prod_local_125 {
        None => None,
        Some(prod_local_127) => { let prod_local_128 = 1074; { let prod_local_129 = prod_local_128; { let prod_local_130 = -(prod_local_129); { let prod_local_131 = int16Subtract(prod_local_130, prod_local_108); match prod_local_131 {
        None => None,
        Some(prod_local_133) => { let prod_local_134 = signedLess(prod_local_127, prod_local_133); { let prod_local_138 = match prod_local_134 {
        false => { let prod_local_136 = false; prod_local_136 },
        true => { let prod_local_137 = true; prod_local_137 },
    }; { let prod_local_140 = match prod_local_138 {
        false => prod_local_127,
        true => prod_local_133,
    }; { let prod_local_141 = round(prod_local_111, prod_local_140); match prod_local_141 {
        None => prod_local_141,
        Some(prod_local_142) => { let prod_local_143 = pack64(sg, prod_local_142, prod_local_122); prod_local_143 },
    } } } } },
    } } } } },
    } } } },
    } },
    } } } },
    } },
    } },
    } } } },
    } } } } },
    } } } },
    },
    } },
    } } } } } } } },
        true => { let _x_3553 = Some(sg); _x_3553 },
    } } } } } },
        true => { let _x_3554 = 9223372036854775807; { let _x_3555 = (a & _x_3554); { let _x_3556 = 0; { let _x_3557 = (_x_3555 == _x_3556); { let _y_3559 = match _x_3557 {
        false => { let _x_3572 = 9223372036854775807; { let _x_3573 = (b & _x_3572); { let _x_3574 = 0; { let _x_3575 = (_x_3573 == _x_3574); _x_3575 } } } },
        true => { let _x_3576 = crate::PUnit {  }; { let _x_3577 = { let prod_local_144 = _x_3576; { let prod_local_145 = true; prod_local_145 } }; _x_3577 } },
    }; { let _y_3561 = match _y_3559 {
        false => { let _x_3570 = false; _x_3570 },
        true => { let _x_3571 = true; _x_3571 },
    }; { let _y_3563 = match _y_3561 {
        false => { let _x_3566 = 9218868437227405312; { let _x_3567 = (sg | _x_3566); _x_3567 } },
        true => { let _x_3569 = 9221120237041090560; _x_3569 },
    }; { let _x_3564 = Some(_y_3563); _x_3564 } } } } } } } },
    } },
        true => { let _x_3578 = 2251799813685248; { let _x_3579 = (b | _x_3578); { let _x_3580 = Some(_x_3579); _x_3580 } } },
    } } } },
        true => { let _x_3194 = 0; { let _x_3195 = (fb == _x_3194); { let _y_3193 = match _x_3195 {
        false => _x_3037,
        true => _y_1836,
    }; { let prod_local_146 = _y_3193; match prod_local_146 {
        false => { let prod_local_154 = match _x_1834 {
        false => { let prod_local_149 = (eb == _x_1821); prod_local_149 },
        true => { let prod_local_150 = crate::PUnit {  }; { let prod_local_153 = { let prod_local_151 = prod_local_150; { let prod_local_152 = true; prod_local_152 } }; prod_local_153 } },
    }; match prod_local_154 {
        false => { let prod_local_155 = 9223372036854775807; { let prod_local_156 = (a & prod_local_155); { let prod_local_157 = 0; { let prod_local_158 = (prod_local_156 == prod_local_157); { let prod_local_168 = match prod_local_158 {
        false => { let prod_local_160 = 9223372036854775807; { let prod_local_161 = (b & prod_local_160); { let prod_local_162 = 0; { let prod_local_163 = (prod_local_161 == prod_local_162); prod_local_163 } } } },
        true => { let prod_local_164 = crate::PUnit {  }; { let prod_local_167 = { let prod_local_165 = prod_local_164; { let prod_local_166 = true; prod_local_166 } }; prod_local_167 } },
    }; match prod_local_168 {
        false => { let prod_local_169 = (ea == prod_local_157); { let prod_local_173 = match prod_local_169 {
        false => { let prod_local_171 = false; prod_local_171 },
        true => { let prod_local_172 = true; prod_local_172 },
    }; { let prod_local_177 = match prod_local_173 {
        false => { let prod_local_175 = 4503599627370496; { let prod_local_176 = (fa | prod_local_175); prod_local_176 } },
        true => fa,
    }; { let prod_local_178 = (eb == prod_local_157); { let prod_local_182 = match prod_local_178 {
        false => { let prod_local_180 = false; prod_local_180 },
        true => { let prod_local_181 = true; prod_local_181 },
    }; { let prod_local_186 = match prod_local_182 {
        false => { let prod_local_184 = 4503599627370496; { let prod_local_185 = (fb | prod_local_184); prod_local_185 } },
        true => fb,
    }; { let prod_local_187 = convertUInt64ToUInt16(ea); match prod_local_187 {
        None => None,
        Some(prod_local_189) => { let prod_local_190 = convertUInt64ToUInt16(eb); match prod_local_190 {
        None => None,
        Some(prod_local_192) => match prod_local_173 {
        false => { let prod_local_194 = convertUInt16ToInt16(prod_local_189); match prod_local_194 {
        None => None,
        Some(prod_local_196) => { let prod_local_197 = prod_local_196; match prod_local_182 {
        false => { let prod_local_199 = convertUInt16ToInt16(prod_local_192); match prod_local_199 {
        None => None,
        Some(prod_local_201) => { let prod_local_202 = prod_local_201; { let prod_local_203 = int16Add(prod_local_197, prod_local_202); match prod_local_203 {
        None => None,
        Some(prod_local_205) => { let prod_local_206 = 2150; { let prod_local_207 = prod_local_206; { let prod_local_208 = int16Subtract(prod_local_205, prod_local_207); match prod_local_208 {
        None => None,
        Some(prod_local_210) => { let prod_local_211 = multiply(prod_local_177, prod_local_186); match prod_local_211 {
        None => None,
        Some(prod_local_213) => { let prod_local_214 = length(prod_local_213); match prod_local_214 {
        None => None,
        Some(prod_local_216) => { let prod_local_217 = 1; { let prod_local_218 = prod_local_217; { let prod_local_219 = int16Subtract(prod_local_216, prod_local_218); match prod_local_219 {
        None => None,
        Some(prod_local_221) => { let prod_local_222 = int16Add(prod_local_221, prod_local_210); match prod_local_222 {
        None => None,
        Some(prod_local_224) => { let prod_local_225 = 52; { let prod_local_226 = prod_local_225; { let prod_local_227 = int16Subtract(prod_local_221, prod_local_226); match prod_local_227 {
        None => None,
        Some(prod_local_229) => { let prod_local_230 = 1074; { let prod_local_231 = prod_local_230; { let prod_local_232 = -(prod_local_231); { let prod_local_233 = int16Subtract(prod_local_232, prod_local_210); match prod_local_233 {
        None => None,
        Some(prod_local_235) => { let prod_local_236 = signedLess(prod_local_229, prod_local_235); { let prod_local_240 = match prod_local_236 {
        false => { let prod_local_238 = false; prod_local_238 },
        true => { let prod_local_239 = true; prod_local_239 },
    }; { let prod_local_242 = match prod_local_240 {
        false => prod_local_229,
        true => prod_local_235,
    }; { let prod_local_243 = round(prod_local_213, prod_local_242); match prod_local_243 {
        None => prod_local_243,
        Some(prod_local_244) => { let prod_local_245 = pack64(sg, prod_local_244, prod_local_224); prod_local_245 },
    } } } } },
    } } } } },
    } } } },
    } },
    } } } },
    } },
    } },
    } } } },
    } } },
    } },
        true => { let prod_local_246 = 1; { let prod_local_247 = prod_local_246; { let prod_local_248 = prod_local_247; { let prod_local_249 = int16Add(prod_local_197, prod_local_248); match prod_local_249 {
        None => None,
        Some(prod_local_251) => { let prod_local_252 = 2150; { let prod_local_253 = prod_local_252; { let prod_local_254 = int16Subtract(prod_local_251, prod_local_253); match prod_local_254 {
        None => None,
        Some(prod_local_256) => { let prod_local_257 = multiply(prod_local_177, prod_local_186); match prod_local_257 {
        None => None,
        Some(prod_local_259) => { let prod_local_260 = length(prod_local_259); match prod_local_260 {
        None => None,
        Some(prod_local_262) => { let prod_local_263 = 1; { let prod_local_264 = prod_local_263; { let prod_local_265 = int16Subtract(prod_local_262, prod_local_264); match prod_local_265 {
        None => None,
        Some(prod_local_267) => { let prod_local_268 = int16Add(prod_local_267, prod_local_256); match prod_local_268 {
        None => None,
        Some(prod_local_270) => { let prod_local_271 = 52; { let prod_local_272 = prod_local_271; { let prod_local_273 = int16Subtract(prod_local_267, prod_local_272); match prod_local_273 {
        None => None,
        Some(prod_local_275) => { let prod_local_276 = 1074; { let prod_local_277 = prod_local_276; { let prod_local_278 = -(prod_local_277); { let prod_local_279 = int16Subtract(prod_local_278, prod_local_256); match prod_local_279 {
        None => None,
        Some(prod_local_281) => { let prod_local_282 = signedLess(prod_local_275, prod_local_281); { let prod_local_286 = match prod_local_282 {
        false => { let prod_local_284 = false; prod_local_284 },
        true => { let prod_local_285 = true; prod_local_285 },
    }; { let prod_local_288 = match prod_local_286 {
        false => prod_local_275,
        true => prod_local_281,
    }; { let prod_local_289 = round(prod_local_259, prod_local_288); match prod_local_289 {
        None => prod_local_289,
        Some(prod_local_290) => { let prod_local_291 = pack64(sg, prod_local_290, prod_local_270); prod_local_291 },
    } } } } },
    } } } } },
    } } } },
    } },
    } } } },
    } },
    } },
    } } } },
    } } } } },
    } },
    } },
        true => { let prod_local_292 = 1; { let prod_local_293 = prod_local_292; { let prod_local_294 = prod_local_293; match prod_local_182 {
        false => { let prod_local_296 = convertUInt16ToInt16(prod_local_192); match prod_local_296 {
        None => None,
        Some(prod_local_298) => { let prod_local_299 = prod_local_298; { let prod_local_300 = int16Add(prod_local_294, prod_local_299); match prod_local_300 {
        None => None,
        Some(prod_local_302) => { let prod_local_303 = 2150; { let prod_local_304 = prod_local_303; { let prod_local_305 = int16Subtract(prod_local_302, prod_local_304); match prod_local_305 {
        None => None,
        Some(prod_local_307) => { let prod_local_308 = multiply(prod_local_177, prod_local_186); match prod_local_308 {
        None => None,
        Some(prod_local_310) => { let prod_local_311 = length(prod_local_310); match prod_local_311 {
        None => None,
        Some(prod_local_313) => { let prod_local_314 = 1; { let prod_local_315 = prod_local_314; { let prod_local_316 = int16Subtract(prod_local_313, prod_local_315); match prod_local_316 {
        None => None,
        Some(prod_local_318) => { let prod_local_319 = int16Add(prod_local_318, prod_local_307); match prod_local_319 {
        None => None,
        Some(prod_local_321) => { let prod_local_322 = 52; { let prod_local_323 = prod_local_322; { let prod_local_324 = int16Subtract(prod_local_318, prod_local_323); match prod_local_324 {
        None => None,
        Some(prod_local_326) => { let prod_local_327 = 1074; { let prod_local_328 = prod_local_327; { let prod_local_329 = -(prod_local_328); { let prod_local_330 = int16Subtract(prod_local_329, prod_local_307); match prod_local_330 {
        None => None,
        Some(prod_local_332) => { let prod_local_333 = signedLess(prod_local_326, prod_local_332); { let prod_local_337 = match prod_local_333 {
        false => { let prod_local_335 = false; prod_local_335 },
        true => { let prod_local_336 = true; prod_local_336 },
    }; { let prod_local_339 = match prod_local_337 {
        false => prod_local_326,
        true => prod_local_332,
    }; { let prod_local_340 = round(prod_local_310, prod_local_339); match prod_local_340 {
        None => prod_local_340,
        Some(prod_local_341) => { let prod_local_342 = pack64(sg, prod_local_341, prod_local_321); prod_local_342 },
    } } } } },
    } } } } },
    } } } },
    } },
    } } } },
    } },
    } },
    } } } },
    } } },
    } },
        true => { let prod_local_343 = 1; { let prod_local_344 = prod_local_343; { let prod_local_345 = prod_local_344; { let prod_local_346 = int16Add(prod_local_294, prod_local_345); match prod_local_346 {
        None => None,
        Some(prod_local_348) => { let prod_local_349 = 2150; { let prod_local_350 = prod_local_349; { let prod_local_351 = int16Subtract(prod_local_348, prod_local_350); match prod_local_351 {
        None => None,
        Some(prod_local_353) => { let prod_local_354 = multiply(prod_local_177, prod_local_186); match prod_local_354 {
        None => None,
        Some(prod_local_356) => { let prod_local_357 = length(prod_local_356); match prod_local_357 {
        None => None,
        Some(prod_local_359) => { let prod_local_360 = 1; { let prod_local_361 = prod_local_360; { let prod_local_362 = int16Subtract(prod_local_359, prod_local_361); match prod_local_362 {
        None => None,
        Some(prod_local_364) => { let prod_local_365 = int16Add(prod_local_364, prod_local_353); match prod_local_365 {
        None => None,
        Some(prod_local_367) => { let prod_local_368 = 52; { let prod_local_369 = prod_local_368; { let prod_local_370 = int16Subtract(prod_local_364, prod_local_369); match prod_local_370 {
        None => None,
        Some(prod_local_372) => { let prod_local_373 = 1074; { let prod_local_374 = prod_local_373; { let prod_local_375 = -(prod_local_374); { let prod_local_376 = int16Subtract(prod_local_375, prod_local_353); match prod_local_376 {
        None => None,
        Some(prod_local_378) => { let prod_local_379 = signedLess(prod_local_372, prod_local_378); { let prod_local_383 = match prod_local_379 {
        false => { let prod_local_381 = false; prod_local_381 },
        true => { let prod_local_382 = true; prod_local_382 },
    }; { let prod_local_385 = match prod_local_383 {
        false => prod_local_372,
        true => prod_local_378,
    }; { let prod_local_386 = round(prod_local_356, prod_local_385); match prod_local_386 {
        None => prod_local_386,
        Some(prod_local_387) => { let prod_local_388 = pack64(sg, prod_local_387, prod_local_367); prod_local_388 },
    } } } } },
    } } } } },
    } } } },
    } },
    } } } },
    } },
    } },
    } } } },
    } } } } },
    } } } },
    },
    } },
    } } } } } } } },
        true => { let prod_local_389 = Some(sg); prod_local_389 },
    } } } } } },
        true => { let prod_local_390 = 9223372036854775807; { let prod_local_391 = (a & prod_local_390); { let prod_local_392 = 0; { let prod_local_393 = (prod_local_391 == prod_local_392); { let prod_local_403 = match prod_local_393 {
        false => { let prod_local_395 = 9223372036854775807; { let prod_local_396 = (b & prod_local_395); { let prod_local_397 = 0; { let prod_local_398 = (prod_local_396 == prod_local_397); prod_local_398 } } } },
        true => { let prod_local_399 = crate::PUnit {  }; { let prod_local_402 = { let prod_local_400 = prod_local_399; { let prod_local_401 = true; prod_local_401 } }; prod_local_402 } },
    }; { let prod_local_407 = match prod_local_403 {
        false => { let prod_local_405 = false; prod_local_405 },
        true => { let prod_local_406 = true; prod_local_406 },
    }; { let prod_local_412 = match prod_local_407 {
        false => { let prod_local_409 = 9218868437227405312; { let prod_local_410 = (sg | prod_local_409); prod_local_410 } },
        true => { let prod_local_411 = 9221120237041090560; prod_local_411 },
    }; { let prod_local_413 = Some(prod_local_412); prod_local_413 } } } } } } } },
    } },
        true => { let prod_local_414 = 2251799813685248; { let prod_local_415 = (b | prod_local_414); { let prod_local_416 = Some(prod_local_415); prod_local_416 } } },
    } } } } },
    } },
        true => { let _x_3581 = 2251799813685248; { let _x_3582 = (a | _x_3581); { let _x_3583 = Some(_x_3582); _x_3583 } } },
    } } } },
        true => { let _x_3031 = 0; { let _x_3032 = (fa == _x_3031); { let _y_3035 = match _x_3032 {
        false => _x_1834,
        true => { let _x_3034 = false; _x_3034 },
    }; { let prod_local_417 = _y_3035; match prod_local_417 {
        false => { let prod_local_418 = (eb == _x_1821); match prod_local_418 {
        false => { let prod_local_420 = crate::PUnit {  }; { let prod_local_423 = { let prod_local_421 = prod_local_420; { let prod_local_422 = false; prod_local_422 } }; { let prod_local_424 = prod_local_423; match prod_local_424 {
        false => { let prod_local_432 = match _x_1834 {
        false => { let prod_local_427 = (eb == _x_1821); prod_local_427 },
        true => { let prod_local_428 = crate::PUnit {  }; { let prod_local_431 = { let prod_local_429 = prod_local_428; { let prod_local_430 = true; prod_local_430 } }; prod_local_431 } },
    }; match prod_local_432 {
        false => { let prod_local_433 = 9223372036854775807; { let prod_local_434 = (a & prod_local_433); { let prod_local_435 = 0; { let prod_local_436 = (prod_local_434 == prod_local_435); { let prod_local_446 = match prod_local_436 {
        false => { let prod_local_438 = 9223372036854775807; { let prod_local_439 = (b & prod_local_438); { let prod_local_440 = 0; { let prod_local_441 = (prod_local_439 == prod_local_440); prod_local_441 } } } },
        true => { let prod_local_442 = crate::PUnit {  }; { let prod_local_445 = { let prod_local_443 = prod_local_442; { let prod_local_444 = true; prod_local_444 } }; prod_local_445 } },
    }; match prod_local_446 {
        false => { let prod_local_447 = (ea == prod_local_435); { let prod_local_451 = match prod_local_447 {
        false => { let prod_local_449 = false; prod_local_449 },
        true => { let prod_local_450 = true; prod_local_450 },
    }; { let prod_local_455 = match prod_local_451 {
        false => { let prod_local_453 = 4503599627370496; { let prod_local_454 = (fa | prod_local_453); prod_local_454 } },
        true => fa,
    }; { let prod_local_456 = (eb == prod_local_435); { let prod_local_460 = match prod_local_456 {
        false => { let prod_local_458 = false; prod_local_458 },
        true => { let prod_local_459 = true; prod_local_459 },
    }; { let prod_local_464 = match prod_local_460 {
        false => { let prod_local_462 = 4503599627370496; { let prod_local_463 = (fb | prod_local_462); prod_local_463 } },
        true => fb,
    }; { let prod_local_465 = convertUInt64ToUInt16(ea); match prod_local_465 {
        None => None,
        Some(prod_local_467) => { let prod_local_468 = convertUInt64ToUInt16(eb); match prod_local_468 {
        None => None,
        Some(prod_local_470) => match prod_local_451 {
        false => { let prod_local_472 = convertUInt16ToInt16(prod_local_467); match prod_local_472 {
        None => None,
        Some(prod_local_474) => { let prod_local_475 = prod_local_474; match prod_local_460 {
        false => { let prod_local_477 = convertUInt16ToInt16(prod_local_470); match prod_local_477 {
        None => None,
        Some(prod_local_479) => { let prod_local_480 = prod_local_479; { let prod_local_481 = int16Add(prod_local_475, prod_local_480); match prod_local_481 {
        None => None,
        Some(prod_local_483) => { let prod_local_484 = 2150; { let prod_local_485 = prod_local_484; { let prod_local_486 = int16Subtract(prod_local_483, prod_local_485); match prod_local_486 {
        None => None,
        Some(prod_local_488) => { let prod_local_489 = multiply(prod_local_455, prod_local_464); match prod_local_489 {
        None => None,
        Some(prod_local_491) => { let prod_local_492 = length(prod_local_491); match prod_local_492 {
        None => None,
        Some(prod_local_494) => { let prod_local_495 = 1; { let prod_local_496 = prod_local_495; { let prod_local_497 = int16Subtract(prod_local_494, prod_local_496); match prod_local_497 {
        None => None,
        Some(prod_local_499) => { let prod_local_500 = int16Add(prod_local_499, prod_local_488); match prod_local_500 {
        None => None,
        Some(prod_local_502) => { let prod_local_503 = 52; { let prod_local_504 = prod_local_503; { let prod_local_505 = int16Subtract(prod_local_499, prod_local_504); match prod_local_505 {
        None => None,
        Some(prod_local_507) => { let prod_local_508 = 1074; { let prod_local_509 = prod_local_508; { let prod_local_510 = -(prod_local_509); { let prod_local_511 = int16Subtract(prod_local_510, prod_local_488); match prod_local_511 {
        None => None,
        Some(prod_local_513) => { let prod_local_514 = signedLess(prod_local_507, prod_local_513); { let prod_local_518 = match prod_local_514 {
        false => { let prod_local_516 = false; prod_local_516 },
        true => { let prod_local_517 = true; prod_local_517 },
    }; { let prod_local_520 = match prod_local_518 {
        false => prod_local_507,
        true => prod_local_513,
    }; { let prod_local_521 = round(prod_local_491, prod_local_520); match prod_local_521 {
        None => prod_local_521,
        Some(prod_local_522) => { let prod_local_523 = pack64(sg, prod_local_522, prod_local_502); prod_local_523 },
    } } } } },
    } } } } },
    } } } },
    } },
    } } } },
    } },
    } },
    } } } },
    } } },
    } },
        true => { let prod_local_524 = 1; { let prod_local_525 = prod_local_524; { let prod_local_526 = prod_local_525; { let prod_local_527 = int16Add(prod_local_475, prod_local_526); match prod_local_527 {
        None => None,
        Some(prod_local_529) => { let prod_local_530 = 2150; { let prod_local_531 = prod_local_530; { let prod_local_532 = int16Subtract(prod_local_529, prod_local_531); match prod_local_532 {
        None => None,
        Some(prod_local_534) => { let prod_local_535 = multiply(prod_local_455, prod_local_464); match prod_local_535 {
        None => None,
        Some(prod_local_537) => { let prod_local_538 = length(prod_local_537); match prod_local_538 {
        None => None,
        Some(prod_local_540) => { let prod_local_541 = 1; { let prod_local_542 = prod_local_541; { let prod_local_543 = int16Subtract(prod_local_540, prod_local_542); match prod_local_543 {
        None => None,
        Some(prod_local_545) => { let prod_local_546 = int16Add(prod_local_545, prod_local_534); match prod_local_546 {
        None => None,
        Some(prod_local_548) => { let prod_local_549 = 52; { let prod_local_550 = prod_local_549; { let prod_local_551 = int16Subtract(prod_local_545, prod_local_550); match prod_local_551 {
        None => None,
        Some(prod_local_553) => { let prod_local_554 = 1074; { let prod_local_555 = prod_local_554; { let prod_local_556 = -(prod_local_555); { let prod_local_557 = int16Subtract(prod_local_556, prod_local_534); match prod_local_557 {
        None => None,
        Some(prod_local_559) => { let prod_local_560 = signedLess(prod_local_553, prod_local_559); { let prod_local_564 = match prod_local_560 {
        false => { let prod_local_562 = false; prod_local_562 },
        true => { let prod_local_563 = true; prod_local_563 },
    }; { let prod_local_566 = match prod_local_564 {
        false => prod_local_553,
        true => prod_local_559,
    }; { let prod_local_567 = round(prod_local_537, prod_local_566); match prod_local_567 {
        None => prod_local_567,
        Some(prod_local_568) => { let prod_local_569 = pack64(sg, prod_local_568, prod_local_548); prod_local_569 },
    } } } } },
    } } } } },
    } } } },
    } },
    } } } },
    } },
    } },
    } } } },
    } } } } },
    } },
    } },
        true => { let prod_local_570 = 1; { let prod_local_571 = prod_local_570; { let prod_local_572 = prod_local_571; match prod_local_460 {
        false => { let prod_local_574 = convertUInt16ToInt16(prod_local_470); match prod_local_574 {
        None => None,
        Some(prod_local_576) => { let prod_local_577 = prod_local_576; { let prod_local_578 = int16Add(prod_local_572, prod_local_577); match prod_local_578 {
        None => None,
        Some(prod_local_580) => { let prod_local_581 = 2150; { let prod_local_582 = prod_local_581; { let prod_local_583 = int16Subtract(prod_local_580, prod_local_582); match prod_local_583 {
        None => None,
        Some(prod_local_585) => { let prod_local_586 = multiply(prod_local_455, prod_local_464); match prod_local_586 {
        None => None,
        Some(prod_local_588) => { let prod_local_589 = length(prod_local_588); match prod_local_589 {
        None => None,
        Some(prod_local_591) => { let prod_local_592 = 1; { let prod_local_593 = prod_local_592; { let prod_local_594 = int16Subtract(prod_local_591, prod_local_593); match prod_local_594 {
        None => None,
        Some(prod_local_596) => { let prod_local_597 = int16Add(prod_local_596, prod_local_585); match prod_local_597 {
        None => None,
        Some(prod_local_599) => { let prod_local_600 = 52; { let prod_local_601 = prod_local_600; { let prod_local_602 = int16Subtract(prod_local_596, prod_local_601); match prod_local_602 {
        None => None,
        Some(prod_local_604) => { let prod_local_605 = 1074; { let prod_local_606 = prod_local_605; { let prod_local_607 = -(prod_local_606); { let prod_local_608 = int16Subtract(prod_local_607, prod_local_585); match prod_local_608 {
        None => None,
        Some(prod_local_610) => { let prod_local_611 = signedLess(prod_local_604, prod_local_610); { let prod_local_615 = match prod_local_611 {
        false => { let prod_local_613 = false; prod_local_613 },
        true => { let prod_local_614 = true; prod_local_614 },
    }; { let prod_local_617 = match prod_local_615 {
        false => prod_local_604,
        true => prod_local_610,
    }; { let prod_local_618 = round(prod_local_588, prod_local_617); match prod_local_618 {
        None => prod_local_618,
        Some(prod_local_619) => { let prod_local_620 = pack64(sg, prod_local_619, prod_local_599); prod_local_620 },
    } } } } },
    } } } } },
    } } } },
    } },
    } } } },
    } },
    } },
    } } } },
    } } },
    } },
        true => { let prod_local_621 = 1; { let prod_local_622 = prod_local_621; { let prod_local_623 = prod_local_622; { let prod_local_624 = int16Add(prod_local_572, prod_local_623); match prod_local_624 {
        None => None,
        Some(prod_local_626) => { let prod_local_627 = 2150; { let prod_local_628 = prod_local_627; { let prod_local_629 = int16Subtract(prod_local_626, prod_local_628); match prod_local_629 {
        None => None,
        Some(prod_local_631) => { let prod_local_632 = multiply(prod_local_455, prod_local_464); match prod_local_632 {
        None => None,
        Some(prod_local_634) => { let prod_local_635 = length(prod_local_634); match prod_local_635 {
        None => None,
        Some(prod_local_637) => { let prod_local_638 = 1; { let prod_local_639 = prod_local_638; { let prod_local_640 = int16Subtract(prod_local_637, prod_local_639); match prod_local_640 {
        None => None,
        Some(prod_local_642) => { let prod_local_643 = int16Add(prod_local_642, prod_local_631); match prod_local_643 {
        None => None,
        Some(prod_local_645) => { let prod_local_646 = 52; { let prod_local_647 = prod_local_646; { let prod_local_648 = int16Subtract(prod_local_642, prod_local_647); match prod_local_648 {
        None => None,
        Some(prod_local_650) => { let prod_local_651 = 1074; { let prod_local_652 = prod_local_651; { let prod_local_653 = -(prod_local_652); { let prod_local_654 = int16Subtract(prod_local_653, prod_local_631); match prod_local_654 {
        None => None,
        Some(prod_local_656) => { let prod_local_657 = signedLess(prod_local_650, prod_local_656); { let prod_local_661 = match prod_local_657 {
        false => { let prod_local_659 = false; prod_local_659 },
        true => { let prod_local_660 = true; prod_local_660 },
    }; { let prod_local_663 = match prod_local_661 {
        false => prod_local_650,
        true => prod_local_656,
    }; { let prod_local_664 = round(prod_local_634, prod_local_663); match prod_local_664 {
        None => prod_local_664,
        Some(prod_local_665) => { let prod_local_666 = pack64(sg, prod_local_665, prod_local_645); prod_local_666 },
    } } } } },
    } } } } },
    } } } },
    } },
    } } } },
    } },
    } },
    } } } },
    } } } } },
    } } } },
    },
    } },
    } } } } } } } },
        true => { let prod_local_667 = Some(sg); prod_local_667 },
    } } } } } },
        true => { let prod_local_668 = 9223372036854775807; { let prod_local_669 = (a & prod_local_668); { let prod_local_670 = 0; { let prod_local_671 = (prod_local_669 == prod_local_670); { let prod_local_681 = match prod_local_671 {
        false => { let prod_local_673 = 9223372036854775807; { let prod_local_674 = (b & prod_local_673); { let prod_local_675 = 0; { let prod_local_676 = (prod_local_674 == prod_local_675); prod_local_676 } } } },
        true => { let prod_local_677 = crate::PUnit {  }; { let prod_local_680 = { let prod_local_678 = prod_local_677; { let prod_local_679 = true; prod_local_679 } }; prod_local_680 } },
    }; { let prod_local_685 = match prod_local_681 {
        false => { let prod_local_683 = false; prod_local_683 },
        true => { let prod_local_684 = true; prod_local_684 },
    }; { let prod_local_690 = match prod_local_685 {
        false => { let prod_local_687 = 9218868437227405312; { let prod_local_688 = (sg | prod_local_687); prod_local_688 } },
        true => { let prod_local_689 = 9221120237041090560; prod_local_689 },
    }; { let prod_local_691 = Some(prod_local_690); prod_local_691 } } } } } } } },
    } },
        true => { let prod_local_692 = 2251799813685248; { let prod_local_693 = (b | prod_local_692); { let prod_local_694 = Some(prod_local_693); prod_local_694 } } },
    } } } },
        true => { let prod_local_696 = 0; { let prod_local_697 = (fb == prod_local_696); { let prod_local_698 = match prod_local_697 {
        false => prod_local_418,
        true => prod_local_417,
    }; { let prod_local_699 = prod_local_698; match prod_local_699 {
        false => { let prod_local_707 = match _x_1834 {
        false => { let prod_local_702 = (eb == _x_1821); prod_local_702 },
        true => { let prod_local_703 = crate::PUnit {  }; { let prod_local_706 = { let prod_local_704 = prod_local_703; { let prod_local_705 = true; prod_local_705 } }; prod_local_706 } },
    }; match prod_local_707 {
        false => { let prod_local_708 = 9223372036854775807; { let prod_local_709 = (a & prod_local_708); { let prod_local_710 = 0; { let prod_local_711 = (prod_local_709 == prod_local_710); { let prod_local_721 = match prod_local_711 {
        false => { let prod_local_713 = 9223372036854775807; { let prod_local_714 = (b & prod_local_713); { let prod_local_715 = 0; { let prod_local_716 = (prod_local_714 == prod_local_715); prod_local_716 } } } },
        true => { let prod_local_717 = crate::PUnit {  }; { let prod_local_720 = { let prod_local_718 = prod_local_717; { let prod_local_719 = true; prod_local_719 } }; prod_local_720 } },
    }; match prod_local_721 {
        false => { let prod_local_722 = (ea == prod_local_710); { let prod_local_726 = match prod_local_722 {
        false => { let prod_local_724 = false; prod_local_724 },
        true => { let prod_local_725 = true; prod_local_725 },
    }; { let prod_local_730 = match prod_local_726 {
        false => { let prod_local_728 = 4503599627370496; { let prod_local_729 = (fa | prod_local_728); prod_local_729 } },
        true => fa,
    }; { let prod_local_731 = (eb == prod_local_710); { let prod_local_735 = match prod_local_731 {
        false => { let prod_local_733 = false; prod_local_733 },
        true => { let prod_local_734 = true; prod_local_734 },
    }; { let prod_local_739 = match prod_local_735 {
        false => { let prod_local_737 = 4503599627370496; { let prod_local_738 = (fb | prod_local_737); prod_local_738 } },
        true => fb,
    }; { let prod_local_740 = convertUInt64ToUInt16(ea); match prod_local_740 {
        None => None,
        Some(prod_local_742) => { let prod_local_743 = convertUInt64ToUInt16(eb); match prod_local_743 {
        None => None,
        Some(prod_local_745) => match prod_local_726 {
        false => { let prod_local_747 = convertUInt16ToInt16(prod_local_742); match prod_local_747 {
        None => None,
        Some(prod_local_749) => { let prod_local_750 = prod_local_749; match prod_local_735 {
        false => { let prod_local_752 = convertUInt16ToInt16(prod_local_745); match prod_local_752 {
        None => None,
        Some(prod_local_754) => { let prod_local_755 = prod_local_754; { let prod_local_756 = int16Add(prod_local_750, prod_local_755); match prod_local_756 {
        None => None,
        Some(prod_local_758) => { let prod_local_759 = 2150; { let prod_local_760 = prod_local_759; { let prod_local_761 = int16Subtract(prod_local_758, prod_local_760); match prod_local_761 {
        None => None,
        Some(prod_local_763) => { let prod_local_764 = multiply(prod_local_730, prod_local_739); match prod_local_764 {
        None => None,
        Some(prod_local_766) => { let prod_local_767 = length(prod_local_766); match prod_local_767 {
        None => None,
        Some(prod_local_769) => { let prod_local_770 = 1; { let prod_local_771 = prod_local_770; { let prod_local_772 = int16Subtract(prod_local_769, prod_local_771); match prod_local_772 {
        None => None,
        Some(prod_local_774) => { let prod_local_775 = int16Add(prod_local_774, prod_local_763); match prod_local_775 {
        None => None,
        Some(prod_local_777) => { let prod_local_778 = 52; { let prod_local_779 = prod_local_778; { let prod_local_780 = int16Subtract(prod_local_774, prod_local_779); match prod_local_780 {
        None => None,
        Some(prod_local_782) => { let prod_local_783 = 1074; { let prod_local_784 = prod_local_783; { let prod_local_785 = -(prod_local_784); { let prod_local_786 = int16Subtract(prod_local_785, prod_local_763); match prod_local_786 {
        None => None,
        Some(prod_local_788) => { let prod_local_789 = signedLess(prod_local_782, prod_local_788); { let prod_local_793 = match prod_local_789 {
        false => { let prod_local_791 = false; prod_local_791 },
        true => { let prod_local_792 = true; prod_local_792 },
    }; { let prod_local_795 = match prod_local_793 {
        false => prod_local_782,
        true => prod_local_788,
    }; { let prod_local_796 = round(prod_local_766, prod_local_795); match prod_local_796 {
        None => prod_local_796,
        Some(prod_local_797) => { let prod_local_798 = pack64(sg, prod_local_797, prod_local_777); prod_local_798 },
    } } } } },
    } } } } },
    } } } },
    } },
    } } } },
    } },
    } },
    } } } },
    } } },
    } },
        true => { let prod_local_799 = 1; { let prod_local_800 = prod_local_799; { let prod_local_801 = prod_local_800; { let prod_local_802 = int16Add(prod_local_750, prod_local_801); match prod_local_802 {
        None => None,
        Some(prod_local_804) => { let prod_local_805 = 2150; { let prod_local_806 = prod_local_805; { let prod_local_807 = int16Subtract(prod_local_804, prod_local_806); match prod_local_807 {
        None => None,
        Some(prod_local_809) => { let prod_local_810 = multiply(prod_local_730, prod_local_739); match prod_local_810 {
        None => None,
        Some(prod_local_812) => { let prod_local_813 = length(prod_local_812); match prod_local_813 {
        None => None,
        Some(prod_local_815) => { let prod_local_816 = 1; { let prod_local_817 = prod_local_816; { let prod_local_818 = int16Subtract(prod_local_815, prod_local_817); match prod_local_818 {
        None => None,
        Some(prod_local_820) => { let prod_local_821 = int16Add(prod_local_820, prod_local_809); match prod_local_821 {
        None => None,
        Some(prod_local_823) => { let prod_local_824 = 52; { let prod_local_825 = prod_local_824; { let prod_local_826 = int16Subtract(prod_local_820, prod_local_825); match prod_local_826 {
        None => None,
        Some(prod_local_828) => { let prod_local_829 = 1074; { let prod_local_830 = prod_local_829; { let prod_local_831 = -(prod_local_830); { let prod_local_832 = int16Subtract(prod_local_831, prod_local_809); match prod_local_832 {
        None => None,
        Some(prod_local_834) => { let prod_local_835 = signedLess(prod_local_828, prod_local_834); { let prod_local_839 = match prod_local_835 {
        false => { let prod_local_837 = false; prod_local_837 },
        true => { let prod_local_838 = true; prod_local_838 },
    }; { let prod_local_841 = match prod_local_839 {
        false => prod_local_828,
        true => prod_local_834,
    }; { let prod_local_842 = round(prod_local_812, prod_local_841); match prod_local_842 {
        None => prod_local_842,
        Some(prod_local_843) => { let prod_local_844 = pack64(sg, prod_local_843, prod_local_823); prod_local_844 },
    } } } } },
    } } } } },
    } } } },
    } },
    } } } },
    } },
    } },
    } } } },
    } } } } },
    } },
    } },
        true => { let prod_local_845 = 1; { let prod_local_846 = prod_local_845; { let prod_local_847 = prod_local_846; match prod_local_735 {
        false => { let prod_local_849 = convertUInt16ToInt16(prod_local_745); match prod_local_849 {
        None => None,
        Some(prod_local_851) => { let prod_local_852 = prod_local_851; { let prod_local_853 = int16Add(prod_local_847, prod_local_852); match prod_local_853 {
        None => None,
        Some(prod_local_855) => { let prod_local_856 = 2150; { let prod_local_857 = prod_local_856; { let prod_local_858 = int16Subtract(prod_local_855, prod_local_857); match prod_local_858 {
        None => None,
        Some(prod_local_860) => { let prod_local_861 = multiply(prod_local_730, prod_local_739); match prod_local_861 {
        None => None,
        Some(prod_local_863) => { let prod_local_864 = length(prod_local_863); match prod_local_864 {
        None => None,
        Some(prod_local_866) => { let prod_local_867 = 1; { let prod_local_868 = prod_local_867; { let prod_local_869 = int16Subtract(prod_local_866, prod_local_868); match prod_local_869 {
        None => None,
        Some(prod_local_871) => { let prod_local_872 = int16Add(prod_local_871, prod_local_860); match prod_local_872 {
        None => None,
        Some(prod_local_874) => { let prod_local_875 = 52; { let prod_local_876 = prod_local_875; { let prod_local_877 = int16Subtract(prod_local_871, prod_local_876); match prod_local_877 {
        None => None,
        Some(prod_local_879) => { let prod_local_880 = 1074; { let prod_local_881 = prod_local_880; { let prod_local_882 = -(prod_local_881); { let prod_local_883 = int16Subtract(prod_local_882, prod_local_860); match prod_local_883 {
        None => None,
        Some(prod_local_885) => { let prod_local_886 = signedLess(prod_local_879, prod_local_885); { let prod_local_890 = match prod_local_886 {
        false => { let prod_local_888 = false; prod_local_888 },
        true => { let prod_local_889 = true; prod_local_889 },
    }; { let prod_local_892 = match prod_local_890 {
        false => prod_local_879,
        true => prod_local_885,
    }; { let prod_local_893 = round(prod_local_863, prod_local_892); match prod_local_893 {
        None => prod_local_893,
        Some(prod_local_894) => { let prod_local_895 = pack64(sg, prod_local_894, prod_local_874); prod_local_895 },
    } } } } },
    } } } } },
    } } } },
    } },
    } } } },
    } },
    } },
    } } } },
    } } },
    } },
        true => { let prod_local_896 = 1; { let prod_local_897 = prod_local_896; { let prod_local_898 = prod_local_897; { let prod_local_899 = int16Add(prod_local_847, prod_local_898); match prod_local_899 {
        None => None,
        Some(prod_local_901) => { let prod_local_902 = 2150; { let prod_local_903 = prod_local_902; { let prod_local_904 = int16Subtract(prod_local_901, prod_local_903); match prod_local_904 {
        None => None,
        Some(prod_local_906) => { let prod_local_907 = multiply(prod_local_730, prod_local_739); match prod_local_907 {
        None => None,
        Some(prod_local_909) => { let prod_local_910 = length(prod_local_909); match prod_local_910 {
        None => None,
        Some(prod_local_912) => { let prod_local_913 = 1; { let prod_local_914 = prod_local_913; { let prod_local_915 = int16Subtract(prod_local_912, prod_local_914); match prod_local_915 {
        None => None,
        Some(prod_local_917) => { let prod_local_918 = int16Add(prod_local_917, prod_local_906); match prod_local_918 {
        None => None,
        Some(prod_local_920) => { let prod_local_921 = 52; { let prod_local_922 = prod_local_921; { let prod_local_923 = int16Subtract(prod_local_917, prod_local_922); match prod_local_923 {
        None => None,
        Some(prod_local_925) => { let prod_local_926 = 1074; { let prod_local_927 = prod_local_926; { let prod_local_928 = -(prod_local_927); { let prod_local_929 = int16Subtract(prod_local_928, prod_local_906); match prod_local_929 {
        None => None,
        Some(prod_local_931) => { let prod_local_932 = signedLess(prod_local_925, prod_local_931); { let prod_local_936 = match prod_local_932 {
        false => { let prod_local_934 = false; prod_local_934 },
        true => { let prod_local_935 = true; prod_local_935 },
    }; { let prod_local_938 = match prod_local_936 {
        false => prod_local_925,
        true => prod_local_931,
    }; { let prod_local_939 = round(prod_local_909, prod_local_938); match prod_local_939 {
        None => prod_local_939,
        Some(prod_local_940) => { let prod_local_941 = pack64(sg, prod_local_940, prod_local_920); prod_local_941 },
    } } } } },
    } } } } },
    } } } },
    } },
    } } } },
    } },
    } },
    } } } },
    } } } } },
    } } } },
    },
    } },
    } } } } } } } },
        true => { let prod_local_942 = Some(sg); prod_local_942 },
    } } } } } },
        true => { let prod_local_943 = 9223372036854775807; { let prod_local_944 = (a & prod_local_943); { let prod_local_945 = 0; { let prod_local_946 = (prod_local_944 == prod_local_945); { let prod_local_956 = match prod_local_946 {
        false => { let prod_local_948 = 9223372036854775807; { let prod_local_949 = (b & prod_local_948); { let prod_local_950 = 0; { let prod_local_951 = (prod_local_949 == prod_local_950); prod_local_951 } } } },
        true => { let prod_local_952 = crate::PUnit {  }; { let prod_local_955 = { let prod_local_953 = prod_local_952; { let prod_local_954 = true; prod_local_954 } }; prod_local_955 } },
    }; { let prod_local_960 = match prod_local_956 {
        false => { let prod_local_958 = false; prod_local_958 },
        true => { let prod_local_959 = true; prod_local_959 },
    }; { let prod_local_965 = match prod_local_960 {
        false => { let prod_local_962 = 9218868437227405312; { let prod_local_963 = (sg | prod_local_962); prod_local_963 } },
        true => { let prod_local_964 = 9221120237041090560; prod_local_964 },
    }; { let prod_local_966 = Some(prod_local_965); prod_local_966 } } } } } } } },
    } },
        true => { let prod_local_967 = 2251799813685248; { let prod_local_968 = (b | prod_local_967); { let prod_local_969 = Some(prod_local_968); prod_local_969 } } },
    } } } } },
    } },
        true => { let prod_local_970 = 2251799813685248; { let prod_local_971 = (a | prod_local_970); { let prod_local_972 = Some(prod_local_971); prod_local_972 } } },
    } } } } },
    } } } } },
    } } },
    } } } } } } } } }
}

pub fn mul64(a: u64, b: u64) -> Option<u64> {
    { let _x_1 = bits64(a, b); _x_1 }
}

pub fn pack64(sg: u64, rounded: u64, exponent: i16) -> Option<u64> {
    { let _x_142 = 9007199254740992; { let overflow = (rounded == _x_142); match overflow {
        false => { let _x_195 = false; { let _y_198 = _x_195; match _y_198 {
        false => { let val_266 = exponent; { let _x_336 = 1022; { let _x_337 = _x_336; { let _x_338 = -(_x_337); { let _x_339 = signedLess(val_266, _x_338); match _x_339 {
        false => { let _x_371 = false; { let _y_341 = _x_371; match _y_341 {
        false => { let _x_351 = 1023; { let _x_352 = _x_351; { let _x_353 = int16Add(val_266, _x_352); match _x_353 {
        None => None,
        Some(val_495) => { let val_343 = val_495; { let _x_373 = 2046; { let _x_374 = _x_373; { let _x_375 = signedLess(_x_374, val_343); match _x_375 {
        false => match overflow {
        false => { let _x_525 = false; { let _y_502 = _x_525; match _y_502 {
        false => { let val_504 = rounded; { let _x_505 = convertInt16ToUInt64(val_343); match _x_505 {
        None => _x_505,
        Some(val_506) => { let _x_508 = 52; { let _x_509 = (val_506).checked_shl(_x_508); match _x_509 {
        None => _x_509,
        Some(val_510) => { let _x_512 = 4503599627370495; { let _x_513 = (val_504 & _x_512); { let _x_514 = (val_510 | _x_513); { let _x_515 = (sg | _x_514); { let _x_516 = Some(_x_515); _x_516 } } } } },
    } } },
    } } },
        true => { let _x_520 = 1; { let _x_521 = (rounded).checked_shr(_x_520); match _x_521 {
        None => _x_521,
        Some(val_524) => { let prod_local_0 = val_524; { let prod_local_1 = convertInt16ToUInt64(val_343); match prod_local_1 {
        None => prod_local_1,
        Some(prod_local_2) => { let prod_local_4 = 52; { let prod_local_5 = (prod_local_2).checked_shl(prod_local_4); match prod_local_5 {
        None => prod_local_5,
        Some(prod_local_6) => { let prod_local_8 = 4503599627370495; { let prod_local_9 = (prod_local_0 & prod_local_8); { let prod_local_10 = (prod_local_6 | prod_local_9); { let prod_local_11 = (sg | prod_local_10); { let prod_local_12 = Some(prod_local_11); prod_local_12 } } } } },
    } } },
    } } },
    } } },
    } } },
        true => { let _x_526 = true; { let prod_local_13 = _x_526; match prod_local_13 {
        false => { let prod_local_15 = rounded; { let prod_local_16 = convertInt16ToUInt64(val_343); match prod_local_16 {
        None => prod_local_16,
        Some(prod_local_17) => { let prod_local_19 = 52; { let prod_local_20 = (prod_local_17).checked_shl(prod_local_19); match prod_local_20 {
        None => prod_local_20,
        Some(prod_local_21) => { let prod_local_23 = 4503599627370495; { let prod_local_24 = (prod_local_15 & prod_local_23); { let prod_local_25 = (prod_local_21 | prod_local_24); { let prod_local_26 = (sg | prod_local_25); { let prod_local_27 = Some(prod_local_26); prod_local_27 } } } } },
    } } },
    } } },
        true => { let prod_local_29 = 1; { let prod_local_30 = (rounded).checked_shr(prod_local_29); match prod_local_30 {
        None => prod_local_30,
        Some(prod_local_31) => { let prod_local_32 = prod_local_31; { let prod_local_33 = convertInt16ToUInt64(val_343); match prod_local_33 {
        None => prod_local_33,
        Some(prod_local_34) => { let prod_local_36 = 52; { let prod_local_37 = (prod_local_34).checked_shl(prod_local_36); match prod_local_37 {
        None => prod_local_37,
        Some(prod_local_38) => { let prod_local_40 = 4503599627370495; { let prod_local_41 = (prod_local_32 & prod_local_40); { let prod_local_42 = (prod_local_38 | prod_local_41); { let prod_local_43 = (sg | prod_local_42); { let prod_local_44 = Some(prod_local_43); prod_local_44 } } } } },
    } } },
    } } },
    } } },
    } } },
    },
        true => { let _x_529 = 9218868437227405312; { let _x_530 = (sg | _x_529); { let _x_531 = Some(_x_530); _x_531 } } },
    } } } } },
    } } } },
        true => { let _x_356 = 4503599627370496; { let _x_357 = unsignedLess(rounded, _x_356); match _x_357 {
        false => { let _x_369 = false; { let _y_359 = _x_369; match _y_359 {
        false => { let _x_364 = 1; { let _x_365 = _x_364; { let _y_361 = _x_365; { let prod_local_45 = _y_361; { let prod_local_46 = 2046; { let prod_local_47 = prod_local_46; { let prod_local_48 = signedLess(prod_local_47, prod_local_45); match prod_local_48 {
        false => match overflow {
        false => { let prod_local_50 = false; { let prod_local_51 = prod_local_50; match prod_local_51 {
        false => { let prod_local_53 = rounded; { let prod_local_54 = convertInt16ToUInt64(prod_local_45); match prod_local_54 {
        None => prod_local_54,
        Some(prod_local_55) => { let prod_local_57 = 52; { let prod_local_58 = (prod_local_55).checked_shl(prod_local_57); match prod_local_58 {
        None => prod_local_58,
        Some(prod_local_59) => { let prod_local_61 = 4503599627370495; { let prod_local_62 = (prod_local_53 & prod_local_61); { let prod_local_63 = (prod_local_59 | prod_local_62); { let prod_local_64 = (sg | prod_local_63); { let prod_local_65 = Some(prod_local_64); prod_local_65 } } } } },
    } } },
    } } },
        true => { let prod_local_67 = 1; { let prod_local_68 = (rounded).checked_shr(prod_local_67); match prod_local_68 {
        None => prod_local_68,
        Some(prod_local_69) => { let prod_local_70 = prod_local_69; { let prod_local_71 = convertInt16ToUInt64(prod_local_45); match prod_local_71 {
        None => prod_local_71,
        Some(prod_local_72) => { let prod_local_74 = 52; { let prod_local_75 = (prod_local_72).checked_shl(prod_local_74); match prod_local_75 {
        None => prod_local_75,
        Some(prod_local_76) => { let prod_local_78 = 4503599627370495; { let prod_local_79 = (prod_local_70 & prod_local_78); { let prod_local_80 = (prod_local_76 | prod_local_79); { let prod_local_81 = (sg | prod_local_80); { let prod_local_82 = Some(prod_local_81); prod_local_82 } } } } },
    } } },
    } } },
    } } },
    } } },
        true => { let prod_local_83 = true; { let prod_local_84 = prod_local_83; match prod_local_84 {
        false => { let prod_local_86 = rounded; { let prod_local_87 = convertInt16ToUInt64(prod_local_45); match prod_local_87 {
        None => prod_local_87,
        Some(prod_local_88) => { let prod_local_90 = 52; { let prod_local_91 = (prod_local_88).checked_shl(prod_local_90); match prod_local_91 {
        None => prod_local_91,
        Some(prod_local_92) => { let prod_local_94 = 4503599627370495; { let prod_local_95 = (prod_local_86 & prod_local_94); { let prod_local_96 = (prod_local_92 | prod_local_95); { let prod_local_97 = (sg | prod_local_96); { let prod_local_98 = Some(prod_local_97); prod_local_98 } } } } },
    } } },
    } } },
        true => { let prod_local_100 = 1; { let prod_local_101 = (rounded).checked_shr(prod_local_100); match prod_local_101 {
        None => prod_local_101,
        Some(prod_local_102) => { let prod_local_103 = prod_local_102; { let prod_local_104 = convertInt16ToUInt64(prod_local_45); match prod_local_104 {
        None => prod_local_104,
        Some(prod_local_105) => { let prod_local_107 = 52; { let prod_local_108 = (prod_local_105).checked_shl(prod_local_107); match prod_local_108 {
        None => prod_local_108,
        Some(prod_local_109) => { let prod_local_111 = 4503599627370495; { let prod_local_112 = (prod_local_103 & prod_local_111); { let prod_local_113 = (prod_local_109 | prod_local_112); { let prod_local_114 = (sg | prod_local_113); { let prod_local_115 = Some(prod_local_114); prod_local_115 } } } } },
    } } },
    } } },
    } } },
    } } },
    },
        true => { let prod_local_117 = 9218868437227405312; { let prod_local_118 = (sg | prod_local_117); { let prod_local_119 = Some(prod_local_118); prod_local_119 } } },
    } } } } } } } },
        true => { let _x_367 = 0; { let _x_368 = _x_367; { let prod_local_120 = _x_368; { let prod_local_121 = prod_local_120; { let prod_local_122 = 2046; { let prod_local_123 = prod_local_122; { let prod_local_124 = signedLess(prod_local_123, prod_local_121); match prod_local_124 {
        false => match overflow {
        false => { let prod_local_126 = false; { let prod_local_127 = prod_local_126; match prod_local_127 {
        false => { let prod_local_129 = rounded; { let prod_local_130 = convertInt16ToUInt64(prod_local_121); match prod_local_130 {
        None => prod_local_130,
        Some(prod_local_131) => { let prod_local_133 = 52; { let prod_local_134 = (prod_local_131).checked_shl(prod_local_133); match prod_local_134 {
        None => prod_local_134,
        Some(prod_local_135) => { let prod_local_137 = 4503599627370495; { let prod_local_138 = (prod_local_129 & prod_local_137); { let prod_local_139 = (prod_local_135 | prod_local_138); { let prod_local_140 = (sg | prod_local_139); { let prod_local_141 = Some(prod_local_140); prod_local_141 } } } } },
    } } },
    } } },
        true => { let prod_local_143 = 1; { let prod_local_144 = (rounded).checked_shr(prod_local_143); match prod_local_144 {
        None => prod_local_144,
        Some(prod_local_145) => { let prod_local_146 = prod_local_145; { let prod_local_147 = convertInt16ToUInt64(prod_local_121); match prod_local_147 {
        None => prod_local_147,
        Some(prod_local_148) => { let prod_local_150 = 52; { let prod_local_151 = (prod_local_148).checked_shl(prod_local_150); match prod_local_151 {
        None => prod_local_151,
        Some(prod_local_152) => { let prod_local_154 = 4503599627370495; { let prod_local_155 = (prod_local_146 & prod_local_154); { let prod_local_156 = (prod_local_152 | prod_local_155); { let prod_local_157 = (sg | prod_local_156); { let prod_local_158 = Some(prod_local_157); prod_local_158 } } } } },
    } } },
    } } },
    } } },
    } } },
        true => { let prod_local_159 = true; { let prod_local_160 = prod_local_159; match prod_local_160 {
        false => { let prod_local_162 = rounded; { let prod_local_163 = convertInt16ToUInt64(prod_local_121); match prod_local_163 {
        None => prod_local_163,
        Some(prod_local_164) => { let prod_local_166 = 52; { let prod_local_167 = (prod_local_164).checked_shl(prod_local_166); match prod_local_167 {
        None => prod_local_167,
        Some(prod_local_168) => { let prod_local_170 = 4503599627370495; { let prod_local_171 = (prod_local_162 & prod_local_170); { let prod_local_172 = (prod_local_168 | prod_local_171); { let prod_local_173 = (sg | prod_local_172); { let prod_local_174 = Some(prod_local_173); prod_local_174 } } } } },
    } } },
    } } },
        true => { let prod_local_176 = 1; { let prod_local_177 = (rounded).checked_shr(prod_local_176); match prod_local_177 {
        None => prod_local_177,
        Some(prod_local_178) => { let prod_local_179 = prod_local_178; { let prod_local_180 = convertInt16ToUInt64(prod_local_121); match prod_local_180 {
        None => prod_local_180,
        Some(prod_local_181) => { let prod_local_183 = 52; { let prod_local_184 = (prod_local_181).checked_shl(prod_local_183); match prod_local_184 {
        None => prod_local_184,
        Some(prod_local_185) => { let prod_local_187 = 4503599627370495; { let prod_local_188 = (prod_local_179 & prod_local_187); { let prod_local_189 = (prod_local_185 | prod_local_188); { let prod_local_190 = (sg | prod_local_189); { let prod_local_191 = Some(prod_local_190); prod_local_191 } } } } },
    } } },
    } } },
    } } },
    } } },
    },
        true => { let prod_local_193 = 9218868437227405312; { let prod_local_194 = (sg | prod_local_193); { let prod_local_195 = Some(prod_local_194); prod_local_195 } } },
    } } } } } } } },
    } } },
        true => { let _x_370 = true; { let prod_local_196 = _x_370; match prod_local_196 {
        false => { let prod_local_198 = 1; { let prod_local_199 = prod_local_198; { let prod_local_200 = prod_local_199; { let prod_local_201 = prod_local_200; { let prod_local_202 = 2046; { let prod_local_203 = prod_local_202; { let prod_local_204 = signedLess(prod_local_203, prod_local_201); match prod_local_204 {
        false => match overflow {
        false => { let prod_local_206 = false; { let prod_local_207 = prod_local_206; match prod_local_207 {
        false => { let prod_local_209 = rounded; { let prod_local_210 = convertInt16ToUInt64(prod_local_201); match prod_local_210 {
        None => prod_local_210,
        Some(prod_local_211) => { let prod_local_213 = 52; { let prod_local_214 = (prod_local_211).checked_shl(prod_local_213); match prod_local_214 {
        None => prod_local_214,
        Some(prod_local_215) => { let prod_local_217 = 4503599627370495; { let prod_local_218 = (prod_local_209 & prod_local_217); { let prod_local_219 = (prod_local_215 | prod_local_218); { let prod_local_220 = (sg | prod_local_219); { let prod_local_221 = Some(prod_local_220); prod_local_221 } } } } },
    } } },
    } } },
        true => { let prod_local_223 = 1; { let prod_local_224 = (rounded).checked_shr(prod_local_223); match prod_local_224 {
        None => prod_local_224,
        Some(prod_local_225) => { let prod_local_226 = prod_local_225; { let prod_local_227 = convertInt16ToUInt64(prod_local_201); match prod_local_227 {
        None => prod_local_227,
        Some(prod_local_228) => { let prod_local_230 = 52; { let prod_local_231 = (prod_local_228).checked_shl(prod_local_230); match prod_local_231 {
        None => prod_local_231,
        Some(prod_local_232) => { let prod_local_234 = 4503599627370495; { let prod_local_235 = (prod_local_226 & prod_local_234); { let prod_local_236 = (prod_local_232 | prod_local_235); { let prod_local_237 = (sg | prod_local_236); { let prod_local_238 = Some(prod_local_237); prod_local_238 } } } } },
    } } },
    } } },
    } } },
    } } },
        true => { let prod_local_239 = true; { let prod_local_240 = prod_local_239; match prod_local_240 {
        false => { let prod_local_242 = rounded; { let prod_local_243 = convertInt16ToUInt64(prod_local_201); match prod_local_243 {
        None => prod_local_243,
        Some(prod_local_244) => { let prod_local_246 = 52; { let prod_local_247 = (prod_local_244).checked_shl(prod_local_246); match prod_local_247 {
        None => prod_local_247,
        Some(prod_local_248) => { let prod_local_250 = 4503599627370495; { let prod_local_251 = (prod_local_242 & prod_local_250); { let prod_local_252 = (prod_local_248 | prod_local_251); { let prod_local_253 = (sg | prod_local_252); { let prod_local_254 = Some(prod_local_253); prod_local_254 } } } } },
    } } },
    } } },
        true => { let prod_local_256 = 1; { let prod_local_257 = (rounded).checked_shr(prod_local_256); match prod_local_257 {
        None => prod_local_257,
        Some(prod_local_258) => { let prod_local_259 = prod_local_258; { let prod_local_260 = convertInt16ToUInt64(prod_local_201); match prod_local_260 {
        None => prod_local_260,
        Some(prod_local_261) => { let prod_local_263 = 52; { let prod_local_264 = (prod_local_261).checked_shl(prod_local_263); match prod_local_264 {
        None => prod_local_264,
        Some(prod_local_265) => { let prod_local_267 = 4503599627370495; { let prod_local_268 = (prod_local_259 & prod_local_267); { let prod_local_269 = (prod_local_265 | prod_local_268); { let prod_local_270 = (sg | prod_local_269); { let prod_local_271 = Some(prod_local_270); prod_local_271 } } } } },
    } } },
    } } },
    } } },
    } } },
    },
        true => { let prod_local_273 = 9218868437227405312; { let prod_local_274 = (sg | prod_local_273); { let prod_local_275 = Some(prod_local_274); prod_local_275 } } },
    } } } } } } } },
        true => { let prod_local_276 = 0; { let prod_local_277 = prod_local_276; { let prod_local_278 = prod_local_277; { let prod_local_279 = prod_local_278; { let prod_local_280 = 2046; { let prod_local_281 = prod_local_280; { let prod_local_282 = signedLess(prod_local_281, prod_local_279); match prod_local_282 {
        false => match overflow {
        false => { let prod_local_284 = false; { let prod_local_285 = prod_local_284; match prod_local_285 {
        false => { let prod_local_287 = rounded; { let prod_local_288 = convertInt16ToUInt64(prod_local_279); match prod_local_288 {
        None => prod_local_288,
        Some(prod_local_289) => { let prod_local_291 = 52; { let prod_local_292 = (prod_local_289).checked_shl(prod_local_291); match prod_local_292 {
        None => prod_local_292,
        Some(prod_local_293) => { let prod_local_295 = 4503599627370495; { let prod_local_296 = (prod_local_287 & prod_local_295); { let prod_local_297 = (prod_local_293 | prod_local_296); { let prod_local_298 = (sg | prod_local_297); { let prod_local_299 = Some(prod_local_298); prod_local_299 } } } } },
    } } },
    } } },
        true => { let prod_local_301 = 1; { let prod_local_302 = (rounded).checked_shr(prod_local_301); match prod_local_302 {
        None => prod_local_302,
        Some(prod_local_303) => { let prod_local_304 = prod_local_303; { let prod_local_305 = convertInt16ToUInt64(prod_local_279); match prod_local_305 {
        None => prod_local_305,
        Some(prod_local_306) => { let prod_local_308 = 52; { let prod_local_309 = (prod_local_306).checked_shl(prod_local_308); match prod_local_309 {
        None => prod_local_309,
        Some(prod_local_310) => { let prod_local_312 = 4503599627370495; { let prod_local_313 = (prod_local_304 & prod_local_312); { let prod_local_314 = (prod_local_310 | prod_local_313); { let prod_local_315 = (sg | prod_local_314); { let prod_local_316 = Some(prod_local_315); prod_local_316 } } } } },
    } } },
    } } },
    } } },
    } } },
        true => { let prod_local_317 = true; { let prod_local_318 = prod_local_317; match prod_local_318 {
        false => { let prod_local_320 = rounded; { let prod_local_321 = convertInt16ToUInt64(prod_local_279); match prod_local_321 {
        None => prod_local_321,
        Some(prod_local_322) => { let prod_local_324 = 52; { let prod_local_325 = (prod_local_322).checked_shl(prod_local_324); match prod_local_325 {
        None => prod_local_325,
        Some(prod_local_326) => { let prod_local_328 = 4503599627370495; { let prod_local_329 = (prod_local_320 & prod_local_328); { let prod_local_330 = (prod_local_326 | prod_local_329); { let prod_local_331 = (sg | prod_local_330); { let prod_local_332 = Some(prod_local_331); prod_local_332 } } } } },
    } } },
    } } },
        true => { let prod_local_334 = 1; { let prod_local_335 = (rounded).checked_shr(prod_local_334); match prod_local_335 {
        None => prod_local_335,
        Some(prod_local_336) => { let prod_local_337 = prod_local_336; { let prod_local_338 = convertInt16ToUInt64(prod_local_279); match prod_local_338 {
        None => prod_local_338,
        Some(prod_local_339) => { let prod_local_341 = 52; { let prod_local_342 = (prod_local_339).checked_shl(prod_local_341); match prod_local_342 {
        None => prod_local_342,
        Some(prod_local_343) => { let prod_local_345 = 4503599627370495; { let prod_local_346 = (prod_local_337 & prod_local_345); { let prod_local_347 = (prod_local_343 | prod_local_346); { let prod_local_348 = (sg | prod_local_347); { let prod_local_349 = Some(prod_local_348); prod_local_349 } } } } },
    } } },
    } } },
    } } },
    } } },
    },
        true => { let prod_local_351 = 9218868437227405312; { let prod_local_352 = (sg | prod_local_351); { let prod_local_353 = Some(prod_local_352); prod_local_353 } } },
    } } } } } } } },
    } } },
    } } },
    } } },
        true => { let _x_372 = true; { let prod_local_354 = _x_372; match prod_local_354 {
        false => { let prod_local_356 = 1023; { let prod_local_357 = prod_local_356; { let prod_local_358 = int16Add(val_266, prod_local_357); match prod_local_358 {
        None => None,
        Some(prod_local_360) => { let prod_local_361 = prod_local_360; { let prod_local_362 = 2046; { let prod_local_363 = prod_local_362; { let prod_local_364 = signedLess(prod_local_363, prod_local_361); match prod_local_364 {
        false => match overflow {
        false => { let prod_local_366 = false; { let prod_local_367 = prod_local_366; match prod_local_367 {
        false => { let prod_local_369 = rounded; { let prod_local_370 = convertInt16ToUInt64(prod_local_361); match prod_local_370 {
        None => prod_local_370,
        Some(prod_local_371) => { let prod_local_373 = 52; { let prod_local_374 = (prod_local_371).checked_shl(prod_local_373); match prod_local_374 {
        None => prod_local_374,
        Some(prod_local_375) => { let prod_local_377 = 4503599627370495; { let prod_local_378 = (prod_local_369 & prod_local_377); { let prod_local_379 = (prod_local_375 | prod_local_378); { let prod_local_380 = (sg | prod_local_379); { let prod_local_381 = Some(prod_local_380); prod_local_381 } } } } },
    } } },
    } } },
        true => { let prod_local_383 = 1; { let prod_local_384 = (rounded).checked_shr(prod_local_383); match prod_local_384 {
        None => prod_local_384,
        Some(prod_local_385) => { let prod_local_386 = prod_local_385; { let prod_local_387 = convertInt16ToUInt64(prod_local_361); match prod_local_387 {
        None => prod_local_387,
        Some(prod_local_388) => { let prod_local_390 = 52; { let prod_local_391 = (prod_local_388).checked_shl(prod_local_390); match prod_local_391 {
        None => prod_local_391,
        Some(prod_local_392) => { let prod_local_394 = 4503599627370495; { let prod_local_395 = (prod_local_386 & prod_local_394); { let prod_local_396 = (prod_local_392 | prod_local_395); { let prod_local_397 = (sg | prod_local_396); { let prod_local_398 = Some(prod_local_397); prod_local_398 } } } } },
    } } },
    } } },
    } } },
    } } },
        true => { let prod_local_399 = true; { let prod_local_400 = prod_local_399; match prod_local_400 {
        false => { let prod_local_402 = rounded; { let prod_local_403 = convertInt16ToUInt64(prod_local_361); match prod_local_403 {
        None => prod_local_403,
        Some(prod_local_404) => { let prod_local_406 = 52; { let prod_local_407 = (prod_local_404).checked_shl(prod_local_406); match prod_local_407 {
        None => prod_local_407,
        Some(prod_local_408) => { let prod_local_410 = 4503599627370495; { let prod_local_411 = (prod_local_402 & prod_local_410); { let prod_local_412 = (prod_local_408 | prod_local_411); { let prod_local_413 = (sg | prod_local_412); { let prod_local_414 = Some(prod_local_413); prod_local_414 } } } } },
    } } },
    } } },
        true => { let prod_local_416 = 1; { let prod_local_417 = (rounded).checked_shr(prod_local_416); match prod_local_417 {
        None => prod_local_417,
        Some(prod_local_418) => { let prod_local_419 = prod_local_418; { let prod_local_420 = convertInt16ToUInt64(prod_local_361); match prod_local_420 {
        None => prod_local_420,
        Some(prod_local_421) => { let prod_local_423 = 52; { let prod_local_424 = (prod_local_421).checked_shl(prod_local_423); match prod_local_424 {
        None => prod_local_424,
        Some(prod_local_425) => { let prod_local_427 = 4503599627370495; { let prod_local_428 = (prod_local_419 & prod_local_427); { let prod_local_429 = (prod_local_425 | prod_local_428); { let prod_local_430 = (sg | prod_local_429); { let prod_local_431 = Some(prod_local_430); prod_local_431 } } } } },
    } } },
    } } },
    } } },
    } } },
    },
        true => { let prod_local_433 = 9218868437227405312; { let prod_local_434 = (sg | prod_local_433); { let prod_local_435 = Some(prod_local_434); prod_local_435 } } },
    } } } } },
    } } } },
        true => { let prod_local_436 = 4503599627370496; { let prod_local_437 = unsignedLess(rounded, prod_local_436); match prod_local_437 {
        false => { let prod_local_439 = false; { let prod_local_440 = prod_local_439; match prod_local_440 {
        false => { let prod_local_442 = 1; { let prod_local_443 = prod_local_442; { let prod_local_444 = prod_local_443; { let prod_local_445 = prod_local_444; { let prod_local_446 = 2046; { let prod_local_447 = prod_local_446; { let prod_local_448 = signedLess(prod_local_447, prod_local_445); match prod_local_448 {
        false => match overflow {
        false => { let prod_local_450 = false; { let prod_local_451 = prod_local_450; match prod_local_451 {
        false => { let prod_local_453 = rounded; { let prod_local_454 = convertInt16ToUInt64(prod_local_445); match prod_local_454 {
        None => prod_local_454,
        Some(prod_local_455) => { let prod_local_457 = 52; { let prod_local_458 = (prod_local_455).checked_shl(prod_local_457); match prod_local_458 {
        None => prod_local_458,
        Some(prod_local_459) => { let prod_local_461 = 4503599627370495; { let prod_local_462 = (prod_local_453 & prod_local_461); { let prod_local_463 = (prod_local_459 | prod_local_462); { let prod_local_464 = (sg | prod_local_463); { let prod_local_465 = Some(prod_local_464); prod_local_465 } } } } },
    } } },
    } } },
        true => { let prod_local_467 = 1; { let prod_local_468 = (rounded).checked_shr(prod_local_467); match prod_local_468 {
        None => prod_local_468,
        Some(prod_local_469) => { let prod_local_470 = prod_local_469; { let prod_local_471 = convertInt16ToUInt64(prod_local_445); match prod_local_471 {
        None => prod_local_471,
        Some(prod_local_472) => { let prod_local_474 = 52; { let prod_local_475 = (prod_local_472).checked_shl(prod_local_474); match prod_local_475 {
        None => prod_local_475,
        Some(prod_local_476) => { let prod_local_478 = 4503599627370495; { let prod_local_479 = (prod_local_470 & prod_local_478); { let prod_local_480 = (prod_local_476 | prod_local_479); { let prod_local_481 = (sg | prod_local_480); { let prod_local_482 = Some(prod_local_481); prod_local_482 } } } } },
    } } },
    } } },
    } } },
    } } },
        true => { let prod_local_483 = true; { let prod_local_484 = prod_local_483; match prod_local_484 {
        false => { let prod_local_486 = rounded; { let prod_local_487 = convertInt16ToUInt64(prod_local_445); match prod_local_487 {
        None => prod_local_487,
        Some(prod_local_488) => { let prod_local_490 = 52; { let prod_local_491 = (prod_local_488).checked_shl(prod_local_490); match prod_local_491 {
        None => prod_local_491,
        Some(prod_local_492) => { let prod_local_494 = 4503599627370495; { let prod_local_495 = (prod_local_486 & prod_local_494); { let prod_local_496 = (prod_local_492 | prod_local_495); { let prod_local_497 = (sg | prod_local_496); { let prod_local_498 = Some(prod_local_497); prod_local_498 } } } } },
    } } },
    } } },
        true => { let prod_local_500 = 1; { let prod_local_501 = (rounded).checked_shr(prod_local_500); match prod_local_501 {
        None => prod_local_501,
        Some(prod_local_502) => { let prod_local_503 = prod_local_502; { let prod_local_504 = convertInt16ToUInt64(prod_local_445); match prod_local_504 {
        None => prod_local_504,
        Some(prod_local_505) => { let prod_local_507 = 52; { let prod_local_508 = (prod_local_505).checked_shl(prod_local_507); match prod_local_508 {
        None => prod_local_508,
        Some(prod_local_509) => { let prod_local_511 = 4503599627370495; { let prod_local_512 = (prod_local_503 & prod_local_511); { let prod_local_513 = (prod_local_509 | prod_local_512); { let prod_local_514 = (sg | prod_local_513); { let prod_local_515 = Some(prod_local_514); prod_local_515 } } } } },
    } } },
    } } },
    } } },
    } } },
    },
        true => { let prod_local_517 = 9218868437227405312; { let prod_local_518 = (sg | prod_local_517); { let prod_local_519 = Some(prod_local_518); prod_local_519 } } },
    } } } } } } } },
        true => { let prod_local_520 = 0; { let prod_local_521 = prod_local_520; { let prod_local_522 = prod_local_521; { let prod_local_523 = prod_local_522; { let prod_local_524 = 2046; { let prod_local_525 = prod_local_524; { let prod_local_526 = signedLess(prod_local_525, prod_local_523); match prod_local_526 {
        false => match overflow {
        false => { let prod_local_528 = false; { let prod_local_529 = prod_local_528; match prod_local_529 {
        false => { let prod_local_531 = rounded; { let prod_local_532 = convertInt16ToUInt64(prod_local_523); match prod_local_532 {
        None => prod_local_532,
        Some(prod_local_533) => { let prod_local_535 = 52; { let prod_local_536 = (prod_local_533).checked_shl(prod_local_535); match prod_local_536 {
        None => prod_local_536,
        Some(prod_local_537) => { let prod_local_539 = 4503599627370495; { let prod_local_540 = (prod_local_531 & prod_local_539); { let prod_local_541 = (prod_local_537 | prod_local_540); { let prod_local_542 = (sg | prod_local_541); { let prod_local_543 = Some(prod_local_542); prod_local_543 } } } } },
    } } },
    } } },
        true => { let prod_local_545 = 1; { let prod_local_546 = (rounded).checked_shr(prod_local_545); match prod_local_546 {
        None => prod_local_546,
        Some(prod_local_547) => { let prod_local_548 = prod_local_547; { let prod_local_549 = convertInt16ToUInt64(prod_local_523); match prod_local_549 {
        None => prod_local_549,
        Some(prod_local_550) => { let prod_local_552 = 52; { let prod_local_553 = (prod_local_550).checked_shl(prod_local_552); match prod_local_553 {
        None => prod_local_553,
        Some(prod_local_554) => { let prod_local_556 = 4503599627370495; { let prod_local_557 = (prod_local_548 & prod_local_556); { let prod_local_558 = (prod_local_554 | prod_local_557); { let prod_local_559 = (sg | prod_local_558); { let prod_local_560 = Some(prod_local_559); prod_local_560 } } } } },
    } } },
    } } },
    } } },
    } } },
        true => { let prod_local_561 = true; { let prod_local_562 = prod_local_561; match prod_local_562 {
        false => { let prod_local_564 = rounded; { let prod_local_565 = convertInt16ToUInt64(prod_local_523); match prod_local_565 {
        None => prod_local_565,
        Some(prod_local_566) => { let prod_local_568 = 52; { let prod_local_569 = (prod_local_566).checked_shl(prod_local_568); match prod_local_569 {
        None => prod_local_569,
        Some(prod_local_570) => { let prod_local_572 = 4503599627370495; { let prod_local_573 = (prod_local_564 & prod_local_572); { let prod_local_574 = (prod_local_570 | prod_local_573); { let prod_local_575 = (sg | prod_local_574); { let prod_local_576 = Some(prod_local_575); prod_local_576 } } } } },
    } } },
    } } },
        true => { let prod_local_578 = 1; { let prod_local_579 = (rounded).checked_shr(prod_local_578); match prod_local_579 {
        None => prod_local_579,
        Some(prod_local_580) => { let prod_local_581 = prod_local_580; { let prod_local_582 = convertInt16ToUInt64(prod_local_523); match prod_local_582 {
        None => prod_local_582,
        Some(prod_local_583) => { let prod_local_585 = 52; { let prod_local_586 = (prod_local_583).checked_shl(prod_local_585); match prod_local_586 {
        None => prod_local_586,
        Some(prod_local_587) => { let prod_local_589 = 4503599627370495; { let prod_local_590 = (prod_local_581 & prod_local_589); { let prod_local_591 = (prod_local_587 | prod_local_590); { let prod_local_592 = (sg | prod_local_591); { let prod_local_593 = Some(prod_local_592); prod_local_593 } } } } },
    } } },
    } } },
    } } },
    } } },
    },
        true => { let prod_local_595 = 9218868437227405312; { let prod_local_596 = (sg | prod_local_595); { let prod_local_597 = Some(prod_local_596); prod_local_597 } } },
    } } } } } } } },
    } } },
        true => { let prod_local_598 = true; { let prod_local_599 = prod_local_598; match prod_local_599 {
        false => { let prod_local_601 = 1; { let prod_local_602 = prod_local_601; { let prod_local_603 = prod_local_602; { let prod_local_604 = prod_local_603; { let prod_local_605 = 2046; { let prod_local_606 = prod_local_605; { let prod_local_607 = signedLess(prod_local_606, prod_local_604); match prod_local_607 {
        false => match overflow {
        false => { let prod_local_609 = false; { let prod_local_610 = prod_local_609; match prod_local_610 {
        false => { let prod_local_612 = rounded; { let prod_local_613 = convertInt16ToUInt64(prod_local_604); match prod_local_613 {
        None => prod_local_613,
        Some(prod_local_614) => { let prod_local_616 = 52; { let prod_local_617 = (prod_local_614).checked_shl(prod_local_616); match prod_local_617 {
        None => prod_local_617,
        Some(prod_local_618) => { let prod_local_620 = 4503599627370495; { let prod_local_621 = (prod_local_612 & prod_local_620); { let prod_local_622 = (prod_local_618 | prod_local_621); { let prod_local_623 = (sg | prod_local_622); { let prod_local_624 = Some(prod_local_623); prod_local_624 } } } } },
    } } },
    } } },
        true => { let prod_local_626 = 1; { let prod_local_627 = (rounded).checked_shr(prod_local_626); match prod_local_627 {
        None => prod_local_627,
        Some(prod_local_628) => { let prod_local_629 = prod_local_628; { let prod_local_630 = convertInt16ToUInt64(prod_local_604); match prod_local_630 {
        None => prod_local_630,
        Some(prod_local_631) => { let prod_local_633 = 52; { let prod_local_634 = (prod_local_631).checked_shl(prod_local_633); match prod_local_634 {
        None => prod_local_634,
        Some(prod_local_635) => { let prod_local_637 = 4503599627370495; { let prod_local_638 = (prod_local_629 & prod_local_637); { let prod_local_639 = (prod_local_635 | prod_local_638); { let prod_local_640 = (sg | prod_local_639); { let prod_local_641 = Some(prod_local_640); prod_local_641 } } } } },
    } } },
    } } },
    } } },
    } } },
        true => { let prod_local_642 = true; { let prod_local_643 = prod_local_642; match prod_local_643 {
        false => { let prod_local_645 = rounded; { let prod_local_646 = convertInt16ToUInt64(prod_local_604); match prod_local_646 {
        None => prod_local_646,
        Some(prod_local_647) => { let prod_local_649 = 52; { let prod_local_650 = (prod_local_647).checked_shl(prod_local_649); match prod_local_650 {
        None => prod_local_650,
        Some(prod_local_651) => { let prod_local_653 = 4503599627370495; { let prod_local_654 = (prod_local_645 & prod_local_653); { let prod_local_655 = (prod_local_651 | prod_local_654); { let prod_local_656 = (sg | prod_local_655); { let prod_local_657 = Some(prod_local_656); prod_local_657 } } } } },
    } } },
    } } },
        true => { let prod_local_659 = 1; { let prod_local_660 = (rounded).checked_shr(prod_local_659); match prod_local_660 {
        None => prod_local_660,
        Some(prod_local_661) => { let prod_local_662 = prod_local_661; { let prod_local_663 = convertInt16ToUInt64(prod_local_604); match prod_local_663 {
        None => prod_local_663,
        Some(prod_local_664) => { let prod_local_666 = 52; { let prod_local_667 = (prod_local_664).checked_shl(prod_local_666); match prod_local_667 {
        None => prod_local_667,
        Some(prod_local_668) => { let prod_local_670 = 4503599627370495; { let prod_local_671 = (prod_local_662 & prod_local_670); { let prod_local_672 = (prod_local_668 | prod_local_671); { let prod_local_673 = (sg | prod_local_672); { let prod_local_674 = Some(prod_local_673); prod_local_674 } } } } },
    } } },
    } } },
    } } },
    } } },
    },
        true => { let prod_local_676 = 9218868437227405312; { let prod_local_677 = (sg | prod_local_676); { let prod_local_678 = Some(prod_local_677); prod_local_678 } } },
    } } } } } } } },
        true => { let prod_local_679 = 0; { let prod_local_680 = prod_local_679; { let prod_local_681 = prod_local_680; { let prod_local_682 = prod_local_681; { let prod_local_683 = 2046; { let prod_local_684 = prod_local_683; { let prod_local_685 = signedLess(prod_local_684, prod_local_682); match prod_local_685 {
        false => match overflow {
        false => { let prod_local_687 = false; { let prod_local_688 = prod_local_687; match prod_local_688 {
        false => { let prod_local_690 = rounded; { let prod_local_691 = convertInt16ToUInt64(prod_local_682); match prod_local_691 {
        None => prod_local_691,
        Some(prod_local_692) => { let prod_local_694 = 52; { let prod_local_695 = (prod_local_692).checked_shl(prod_local_694); match prod_local_695 {
        None => prod_local_695,
        Some(prod_local_696) => { let prod_local_698 = 4503599627370495; { let prod_local_699 = (prod_local_690 & prod_local_698); { let prod_local_700 = (prod_local_696 | prod_local_699); { let prod_local_701 = (sg | prod_local_700); { let prod_local_702 = Some(prod_local_701); prod_local_702 } } } } },
    } } },
    } } },
        true => { let prod_local_704 = 1; { let prod_local_705 = (rounded).checked_shr(prod_local_704); match prod_local_705 {
        None => prod_local_705,
        Some(prod_local_706) => { let prod_local_707 = prod_local_706; { let prod_local_708 = convertInt16ToUInt64(prod_local_682); match prod_local_708 {
        None => prod_local_708,
        Some(prod_local_709) => { let prod_local_711 = 52; { let prod_local_712 = (prod_local_709).checked_shl(prod_local_711); match prod_local_712 {
        None => prod_local_712,
        Some(prod_local_713) => { let prod_local_715 = 4503599627370495; { let prod_local_716 = (prod_local_707 & prod_local_715); { let prod_local_717 = (prod_local_713 | prod_local_716); { let prod_local_718 = (sg | prod_local_717); { let prod_local_719 = Some(prod_local_718); prod_local_719 } } } } },
    } } },
    } } },
    } } },
    } } },
        true => { let prod_local_720 = true; { let prod_local_721 = prod_local_720; match prod_local_721 {
        false => { let prod_local_723 = rounded; { let prod_local_724 = convertInt16ToUInt64(prod_local_682); match prod_local_724 {
        None => prod_local_724,
        Some(prod_local_725) => { let prod_local_727 = 52; { let prod_local_728 = (prod_local_725).checked_shl(prod_local_727); match prod_local_728 {
        None => prod_local_728,
        Some(prod_local_729) => { let prod_local_731 = 4503599627370495; { let prod_local_732 = (prod_local_723 & prod_local_731); { let prod_local_733 = (prod_local_729 | prod_local_732); { let prod_local_734 = (sg | prod_local_733); { let prod_local_735 = Some(prod_local_734); prod_local_735 } } } } },
    } } },
    } } },
        true => { let prod_local_737 = 1; { let prod_local_738 = (rounded).checked_shr(prod_local_737); match prod_local_738 {
        None => prod_local_738,
        Some(prod_local_739) => { let prod_local_740 = prod_local_739; { let prod_local_741 = convertInt16ToUInt64(prod_local_682); match prod_local_741 {
        None => prod_local_741,
        Some(prod_local_742) => { let prod_local_744 = 52; { let prod_local_745 = (prod_local_742).checked_shl(prod_local_744); match prod_local_745 {
        None => prod_local_745,
        Some(prod_local_746) => { let prod_local_748 = 4503599627370495; { let prod_local_749 = (prod_local_740 & prod_local_748); { let prod_local_750 = (prod_local_746 | prod_local_749); { let prod_local_751 = (sg | prod_local_750); { let prod_local_752 = Some(prod_local_751); prod_local_752 } } } } },
    } } },
    } } },
    } } },
    } } },
    },
        true => { let prod_local_754 = 9218868437227405312; { let prod_local_755 = (sg | prod_local_754); { let prod_local_756 = Some(prod_local_755); prod_local_756 } } },
    } } } } } } } },
    } } },
    } } },
    } } },
    } } } } } },
        true => { let _x_130 = 1; { let _x_200 = _x_130; { let _x_133 = int16Add(exponent, _x_200); match _x_133 {
        None => None,
        Some(val_498) => { let prod_local_757 = val_498; { let prod_local_758 = 1022; { let prod_local_759 = prod_local_758; { let prod_local_760 = -(prod_local_759); { let prod_local_761 = signedLess(prod_local_757, prod_local_760); match prod_local_761 {
        false => { let prod_local_763 = false; { let prod_local_764 = prod_local_763; match prod_local_764 {
        false => { let prod_local_766 = 1023; { let prod_local_767 = prod_local_766; { let prod_local_768 = int16Add(prod_local_757, prod_local_767); match prod_local_768 {
        None => None,
        Some(prod_local_770) => { let prod_local_771 = prod_local_770; { let prod_local_772 = 2046; { let prod_local_773 = prod_local_772; { let prod_local_774 = signedLess(prod_local_773, prod_local_771); match prod_local_774 {
        false => match overflow {
        false => { let prod_local_776 = false; { let prod_local_777 = prod_local_776; match prod_local_777 {
        false => { let prod_local_779 = rounded; { let prod_local_780 = convertInt16ToUInt64(prod_local_771); match prod_local_780 {
        None => prod_local_780,
        Some(prod_local_781) => { let prod_local_783 = 52; { let prod_local_784 = (prod_local_781).checked_shl(prod_local_783); match prod_local_784 {
        None => prod_local_784,
        Some(prod_local_785) => { let prod_local_787 = 4503599627370495; { let prod_local_788 = (prod_local_779 & prod_local_787); { let prod_local_789 = (prod_local_785 | prod_local_788); { let prod_local_790 = (sg | prod_local_789); { let prod_local_791 = Some(prod_local_790); prod_local_791 } } } } },
    } } },
    } } },
        true => { let prod_local_793 = 1; { let prod_local_794 = (rounded).checked_shr(prod_local_793); match prod_local_794 {
        None => prod_local_794,
        Some(prod_local_795) => { let prod_local_796 = prod_local_795; { let prod_local_797 = convertInt16ToUInt64(prod_local_771); match prod_local_797 {
        None => prod_local_797,
        Some(prod_local_798) => { let prod_local_800 = 52; { let prod_local_801 = (prod_local_798).checked_shl(prod_local_800); match prod_local_801 {
        None => prod_local_801,
        Some(prod_local_802) => { let prod_local_804 = 4503599627370495; { let prod_local_805 = (prod_local_796 & prod_local_804); { let prod_local_806 = (prod_local_802 | prod_local_805); { let prod_local_807 = (sg | prod_local_806); { let prod_local_808 = Some(prod_local_807); prod_local_808 } } } } },
    } } },
    } } },
    } } },
    } } },
        true => { let prod_local_809 = true; { let prod_local_810 = prod_local_809; match prod_local_810 {
        false => { let prod_local_812 = rounded; { let prod_local_813 = convertInt16ToUInt64(prod_local_771); match prod_local_813 {
        None => prod_local_813,
        Some(prod_local_814) => { let prod_local_816 = 52; { let prod_local_817 = (prod_local_814).checked_shl(prod_local_816); match prod_local_817 {
        None => prod_local_817,
        Some(prod_local_818) => { let prod_local_820 = 4503599627370495; { let prod_local_821 = (prod_local_812 & prod_local_820); { let prod_local_822 = (prod_local_818 | prod_local_821); { let prod_local_823 = (sg | prod_local_822); { let prod_local_824 = Some(prod_local_823); prod_local_824 } } } } },
    } } },
    } } },
        true => { let prod_local_826 = 1; { let prod_local_827 = (rounded).checked_shr(prod_local_826); match prod_local_827 {
        None => prod_local_827,
        Some(prod_local_828) => { let prod_local_829 = prod_local_828; { let prod_local_830 = convertInt16ToUInt64(prod_local_771); match prod_local_830 {
        None => prod_local_830,
        Some(prod_local_831) => { let prod_local_833 = 52; { let prod_local_834 = (prod_local_831).checked_shl(prod_local_833); match prod_local_834 {
        None => prod_local_834,
        Some(prod_local_835) => { let prod_local_837 = 4503599627370495; { let prod_local_838 = (prod_local_829 & prod_local_837); { let prod_local_839 = (prod_local_835 | prod_local_838); { let prod_local_840 = (sg | prod_local_839); { let prod_local_841 = Some(prod_local_840); prod_local_841 } } } } },
    } } },
    } } },
    } } },
    } } },
    },
        true => { let prod_local_843 = 9218868437227405312; { let prod_local_844 = (sg | prod_local_843); { let prod_local_845 = Some(prod_local_844); prod_local_845 } } },
    } } } } },
    } } } },
        true => { let prod_local_846 = 4503599627370496; { let prod_local_847 = unsignedLess(rounded, prod_local_846); match prod_local_847 {
        false => { let prod_local_849 = false; { let prod_local_850 = prod_local_849; match prod_local_850 {
        false => { let prod_local_852 = 1; { let prod_local_853 = prod_local_852; { let prod_local_854 = prod_local_853; { let prod_local_855 = prod_local_854; { let prod_local_856 = 2046; { let prod_local_857 = prod_local_856; { let prod_local_858 = signedLess(prod_local_857, prod_local_855); match prod_local_858 {
        false => match overflow {
        false => { let prod_local_860 = false; { let prod_local_861 = prod_local_860; match prod_local_861 {
        false => { let prod_local_863 = rounded; { let prod_local_864 = convertInt16ToUInt64(prod_local_855); match prod_local_864 {
        None => prod_local_864,
        Some(prod_local_865) => { let prod_local_867 = 52; { let prod_local_868 = (prod_local_865).checked_shl(prod_local_867); match prod_local_868 {
        None => prod_local_868,
        Some(prod_local_869) => { let prod_local_871 = 4503599627370495; { let prod_local_872 = (prod_local_863 & prod_local_871); { let prod_local_873 = (prod_local_869 | prod_local_872); { let prod_local_874 = (sg | prod_local_873); { let prod_local_875 = Some(prod_local_874); prod_local_875 } } } } },
    } } },
    } } },
        true => { let prod_local_877 = 1; { let prod_local_878 = (rounded).checked_shr(prod_local_877); match prod_local_878 {
        None => prod_local_878,
        Some(prod_local_879) => { let prod_local_880 = prod_local_879; { let prod_local_881 = convertInt16ToUInt64(prod_local_855); match prod_local_881 {
        None => prod_local_881,
        Some(prod_local_882) => { let prod_local_884 = 52; { let prod_local_885 = (prod_local_882).checked_shl(prod_local_884); match prod_local_885 {
        None => prod_local_885,
        Some(prod_local_886) => { let prod_local_888 = 4503599627370495; { let prod_local_889 = (prod_local_880 & prod_local_888); { let prod_local_890 = (prod_local_886 | prod_local_889); { let prod_local_891 = (sg | prod_local_890); { let prod_local_892 = Some(prod_local_891); prod_local_892 } } } } },
    } } },
    } } },
    } } },
    } } },
        true => { let prod_local_893 = true; { let prod_local_894 = prod_local_893; match prod_local_894 {
        false => { let prod_local_896 = rounded; { let prod_local_897 = convertInt16ToUInt64(prod_local_855); match prod_local_897 {
        None => prod_local_897,
        Some(prod_local_898) => { let prod_local_900 = 52; { let prod_local_901 = (prod_local_898).checked_shl(prod_local_900); match prod_local_901 {
        None => prod_local_901,
        Some(prod_local_902) => { let prod_local_904 = 4503599627370495; { let prod_local_905 = (prod_local_896 & prod_local_904); { let prod_local_906 = (prod_local_902 | prod_local_905); { let prod_local_907 = (sg | prod_local_906); { let prod_local_908 = Some(prod_local_907); prod_local_908 } } } } },
    } } },
    } } },
        true => { let prod_local_910 = 1; { let prod_local_911 = (rounded).checked_shr(prod_local_910); match prod_local_911 {
        None => prod_local_911,
        Some(prod_local_912) => { let prod_local_913 = prod_local_912; { let prod_local_914 = convertInt16ToUInt64(prod_local_855); match prod_local_914 {
        None => prod_local_914,
        Some(prod_local_915) => { let prod_local_917 = 52; { let prod_local_918 = (prod_local_915).checked_shl(prod_local_917); match prod_local_918 {
        None => prod_local_918,
        Some(prod_local_919) => { let prod_local_921 = 4503599627370495; { let prod_local_922 = (prod_local_913 & prod_local_921); { let prod_local_923 = (prod_local_919 | prod_local_922); { let prod_local_924 = (sg | prod_local_923); { let prod_local_925 = Some(prod_local_924); prod_local_925 } } } } },
    } } },
    } } },
    } } },
    } } },
    },
        true => { let prod_local_927 = 9218868437227405312; { let prod_local_928 = (sg | prod_local_927); { let prod_local_929 = Some(prod_local_928); prod_local_929 } } },
    } } } } } } } },
        true => { let prod_local_930 = 0; { let prod_local_931 = prod_local_930; { let prod_local_932 = prod_local_931; { let prod_local_933 = prod_local_932; { let prod_local_934 = 2046; { let prod_local_935 = prod_local_934; { let prod_local_936 = signedLess(prod_local_935, prod_local_933); match prod_local_936 {
        false => match overflow {
        false => { let prod_local_938 = false; { let prod_local_939 = prod_local_938; match prod_local_939 {
        false => { let prod_local_941 = rounded; { let prod_local_942 = convertInt16ToUInt64(prod_local_933); match prod_local_942 {
        None => prod_local_942,
        Some(prod_local_943) => { let prod_local_945 = 52; { let prod_local_946 = (prod_local_943).checked_shl(prod_local_945); match prod_local_946 {
        None => prod_local_946,
        Some(prod_local_947) => { let prod_local_949 = 4503599627370495; { let prod_local_950 = (prod_local_941 & prod_local_949); { let prod_local_951 = (prod_local_947 | prod_local_950); { let prod_local_952 = (sg | prod_local_951); { let prod_local_953 = Some(prod_local_952); prod_local_953 } } } } },
    } } },
    } } },
        true => { let prod_local_955 = 1; { let prod_local_956 = (rounded).checked_shr(prod_local_955); match prod_local_956 {
        None => prod_local_956,
        Some(prod_local_957) => { let prod_local_958 = prod_local_957; { let prod_local_959 = convertInt16ToUInt64(prod_local_933); match prod_local_959 {
        None => prod_local_959,
        Some(prod_local_960) => { let prod_local_962 = 52; { let prod_local_963 = (prod_local_960).checked_shl(prod_local_962); match prod_local_963 {
        None => prod_local_963,
        Some(prod_local_964) => { let prod_local_966 = 4503599627370495; { let prod_local_967 = (prod_local_958 & prod_local_966); { let prod_local_968 = (prod_local_964 | prod_local_967); { let prod_local_969 = (sg | prod_local_968); { let prod_local_970 = Some(prod_local_969); prod_local_970 } } } } },
    } } },
    } } },
    } } },
    } } },
        true => { let prod_local_971 = true; { let prod_local_972 = prod_local_971; match prod_local_972 {
        false => { let prod_local_974 = rounded; { let prod_local_975 = convertInt16ToUInt64(prod_local_933); match prod_local_975 {
        None => prod_local_975,
        Some(prod_local_976) => { let prod_local_978 = 52; { let prod_local_979 = (prod_local_976).checked_shl(prod_local_978); match prod_local_979 {
        None => prod_local_979,
        Some(prod_local_980) => { let prod_local_982 = 4503599627370495; { let prod_local_983 = (prod_local_974 & prod_local_982); { let prod_local_984 = (prod_local_980 | prod_local_983); { let prod_local_985 = (sg | prod_local_984); { let prod_local_986 = Some(prod_local_985); prod_local_986 } } } } },
    } } },
    } } },
        true => { let prod_local_988 = 1; { let prod_local_989 = (rounded).checked_shr(prod_local_988); match prod_local_989 {
        None => prod_local_989,
        Some(prod_local_990) => { let prod_local_991 = prod_local_990; { let prod_local_992 = convertInt16ToUInt64(prod_local_933); match prod_local_992 {
        None => prod_local_992,
        Some(prod_local_993) => { let prod_local_995 = 52; { let prod_local_996 = (prod_local_993).checked_shl(prod_local_995); match prod_local_996 {
        None => prod_local_996,
        Some(prod_local_997) => { let prod_local_999 = 4503599627370495; { let prod_local_1000 = (prod_local_991 & prod_local_999); { let prod_local_1001 = (prod_local_997 | prod_local_1000); { let prod_local_1002 = (sg | prod_local_1001); { let prod_local_1003 = Some(prod_local_1002); prod_local_1003 } } } } },
    } } },
    } } },
    } } },
    } } },
    },
        true => { let prod_local_1005 = 9218868437227405312; { let prod_local_1006 = (sg | prod_local_1005); { let prod_local_1007 = Some(prod_local_1006); prod_local_1007 } } },
    } } } } } } } },
    } } },
        true => { let prod_local_1008 = true; { let prod_local_1009 = prod_local_1008; match prod_local_1009 {
        false => { let prod_local_1011 = 1; { let prod_local_1012 = prod_local_1011; { let prod_local_1013 = prod_local_1012; { let prod_local_1014 = prod_local_1013; { let prod_local_1015 = 2046; { let prod_local_1016 = prod_local_1015; { let prod_local_1017 = signedLess(prod_local_1016, prod_local_1014); match prod_local_1017 {
        false => match overflow {
        false => { let prod_local_1019 = false; { let prod_local_1020 = prod_local_1019; match prod_local_1020 {
        false => { let prod_local_1022 = rounded; { let prod_local_1023 = convertInt16ToUInt64(prod_local_1014); match prod_local_1023 {
        None => prod_local_1023,
        Some(prod_local_1024) => { let prod_local_1026 = 52; { let prod_local_1027 = (prod_local_1024).checked_shl(prod_local_1026); match prod_local_1027 {
        None => prod_local_1027,
        Some(prod_local_1028) => { let prod_local_1030 = 4503599627370495; { let prod_local_1031 = (prod_local_1022 & prod_local_1030); { let prod_local_1032 = (prod_local_1028 | prod_local_1031); { let prod_local_1033 = (sg | prod_local_1032); { let prod_local_1034 = Some(prod_local_1033); prod_local_1034 } } } } },
    } } },
    } } },
        true => { let prod_local_1036 = 1; { let prod_local_1037 = (rounded).checked_shr(prod_local_1036); match prod_local_1037 {
        None => prod_local_1037,
        Some(prod_local_1038) => { let prod_local_1039 = prod_local_1038; { let prod_local_1040 = convertInt16ToUInt64(prod_local_1014); match prod_local_1040 {
        None => prod_local_1040,
        Some(prod_local_1041) => { let prod_local_1043 = 52; { let prod_local_1044 = (prod_local_1041).checked_shl(prod_local_1043); match prod_local_1044 {
        None => prod_local_1044,
        Some(prod_local_1045) => { let prod_local_1047 = 4503599627370495; { let prod_local_1048 = (prod_local_1039 & prod_local_1047); { let prod_local_1049 = (prod_local_1045 | prod_local_1048); { let prod_local_1050 = (sg | prod_local_1049); { let prod_local_1051 = Some(prod_local_1050); prod_local_1051 } } } } },
    } } },
    } } },
    } } },
    } } },
        true => { let prod_local_1052 = true; { let prod_local_1053 = prod_local_1052; match prod_local_1053 {
        false => { let prod_local_1055 = rounded; { let prod_local_1056 = convertInt16ToUInt64(prod_local_1014); match prod_local_1056 {
        None => prod_local_1056,
        Some(prod_local_1057) => { let prod_local_1059 = 52; { let prod_local_1060 = (prod_local_1057).checked_shl(prod_local_1059); match prod_local_1060 {
        None => prod_local_1060,
        Some(prod_local_1061) => { let prod_local_1063 = 4503599627370495; { let prod_local_1064 = (prod_local_1055 & prod_local_1063); { let prod_local_1065 = (prod_local_1061 | prod_local_1064); { let prod_local_1066 = (sg | prod_local_1065); { let prod_local_1067 = Some(prod_local_1066); prod_local_1067 } } } } },
    } } },
    } } },
        true => { let prod_local_1069 = 1; { let prod_local_1070 = (rounded).checked_shr(prod_local_1069); match prod_local_1070 {
        None => prod_local_1070,
        Some(prod_local_1071) => { let prod_local_1072 = prod_local_1071; { let prod_local_1073 = convertInt16ToUInt64(prod_local_1014); match prod_local_1073 {
        None => prod_local_1073,
        Some(prod_local_1074) => { let prod_local_1076 = 52; { let prod_local_1077 = (prod_local_1074).checked_shl(prod_local_1076); match prod_local_1077 {
        None => prod_local_1077,
        Some(prod_local_1078) => { let prod_local_1080 = 4503599627370495; { let prod_local_1081 = (prod_local_1072 & prod_local_1080); { let prod_local_1082 = (prod_local_1078 | prod_local_1081); { let prod_local_1083 = (sg | prod_local_1082); { let prod_local_1084 = Some(prod_local_1083); prod_local_1084 } } } } },
    } } },
    } } },
    } } },
    } } },
    },
        true => { let prod_local_1086 = 9218868437227405312; { let prod_local_1087 = (sg | prod_local_1086); { let prod_local_1088 = Some(prod_local_1087); prod_local_1088 } } },
    } } } } } } } },
        true => { let prod_local_1089 = 0; { let prod_local_1090 = prod_local_1089; { let prod_local_1091 = prod_local_1090; { let prod_local_1092 = prod_local_1091; { let prod_local_1093 = 2046; { let prod_local_1094 = prod_local_1093; { let prod_local_1095 = signedLess(prod_local_1094, prod_local_1092); match prod_local_1095 {
        false => match overflow {
        false => { let prod_local_1097 = false; { let prod_local_1098 = prod_local_1097; match prod_local_1098 {
        false => { let prod_local_1100 = rounded; { let prod_local_1101 = convertInt16ToUInt64(prod_local_1092); match prod_local_1101 {
        None => prod_local_1101,
        Some(prod_local_1102) => { let prod_local_1104 = 52; { let prod_local_1105 = (prod_local_1102).checked_shl(prod_local_1104); match prod_local_1105 {
        None => prod_local_1105,
        Some(prod_local_1106) => { let prod_local_1108 = 4503599627370495; { let prod_local_1109 = (prod_local_1100 & prod_local_1108); { let prod_local_1110 = (prod_local_1106 | prod_local_1109); { let prod_local_1111 = (sg | prod_local_1110); { let prod_local_1112 = Some(prod_local_1111); prod_local_1112 } } } } },
    } } },
    } } },
        true => { let prod_local_1114 = 1; { let prod_local_1115 = (rounded).checked_shr(prod_local_1114); match prod_local_1115 {
        None => prod_local_1115,
        Some(prod_local_1116) => { let prod_local_1117 = prod_local_1116; { let prod_local_1118 = convertInt16ToUInt64(prod_local_1092); match prod_local_1118 {
        None => prod_local_1118,
        Some(prod_local_1119) => { let prod_local_1121 = 52; { let prod_local_1122 = (prod_local_1119).checked_shl(prod_local_1121); match prod_local_1122 {
        None => prod_local_1122,
        Some(prod_local_1123) => { let prod_local_1125 = 4503599627370495; { let prod_local_1126 = (prod_local_1117 & prod_local_1125); { let prod_local_1127 = (prod_local_1123 | prod_local_1126); { let prod_local_1128 = (sg | prod_local_1127); { let prod_local_1129 = Some(prod_local_1128); prod_local_1129 } } } } },
    } } },
    } } },
    } } },
    } } },
        true => { let prod_local_1130 = true; { let prod_local_1131 = prod_local_1130; match prod_local_1131 {
        false => { let prod_local_1133 = rounded; { let prod_local_1134 = convertInt16ToUInt64(prod_local_1092); match prod_local_1134 {
        None => prod_local_1134,
        Some(prod_local_1135) => { let prod_local_1137 = 52; { let prod_local_1138 = (prod_local_1135).checked_shl(prod_local_1137); match prod_local_1138 {
        None => prod_local_1138,
        Some(prod_local_1139) => { let prod_local_1141 = 4503599627370495; { let prod_local_1142 = (prod_local_1133 & prod_local_1141); { let prod_local_1143 = (prod_local_1139 | prod_local_1142); { let prod_local_1144 = (sg | prod_local_1143); { let prod_local_1145 = Some(prod_local_1144); prod_local_1145 } } } } },
    } } },
    } } },
        true => { let prod_local_1147 = 1; { let prod_local_1148 = (rounded).checked_shr(prod_local_1147); match prod_local_1148 {
        None => prod_local_1148,
        Some(prod_local_1149) => { let prod_local_1150 = prod_local_1149; { let prod_local_1151 = convertInt16ToUInt64(prod_local_1092); match prod_local_1151 {
        None => prod_local_1151,
        Some(prod_local_1152) => { let prod_local_1154 = 52; { let prod_local_1155 = (prod_local_1152).checked_shl(prod_local_1154); match prod_local_1155 {
        None => prod_local_1155,
        Some(prod_local_1156) => { let prod_local_1158 = 4503599627370495; { let prod_local_1159 = (prod_local_1150 & prod_local_1158); { let prod_local_1160 = (prod_local_1156 | prod_local_1159); { let prod_local_1161 = (sg | prod_local_1160); { let prod_local_1162 = Some(prod_local_1161); prod_local_1162 } } } } },
    } } },
    } } },
    } } },
    } } },
    },
        true => { let prod_local_1164 = 9218868437227405312; { let prod_local_1165 = (sg | prod_local_1164); { let prod_local_1166 = Some(prod_local_1165); prod_local_1166 } } },
    } } } } } } } },
    } } },
    } } },
    } } },
        true => { let prod_local_1167 = true; { let prod_local_1168 = prod_local_1167; match prod_local_1168 {
        false => { let prod_local_1170 = 1023; { let prod_local_1171 = prod_local_1170; { let prod_local_1172 = int16Add(prod_local_757, prod_local_1171); match prod_local_1172 {
        None => None,
        Some(prod_local_1174) => { let prod_local_1175 = prod_local_1174; { let prod_local_1176 = 2046; { let prod_local_1177 = prod_local_1176; { let prod_local_1178 = signedLess(prod_local_1177, prod_local_1175); match prod_local_1178 {
        false => match overflow {
        false => { let prod_local_1180 = false; { let prod_local_1181 = prod_local_1180; match prod_local_1181 {
        false => { let prod_local_1183 = rounded; { let prod_local_1184 = convertInt16ToUInt64(prod_local_1175); match prod_local_1184 {
        None => prod_local_1184,
        Some(prod_local_1185) => { let prod_local_1187 = 52; { let prod_local_1188 = (prod_local_1185).checked_shl(prod_local_1187); match prod_local_1188 {
        None => prod_local_1188,
        Some(prod_local_1189) => { let prod_local_1191 = 4503599627370495; { let prod_local_1192 = (prod_local_1183 & prod_local_1191); { let prod_local_1193 = (prod_local_1189 | prod_local_1192); { let prod_local_1194 = (sg | prod_local_1193); { let prod_local_1195 = Some(prod_local_1194); prod_local_1195 } } } } },
    } } },
    } } },
        true => { let prod_local_1197 = 1; { let prod_local_1198 = (rounded).checked_shr(prod_local_1197); match prod_local_1198 {
        None => prod_local_1198,
        Some(prod_local_1199) => { let prod_local_1200 = prod_local_1199; { let prod_local_1201 = convertInt16ToUInt64(prod_local_1175); match prod_local_1201 {
        None => prod_local_1201,
        Some(prod_local_1202) => { let prod_local_1204 = 52; { let prod_local_1205 = (prod_local_1202).checked_shl(prod_local_1204); match prod_local_1205 {
        None => prod_local_1205,
        Some(prod_local_1206) => { let prod_local_1208 = 4503599627370495; { let prod_local_1209 = (prod_local_1200 & prod_local_1208); { let prod_local_1210 = (prod_local_1206 | prod_local_1209); { let prod_local_1211 = (sg | prod_local_1210); { let prod_local_1212 = Some(prod_local_1211); prod_local_1212 } } } } },
    } } },
    } } },
    } } },
    } } },
        true => { let prod_local_1213 = true; { let prod_local_1214 = prod_local_1213; match prod_local_1214 {
        false => { let prod_local_1216 = rounded; { let prod_local_1217 = convertInt16ToUInt64(prod_local_1175); match prod_local_1217 {
        None => prod_local_1217,
        Some(prod_local_1218) => { let prod_local_1220 = 52; { let prod_local_1221 = (prod_local_1218).checked_shl(prod_local_1220); match prod_local_1221 {
        None => prod_local_1221,
        Some(prod_local_1222) => { let prod_local_1224 = 4503599627370495; { let prod_local_1225 = (prod_local_1216 & prod_local_1224); { let prod_local_1226 = (prod_local_1222 | prod_local_1225); { let prod_local_1227 = (sg | prod_local_1226); { let prod_local_1228 = Some(prod_local_1227); prod_local_1228 } } } } },
    } } },
    } } },
        true => { let prod_local_1230 = 1; { let prod_local_1231 = (rounded).checked_shr(prod_local_1230); match prod_local_1231 {
        None => prod_local_1231,
        Some(prod_local_1232) => { let prod_local_1233 = prod_local_1232; { let prod_local_1234 = convertInt16ToUInt64(prod_local_1175); match prod_local_1234 {
        None => prod_local_1234,
        Some(prod_local_1235) => { let prod_local_1237 = 52; { let prod_local_1238 = (prod_local_1235).checked_shl(prod_local_1237); match prod_local_1238 {
        None => prod_local_1238,
        Some(prod_local_1239) => { let prod_local_1241 = 4503599627370495; { let prod_local_1242 = (prod_local_1233 & prod_local_1241); { let prod_local_1243 = (prod_local_1239 | prod_local_1242); { let prod_local_1244 = (sg | prod_local_1243); { let prod_local_1245 = Some(prod_local_1244); prod_local_1245 } } } } },
    } } },
    } } },
    } } },
    } } },
    },
        true => { let prod_local_1247 = 9218868437227405312; { let prod_local_1248 = (sg | prod_local_1247); { let prod_local_1249 = Some(prod_local_1248); prod_local_1249 } } },
    } } } } },
    } } } },
        true => { let prod_local_1250 = 4503599627370496; { let prod_local_1251 = unsignedLess(rounded, prod_local_1250); match prod_local_1251 {
        false => { let prod_local_1253 = false; { let prod_local_1254 = prod_local_1253; match prod_local_1254 {
        false => { let prod_local_1256 = 1; { let prod_local_1257 = prod_local_1256; { let prod_local_1258 = prod_local_1257; { let prod_local_1259 = prod_local_1258; { let prod_local_1260 = 2046; { let prod_local_1261 = prod_local_1260; { let prod_local_1262 = signedLess(prod_local_1261, prod_local_1259); match prod_local_1262 {
        false => match overflow {
        false => { let prod_local_1264 = false; { let prod_local_1265 = prod_local_1264; match prod_local_1265 {
        false => { let prod_local_1267 = rounded; { let prod_local_1268 = convertInt16ToUInt64(prod_local_1259); match prod_local_1268 {
        None => prod_local_1268,
        Some(prod_local_1269) => { let prod_local_1271 = 52; { let prod_local_1272 = (prod_local_1269).checked_shl(prod_local_1271); match prod_local_1272 {
        None => prod_local_1272,
        Some(prod_local_1273) => { let prod_local_1275 = 4503599627370495; { let prod_local_1276 = (prod_local_1267 & prod_local_1275); { let prod_local_1277 = (prod_local_1273 | prod_local_1276); { let prod_local_1278 = (sg | prod_local_1277); { let prod_local_1279 = Some(prod_local_1278); prod_local_1279 } } } } },
    } } },
    } } },
        true => { let prod_local_1281 = 1; { let prod_local_1282 = (rounded).checked_shr(prod_local_1281); match prod_local_1282 {
        None => prod_local_1282,
        Some(prod_local_1283) => { let prod_local_1284 = prod_local_1283; { let prod_local_1285 = convertInt16ToUInt64(prod_local_1259); match prod_local_1285 {
        None => prod_local_1285,
        Some(prod_local_1286) => { let prod_local_1288 = 52; { let prod_local_1289 = (prod_local_1286).checked_shl(prod_local_1288); match prod_local_1289 {
        None => prod_local_1289,
        Some(prod_local_1290) => { let prod_local_1292 = 4503599627370495; { let prod_local_1293 = (prod_local_1284 & prod_local_1292); { let prod_local_1294 = (prod_local_1290 | prod_local_1293); { let prod_local_1295 = (sg | prod_local_1294); { let prod_local_1296 = Some(prod_local_1295); prod_local_1296 } } } } },
    } } },
    } } },
    } } },
    } } },
        true => { let prod_local_1297 = true; { let prod_local_1298 = prod_local_1297; match prod_local_1298 {
        false => { let prod_local_1300 = rounded; { let prod_local_1301 = convertInt16ToUInt64(prod_local_1259); match prod_local_1301 {
        None => prod_local_1301,
        Some(prod_local_1302) => { let prod_local_1304 = 52; { let prod_local_1305 = (prod_local_1302).checked_shl(prod_local_1304); match prod_local_1305 {
        None => prod_local_1305,
        Some(prod_local_1306) => { let prod_local_1308 = 4503599627370495; { let prod_local_1309 = (prod_local_1300 & prod_local_1308); { let prod_local_1310 = (prod_local_1306 | prod_local_1309); { let prod_local_1311 = (sg | prod_local_1310); { let prod_local_1312 = Some(prod_local_1311); prod_local_1312 } } } } },
    } } },
    } } },
        true => { let prod_local_1314 = 1; { let prod_local_1315 = (rounded).checked_shr(prod_local_1314); match prod_local_1315 {
        None => prod_local_1315,
        Some(prod_local_1316) => { let prod_local_1317 = prod_local_1316; { let prod_local_1318 = convertInt16ToUInt64(prod_local_1259); match prod_local_1318 {
        None => prod_local_1318,
        Some(prod_local_1319) => { let prod_local_1321 = 52; { let prod_local_1322 = (prod_local_1319).checked_shl(prod_local_1321); match prod_local_1322 {
        None => prod_local_1322,
        Some(prod_local_1323) => { let prod_local_1325 = 4503599627370495; { let prod_local_1326 = (prod_local_1317 & prod_local_1325); { let prod_local_1327 = (prod_local_1323 | prod_local_1326); { let prod_local_1328 = (sg | prod_local_1327); { let prod_local_1329 = Some(prod_local_1328); prod_local_1329 } } } } },
    } } },
    } } },
    } } },
    } } },
    },
        true => { let prod_local_1331 = 9218868437227405312; { let prod_local_1332 = (sg | prod_local_1331); { let prod_local_1333 = Some(prod_local_1332); prod_local_1333 } } },
    } } } } } } } },
        true => { let prod_local_1334 = 0; { let prod_local_1335 = prod_local_1334; { let prod_local_1336 = prod_local_1335; { let prod_local_1337 = prod_local_1336; { let prod_local_1338 = 2046; { let prod_local_1339 = prod_local_1338; { let prod_local_1340 = signedLess(prod_local_1339, prod_local_1337); match prod_local_1340 {
        false => match overflow {
        false => { let prod_local_1342 = false; { let prod_local_1343 = prod_local_1342; match prod_local_1343 {
        false => { let prod_local_1345 = rounded; { let prod_local_1346 = convertInt16ToUInt64(prod_local_1337); match prod_local_1346 {
        None => prod_local_1346,
        Some(prod_local_1347) => { let prod_local_1349 = 52; { let prod_local_1350 = (prod_local_1347).checked_shl(prod_local_1349); match prod_local_1350 {
        None => prod_local_1350,
        Some(prod_local_1351) => { let prod_local_1353 = 4503599627370495; { let prod_local_1354 = (prod_local_1345 & prod_local_1353); { let prod_local_1355 = (prod_local_1351 | prod_local_1354); { let prod_local_1356 = (sg | prod_local_1355); { let prod_local_1357 = Some(prod_local_1356); prod_local_1357 } } } } },
    } } },
    } } },
        true => { let prod_local_1359 = 1; { let prod_local_1360 = (rounded).checked_shr(prod_local_1359); match prod_local_1360 {
        None => prod_local_1360,
        Some(prod_local_1361) => { let prod_local_1362 = prod_local_1361; { let prod_local_1363 = convertInt16ToUInt64(prod_local_1337); match prod_local_1363 {
        None => prod_local_1363,
        Some(prod_local_1364) => { let prod_local_1366 = 52; { let prod_local_1367 = (prod_local_1364).checked_shl(prod_local_1366); match prod_local_1367 {
        None => prod_local_1367,
        Some(prod_local_1368) => { let prod_local_1370 = 4503599627370495; { let prod_local_1371 = (prod_local_1362 & prod_local_1370); { let prod_local_1372 = (prod_local_1368 | prod_local_1371); { let prod_local_1373 = (sg | prod_local_1372); { let prod_local_1374 = Some(prod_local_1373); prod_local_1374 } } } } },
    } } },
    } } },
    } } },
    } } },
        true => { let prod_local_1375 = true; { let prod_local_1376 = prod_local_1375; match prod_local_1376 {
        false => { let prod_local_1378 = rounded; { let prod_local_1379 = convertInt16ToUInt64(prod_local_1337); match prod_local_1379 {
        None => prod_local_1379,
        Some(prod_local_1380) => { let prod_local_1382 = 52; { let prod_local_1383 = (prod_local_1380).checked_shl(prod_local_1382); match prod_local_1383 {
        None => prod_local_1383,
        Some(prod_local_1384) => { let prod_local_1386 = 4503599627370495; { let prod_local_1387 = (prod_local_1378 & prod_local_1386); { let prod_local_1388 = (prod_local_1384 | prod_local_1387); { let prod_local_1389 = (sg | prod_local_1388); { let prod_local_1390 = Some(prod_local_1389); prod_local_1390 } } } } },
    } } },
    } } },
        true => { let prod_local_1392 = 1; { let prod_local_1393 = (rounded).checked_shr(prod_local_1392); match prod_local_1393 {
        None => prod_local_1393,
        Some(prod_local_1394) => { let prod_local_1395 = prod_local_1394; { let prod_local_1396 = convertInt16ToUInt64(prod_local_1337); match prod_local_1396 {
        None => prod_local_1396,
        Some(prod_local_1397) => { let prod_local_1399 = 52; { let prod_local_1400 = (prod_local_1397).checked_shl(prod_local_1399); match prod_local_1400 {
        None => prod_local_1400,
        Some(prod_local_1401) => { let prod_local_1403 = 4503599627370495; { let prod_local_1404 = (prod_local_1395 & prod_local_1403); { let prod_local_1405 = (prod_local_1401 | prod_local_1404); { let prod_local_1406 = (sg | prod_local_1405); { let prod_local_1407 = Some(prod_local_1406); prod_local_1407 } } } } },
    } } },
    } } },
    } } },
    } } },
    },
        true => { let prod_local_1409 = 9218868437227405312; { let prod_local_1410 = (sg | prod_local_1409); { let prod_local_1411 = Some(prod_local_1410); prod_local_1411 } } },
    } } } } } } } },
    } } },
        true => { let prod_local_1412 = true; { let prod_local_1413 = prod_local_1412; match prod_local_1413 {
        false => { let prod_local_1415 = 1; { let prod_local_1416 = prod_local_1415; { let prod_local_1417 = prod_local_1416; { let prod_local_1418 = prod_local_1417; { let prod_local_1419 = 2046; { let prod_local_1420 = prod_local_1419; { let prod_local_1421 = signedLess(prod_local_1420, prod_local_1418); match prod_local_1421 {
        false => match overflow {
        false => { let prod_local_1423 = false; { let prod_local_1424 = prod_local_1423; match prod_local_1424 {
        false => { let prod_local_1426 = rounded; { let prod_local_1427 = convertInt16ToUInt64(prod_local_1418); match prod_local_1427 {
        None => prod_local_1427,
        Some(prod_local_1428) => { let prod_local_1430 = 52; { let prod_local_1431 = (prod_local_1428).checked_shl(prod_local_1430); match prod_local_1431 {
        None => prod_local_1431,
        Some(prod_local_1432) => { let prod_local_1434 = 4503599627370495; { let prod_local_1435 = (prod_local_1426 & prod_local_1434); { let prod_local_1436 = (prod_local_1432 | prod_local_1435); { let prod_local_1437 = (sg | prod_local_1436); { let prod_local_1438 = Some(prod_local_1437); prod_local_1438 } } } } },
    } } },
    } } },
        true => { let prod_local_1440 = 1; { let prod_local_1441 = (rounded).checked_shr(prod_local_1440); match prod_local_1441 {
        None => prod_local_1441,
        Some(prod_local_1442) => { let prod_local_1443 = prod_local_1442; { let prod_local_1444 = convertInt16ToUInt64(prod_local_1418); match prod_local_1444 {
        None => prod_local_1444,
        Some(prod_local_1445) => { let prod_local_1447 = 52; { let prod_local_1448 = (prod_local_1445).checked_shl(prod_local_1447); match prod_local_1448 {
        None => prod_local_1448,
        Some(prod_local_1449) => { let prod_local_1451 = 4503599627370495; { let prod_local_1452 = (prod_local_1443 & prod_local_1451); { let prod_local_1453 = (prod_local_1449 | prod_local_1452); { let prod_local_1454 = (sg | prod_local_1453); { let prod_local_1455 = Some(prod_local_1454); prod_local_1455 } } } } },
    } } },
    } } },
    } } },
    } } },
        true => { let prod_local_1456 = true; { let prod_local_1457 = prod_local_1456; match prod_local_1457 {
        false => { let prod_local_1459 = rounded; { let prod_local_1460 = convertInt16ToUInt64(prod_local_1418); match prod_local_1460 {
        None => prod_local_1460,
        Some(prod_local_1461) => { let prod_local_1463 = 52; { let prod_local_1464 = (prod_local_1461).checked_shl(prod_local_1463); match prod_local_1464 {
        None => prod_local_1464,
        Some(prod_local_1465) => { let prod_local_1467 = 4503599627370495; { let prod_local_1468 = (prod_local_1459 & prod_local_1467); { let prod_local_1469 = (prod_local_1465 | prod_local_1468); { let prod_local_1470 = (sg | prod_local_1469); { let prod_local_1471 = Some(prod_local_1470); prod_local_1471 } } } } },
    } } },
    } } },
        true => { let prod_local_1473 = 1; { let prod_local_1474 = (rounded).checked_shr(prod_local_1473); match prod_local_1474 {
        None => prod_local_1474,
        Some(prod_local_1475) => { let prod_local_1476 = prod_local_1475; { let prod_local_1477 = convertInt16ToUInt64(prod_local_1418); match prod_local_1477 {
        None => prod_local_1477,
        Some(prod_local_1478) => { let prod_local_1480 = 52; { let prod_local_1481 = (prod_local_1478).checked_shl(prod_local_1480); match prod_local_1481 {
        None => prod_local_1481,
        Some(prod_local_1482) => { let prod_local_1484 = 4503599627370495; { let prod_local_1485 = (prod_local_1476 & prod_local_1484); { let prod_local_1486 = (prod_local_1482 | prod_local_1485); { let prod_local_1487 = (sg | prod_local_1486); { let prod_local_1488 = Some(prod_local_1487); prod_local_1488 } } } } },
    } } },
    } } },
    } } },
    } } },
    },
        true => { let prod_local_1490 = 9218868437227405312; { let prod_local_1491 = (sg | prod_local_1490); { let prod_local_1492 = Some(prod_local_1491); prod_local_1492 } } },
    } } } } } } } },
        true => { let prod_local_1493 = 0; { let prod_local_1494 = prod_local_1493; { let prod_local_1495 = prod_local_1494; { let prod_local_1496 = prod_local_1495; { let prod_local_1497 = 2046; { let prod_local_1498 = prod_local_1497; { let prod_local_1499 = signedLess(prod_local_1498, prod_local_1496); match prod_local_1499 {
        false => match overflow {
        false => { let prod_local_1501 = false; { let prod_local_1502 = prod_local_1501; match prod_local_1502 {
        false => { let prod_local_1504 = rounded; { let prod_local_1505 = convertInt16ToUInt64(prod_local_1496); match prod_local_1505 {
        None => prod_local_1505,
        Some(prod_local_1506) => { let prod_local_1508 = 52; { let prod_local_1509 = (prod_local_1506).checked_shl(prod_local_1508); match prod_local_1509 {
        None => prod_local_1509,
        Some(prod_local_1510) => { let prod_local_1512 = 4503599627370495; { let prod_local_1513 = (prod_local_1504 & prod_local_1512); { let prod_local_1514 = (prod_local_1510 | prod_local_1513); { let prod_local_1515 = (sg | prod_local_1514); { let prod_local_1516 = Some(prod_local_1515); prod_local_1516 } } } } },
    } } },
    } } },
        true => { let prod_local_1518 = 1; { let prod_local_1519 = (rounded).checked_shr(prod_local_1518); match prod_local_1519 {
        None => prod_local_1519,
        Some(prod_local_1520) => { let prod_local_1521 = prod_local_1520; { let prod_local_1522 = convertInt16ToUInt64(prod_local_1496); match prod_local_1522 {
        None => prod_local_1522,
        Some(prod_local_1523) => { let prod_local_1525 = 52; { let prod_local_1526 = (prod_local_1523).checked_shl(prod_local_1525); match prod_local_1526 {
        None => prod_local_1526,
        Some(prod_local_1527) => { let prod_local_1529 = 4503599627370495; { let prod_local_1530 = (prod_local_1521 & prod_local_1529); { let prod_local_1531 = (prod_local_1527 | prod_local_1530); { let prod_local_1532 = (sg | prod_local_1531); { let prod_local_1533 = Some(prod_local_1532); prod_local_1533 } } } } },
    } } },
    } } },
    } } },
    } } },
        true => { let prod_local_1534 = true; { let prod_local_1535 = prod_local_1534; match prod_local_1535 {
        false => { let prod_local_1537 = rounded; { let prod_local_1538 = convertInt16ToUInt64(prod_local_1496); match prod_local_1538 {
        None => prod_local_1538,
        Some(prod_local_1539) => { let prod_local_1541 = 52; { let prod_local_1542 = (prod_local_1539).checked_shl(prod_local_1541); match prod_local_1542 {
        None => prod_local_1542,
        Some(prod_local_1543) => { let prod_local_1545 = 4503599627370495; { let prod_local_1546 = (prod_local_1537 & prod_local_1545); { let prod_local_1547 = (prod_local_1543 | prod_local_1546); { let prod_local_1548 = (sg | prod_local_1547); { let prod_local_1549 = Some(prod_local_1548); prod_local_1549 } } } } },
    } } },
    } } },
        true => { let prod_local_1551 = 1; { let prod_local_1552 = (rounded).checked_shr(prod_local_1551); match prod_local_1552 {
        None => prod_local_1552,
        Some(prod_local_1553) => { let prod_local_1554 = prod_local_1553; { let prod_local_1555 = convertInt16ToUInt64(prod_local_1496); match prod_local_1555 {
        None => prod_local_1555,
        Some(prod_local_1556) => { let prod_local_1558 = 52; { let prod_local_1559 = (prod_local_1556).checked_shl(prod_local_1558); match prod_local_1559 {
        None => prod_local_1559,
        Some(prod_local_1560) => { let prod_local_1562 = 4503599627370495; { let prod_local_1563 = (prod_local_1554 & prod_local_1562); { let prod_local_1564 = (prod_local_1560 | prod_local_1563); { let prod_local_1565 = (sg | prod_local_1564); { let prod_local_1566 = Some(prod_local_1565); prod_local_1566 } } } } },
    } } },
    } } },
    } } },
    } } },
    },
        true => { let prod_local_1568 = 9218868437227405312; { let prod_local_1569 = (sg | prod_local_1568); { let prod_local_1570 = Some(prod_local_1569); prod_local_1570 } } },
    } } } } } } } },
    } } },
    } } },
    } } },
    } } } } } },
    } } } },
    } } },
        true => { let _x_197 = true; { let prod_local_1571 = _x_197; match prod_local_1571 {
        false => { let prod_local_1573 = exponent; { let prod_local_1574 = 1022; { let prod_local_1575 = prod_local_1574; { let prod_local_1576 = -(prod_local_1575); { let prod_local_1577 = signedLess(prod_local_1573, prod_local_1576); match prod_local_1577 {
        false => { let prod_local_1579 = false; { let prod_local_1580 = prod_local_1579; match prod_local_1580 {
        false => { let prod_local_1582 = 1023; { let prod_local_1583 = prod_local_1582; { let prod_local_1584 = int16Add(prod_local_1573, prod_local_1583); match prod_local_1584 {
        None => None,
        Some(prod_local_1586) => { let prod_local_1587 = prod_local_1586; { let prod_local_1588 = 2046; { let prod_local_1589 = prod_local_1588; { let prod_local_1590 = signedLess(prod_local_1589, prod_local_1587); match prod_local_1590 {
        false => match overflow {
        false => { let prod_local_1592 = false; { let prod_local_1593 = prod_local_1592; match prod_local_1593 {
        false => { let prod_local_1595 = rounded; { let prod_local_1596 = convertInt16ToUInt64(prod_local_1587); match prod_local_1596 {
        None => prod_local_1596,
        Some(prod_local_1597) => { let prod_local_1599 = 52; { let prod_local_1600 = (prod_local_1597).checked_shl(prod_local_1599); match prod_local_1600 {
        None => prod_local_1600,
        Some(prod_local_1601) => { let prod_local_1603 = 4503599627370495; { let prod_local_1604 = (prod_local_1595 & prod_local_1603); { let prod_local_1605 = (prod_local_1601 | prod_local_1604); { let prod_local_1606 = (sg | prod_local_1605); { let prod_local_1607 = Some(prod_local_1606); prod_local_1607 } } } } },
    } } },
    } } },
        true => { let prod_local_1609 = 1; { let prod_local_1610 = (rounded).checked_shr(prod_local_1609); match prod_local_1610 {
        None => prod_local_1610,
        Some(prod_local_1611) => { let prod_local_1612 = prod_local_1611; { let prod_local_1613 = convertInt16ToUInt64(prod_local_1587); match prod_local_1613 {
        None => prod_local_1613,
        Some(prod_local_1614) => { let prod_local_1616 = 52; { let prod_local_1617 = (prod_local_1614).checked_shl(prod_local_1616); match prod_local_1617 {
        None => prod_local_1617,
        Some(prod_local_1618) => { let prod_local_1620 = 4503599627370495; { let prod_local_1621 = (prod_local_1612 & prod_local_1620); { let prod_local_1622 = (prod_local_1618 | prod_local_1621); { let prod_local_1623 = (sg | prod_local_1622); { let prod_local_1624 = Some(prod_local_1623); prod_local_1624 } } } } },
    } } },
    } } },
    } } },
    } } },
        true => { let prod_local_1625 = true; { let prod_local_1626 = prod_local_1625; match prod_local_1626 {
        false => { let prod_local_1628 = rounded; { let prod_local_1629 = convertInt16ToUInt64(prod_local_1587); match prod_local_1629 {
        None => prod_local_1629,
        Some(prod_local_1630) => { let prod_local_1632 = 52; { let prod_local_1633 = (prod_local_1630).checked_shl(prod_local_1632); match prod_local_1633 {
        None => prod_local_1633,
        Some(prod_local_1634) => { let prod_local_1636 = 4503599627370495; { let prod_local_1637 = (prod_local_1628 & prod_local_1636); { let prod_local_1638 = (prod_local_1634 | prod_local_1637); { let prod_local_1639 = (sg | prod_local_1638); { let prod_local_1640 = Some(prod_local_1639); prod_local_1640 } } } } },
    } } },
    } } },
        true => { let prod_local_1642 = 1; { let prod_local_1643 = (rounded).checked_shr(prod_local_1642); match prod_local_1643 {
        None => prod_local_1643,
        Some(prod_local_1644) => { let prod_local_1645 = prod_local_1644; { let prod_local_1646 = convertInt16ToUInt64(prod_local_1587); match prod_local_1646 {
        None => prod_local_1646,
        Some(prod_local_1647) => { let prod_local_1649 = 52; { let prod_local_1650 = (prod_local_1647).checked_shl(prod_local_1649); match prod_local_1650 {
        None => prod_local_1650,
        Some(prod_local_1651) => { let prod_local_1653 = 4503599627370495; { let prod_local_1654 = (prod_local_1645 & prod_local_1653); { let prod_local_1655 = (prod_local_1651 | prod_local_1654); { let prod_local_1656 = (sg | prod_local_1655); { let prod_local_1657 = Some(prod_local_1656); prod_local_1657 } } } } },
    } } },
    } } },
    } } },
    } } },
    },
        true => { let prod_local_1659 = 9218868437227405312; { let prod_local_1660 = (sg | prod_local_1659); { let prod_local_1661 = Some(prod_local_1660); prod_local_1661 } } },
    } } } } },
    } } } },
        true => { let prod_local_1662 = 4503599627370496; { let prod_local_1663 = unsignedLess(rounded, prod_local_1662); match prod_local_1663 {
        false => { let prod_local_1665 = false; { let prod_local_1666 = prod_local_1665; match prod_local_1666 {
        false => { let prod_local_1668 = 1; { let prod_local_1669 = prod_local_1668; { let prod_local_1670 = prod_local_1669; { let prod_local_1671 = prod_local_1670; { let prod_local_1672 = 2046; { let prod_local_1673 = prod_local_1672; { let prod_local_1674 = signedLess(prod_local_1673, prod_local_1671); match prod_local_1674 {
        false => match overflow {
        false => { let prod_local_1676 = false; { let prod_local_1677 = prod_local_1676; match prod_local_1677 {
        false => { let prod_local_1679 = rounded; { let prod_local_1680 = convertInt16ToUInt64(prod_local_1671); match prod_local_1680 {
        None => prod_local_1680,
        Some(prod_local_1681) => { let prod_local_1683 = 52; { let prod_local_1684 = (prod_local_1681).checked_shl(prod_local_1683); match prod_local_1684 {
        None => prod_local_1684,
        Some(prod_local_1685) => { let prod_local_1687 = 4503599627370495; { let prod_local_1688 = (prod_local_1679 & prod_local_1687); { let prod_local_1689 = (prod_local_1685 | prod_local_1688); { let prod_local_1690 = (sg | prod_local_1689); { let prod_local_1691 = Some(prod_local_1690); prod_local_1691 } } } } },
    } } },
    } } },
        true => { let prod_local_1693 = 1; { let prod_local_1694 = (rounded).checked_shr(prod_local_1693); match prod_local_1694 {
        None => prod_local_1694,
        Some(prod_local_1695) => { let prod_local_1696 = prod_local_1695; { let prod_local_1697 = convertInt16ToUInt64(prod_local_1671); match prod_local_1697 {
        None => prod_local_1697,
        Some(prod_local_1698) => { let prod_local_1700 = 52; { let prod_local_1701 = (prod_local_1698).checked_shl(prod_local_1700); match prod_local_1701 {
        None => prod_local_1701,
        Some(prod_local_1702) => { let prod_local_1704 = 4503599627370495; { let prod_local_1705 = (prod_local_1696 & prod_local_1704); { let prod_local_1706 = (prod_local_1702 | prod_local_1705); { let prod_local_1707 = (sg | prod_local_1706); { let prod_local_1708 = Some(prod_local_1707); prod_local_1708 } } } } },
    } } },
    } } },
    } } },
    } } },
        true => { let prod_local_1709 = true; { let prod_local_1710 = prod_local_1709; match prod_local_1710 {
        false => { let prod_local_1712 = rounded; { let prod_local_1713 = convertInt16ToUInt64(prod_local_1671); match prod_local_1713 {
        None => prod_local_1713,
        Some(prod_local_1714) => { let prod_local_1716 = 52; { let prod_local_1717 = (prod_local_1714).checked_shl(prod_local_1716); match prod_local_1717 {
        None => prod_local_1717,
        Some(prod_local_1718) => { let prod_local_1720 = 4503599627370495; { let prod_local_1721 = (prod_local_1712 & prod_local_1720); { let prod_local_1722 = (prod_local_1718 | prod_local_1721); { let prod_local_1723 = (sg | prod_local_1722); { let prod_local_1724 = Some(prod_local_1723); prod_local_1724 } } } } },
    } } },
    } } },
        true => { let prod_local_1726 = 1; { let prod_local_1727 = (rounded).checked_shr(prod_local_1726); match prod_local_1727 {
        None => prod_local_1727,
        Some(prod_local_1728) => { let prod_local_1729 = prod_local_1728; { let prod_local_1730 = convertInt16ToUInt64(prod_local_1671); match prod_local_1730 {
        None => prod_local_1730,
        Some(prod_local_1731) => { let prod_local_1733 = 52; { let prod_local_1734 = (prod_local_1731).checked_shl(prod_local_1733); match prod_local_1734 {
        None => prod_local_1734,
        Some(prod_local_1735) => { let prod_local_1737 = 4503599627370495; { let prod_local_1738 = (prod_local_1729 & prod_local_1737); { let prod_local_1739 = (prod_local_1735 | prod_local_1738); { let prod_local_1740 = (sg | prod_local_1739); { let prod_local_1741 = Some(prod_local_1740); prod_local_1741 } } } } },
    } } },
    } } },
    } } },
    } } },
    },
        true => { let prod_local_1743 = 9218868437227405312; { let prod_local_1744 = (sg | prod_local_1743); { let prod_local_1745 = Some(prod_local_1744); prod_local_1745 } } },
    } } } } } } } },
        true => { let prod_local_1746 = 0; { let prod_local_1747 = prod_local_1746; { let prod_local_1748 = prod_local_1747; { let prod_local_1749 = prod_local_1748; { let prod_local_1750 = 2046; { let prod_local_1751 = prod_local_1750; { let prod_local_1752 = signedLess(prod_local_1751, prod_local_1749); match prod_local_1752 {
        false => match overflow {
        false => { let prod_local_1754 = false; { let prod_local_1755 = prod_local_1754; match prod_local_1755 {
        false => { let prod_local_1757 = rounded; { let prod_local_1758 = convertInt16ToUInt64(prod_local_1749); match prod_local_1758 {
        None => prod_local_1758,
        Some(prod_local_1759) => { let prod_local_1761 = 52; { let prod_local_1762 = (prod_local_1759).checked_shl(prod_local_1761); match prod_local_1762 {
        None => prod_local_1762,
        Some(prod_local_1763) => { let prod_local_1765 = 4503599627370495; { let prod_local_1766 = (prod_local_1757 & prod_local_1765); { let prod_local_1767 = (prod_local_1763 | prod_local_1766); { let prod_local_1768 = (sg | prod_local_1767); { let prod_local_1769 = Some(prod_local_1768); prod_local_1769 } } } } },
    } } },
    } } },
        true => { let prod_local_1771 = 1; { let prod_local_1772 = (rounded).checked_shr(prod_local_1771); match prod_local_1772 {
        None => prod_local_1772,
        Some(prod_local_1773) => { let prod_local_1774 = prod_local_1773; { let prod_local_1775 = convertInt16ToUInt64(prod_local_1749); match prod_local_1775 {
        None => prod_local_1775,
        Some(prod_local_1776) => { let prod_local_1778 = 52; { let prod_local_1779 = (prod_local_1776).checked_shl(prod_local_1778); match prod_local_1779 {
        None => prod_local_1779,
        Some(prod_local_1780) => { let prod_local_1782 = 4503599627370495; { let prod_local_1783 = (prod_local_1774 & prod_local_1782); { let prod_local_1784 = (prod_local_1780 | prod_local_1783); { let prod_local_1785 = (sg | prod_local_1784); { let prod_local_1786 = Some(prod_local_1785); prod_local_1786 } } } } },
    } } },
    } } },
    } } },
    } } },
        true => { let prod_local_1787 = true; { let prod_local_1788 = prod_local_1787; match prod_local_1788 {
        false => { let prod_local_1790 = rounded; { let prod_local_1791 = convertInt16ToUInt64(prod_local_1749); match prod_local_1791 {
        None => prod_local_1791,
        Some(prod_local_1792) => { let prod_local_1794 = 52; { let prod_local_1795 = (prod_local_1792).checked_shl(prod_local_1794); match prod_local_1795 {
        None => prod_local_1795,
        Some(prod_local_1796) => { let prod_local_1798 = 4503599627370495; { let prod_local_1799 = (prod_local_1790 & prod_local_1798); { let prod_local_1800 = (prod_local_1796 | prod_local_1799); { let prod_local_1801 = (sg | prod_local_1800); { let prod_local_1802 = Some(prod_local_1801); prod_local_1802 } } } } },
    } } },
    } } },
        true => { let prod_local_1804 = 1; { let prod_local_1805 = (rounded).checked_shr(prod_local_1804); match prod_local_1805 {
        None => prod_local_1805,
        Some(prod_local_1806) => { let prod_local_1807 = prod_local_1806; { let prod_local_1808 = convertInt16ToUInt64(prod_local_1749); match prod_local_1808 {
        None => prod_local_1808,
        Some(prod_local_1809) => { let prod_local_1811 = 52; { let prod_local_1812 = (prod_local_1809).checked_shl(prod_local_1811); match prod_local_1812 {
        None => prod_local_1812,
        Some(prod_local_1813) => { let prod_local_1815 = 4503599627370495; { let prod_local_1816 = (prod_local_1807 & prod_local_1815); { let prod_local_1817 = (prod_local_1813 | prod_local_1816); { let prod_local_1818 = (sg | prod_local_1817); { let prod_local_1819 = Some(prod_local_1818); prod_local_1819 } } } } },
    } } },
    } } },
    } } },
    } } },
    },
        true => { let prod_local_1821 = 9218868437227405312; { let prod_local_1822 = (sg | prod_local_1821); { let prod_local_1823 = Some(prod_local_1822); prod_local_1823 } } },
    } } } } } } } },
    } } },
        true => { let prod_local_1824 = true; { let prod_local_1825 = prod_local_1824; match prod_local_1825 {
        false => { let prod_local_1827 = 1; { let prod_local_1828 = prod_local_1827; { let prod_local_1829 = prod_local_1828; { let prod_local_1830 = prod_local_1829; { let prod_local_1831 = 2046; { let prod_local_1832 = prod_local_1831; { let prod_local_1833 = signedLess(prod_local_1832, prod_local_1830); match prod_local_1833 {
        false => match overflow {
        false => { let prod_local_1835 = false; { let prod_local_1836 = prod_local_1835; match prod_local_1836 {
        false => { let prod_local_1838 = rounded; { let prod_local_1839 = convertInt16ToUInt64(prod_local_1830); match prod_local_1839 {
        None => prod_local_1839,
        Some(prod_local_1840) => { let prod_local_1842 = 52; { let prod_local_1843 = (prod_local_1840).checked_shl(prod_local_1842); match prod_local_1843 {
        None => prod_local_1843,
        Some(prod_local_1844) => { let prod_local_1846 = 4503599627370495; { let prod_local_1847 = (prod_local_1838 & prod_local_1846); { let prod_local_1848 = (prod_local_1844 | prod_local_1847); { let prod_local_1849 = (sg | prod_local_1848); { let prod_local_1850 = Some(prod_local_1849); prod_local_1850 } } } } },
    } } },
    } } },
        true => { let prod_local_1852 = 1; { let prod_local_1853 = (rounded).checked_shr(prod_local_1852); match prod_local_1853 {
        None => prod_local_1853,
        Some(prod_local_1854) => { let prod_local_1855 = prod_local_1854; { let prod_local_1856 = convertInt16ToUInt64(prod_local_1830); match prod_local_1856 {
        None => prod_local_1856,
        Some(prod_local_1857) => { let prod_local_1859 = 52; { let prod_local_1860 = (prod_local_1857).checked_shl(prod_local_1859); match prod_local_1860 {
        None => prod_local_1860,
        Some(prod_local_1861) => { let prod_local_1863 = 4503599627370495; { let prod_local_1864 = (prod_local_1855 & prod_local_1863); { let prod_local_1865 = (prod_local_1861 | prod_local_1864); { let prod_local_1866 = (sg | prod_local_1865); { let prod_local_1867 = Some(prod_local_1866); prod_local_1867 } } } } },
    } } },
    } } },
    } } },
    } } },
        true => { let prod_local_1868 = true; { let prod_local_1869 = prod_local_1868; match prod_local_1869 {
        false => { let prod_local_1871 = rounded; { let prod_local_1872 = convertInt16ToUInt64(prod_local_1830); match prod_local_1872 {
        None => prod_local_1872,
        Some(prod_local_1873) => { let prod_local_1875 = 52; { let prod_local_1876 = (prod_local_1873).checked_shl(prod_local_1875); match prod_local_1876 {
        None => prod_local_1876,
        Some(prod_local_1877) => { let prod_local_1879 = 4503599627370495; { let prod_local_1880 = (prod_local_1871 & prod_local_1879); { let prod_local_1881 = (prod_local_1877 | prod_local_1880); { let prod_local_1882 = (sg | prod_local_1881); { let prod_local_1883 = Some(prod_local_1882); prod_local_1883 } } } } },
    } } },
    } } },
        true => { let prod_local_1885 = 1; { let prod_local_1886 = (rounded).checked_shr(prod_local_1885); match prod_local_1886 {
        None => prod_local_1886,
        Some(prod_local_1887) => { let prod_local_1888 = prod_local_1887; { let prod_local_1889 = convertInt16ToUInt64(prod_local_1830); match prod_local_1889 {
        None => prod_local_1889,
        Some(prod_local_1890) => { let prod_local_1892 = 52; { let prod_local_1893 = (prod_local_1890).checked_shl(prod_local_1892); match prod_local_1893 {
        None => prod_local_1893,
        Some(prod_local_1894) => { let prod_local_1896 = 4503599627370495; { let prod_local_1897 = (prod_local_1888 & prod_local_1896); { let prod_local_1898 = (prod_local_1894 | prod_local_1897); { let prod_local_1899 = (sg | prod_local_1898); { let prod_local_1900 = Some(prod_local_1899); prod_local_1900 } } } } },
    } } },
    } } },
    } } },
    } } },
    },
        true => { let prod_local_1902 = 9218868437227405312; { let prod_local_1903 = (sg | prod_local_1902); { let prod_local_1904 = Some(prod_local_1903); prod_local_1904 } } },
    } } } } } } } },
        true => { let prod_local_1905 = 0; { let prod_local_1906 = prod_local_1905; { let prod_local_1907 = prod_local_1906; { let prod_local_1908 = prod_local_1907; { let prod_local_1909 = 2046; { let prod_local_1910 = prod_local_1909; { let prod_local_1911 = signedLess(prod_local_1910, prod_local_1908); match prod_local_1911 {
        false => match overflow {
        false => { let prod_local_1913 = false; { let prod_local_1914 = prod_local_1913; match prod_local_1914 {
        false => { let prod_local_1916 = rounded; { let prod_local_1917 = convertInt16ToUInt64(prod_local_1908); match prod_local_1917 {
        None => prod_local_1917,
        Some(prod_local_1918) => { let prod_local_1920 = 52; { let prod_local_1921 = (prod_local_1918).checked_shl(prod_local_1920); match prod_local_1921 {
        None => prod_local_1921,
        Some(prod_local_1922) => { let prod_local_1924 = 4503599627370495; { let prod_local_1925 = (prod_local_1916 & prod_local_1924); { let prod_local_1926 = (prod_local_1922 | prod_local_1925); { let prod_local_1927 = (sg | prod_local_1926); { let prod_local_1928 = Some(prod_local_1927); prod_local_1928 } } } } },
    } } },
    } } },
        true => { let prod_local_1930 = 1; { let prod_local_1931 = (rounded).checked_shr(prod_local_1930); match prod_local_1931 {
        None => prod_local_1931,
        Some(prod_local_1932) => { let prod_local_1933 = prod_local_1932; { let prod_local_1934 = convertInt16ToUInt64(prod_local_1908); match prod_local_1934 {
        None => prod_local_1934,
        Some(prod_local_1935) => { let prod_local_1937 = 52; { let prod_local_1938 = (prod_local_1935).checked_shl(prod_local_1937); match prod_local_1938 {
        None => prod_local_1938,
        Some(prod_local_1939) => { let prod_local_1941 = 4503599627370495; { let prod_local_1942 = (prod_local_1933 & prod_local_1941); { let prod_local_1943 = (prod_local_1939 | prod_local_1942); { let prod_local_1944 = (sg | prod_local_1943); { let prod_local_1945 = Some(prod_local_1944); prod_local_1945 } } } } },
    } } },
    } } },
    } } },
    } } },
        true => { let prod_local_1946 = true; { let prod_local_1947 = prod_local_1946; match prod_local_1947 {
        false => { let prod_local_1949 = rounded; { let prod_local_1950 = convertInt16ToUInt64(prod_local_1908); match prod_local_1950 {
        None => prod_local_1950,
        Some(prod_local_1951) => { let prod_local_1953 = 52; { let prod_local_1954 = (prod_local_1951).checked_shl(prod_local_1953); match prod_local_1954 {
        None => prod_local_1954,
        Some(prod_local_1955) => { let prod_local_1957 = 4503599627370495; { let prod_local_1958 = (prod_local_1949 & prod_local_1957); { let prod_local_1959 = (prod_local_1955 | prod_local_1958); { let prod_local_1960 = (sg | prod_local_1959); { let prod_local_1961 = Some(prod_local_1960); prod_local_1961 } } } } },
    } } },
    } } },
        true => { let prod_local_1963 = 1; { let prod_local_1964 = (rounded).checked_shr(prod_local_1963); match prod_local_1964 {
        None => prod_local_1964,
        Some(prod_local_1965) => { let prod_local_1966 = prod_local_1965; { let prod_local_1967 = convertInt16ToUInt64(prod_local_1908); match prod_local_1967 {
        None => prod_local_1967,
        Some(prod_local_1968) => { let prod_local_1970 = 52; { let prod_local_1971 = (prod_local_1968).checked_shl(prod_local_1970); match prod_local_1971 {
        None => prod_local_1971,
        Some(prod_local_1972) => { let prod_local_1974 = 4503599627370495; { let prod_local_1975 = (prod_local_1966 & prod_local_1974); { let prod_local_1976 = (prod_local_1972 | prod_local_1975); { let prod_local_1977 = (sg | prod_local_1976); { let prod_local_1978 = Some(prod_local_1977); prod_local_1978 } } } } },
    } } },
    } } },
    } } },
    } } },
    },
        true => { let prod_local_1980 = 9218868437227405312; { let prod_local_1981 = (sg | prod_local_1980); { let prod_local_1982 = Some(prod_local_1981); prod_local_1982 } } },
    } } } } } } } },
    } } },
    } } },
    } } },
        true => { let prod_local_1983 = true; { let prod_local_1984 = prod_local_1983; match prod_local_1984 {
        false => { let prod_local_1986 = 1023; { let prod_local_1987 = prod_local_1986; { let prod_local_1988 = int16Add(prod_local_1573, prod_local_1987); match prod_local_1988 {
        None => None,
        Some(prod_local_1990) => { let prod_local_1991 = prod_local_1990; { let prod_local_1992 = 2046; { let prod_local_1993 = prod_local_1992; { let prod_local_1994 = signedLess(prod_local_1993, prod_local_1991); match prod_local_1994 {
        false => match overflow {
        false => { let prod_local_1996 = false; { let prod_local_1997 = prod_local_1996; match prod_local_1997 {
        false => { let prod_local_1999 = rounded; { let prod_local_2000 = convertInt16ToUInt64(prod_local_1991); match prod_local_2000 {
        None => prod_local_2000,
        Some(prod_local_2001) => { let prod_local_2003 = 52; { let prod_local_2004 = (prod_local_2001).checked_shl(prod_local_2003); match prod_local_2004 {
        None => prod_local_2004,
        Some(prod_local_2005) => { let prod_local_2007 = 4503599627370495; { let prod_local_2008 = (prod_local_1999 & prod_local_2007); { let prod_local_2009 = (prod_local_2005 | prod_local_2008); { let prod_local_2010 = (sg | prod_local_2009); { let prod_local_2011 = Some(prod_local_2010); prod_local_2011 } } } } },
    } } },
    } } },
        true => { let prod_local_2013 = 1; { let prod_local_2014 = (rounded).checked_shr(prod_local_2013); match prod_local_2014 {
        None => prod_local_2014,
        Some(prod_local_2015) => { let prod_local_2016 = prod_local_2015; { let prod_local_2017 = convertInt16ToUInt64(prod_local_1991); match prod_local_2017 {
        None => prod_local_2017,
        Some(prod_local_2018) => { let prod_local_2020 = 52; { let prod_local_2021 = (prod_local_2018).checked_shl(prod_local_2020); match prod_local_2021 {
        None => prod_local_2021,
        Some(prod_local_2022) => { let prod_local_2024 = 4503599627370495; { let prod_local_2025 = (prod_local_2016 & prod_local_2024); { let prod_local_2026 = (prod_local_2022 | prod_local_2025); { let prod_local_2027 = (sg | prod_local_2026); { let prod_local_2028 = Some(prod_local_2027); prod_local_2028 } } } } },
    } } },
    } } },
    } } },
    } } },
        true => { let prod_local_2029 = true; { let prod_local_2030 = prod_local_2029; match prod_local_2030 {
        false => { let prod_local_2032 = rounded; { let prod_local_2033 = convertInt16ToUInt64(prod_local_1991); match prod_local_2033 {
        None => prod_local_2033,
        Some(prod_local_2034) => { let prod_local_2036 = 52; { let prod_local_2037 = (prod_local_2034).checked_shl(prod_local_2036); match prod_local_2037 {
        None => prod_local_2037,
        Some(prod_local_2038) => { let prod_local_2040 = 4503599627370495; { let prod_local_2041 = (prod_local_2032 & prod_local_2040); { let prod_local_2042 = (prod_local_2038 | prod_local_2041); { let prod_local_2043 = (sg | prod_local_2042); { let prod_local_2044 = Some(prod_local_2043); prod_local_2044 } } } } },
    } } },
    } } },
        true => { let prod_local_2046 = 1; { let prod_local_2047 = (rounded).checked_shr(prod_local_2046); match prod_local_2047 {
        None => prod_local_2047,
        Some(prod_local_2048) => { let prod_local_2049 = prod_local_2048; { let prod_local_2050 = convertInt16ToUInt64(prod_local_1991); match prod_local_2050 {
        None => prod_local_2050,
        Some(prod_local_2051) => { let prod_local_2053 = 52; { let prod_local_2054 = (prod_local_2051).checked_shl(prod_local_2053); match prod_local_2054 {
        None => prod_local_2054,
        Some(prod_local_2055) => { let prod_local_2057 = 4503599627370495; { let prod_local_2058 = (prod_local_2049 & prod_local_2057); { let prod_local_2059 = (prod_local_2055 | prod_local_2058); { let prod_local_2060 = (sg | prod_local_2059); { let prod_local_2061 = Some(prod_local_2060); prod_local_2061 } } } } },
    } } },
    } } },
    } } },
    } } },
    },
        true => { let prod_local_2063 = 9218868437227405312; { let prod_local_2064 = (sg | prod_local_2063); { let prod_local_2065 = Some(prod_local_2064); prod_local_2065 } } },
    } } } } },
    } } } },
        true => { let prod_local_2066 = 4503599627370496; { let prod_local_2067 = unsignedLess(rounded, prod_local_2066); match prod_local_2067 {
        false => { let prod_local_2069 = false; { let prod_local_2070 = prod_local_2069; match prod_local_2070 {
        false => { let prod_local_2072 = 1; { let prod_local_2073 = prod_local_2072; { let prod_local_2074 = prod_local_2073; { let prod_local_2075 = prod_local_2074; { let prod_local_2076 = 2046; { let prod_local_2077 = prod_local_2076; { let prod_local_2078 = signedLess(prod_local_2077, prod_local_2075); match prod_local_2078 {
        false => match overflow {
        false => { let prod_local_2080 = false; { let prod_local_2081 = prod_local_2080; match prod_local_2081 {
        false => { let prod_local_2083 = rounded; { let prod_local_2084 = convertInt16ToUInt64(prod_local_2075); match prod_local_2084 {
        None => prod_local_2084,
        Some(prod_local_2085) => { let prod_local_2087 = 52; { let prod_local_2088 = (prod_local_2085).checked_shl(prod_local_2087); match prod_local_2088 {
        None => prod_local_2088,
        Some(prod_local_2089) => { let prod_local_2091 = 4503599627370495; { let prod_local_2092 = (prod_local_2083 & prod_local_2091); { let prod_local_2093 = (prod_local_2089 | prod_local_2092); { let prod_local_2094 = (sg | prod_local_2093); { let prod_local_2095 = Some(prod_local_2094); prod_local_2095 } } } } },
    } } },
    } } },
        true => { let prod_local_2097 = 1; { let prod_local_2098 = (rounded).checked_shr(prod_local_2097); match prod_local_2098 {
        None => prod_local_2098,
        Some(prod_local_2099) => { let prod_local_2100 = prod_local_2099; { let prod_local_2101 = convertInt16ToUInt64(prod_local_2075); match prod_local_2101 {
        None => prod_local_2101,
        Some(prod_local_2102) => { let prod_local_2104 = 52; { let prod_local_2105 = (prod_local_2102).checked_shl(prod_local_2104); match prod_local_2105 {
        None => prod_local_2105,
        Some(prod_local_2106) => { let prod_local_2108 = 4503599627370495; { let prod_local_2109 = (prod_local_2100 & prod_local_2108); { let prod_local_2110 = (prod_local_2106 | prod_local_2109); { let prod_local_2111 = (sg | prod_local_2110); { let prod_local_2112 = Some(prod_local_2111); prod_local_2112 } } } } },
    } } },
    } } },
    } } },
    } } },
        true => { let prod_local_2113 = true; { let prod_local_2114 = prod_local_2113; match prod_local_2114 {
        false => { let prod_local_2116 = rounded; { let prod_local_2117 = convertInt16ToUInt64(prod_local_2075); match prod_local_2117 {
        None => prod_local_2117,
        Some(prod_local_2118) => { let prod_local_2120 = 52; { let prod_local_2121 = (prod_local_2118).checked_shl(prod_local_2120); match prod_local_2121 {
        None => prod_local_2121,
        Some(prod_local_2122) => { let prod_local_2124 = 4503599627370495; { let prod_local_2125 = (prod_local_2116 & prod_local_2124); { let prod_local_2126 = (prod_local_2122 | prod_local_2125); { let prod_local_2127 = (sg | prod_local_2126); { let prod_local_2128 = Some(prod_local_2127); prod_local_2128 } } } } },
    } } },
    } } },
        true => { let prod_local_2130 = 1; { let prod_local_2131 = (rounded).checked_shr(prod_local_2130); match prod_local_2131 {
        None => prod_local_2131,
        Some(prod_local_2132) => { let prod_local_2133 = prod_local_2132; { let prod_local_2134 = convertInt16ToUInt64(prod_local_2075); match prod_local_2134 {
        None => prod_local_2134,
        Some(prod_local_2135) => { let prod_local_2137 = 52; { let prod_local_2138 = (prod_local_2135).checked_shl(prod_local_2137); match prod_local_2138 {
        None => prod_local_2138,
        Some(prod_local_2139) => { let prod_local_2141 = 4503599627370495; { let prod_local_2142 = (prod_local_2133 & prod_local_2141); { let prod_local_2143 = (prod_local_2139 | prod_local_2142); { let prod_local_2144 = (sg | prod_local_2143); { let prod_local_2145 = Some(prod_local_2144); prod_local_2145 } } } } },
    } } },
    } } },
    } } },
    } } },
    },
        true => { let prod_local_2147 = 9218868437227405312; { let prod_local_2148 = (sg | prod_local_2147); { let prod_local_2149 = Some(prod_local_2148); prod_local_2149 } } },
    } } } } } } } },
        true => { let prod_local_2150 = 0; { let prod_local_2151 = prod_local_2150; { let prod_local_2152 = prod_local_2151; { let prod_local_2153 = prod_local_2152; { let prod_local_2154 = 2046; { let prod_local_2155 = prod_local_2154; { let prod_local_2156 = signedLess(prod_local_2155, prod_local_2153); match prod_local_2156 {
        false => match overflow {
        false => { let prod_local_2158 = false; { let prod_local_2159 = prod_local_2158; match prod_local_2159 {
        false => { let prod_local_2161 = rounded; { let prod_local_2162 = convertInt16ToUInt64(prod_local_2153); match prod_local_2162 {
        None => prod_local_2162,
        Some(prod_local_2163) => { let prod_local_2165 = 52; { let prod_local_2166 = (prod_local_2163).checked_shl(prod_local_2165); match prod_local_2166 {
        None => prod_local_2166,
        Some(prod_local_2167) => { let prod_local_2169 = 4503599627370495; { let prod_local_2170 = (prod_local_2161 & prod_local_2169); { let prod_local_2171 = (prod_local_2167 | prod_local_2170); { let prod_local_2172 = (sg | prod_local_2171); { let prod_local_2173 = Some(prod_local_2172); prod_local_2173 } } } } },
    } } },
    } } },
        true => { let prod_local_2175 = 1; { let prod_local_2176 = (rounded).checked_shr(prod_local_2175); match prod_local_2176 {
        None => prod_local_2176,
        Some(prod_local_2177) => { let prod_local_2178 = prod_local_2177; { let prod_local_2179 = convertInt16ToUInt64(prod_local_2153); match prod_local_2179 {
        None => prod_local_2179,
        Some(prod_local_2180) => { let prod_local_2182 = 52; { let prod_local_2183 = (prod_local_2180).checked_shl(prod_local_2182); match prod_local_2183 {
        None => prod_local_2183,
        Some(prod_local_2184) => { let prod_local_2186 = 4503599627370495; { let prod_local_2187 = (prod_local_2178 & prod_local_2186); { let prod_local_2188 = (prod_local_2184 | prod_local_2187); { let prod_local_2189 = (sg | prod_local_2188); { let prod_local_2190 = Some(prod_local_2189); prod_local_2190 } } } } },
    } } },
    } } },
    } } },
    } } },
        true => { let prod_local_2191 = true; { let prod_local_2192 = prod_local_2191; match prod_local_2192 {
        false => { let prod_local_2194 = rounded; { let prod_local_2195 = convertInt16ToUInt64(prod_local_2153); match prod_local_2195 {
        None => prod_local_2195,
        Some(prod_local_2196) => { let prod_local_2198 = 52; { let prod_local_2199 = (prod_local_2196).checked_shl(prod_local_2198); match prod_local_2199 {
        None => prod_local_2199,
        Some(prod_local_2200) => { let prod_local_2202 = 4503599627370495; { let prod_local_2203 = (prod_local_2194 & prod_local_2202); { let prod_local_2204 = (prod_local_2200 | prod_local_2203); { let prod_local_2205 = (sg | prod_local_2204); { let prod_local_2206 = Some(prod_local_2205); prod_local_2206 } } } } },
    } } },
    } } },
        true => { let prod_local_2208 = 1; { let prod_local_2209 = (rounded).checked_shr(prod_local_2208); match prod_local_2209 {
        None => prod_local_2209,
        Some(prod_local_2210) => { let prod_local_2211 = prod_local_2210; { let prod_local_2212 = convertInt16ToUInt64(prod_local_2153); match prod_local_2212 {
        None => prod_local_2212,
        Some(prod_local_2213) => { let prod_local_2215 = 52; { let prod_local_2216 = (prod_local_2213).checked_shl(prod_local_2215); match prod_local_2216 {
        None => prod_local_2216,
        Some(prod_local_2217) => { let prod_local_2219 = 4503599627370495; { let prod_local_2220 = (prod_local_2211 & prod_local_2219); { let prod_local_2221 = (prod_local_2217 | prod_local_2220); { let prod_local_2222 = (sg | prod_local_2221); { let prod_local_2223 = Some(prod_local_2222); prod_local_2223 } } } } },
    } } },
    } } },
    } } },
    } } },
    },
        true => { let prod_local_2225 = 9218868437227405312; { let prod_local_2226 = (sg | prod_local_2225); { let prod_local_2227 = Some(prod_local_2226); prod_local_2227 } } },
    } } } } } } } },
    } } },
        true => { let prod_local_2228 = true; { let prod_local_2229 = prod_local_2228; match prod_local_2229 {
        false => { let prod_local_2231 = 1; { let prod_local_2232 = prod_local_2231; { let prod_local_2233 = prod_local_2232; { let prod_local_2234 = prod_local_2233; { let prod_local_2235 = 2046; { let prod_local_2236 = prod_local_2235; { let prod_local_2237 = signedLess(prod_local_2236, prod_local_2234); match prod_local_2237 {
        false => match overflow {
        false => { let prod_local_2239 = false; { let prod_local_2240 = prod_local_2239; match prod_local_2240 {
        false => { let prod_local_2242 = rounded; { let prod_local_2243 = convertInt16ToUInt64(prod_local_2234); match prod_local_2243 {
        None => prod_local_2243,
        Some(prod_local_2244) => { let prod_local_2246 = 52; { let prod_local_2247 = (prod_local_2244).checked_shl(prod_local_2246); match prod_local_2247 {
        None => prod_local_2247,
        Some(prod_local_2248) => { let prod_local_2250 = 4503599627370495; { let prod_local_2251 = (prod_local_2242 & prod_local_2250); { let prod_local_2252 = (prod_local_2248 | prod_local_2251); { let prod_local_2253 = (sg | prod_local_2252); { let prod_local_2254 = Some(prod_local_2253); prod_local_2254 } } } } },
    } } },
    } } },
        true => { let prod_local_2256 = 1; { let prod_local_2257 = (rounded).checked_shr(prod_local_2256); match prod_local_2257 {
        None => prod_local_2257,
        Some(prod_local_2258) => { let prod_local_2259 = prod_local_2258; { let prod_local_2260 = convertInt16ToUInt64(prod_local_2234); match prod_local_2260 {
        None => prod_local_2260,
        Some(prod_local_2261) => { let prod_local_2263 = 52; { let prod_local_2264 = (prod_local_2261).checked_shl(prod_local_2263); match prod_local_2264 {
        None => prod_local_2264,
        Some(prod_local_2265) => { let prod_local_2267 = 4503599627370495; { let prod_local_2268 = (prod_local_2259 & prod_local_2267); { let prod_local_2269 = (prod_local_2265 | prod_local_2268); { let prod_local_2270 = (sg | prod_local_2269); { let prod_local_2271 = Some(prod_local_2270); prod_local_2271 } } } } },
    } } },
    } } },
    } } },
    } } },
        true => { let prod_local_2272 = true; { let prod_local_2273 = prod_local_2272; match prod_local_2273 {
        false => { let prod_local_2275 = rounded; { let prod_local_2276 = convertInt16ToUInt64(prod_local_2234); match prod_local_2276 {
        None => prod_local_2276,
        Some(prod_local_2277) => { let prod_local_2279 = 52; { let prod_local_2280 = (prod_local_2277).checked_shl(prod_local_2279); match prod_local_2280 {
        None => prod_local_2280,
        Some(prod_local_2281) => { let prod_local_2283 = 4503599627370495; { let prod_local_2284 = (prod_local_2275 & prod_local_2283); { let prod_local_2285 = (prod_local_2281 | prod_local_2284); { let prod_local_2286 = (sg | prod_local_2285); { let prod_local_2287 = Some(prod_local_2286); prod_local_2287 } } } } },
    } } },
    } } },
        true => { let prod_local_2289 = 1; { let prod_local_2290 = (rounded).checked_shr(prod_local_2289); match prod_local_2290 {
        None => prod_local_2290,
        Some(prod_local_2291) => { let prod_local_2292 = prod_local_2291; { let prod_local_2293 = convertInt16ToUInt64(prod_local_2234); match prod_local_2293 {
        None => prod_local_2293,
        Some(prod_local_2294) => { let prod_local_2296 = 52; { let prod_local_2297 = (prod_local_2294).checked_shl(prod_local_2296); match prod_local_2297 {
        None => prod_local_2297,
        Some(prod_local_2298) => { let prod_local_2300 = 4503599627370495; { let prod_local_2301 = (prod_local_2292 & prod_local_2300); { let prod_local_2302 = (prod_local_2298 | prod_local_2301); { let prod_local_2303 = (sg | prod_local_2302); { let prod_local_2304 = Some(prod_local_2303); prod_local_2304 } } } } },
    } } },
    } } },
    } } },
    } } },
    },
        true => { let prod_local_2306 = 9218868437227405312; { let prod_local_2307 = (sg | prod_local_2306); { let prod_local_2308 = Some(prod_local_2307); prod_local_2308 } } },
    } } } } } } } },
        true => { let prod_local_2309 = 0; { let prod_local_2310 = prod_local_2309; { let prod_local_2311 = prod_local_2310; { let prod_local_2312 = prod_local_2311; { let prod_local_2313 = 2046; { let prod_local_2314 = prod_local_2313; { let prod_local_2315 = signedLess(prod_local_2314, prod_local_2312); match prod_local_2315 {
        false => match overflow {
        false => { let prod_local_2317 = false; { let prod_local_2318 = prod_local_2317; match prod_local_2318 {
        false => { let prod_local_2320 = rounded; { let prod_local_2321 = convertInt16ToUInt64(prod_local_2312); match prod_local_2321 {
        None => prod_local_2321,
        Some(prod_local_2322) => { let prod_local_2324 = 52; { let prod_local_2325 = (prod_local_2322).checked_shl(prod_local_2324); match prod_local_2325 {
        None => prod_local_2325,
        Some(prod_local_2326) => { let prod_local_2328 = 4503599627370495; { let prod_local_2329 = (prod_local_2320 & prod_local_2328); { let prod_local_2330 = (prod_local_2326 | prod_local_2329); { let prod_local_2331 = (sg | prod_local_2330); { let prod_local_2332 = Some(prod_local_2331); prod_local_2332 } } } } },
    } } },
    } } },
        true => { let prod_local_2334 = 1; { let prod_local_2335 = (rounded).checked_shr(prod_local_2334); match prod_local_2335 {
        None => prod_local_2335,
        Some(prod_local_2336) => { let prod_local_2337 = prod_local_2336; { let prod_local_2338 = convertInt16ToUInt64(prod_local_2312); match prod_local_2338 {
        None => prod_local_2338,
        Some(prod_local_2339) => { let prod_local_2341 = 52; { let prod_local_2342 = (prod_local_2339).checked_shl(prod_local_2341); match prod_local_2342 {
        None => prod_local_2342,
        Some(prod_local_2343) => { let prod_local_2345 = 4503599627370495; { let prod_local_2346 = (prod_local_2337 & prod_local_2345); { let prod_local_2347 = (prod_local_2343 | prod_local_2346); { let prod_local_2348 = (sg | prod_local_2347); { let prod_local_2349 = Some(prod_local_2348); prod_local_2349 } } } } },
    } } },
    } } },
    } } },
    } } },
        true => { let prod_local_2350 = true; { let prod_local_2351 = prod_local_2350; match prod_local_2351 {
        false => { let prod_local_2353 = rounded; { let prod_local_2354 = convertInt16ToUInt64(prod_local_2312); match prod_local_2354 {
        None => prod_local_2354,
        Some(prod_local_2355) => { let prod_local_2357 = 52; { let prod_local_2358 = (prod_local_2355).checked_shl(prod_local_2357); match prod_local_2358 {
        None => prod_local_2358,
        Some(prod_local_2359) => { let prod_local_2361 = 4503599627370495; { let prod_local_2362 = (prod_local_2353 & prod_local_2361); { let prod_local_2363 = (prod_local_2359 | prod_local_2362); { let prod_local_2364 = (sg | prod_local_2363); { let prod_local_2365 = Some(prod_local_2364); prod_local_2365 } } } } },
    } } },
    } } },
        true => { let prod_local_2367 = 1; { let prod_local_2368 = (rounded).checked_shr(prod_local_2367); match prod_local_2368 {
        None => prod_local_2368,
        Some(prod_local_2369) => { let prod_local_2370 = prod_local_2369; { let prod_local_2371 = convertInt16ToUInt64(prod_local_2312); match prod_local_2371 {
        None => prod_local_2371,
        Some(prod_local_2372) => { let prod_local_2374 = 52; { let prod_local_2375 = (prod_local_2372).checked_shl(prod_local_2374); match prod_local_2375 {
        None => prod_local_2375,
        Some(prod_local_2376) => { let prod_local_2378 = 4503599627370495; { let prod_local_2379 = (prod_local_2370 & prod_local_2378); { let prod_local_2380 = (prod_local_2376 | prod_local_2379); { let prod_local_2381 = (sg | prod_local_2380); { let prod_local_2382 = Some(prod_local_2381); prod_local_2382 } } } } },
    } } },
    } } },
    } } },
    } } },
    },
        true => { let prod_local_2384 = 9218868437227405312; { let prod_local_2385 = (sg | prod_local_2384); { let prod_local_2386 = Some(prod_local_2385); prod_local_2386 } } },
    } } } } } } } },
    } } },
    } } },
    } } },
    } } } } } },
        true => { let prod_local_2387 = 1; { let prod_local_2388 = prod_local_2387; { let prod_local_2389 = int16Add(exponent, prod_local_2388); match prod_local_2389 {
        None => None,
        Some(prod_local_2391) => { let prod_local_2392 = prod_local_2391; { let prod_local_2393 = 1022; { let prod_local_2394 = prod_local_2393; { let prod_local_2395 = -(prod_local_2394); { let prod_local_2396 = signedLess(prod_local_2392, prod_local_2395); match prod_local_2396 {
        false => { let prod_local_2398 = false; { let prod_local_2399 = prod_local_2398; match prod_local_2399 {
        false => { let prod_local_2401 = 1023; { let prod_local_2402 = prod_local_2401; { let prod_local_2403 = int16Add(prod_local_2392, prod_local_2402); match prod_local_2403 {
        None => None,
        Some(prod_local_2405) => { let prod_local_2406 = prod_local_2405; { let prod_local_2407 = 2046; { let prod_local_2408 = prod_local_2407; { let prod_local_2409 = signedLess(prod_local_2408, prod_local_2406); match prod_local_2409 {
        false => match overflow {
        false => { let prod_local_2411 = false; { let prod_local_2412 = prod_local_2411; match prod_local_2412 {
        false => { let prod_local_2414 = rounded; { let prod_local_2415 = convertInt16ToUInt64(prod_local_2406); match prod_local_2415 {
        None => prod_local_2415,
        Some(prod_local_2416) => { let prod_local_2418 = 52; { let prod_local_2419 = (prod_local_2416).checked_shl(prod_local_2418); match prod_local_2419 {
        None => prod_local_2419,
        Some(prod_local_2420) => { let prod_local_2422 = 4503599627370495; { let prod_local_2423 = (prod_local_2414 & prod_local_2422); { let prod_local_2424 = (prod_local_2420 | prod_local_2423); { let prod_local_2425 = (sg | prod_local_2424); { let prod_local_2426 = Some(prod_local_2425); prod_local_2426 } } } } },
    } } },
    } } },
        true => { let prod_local_2428 = 1; { let prod_local_2429 = (rounded).checked_shr(prod_local_2428); match prod_local_2429 {
        None => prod_local_2429,
        Some(prod_local_2430) => { let prod_local_2431 = prod_local_2430; { let prod_local_2432 = convertInt16ToUInt64(prod_local_2406); match prod_local_2432 {
        None => prod_local_2432,
        Some(prod_local_2433) => { let prod_local_2435 = 52; { let prod_local_2436 = (prod_local_2433).checked_shl(prod_local_2435); match prod_local_2436 {
        None => prod_local_2436,
        Some(prod_local_2437) => { let prod_local_2439 = 4503599627370495; { let prod_local_2440 = (prod_local_2431 & prod_local_2439); { let prod_local_2441 = (prod_local_2437 | prod_local_2440); { let prod_local_2442 = (sg | prod_local_2441); { let prod_local_2443 = Some(prod_local_2442); prod_local_2443 } } } } },
    } } },
    } } },
    } } },
    } } },
        true => { let prod_local_2444 = true; { let prod_local_2445 = prod_local_2444; match prod_local_2445 {
        false => { let prod_local_2447 = rounded; { let prod_local_2448 = convertInt16ToUInt64(prod_local_2406); match prod_local_2448 {
        None => prod_local_2448,
        Some(prod_local_2449) => { let prod_local_2451 = 52; { let prod_local_2452 = (prod_local_2449).checked_shl(prod_local_2451); match prod_local_2452 {
        None => prod_local_2452,
        Some(prod_local_2453) => { let prod_local_2455 = 4503599627370495; { let prod_local_2456 = (prod_local_2447 & prod_local_2455); { let prod_local_2457 = (prod_local_2453 | prod_local_2456); { let prod_local_2458 = (sg | prod_local_2457); { let prod_local_2459 = Some(prod_local_2458); prod_local_2459 } } } } },
    } } },
    } } },
        true => { let prod_local_2461 = 1; { let prod_local_2462 = (rounded).checked_shr(prod_local_2461); match prod_local_2462 {
        None => prod_local_2462,
        Some(prod_local_2463) => { let prod_local_2464 = prod_local_2463; { let prod_local_2465 = convertInt16ToUInt64(prod_local_2406); match prod_local_2465 {
        None => prod_local_2465,
        Some(prod_local_2466) => { let prod_local_2468 = 52; { let prod_local_2469 = (prod_local_2466).checked_shl(prod_local_2468); match prod_local_2469 {
        None => prod_local_2469,
        Some(prod_local_2470) => { let prod_local_2472 = 4503599627370495; { let prod_local_2473 = (prod_local_2464 & prod_local_2472); { let prod_local_2474 = (prod_local_2470 | prod_local_2473); { let prod_local_2475 = (sg | prod_local_2474); { let prod_local_2476 = Some(prod_local_2475); prod_local_2476 } } } } },
    } } },
    } } },
    } } },
    } } },
    },
        true => { let prod_local_2478 = 9218868437227405312; { let prod_local_2479 = (sg | prod_local_2478); { let prod_local_2480 = Some(prod_local_2479); prod_local_2480 } } },
    } } } } },
    } } } },
        true => { let prod_local_2481 = 4503599627370496; { let prod_local_2482 = unsignedLess(rounded, prod_local_2481); match prod_local_2482 {
        false => { let prod_local_2484 = false; { let prod_local_2485 = prod_local_2484; match prod_local_2485 {
        false => { let prod_local_2487 = 1; { let prod_local_2488 = prod_local_2487; { let prod_local_2489 = prod_local_2488; { let prod_local_2490 = prod_local_2489; { let prod_local_2491 = 2046; { let prod_local_2492 = prod_local_2491; { let prod_local_2493 = signedLess(prod_local_2492, prod_local_2490); match prod_local_2493 {
        false => match overflow {
        false => { let prod_local_2495 = false; { let prod_local_2496 = prod_local_2495; match prod_local_2496 {
        false => { let prod_local_2498 = rounded; { let prod_local_2499 = convertInt16ToUInt64(prod_local_2490); match prod_local_2499 {
        None => prod_local_2499,
        Some(prod_local_2500) => { let prod_local_2502 = 52; { let prod_local_2503 = (prod_local_2500).checked_shl(prod_local_2502); match prod_local_2503 {
        None => prod_local_2503,
        Some(prod_local_2504) => { let prod_local_2506 = 4503599627370495; { let prod_local_2507 = (prod_local_2498 & prod_local_2506); { let prod_local_2508 = (prod_local_2504 | prod_local_2507); { let prod_local_2509 = (sg | prod_local_2508); { let prod_local_2510 = Some(prod_local_2509); prod_local_2510 } } } } },
    } } },
    } } },
        true => { let prod_local_2512 = 1; { let prod_local_2513 = (rounded).checked_shr(prod_local_2512); match prod_local_2513 {
        None => prod_local_2513,
        Some(prod_local_2514) => { let prod_local_2515 = prod_local_2514; { let prod_local_2516 = convertInt16ToUInt64(prod_local_2490); match prod_local_2516 {
        None => prod_local_2516,
        Some(prod_local_2517) => { let prod_local_2519 = 52; { let prod_local_2520 = (prod_local_2517).checked_shl(prod_local_2519); match prod_local_2520 {
        None => prod_local_2520,
        Some(prod_local_2521) => { let prod_local_2523 = 4503599627370495; { let prod_local_2524 = (prod_local_2515 & prod_local_2523); { let prod_local_2525 = (prod_local_2521 | prod_local_2524); { let prod_local_2526 = (sg | prod_local_2525); { let prod_local_2527 = Some(prod_local_2526); prod_local_2527 } } } } },
    } } },
    } } },
    } } },
    } } },
        true => { let prod_local_2528 = true; { let prod_local_2529 = prod_local_2528; match prod_local_2529 {
        false => { let prod_local_2531 = rounded; { let prod_local_2532 = convertInt16ToUInt64(prod_local_2490); match prod_local_2532 {
        None => prod_local_2532,
        Some(prod_local_2533) => { let prod_local_2535 = 52; { let prod_local_2536 = (prod_local_2533).checked_shl(prod_local_2535); match prod_local_2536 {
        None => prod_local_2536,
        Some(prod_local_2537) => { let prod_local_2539 = 4503599627370495; { let prod_local_2540 = (prod_local_2531 & prod_local_2539); { let prod_local_2541 = (prod_local_2537 | prod_local_2540); { let prod_local_2542 = (sg | prod_local_2541); { let prod_local_2543 = Some(prod_local_2542); prod_local_2543 } } } } },
    } } },
    } } },
        true => { let prod_local_2545 = 1; { let prod_local_2546 = (rounded).checked_shr(prod_local_2545); match prod_local_2546 {
        None => prod_local_2546,
        Some(prod_local_2547) => { let prod_local_2548 = prod_local_2547; { let prod_local_2549 = convertInt16ToUInt64(prod_local_2490); match prod_local_2549 {
        None => prod_local_2549,
        Some(prod_local_2550) => { let prod_local_2552 = 52; { let prod_local_2553 = (prod_local_2550).checked_shl(prod_local_2552); match prod_local_2553 {
        None => prod_local_2553,
        Some(prod_local_2554) => { let prod_local_2556 = 4503599627370495; { let prod_local_2557 = (prod_local_2548 & prod_local_2556); { let prod_local_2558 = (prod_local_2554 | prod_local_2557); { let prod_local_2559 = (sg | prod_local_2558); { let prod_local_2560 = Some(prod_local_2559); prod_local_2560 } } } } },
    } } },
    } } },
    } } },
    } } },
    },
        true => { let prod_local_2562 = 9218868437227405312; { let prod_local_2563 = (sg | prod_local_2562); { let prod_local_2564 = Some(prod_local_2563); prod_local_2564 } } },
    } } } } } } } },
        true => { let prod_local_2565 = 0; { let prod_local_2566 = prod_local_2565; { let prod_local_2567 = prod_local_2566; { let prod_local_2568 = prod_local_2567; { let prod_local_2569 = 2046; { let prod_local_2570 = prod_local_2569; { let prod_local_2571 = signedLess(prod_local_2570, prod_local_2568); match prod_local_2571 {
        false => match overflow {
        false => { let prod_local_2573 = false; { let prod_local_2574 = prod_local_2573; match prod_local_2574 {
        false => { let prod_local_2576 = rounded; { let prod_local_2577 = convertInt16ToUInt64(prod_local_2568); match prod_local_2577 {
        None => prod_local_2577,
        Some(prod_local_2578) => { let prod_local_2580 = 52; { let prod_local_2581 = (prod_local_2578).checked_shl(prod_local_2580); match prod_local_2581 {
        None => prod_local_2581,
        Some(prod_local_2582) => { let prod_local_2584 = 4503599627370495; { let prod_local_2585 = (prod_local_2576 & prod_local_2584); { let prod_local_2586 = (prod_local_2582 | prod_local_2585); { let prod_local_2587 = (sg | prod_local_2586); { let prod_local_2588 = Some(prod_local_2587); prod_local_2588 } } } } },
    } } },
    } } },
        true => { let prod_local_2590 = 1; { let prod_local_2591 = (rounded).checked_shr(prod_local_2590); match prod_local_2591 {
        None => prod_local_2591,
        Some(prod_local_2592) => { let prod_local_2593 = prod_local_2592; { let prod_local_2594 = convertInt16ToUInt64(prod_local_2568); match prod_local_2594 {
        None => prod_local_2594,
        Some(prod_local_2595) => { let prod_local_2597 = 52; { let prod_local_2598 = (prod_local_2595).checked_shl(prod_local_2597); match prod_local_2598 {
        None => prod_local_2598,
        Some(prod_local_2599) => { let prod_local_2601 = 4503599627370495; { let prod_local_2602 = (prod_local_2593 & prod_local_2601); { let prod_local_2603 = (prod_local_2599 | prod_local_2602); { let prod_local_2604 = (sg | prod_local_2603); { let prod_local_2605 = Some(prod_local_2604); prod_local_2605 } } } } },
    } } },
    } } },
    } } },
    } } },
        true => { let prod_local_2606 = true; { let prod_local_2607 = prod_local_2606; match prod_local_2607 {
        false => { let prod_local_2609 = rounded; { let prod_local_2610 = convertInt16ToUInt64(prod_local_2568); match prod_local_2610 {
        None => prod_local_2610,
        Some(prod_local_2611) => { let prod_local_2613 = 52; { let prod_local_2614 = (prod_local_2611).checked_shl(prod_local_2613); match prod_local_2614 {
        None => prod_local_2614,
        Some(prod_local_2615) => { let prod_local_2617 = 4503599627370495; { let prod_local_2618 = (prod_local_2609 & prod_local_2617); { let prod_local_2619 = (prod_local_2615 | prod_local_2618); { let prod_local_2620 = (sg | prod_local_2619); { let prod_local_2621 = Some(prod_local_2620); prod_local_2621 } } } } },
    } } },
    } } },
        true => { let prod_local_2623 = 1; { let prod_local_2624 = (rounded).checked_shr(prod_local_2623); match prod_local_2624 {
        None => prod_local_2624,
        Some(prod_local_2625) => { let prod_local_2626 = prod_local_2625; { let prod_local_2627 = convertInt16ToUInt64(prod_local_2568); match prod_local_2627 {
        None => prod_local_2627,
        Some(prod_local_2628) => { let prod_local_2630 = 52; { let prod_local_2631 = (prod_local_2628).checked_shl(prod_local_2630); match prod_local_2631 {
        None => prod_local_2631,
        Some(prod_local_2632) => { let prod_local_2634 = 4503599627370495; { let prod_local_2635 = (prod_local_2626 & prod_local_2634); { let prod_local_2636 = (prod_local_2632 | prod_local_2635); { let prod_local_2637 = (sg | prod_local_2636); { let prod_local_2638 = Some(prod_local_2637); prod_local_2638 } } } } },
    } } },
    } } },
    } } },
    } } },
    },
        true => { let prod_local_2640 = 9218868437227405312; { let prod_local_2641 = (sg | prod_local_2640); { let prod_local_2642 = Some(prod_local_2641); prod_local_2642 } } },
    } } } } } } } },
    } } },
        true => { let prod_local_2643 = true; { let prod_local_2644 = prod_local_2643; match prod_local_2644 {
        false => { let prod_local_2646 = 1; { let prod_local_2647 = prod_local_2646; { let prod_local_2648 = prod_local_2647; { let prod_local_2649 = prod_local_2648; { let prod_local_2650 = 2046; { let prod_local_2651 = prod_local_2650; { let prod_local_2652 = signedLess(prod_local_2651, prod_local_2649); match prod_local_2652 {
        false => match overflow {
        false => { let prod_local_2654 = false; { let prod_local_2655 = prod_local_2654; match prod_local_2655 {
        false => { let prod_local_2657 = rounded; { let prod_local_2658 = convertInt16ToUInt64(prod_local_2649); match prod_local_2658 {
        None => prod_local_2658,
        Some(prod_local_2659) => { let prod_local_2661 = 52; { let prod_local_2662 = (prod_local_2659).checked_shl(prod_local_2661); match prod_local_2662 {
        None => prod_local_2662,
        Some(prod_local_2663) => { let prod_local_2665 = 4503599627370495; { let prod_local_2666 = (prod_local_2657 & prod_local_2665); { let prod_local_2667 = (prod_local_2663 | prod_local_2666); { let prod_local_2668 = (sg | prod_local_2667); { let prod_local_2669 = Some(prod_local_2668); prod_local_2669 } } } } },
    } } },
    } } },
        true => { let prod_local_2671 = 1; { let prod_local_2672 = (rounded).checked_shr(prod_local_2671); match prod_local_2672 {
        None => prod_local_2672,
        Some(prod_local_2673) => { let prod_local_2674 = prod_local_2673; { let prod_local_2675 = convertInt16ToUInt64(prod_local_2649); match prod_local_2675 {
        None => prod_local_2675,
        Some(prod_local_2676) => { let prod_local_2678 = 52; { let prod_local_2679 = (prod_local_2676).checked_shl(prod_local_2678); match prod_local_2679 {
        None => prod_local_2679,
        Some(prod_local_2680) => { let prod_local_2682 = 4503599627370495; { let prod_local_2683 = (prod_local_2674 & prod_local_2682); { let prod_local_2684 = (prod_local_2680 | prod_local_2683); { let prod_local_2685 = (sg | prod_local_2684); { let prod_local_2686 = Some(prod_local_2685); prod_local_2686 } } } } },
    } } },
    } } },
    } } },
    } } },
        true => { let prod_local_2687 = true; { let prod_local_2688 = prod_local_2687; match prod_local_2688 {
        false => { let prod_local_2690 = rounded; { let prod_local_2691 = convertInt16ToUInt64(prod_local_2649); match prod_local_2691 {
        None => prod_local_2691,
        Some(prod_local_2692) => { let prod_local_2694 = 52; { let prod_local_2695 = (prod_local_2692).checked_shl(prod_local_2694); match prod_local_2695 {
        None => prod_local_2695,
        Some(prod_local_2696) => { let prod_local_2698 = 4503599627370495; { let prod_local_2699 = (prod_local_2690 & prod_local_2698); { let prod_local_2700 = (prod_local_2696 | prod_local_2699); { let prod_local_2701 = (sg | prod_local_2700); { let prod_local_2702 = Some(prod_local_2701); prod_local_2702 } } } } },
    } } },
    } } },
        true => { let prod_local_2704 = 1; { let prod_local_2705 = (rounded).checked_shr(prod_local_2704); match prod_local_2705 {
        None => prod_local_2705,
        Some(prod_local_2706) => { let prod_local_2707 = prod_local_2706; { let prod_local_2708 = convertInt16ToUInt64(prod_local_2649); match prod_local_2708 {
        None => prod_local_2708,
        Some(prod_local_2709) => { let prod_local_2711 = 52; { let prod_local_2712 = (prod_local_2709).checked_shl(prod_local_2711); match prod_local_2712 {
        None => prod_local_2712,
        Some(prod_local_2713) => { let prod_local_2715 = 4503599627370495; { let prod_local_2716 = (prod_local_2707 & prod_local_2715); { let prod_local_2717 = (prod_local_2713 | prod_local_2716); { let prod_local_2718 = (sg | prod_local_2717); { let prod_local_2719 = Some(prod_local_2718); prod_local_2719 } } } } },
    } } },
    } } },
    } } },
    } } },
    },
        true => { let prod_local_2721 = 9218868437227405312; { let prod_local_2722 = (sg | prod_local_2721); { let prod_local_2723 = Some(prod_local_2722); prod_local_2723 } } },
    } } } } } } } },
        true => { let prod_local_2724 = 0; { let prod_local_2725 = prod_local_2724; { let prod_local_2726 = prod_local_2725; { let prod_local_2727 = prod_local_2726; { let prod_local_2728 = 2046; { let prod_local_2729 = prod_local_2728; { let prod_local_2730 = signedLess(prod_local_2729, prod_local_2727); match prod_local_2730 {
        false => match overflow {
        false => { let prod_local_2732 = false; { let prod_local_2733 = prod_local_2732; match prod_local_2733 {
        false => { let prod_local_2735 = rounded; { let prod_local_2736 = convertInt16ToUInt64(prod_local_2727); match prod_local_2736 {
        None => prod_local_2736,
        Some(prod_local_2737) => { let prod_local_2739 = 52; { let prod_local_2740 = (prod_local_2737).checked_shl(prod_local_2739); match prod_local_2740 {
        None => prod_local_2740,
        Some(prod_local_2741) => { let prod_local_2743 = 4503599627370495; { let prod_local_2744 = (prod_local_2735 & prod_local_2743); { let prod_local_2745 = (prod_local_2741 | prod_local_2744); { let prod_local_2746 = (sg | prod_local_2745); { let prod_local_2747 = Some(prod_local_2746); prod_local_2747 } } } } },
    } } },
    } } },
        true => { let prod_local_2749 = 1; { let prod_local_2750 = (rounded).checked_shr(prod_local_2749); match prod_local_2750 {
        None => prod_local_2750,
        Some(prod_local_2751) => { let prod_local_2752 = prod_local_2751; { let prod_local_2753 = convertInt16ToUInt64(prod_local_2727); match prod_local_2753 {
        None => prod_local_2753,
        Some(prod_local_2754) => { let prod_local_2756 = 52; { let prod_local_2757 = (prod_local_2754).checked_shl(prod_local_2756); match prod_local_2757 {
        None => prod_local_2757,
        Some(prod_local_2758) => { let prod_local_2760 = 4503599627370495; { let prod_local_2761 = (prod_local_2752 & prod_local_2760); { let prod_local_2762 = (prod_local_2758 | prod_local_2761); { let prod_local_2763 = (sg | prod_local_2762); { let prod_local_2764 = Some(prod_local_2763); prod_local_2764 } } } } },
    } } },
    } } },
    } } },
    } } },
        true => { let prod_local_2765 = true; { let prod_local_2766 = prod_local_2765; match prod_local_2766 {
        false => { let prod_local_2768 = rounded; { let prod_local_2769 = convertInt16ToUInt64(prod_local_2727); match prod_local_2769 {
        None => prod_local_2769,
        Some(prod_local_2770) => { let prod_local_2772 = 52; { let prod_local_2773 = (prod_local_2770).checked_shl(prod_local_2772); match prod_local_2773 {
        None => prod_local_2773,
        Some(prod_local_2774) => { let prod_local_2776 = 4503599627370495; { let prod_local_2777 = (prod_local_2768 & prod_local_2776); { let prod_local_2778 = (prod_local_2774 | prod_local_2777); { let prod_local_2779 = (sg | prod_local_2778); { let prod_local_2780 = Some(prod_local_2779); prod_local_2780 } } } } },
    } } },
    } } },
        true => { let prod_local_2782 = 1; { let prod_local_2783 = (rounded).checked_shr(prod_local_2782); match prod_local_2783 {
        None => prod_local_2783,
        Some(prod_local_2784) => { let prod_local_2785 = prod_local_2784; { let prod_local_2786 = convertInt16ToUInt64(prod_local_2727); match prod_local_2786 {
        None => prod_local_2786,
        Some(prod_local_2787) => { let prod_local_2789 = 52; { let prod_local_2790 = (prod_local_2787).checked_shl(prod_local_2789); match prod_local_2790 {
        None => prod_local_2790,
        Some(prod_local_2791) => { let prod_local_2793 = 4503599627370495; { let prod_local_2794 = (prod_local_2785 & prod_local_2793); { let prod_local_2795 = (prod_local_2791 | prod_local_2794); { let prod_local_2796 = (sg | prod_local_2795); { let prod_local_2797 = Some(prod_local_2796); prod_local_2797 } } } } },
    } } },
    } } },
    } } },
    } } },
    },
        true => { let prod_local_2799 = 9218868437227405312; { let prod_local_2800 = (sg | prod_local_2799); { let prod_local_2801 = Some(prod_local_2800); prod_local_2801 } } },
    } } } } } } } },
    } } },
    } } },
    } } },
        true => { let prod_local_2802 = true; { let prod_local_2803 = prod_local_2802; match prod_local_2803 {
        false => { let prod_local_2805 = 1023; { let prod_local_2806 = prod_local_2805; { let prod_local_2807 = int16Add(prod_local_2392, prod_local_2806); match prod_local_2807 {
        None => None,
        Some(prod_local_2809) => { let prod_local_2810 = prod_local_2809; { let prod_local_2811 = 2046; { let prod_local_2812 = prod_local_2811; { let prod_local_2813 = signedLess(prod_local_2812, prod_local_2810); match prod_local_2813 {
        false => match overflow {
        false => { let prod_local_2815 = false; { let prod_local_2816 = prod_local_2815; match prod_local_2816 {
        false => { let prod_local_2818 = rounded; { let prod_local_2819 = convertInt16ToUInt64(prod_local_2810); match prod_local_2819 {
        None => prod_local_2819,
        Some(prod_local_2820) => { let prod_local_2822 = 52; { let prod_local_2823 = (prod_local_2820).checked_shl(prod_local_2822); match prod_local_2823 {
        None => prod_local_2823,
        Some(prod_local_2824) => { let prod_local_2826 = 4503599627370495; { let prod_local_2827 = (prod_local_2818 & prod_local_2826); { let prod_local_2828 = (prod_local_2824 | prod_local_2827); { let prod_local_2829 = (sg | prod_local_2828); { let prod_local_2830 = Some(prod_local_2829); prod_local_2830 } } } } },
    } } },
    } } },
        true => { let prod_local_2832 = 1; { let prod_local_2833 = (rounded).checked_shr(prod_local_2832); match prod_local_2833 {
        None => prod_local_2833,
        Some(prod_local_2834) => { let prod_local_2835 = prod_local_2834; { let prod_local_2836 = convertInt16ToUInt64(prod_local_2810); match prod_local_2836 {
        None => prod_local_2836,
        Some(prod_local_2837) => { let prod_local_2839 = 52; { let prod_local_2840 = (prod_local_2837).checked_shl(prod_local_2839); match prod_local_2840 {
        None => prod_local_2840,
        Some(prod_local_2841) => { let prod_local_2843 = 4503599627370495; { let prod_local_2844 = (prod_local_2835 & prod_local_2843); { let prod_local_2845 = (prod_local_2841 | prod_local_2844); { let prod_local_2846 = (sg | prod_local_2845); { let prod_local_2847 = Some(prod_local_2846); prod_local_2847 } } } } },
    } } },
    } } },
    } } },
    } } },
        true => { let prod_local_2848 = true; { let prod_local_2849 = prod_local_2848; match prod_local_2849 {
        false => { let prod_local_2851 = rounded; { let prod_local_2852 = convertInt16ToUInt64(prod_local_2810); match prod_local_2852 {
        None => prod_local_2852,
        Some(prod_local_2853) => { let prod_local_2855 = 52; { let prod_local_2856 = (prod_local_2853).checked_shl(prod_local_2855); match prod_local_2856 {
        None => prod_local_2856,
        Some(prod_local_2857) => { let prod_local_2859 = 4503599627370495; { let prod_local_2860 = (prod_local_2851 & prod_local_2859); { let prod_local_2861 = (prod_local_2857 | prod_local_2860); { let prod_local_2862 = (sg | prod_local_2861); { let prod_local_2863 = Some(prod_local_2862); prod_local_2863 } } } } },
    } } },
    } } },
        true => { let prod_local_2865 = 1; { let prod_local_2866 = (rounded).checked_shr(prod_local_2865); match prod_local_2866 {
        None => prod_local_2866,
        Some(prod_local_2867) => { let prod_local_2868 = prod_local_2867; { let prod_local_2869 = convertInt16ToUInt64(prod_local_2810); match prod_local_2869 {
        None => prod_local_2869,
        Some(prod_local_2870) => { let prod_local_2872 = 52; { let prod_local_2873 = (prod_local_2870).checked_shl(prod_local_2872); match prod_local_2873 {
        None => prod_local_2873,
        Some(prod_local_2874) => { let prod_local_2876 = 4503599627370495; { let prod_local_2877 = (prod_local_2868 & prod_local_2876); { let prod_local_2878 = (prod_local_2874 | prod_local_2877); { let prod_local_2879 = (sg | prod_local_2878); { let prod_local_2880 = Some(prod_local_2879); prod_local_2880 } } } } },
    } } },
    } } },
    } } },
    } } },
    },
        true => { let prod_local_2882 = 9218868437227405312; { let prod_local_2883 = (sg | prod_local_2882); { let prod_local_2884 = Some(prod_local_2883); prod_local_2884 } } },
    } } } } },
    } } } },
        true => { let prod_local_2885 = 4503599627370496; { let prod_local_2886 = unsignedLess(rounded, prod_local_2885); match prod_local_2886 {
        false => { let prod_local_2888 = false; { let prod_local_2889 = prod_local_2888; match prod_local_2889 {
        false => { let prod_local_2891 = 1; { let prod_local_2892 = prod_local_2891; { let prod_local_2893 = prod_local_2892; { let prod_local_2894 = prod_local_2893; { let prod_local_2895 = 2046; { let prod_local_2896 = prod_local_2895; { let prod_local_2897 = signedLess(prod_local_2896, prod_local_2894); match prod_local_2897 {
        false => match overflow {
        false => { let prod_local_2899 = false; { let prod_local_2900 = prod_local_2899; match prod_local_2900 {
        false => { let prod_local_2902 = rounded; { let prod_local_2903 = convertInt16ToUInt64(prod_local_2894); match prod_local_2903 {
        None => prod_local_2903,
        Some(prod_local_2904) => { let prod_local_2906 = 52; { let prod_local_2907 = (prod_local_2904).checked_shl(prod_local_2906); match prod_local_2907 {
        None => prod_local_2907,
        Some(prod_local_2908) => { let prod_local_2910 = 4503599627370495; { let prod_local_2911 = (prod_local_2902 & prod_local_2910); { let prod_local_2912 = (prod_local_2908 | prod_local_2911); { let prod_local_2913 = (sg | prod_local_2912); { let prod_local_2914 = Some(prod_local_2913); prod_local_2914 } } } } },
    } } },
    } } },
        true => { let prod_local_2916 = 1; { let prod_local_2917 = (rounded).checked_shr(prod_local_2916); match prod_local_2917 {
        None => prod_local_2917,
        Some(prod_local_2918) => { let prod_local_2919 = prod_local_2918; { let prod_local_2920 = convertInt16ToUInt64(prod_local_2894); match prod_local_2920 {
        None => prod_local_2920,
        Some(prod_local_2921) => { let prod_local_2923 = 52; { let prod_local_2924 = (prod_local_2921).checked_shl(prod_local_2923); match prod_local_2924 {
        None => prod_local_2924,
        Some(prod_local_2925) => { let prod_local_2927 = 4503599627370495; { let prod_local_2928 = (prod_local_2919 & prod_local_2927); { let prod_local_2929 = (prod_local_2925 | prod_local_2928); { let prod_local_2930 = (sg | prod_local_2929); { let prod_local_2931 = Some(prod_local_2930); prod_local_2931 } } } } },
    } } },
    } } },
    } } },
    } } },
        true => { let prod_local_2932 = true; { let prod_local_2933 = prod_local_2932; match prod_local_2933 {
        false => { let prod_local_2935 = rounded; { let prod_local_2936 = convertInt16ToUInt64(prod_local_2894); match prod_local_2936 {
        None => prod_local_2936,
        Some(prod_local_2937) => { let prod_local_2939 = 52; { let prod_local_2940 = (prod_local_2937).checked_shl(prod_local_2939); match prod_local_2940 {
        None => prod_local_2940,
        Some(prod_local_2941) => { let prod_local_2943 = 4503599627370495; { let prod_local_2944 = (prod_local_2935 & prod_local_2943); { let prod_local_2945 = (prod_local_2941 | prod_local_2944); { let prod_local_2946 = (sg | prod_local_2945); { let prod_local_2947 = Some(prod_local_2946); prod_local_2947 } } } } },
    } } },
    } } },
        true => { let prod_local_2949 = 1; { let prod_local_2950 = (rounded).checked_shr(prod_local_2949); match prod_local_2950 {
        None => prod_local_2950,
        Some(prod_local_2951) => { let prod_local_2952 = prod_local_2951; { let prod_local_2953 = convertInt16ToUInt64(prod_local_2894); match prod_local_2953 {
        None => prod_local_2953,
        Some(prod_local_2954) => { let prod_local_2956 = 52; { let prod_local_2957 = (prod_local_2954).checked_shl(prod_local_2956); match prod_local_2957 {
        None => prod_local_2957,
        Some(prod_local_2958) => { let prod_local_2960 = 4503599627370495; { let prod_local_2961 = (prod_local_2952 & prod_local_2960); { let prod_local_2962 = (prod_local_2958 | prod_local_2961); { let prod_local_2963 = (sg | prod_local_2962); { let prod_local_2964 = Some(prod_local_2963); prod_local_2964 } } } } },
    } } },
    } } },
    } } },
    } } },
    },
        true => { let prod_local_2966 = 9218868437227405312; { let prod_local_2967 = (sg | prod_local_2966); { let prod_local_2968 = Some(prod_local_2967); prod_local_2968 } } },
    } } } } } } } },
        true => { let prod_local_2969 = 0; { let prod_local_2970 = prod_local_2969; { let prod_local_2971 = prod_local_2970; { let prod_local_2972 = prod_local_2971; { let prod_local_2973 = 2046; { let prod_local_2974 = prod_local_2973; { let prod_local_2975 = signedLess(prod_local_2974, prod_local_2972); match prod_local_2975 {
        false => match overflow {
        false => { let prod_local_2977 = false; { let prod_local_2978 = prod_local_2977; match prod_local_2978 {
        false => { let prod_local_2980 = rounded; { let prod_local_2981 = convertInt16ToUInt64(prod_local_2972); match prod_local_2981 {
        None => prod_local_2981,
        Some(prod_local_2982) => { let prod_local_2984 = 52; { let prod_local_2985 = (prod_local_2982).checked_shl(prod_local_2984); match prod_local_2985 {
        None => prod_local_2985,
        Some(prod_local_2986) => { let prod_local_2988 = 4503599627370495; { let prod_local_2989 = (prod_local_2980 & prod_local_2988); { let prod_local_2990 = (prod_local_2986 | prod_local_2989); { let prod_local_2991 = (sg | prod_local_2990); { let prod_local_2992 = Some(prod_local_2991); prod_local_2992 } } } } },
    } } },
    } } },
        true => { let prod_local_2994 = 1; { let prod_local_2995 = (rounded).checked_shr(prod_local_2994); match prod_local_2995 {
        None => prod_local_2995,
        Some(prod_local_2996) => { let prod_local_2997 = prod_local_2996; { let prod_local_2998 = convertInt16ToUInt64(prod_local_2972); match prod_local_2998 {
        None => prod_local_2998,
        Some(prod_local_2999) => { let prod_local_3001 = 52; { let prod_local_3002 = (prod_local_2999).checked_shl(prod_local_3001); match prod_local_3002 {
        None => prod_local_3002,
        Some(prod_local_3003) => { let prod_local_3005 = 4503599627370495; { let prod_local_3006 = (prod_local_2997 & prod_local_3005); { let prod_local_3007 = (prod_local_3003 | prod_local_3006); { let prod_local_3008 = (sg | prod_local_3007); { let prod_local_3009 = Some(prod_local_3008); prod_local_3009 } } } } },
    } } },
    } } },
    } } },
    } } },
        true => { let prod_local_3010 = true; { let prod_local_3011 = prod_local_3010; match prod_local_3011 {
        false => { let prod_local_3013 = rounded; { let prod_local_3014 = convertInt16ToUInt64(prod_local_2972); match prod_local_3014 {
        None => prod_local_3014,
        Some(prod_local_3015) => { let prod_local_3017 = 52; { let prod_local_3018 = (prod_local_3015).checked_shl(prod_local_3017); match prod_local_3018 {
        None => prod_local_3018,
        Some(prod_local_3019) => { let prod_local_3021 = 4503599627370495; { let prod_local_3022 = (prod_local_3013 & prod_local_3021); { let prod_local_3023 = (prod_local_3019 | prod_local_3022); { let prod_local_3024 = (sg | prod_local_3023); { let prod_local_3025 = Some(prod_local_3024); prod_local_3025 } } } } },
    } } },
    } } },
        true => { let prod_local_3027 = 1; { let prod_local_3028 = (rounded).checked_shr(prod_local_3027); match prod_local_3028 {
        None => prod_local_3028,
        Some(prod_local_3029) => { let prod_local_3030 = prod_local_3029; { let prod_local_3031 = convertInt16ToUInt64(prod_local_2972); match prod_local_3031 {
        None => prod_local_3031,
        Some(prod_local_3032) => { let prod_local_3034 = 52; { let prod_local_3035 = (prod_local_3032).checked_shl(prod_local_3034); match prod_local_3035 {
        None => prod_local_3035,
        Some(prod_local_3036) => { let prod_local_3038 = 4503599627370495; { let prod_local_3039 = (prod_local_3030 & prod_local_3038); { let prod_local_3040 = (prod_local_3036 | prod_local_3039); { let prod_local_3041 = (sg | prod_local_3040); { let prod_local_3042 = Some(prod_local_3041); prod_local_3042 } } } } },
    } } },
    } } },
    } } },
    } } },
    },
        true => { let prod_local_3044 = 9218868437227405312; { let prod_local_3045 = (sg | prod_local_3044); { let prod_local_3046 = Some(prod_local_3045); prod_local_3046 } } },
    } } } } } } } },
    } } },
        true => { let prod_local_3047 = true; { let prod_local_3048 = prod_local_3047; match prod_local_3048 {
        false => { let prod_local_3050 = 1; { let prod_local_3051 = prod_local_3050; { let prod_local_3052 = prod_local_3051; { let prod_local_3053 = prod_local_3052; { let prod_local_3054 = 2046; { let prod_local_3055 = prod_local_3054; { let prod_local_3056 = signedLess(prod_local_3055, prod_local_3053); match prod_local_3056 {
        false => match overflow {
        false => { let prod_local_3058 = false; { let prod_local_3059 = prod_local_3058; match prod_local_3059 {
        false => { let prod_local_3061 = rounded; { let prod_local_3062 = convertInt16ToUInt64(prod_local_3053); match prod_local_3062 {
        None => prod_local_3062,
        Some(prod_local_3063) => { let prod_local_3065 = 52; { let prod_local_3066 = (prod_local_3063).checked_shl(prod_local_3065); match prod_local_3066 {
        None => prod_local_3066,
        Some(prod_local_3067) => { let prod_local_3069 = 4503599627370495; { let prod_local_3070 = (prod_local_3061 & prod_local_3069); { let prod_local_3071 = (prod_local_3067 | prod_local_3070); { let prod_local_3072 = (sg | prod_local_3071); { let prod_local_3073 = Some(prod_local_3072); prod_local_3073 } } } } },
    } } },
    } } },
        true => { let prod_local_3075 = 1; { let prod_local_3076 = (rounded).checked_shr(prod_local_3075); match prod_local_3076 {
        None => prod_local_3076,
        Some(prod_local_3077) => { let prod_local_3078 = prod_local_3077; { let prod_local_3079 = convertInt16ToUInt64(prod_local_3053); match prod_local_3079 {
        None => prod_local_3079,
        Some(prod_local_3080) => { let prod_local_3082 = 52; { let prod_local_3083 = (prod_local_3080).checked_shl(prod_local_3082); match prod_local_3083 {
        None => prod_local_3083,
        Some(prod_local_3084) => { let prod_local_3086 = 4503599627370495; { let prod_local_3087 = (prod_local_3078 & prod_local_3086); { let prod_local_3088 = (prod_local_3084 | prod_local_3087); { let prod_local_3089 = (sg | prod_local_3088); { let prod_local_3090 = Some(prod_local_3089); prod_local_3090 } } } } },
    } } },
    } } },
    } } },
    } } },
        true => { let prod_local_3091 = true; { let prod_local_3092 = prod_local_3091; match prod_local_3092 {
        false => { let prod_local_3094 = rounded; { let prod_local_3095 = convertInt16ToUInt64(prod_local_3053); match prod_local_3095 {
        None => prod_local_3095,
        Some(prod_local_3096) => { let prod_local_3098 = 52; { let prod_local_3099 = (prod_local_3096).checked_shl(prod_local_3098); match prod_local_3099 {
        None => prod_local_3099,
        Some(prod_local_3100) => { let prod_local_3102 = 4503599627370495; { let prod_local_3103 = (prod_local_3094 & prod_local_3102); { let prod_local_3104 = (prod_local_3100 | prod_local_3103); { let prod_local_3105 = (sg | prod_local_3104); { let prod_local_3106 = Some(prod_local_3105); prod_local_3106 } } } } },
    } } },
    } } },
        true => { let prod_local_3108 = 1; { let prod_local_3109 = (rounded).checked_shr(prod_local_3108); match prod_local_3109 {
        None => prod_local_3109,
        Some(prod_local_3110) => { let prod_local_3111 = prod_local_3110; { let prod_local_3112 = convertInt16ToUInt64(prod_local_3053); match prod_local_3112 {
        None => prod_local_3112,
        Some(prod_local_3113) => { let prod_local_3115 = 52; { let prod_local_3116 = (prod_local_3113).checked_shl(prod_local_3115); match prod_local_3116 {
        None => prod_local_3116,
        Some(prod_local_3117) => { let prod_local_3119 = 4503599627370495; { let prod_local_3120 = (prod_local_3111 & prod_local_3119); { let prod_local_3121 = (prod_local_3117 | prod_local_3120); { let prod_local_3122 = (sg | prod_local_3121); { let prod_local_3123 = Some(prod_local_3122); prod_local_3123 } } } } },
    } } },
    } } },
    } } },
    } } },
    },
        true => { let prod_local_3125 = 9218868437227405312; { let prod_local_3126 = (sg | prod_local_3125); { let prod_local_3127 = Some(prod_local_3126); prod_local_3127 } } },
    } } } } } } } },
        true => { let prod_local_3128 = 0; { let prod_local_3129 = prod_local_3128; { let prod_local_3130 = prod_local_3129; { let prod_local_3131 = prod_local_3130; { let prod_local_3132 = 2046; { let prod_local_3133 = prod_local_3132; { let prod_local_3134 = signedLess(prod_local_3133, prod_local_3131); match prod_local_3134 {
        false => match overflow {
        false => { let prod_local_3136 = false; { let prod_local_3137 = prod_local_3136; match prod_local_3137 {
        false => { let prod_local_3139 = rounded; { let prod_local_3140 = convertInt16ToUInt64(prod_local_3131); match prod_local_3140 {
        None => prod_local_3140,
        Some(prod_local_3141) => { let prod_local_3143 = 52; { let prod_local_3144 = (prod_local_3141).checked_shl(prod_local_3143); match prod_local_3144 {
        None => prod_local_3144,
        Some(prod_local_3145) => { let prod_local_3147 = 4503599627370495; { let prod_local_3148 = (prod_local_3139 & prod_local_3147); { let prod_local_3149 = (prod_local_3145 | prod_local_3148); { let prod_local_3150 = (sg | prod_local_3149); { let prod_local_3151 = Some(prod_local_3150); prod_local_3151 } } } } },
    } } },
    } } },
        true => { let prod_local_3153 = 1; { let prod_local_3154 = (rounded).checked_shr(prod_local_3153); match prod_local_3154 {
        None => prod_local_3154,
        Some(prod_local_3155) => { let prod_local_3156 = prod_local_3155; { let prod_local_3157 = convertInt16ToUInt64(prod_local_3131); match prod_local_3157 {
        None => prod_local_3157,
        Some(prod_local_3158) => { let prod_local_3160 = 52; { let prod_local_3161 = (prod_local_3158).checked_shl(prod_local_3160); match prod_local_3161 {
        None => prod_local_3161,
        Some(prod_local_3162) => { let prod_local_3164 = 4503599627370495; { let prod_local_3165 = (prod_local_3156 & prod_local_3164); { let prod_local_3166 = (prod_local_3162 | prod_local_3165); { let prod_local_3167 = (sg | prod_local_3166); { let prod_local_3168 = Some(prod_local_3167); prod_local_3168 } } } } },
    } } },
    } } },
    } } },
    } } },
        true => { let prod_local_3169 = true; { let prod_local_3170 = prod_local_3169; match prod_local_3170 {
        false => { let prod_local_3172 = rounded; { let prod_local_3173 = convertInt16ToUInt64(prod_local_3131); match prod_local_3173 {
        None => prod_local_3173,
        Some(prod_local_3174) => { let prod_local_3176 = 52; { let prod_local_3177 = (prod_local_3174).checked_shl(prod_local_3176); match prod_local_3177 {
        None => prod_local_3177,
        Some(prod_local_3178) => { let prod_local_3180 = 4503599627370495; { let prod_local_3181 = (prod_local_3172 & prod_local_3180); { let prod_local_3182 = (prod_local_3178 | prod_local_3181); { let prod_local_3183 = (sg | prod_local_3182); { let prod_local_3184 = Some(prod_local_3183); prod_local_3184 } } } } },
    } } },
    } } },
        true => { let prod_local_3186 = 1; { let prod_local_3187 = (rounded).checked_shr(prod_local_3186); match prod_local_3187 {
        None => prod_local_3187,
        Some(prod_local_3188) => { let prod_local_3189 = prod_local_3188; { let prod_local_3190 = convertInt16ToUInt64(prod_local_3131); match prod_local_3190 {
        None => prod_local_3190,
        Some(prod_local_3191) => { let prod_local_3193 = 52; { let prod_local_3194 = (prod_local_3191).checked_shl(prod_local_3193); match prod_local_3194 {
        None => prod_local_3194,
        Some(prod_local_3195) => { let prod_local_3197 = 4503599627370495; { let prod_local_3198 = (prod_local_3189 & prod_local_3197); { let prod_local_3199 = (prod_local_3195 | prod_local_3198); { let prod_local_3200 = (sg | prod_local_3199); { let prod_local_3201 = Some(prod_local_3200); prod_local_3201 } } } } },
    } } },
    } } },
    } } },
    } } },
    },
        true => { let prod_local_3203 = 9218868437227405312; { let prod_local_3204 = (sg | prod_local_3203); { let prod_local_3205 = Some(prod_local_3204); prod_local_3205 } } },
    } } } } } } } },
    } } },
    } } },
    } } },
    } } } } } },
    } } } },
    } } },
    } } }
}

pub fn convertInt16ToUInt16(value: i16) -> Option<u16> {
    { let _x_4 = core::convert::TryFrom::try_from(value).ok(); _x_4 }
}

pub fn convertInt16ToUInt32(value: i16) -> Option<u32> {
    { let _x_4 = core::convert::TryFrom::try_from(value).ok(); _x_4 }
}

pub fn convertInt16ToUInt64(value: i16) -> Option<u64> {
    { let _x_4 = core::convert::TryFrom::try_from(value).ok(); _x_4 }
}

pub fn convertInt16ToUInt8(value: i16) -> Option<u8> {
    { let _x_4 = core::convert::TryFrom::try_from(value).ok(); _x_4 }
}

pub fn convertUInt16ToInt16(value: u16) -> Option<i16> {
    { let _x_4 = core::convert::TryFrom::try_from(value).ok(); _x_4 }
}

pub fn convertUInt32ToUInt64(value: u32) -> Option<u64> {
    { let _x_4 = core::convert::TryFrom::try_from(value).ok(); _x_4 }
}

pub fn convertUInt64ToUInt16(value: u64) -> Option<u16> {
    { let _x_4 = core::convert::TryFrom::try_from(value).ok(); _x_4 }
}

pub fn convertUInt64ToUInt32(value: u64) -> Option<u32> {
    { let _x_4 = core::convert::TryFrom::try_from(value).ok(); _x_4 }
}

pub fn int16Add(a: i16, b: i16) -> Option<i16> {
    { let _x_2 = (a).checked_add(b); _x_2 }
}

pub fn int16Negate(a: i16) -> Option<i16> {
    { let _x_2 = (a).checked_neg(); _x_2 }
}

pub fn int16Subtract(a: i16, b: i16) -> Option<i16> {
    { let _x_2 = (a).checked_sub(b); _x_2 }
}

pub fn length(w: crate::Limbs) -> Option<i16> {
    { let _x_3 = (w).l3; { let _x_73 = 0; { let _x_7 = (_x_3 == _x_73); match _x_7 {
        false => { let _x_234 = length32(_x_3); match _x_234 {
        None => _x_234,
        Some(val_235) => { let _x_236 = 96; { let _x_237 = _x_236; { let _x_238 = int16Add(val_235, _x_237); _x_238 } } },
    } },
        true => { let _x_239 = (w).l2; { let _x_240 = (_x_239 == _x_73); match _x_240 {
        false => { let _x_259 = length32(_x_239); match _x_259 {
        None => _x_259,
        Some(val_260) => { let _x_261 = 64; { let _x_262 = _x_261; { let _x_263 = int16Add(val_260, _x_262); _x_263 } } },
    } },
        true => { let _x_264 = (w).l1; { let _x_265 = (_x_264 == _x_73); match _x_265 {
        false => { let _x_275 = length32(_x_264); match _x_275 {
        None => _x_275,
        Some(val_276) => { let _x_277 = 32; { let _x_278 = _x_277; { let _x_279 = int16Add(val_276, _x_278); _x_279 } } },
    } },
        true => { let _x_280 = (w).l0; { let _x_281 = length32(_x_280); _x_281 } },
    } } },
    } } },
    } } } }
}

pub fn length16(state: Option<crate::LengthState>) -> Option<crate::LengthState> {
    { let _x_1 = length8(state); { let _x_2 = length8(_x_1); _x_2 } }
}

pub fn length2(state: Option<crate::LengthState>) -> Option<crate::LengthState> {
    { let _x_1 = lengthStep(state); { let _x_2 = lengthStep(_x_1); _x_2 } }
}

pub fn length32(v: u32) -> Option<i16> {
    { let _x_8 = 0; { let _x_20 = _x_8; { let _x_11 = crate::LengthState { word: v, count: _x_20 }; { let _x_12 = Some(_x_11); { let _x_13 = length32Steps(_x_12); match _x_13 {
        None => None,
        Some(val_16) => { let _x_24 = (val_16).count; { let _x_25 = Some(_x_24); _x_25 } },
    } } } } } }
}

pub fn length32Steps(state: Option<crate::LengthState>) -> Option<crate::LengthState> {
    { let _x_1 = length16(state); { let _x_2 = length16(_x_1); _x_2 } }
}

pub fn length4(state: Option<crate::LengthState>) -> Option<crate::LengthState> {
    { let _x_1 = length2(state); { let _x_2 = length2(_x_1); _x_2 } }
}

pub fn length8(state: Option<crate::LengthState>) -> Option<crate::LengthState> {
    { let _x_1 = length4(state); { let _x_2 = length4(_x_1); _x_2 } }
}

pub fn lengthStep(state: Option<crate::LengthState>) -> Option<crate::LengthState> {
    match state {
        None => state,
        Some(val_56) => { let _x_130 = (val_56).word; { let _x_132 = 1; { let _x_133 = (_x_130).checked_shr(_x_132); match _x_133 {
        None => None,
        Some(val_136) => { let _x_141 = (val_56).word; { let _x_143 = 0; { let _x_144 = (_x_141 == _x_143); match _x_144 {
        false => { let _x_172 = (val_56).count; { let _x_173 = 1; { let _x_174 = _x_173; { let _x_175 = int16Add(_x_172, _x_174); match _x_175 {
        None => None,
        Some(val_177) => { let _x_178 = crate::LengthState { word: val_136, count: val_177 }; { let _x_179 = Some(_x_178); _x_179 } },
    } } } } },
        true => { let _x_180 = (val_56).count; { let _x_181 = crate::LengthState { word: val_136, count: _x_180 }; { let _x_182 = Some(_x_181); _x_182 } } },
    } } } },
    } } } },
    }
}

pub fn low64(w: crate::Limbs) -> Option<u64> {
    { let _x_15 = (w).l2; { let _x_83 = 0; { let _x_19 = (_x_15 == _x_83); match _x_19 {
        false => { let _y_24 = _x_19; match _y_24 {
        false => None,
        true => { let _x_188 = (w).l0; { let _x_189 = convertUInt32ToUInt64(_x_188); match _x_189 {
        None => _x_189,
        Some(val_190) => { let _x_191 = (w).l1; { let _x_192 = convertUInt32ToUInt64(_x_191); match _x_192 {
        None => _x_192,
        Some(val_193) => { let _x_195 = 32; { let _x_196 = (val_193).checked_shl(_x_195); match _x_196 {
        None => _x_196,
        Some(val_197) => { let _x_199 = (val_190 | val_197); { let _x_200 = Some(_x_199); _x_200 } },
    } } },
    } } },
    } } },
    } },
        true => { let _x_183 = (w).l3; { let _x_185 = 0; { let _x_186 = (_x_183 == _x_185); { let prod_local_0 = _x_186; match prod_local_0 {
        false => None,
        true => { let prod_local_2 = (w).l0; { let prod_local_3 = convertUInt32ToUInt64(prod_local_2); match prod_local_3 {
        None => prod_local_3,
        Some(prod_local_4) => { let prod_local_5 = (w).l1; { let prod_local_6 = convertUInt32ToUInt64(prod_local_5); match prod_local_6 {
        None => prod_local_6,
        Some(prod_local_7) => { let prod_local_9 = 32; { let prod_local_10 = (prod_local_7).checked_shl(prod_local_9); match prod_local_10 {
        None => prod_local_10,
        Some(prod_local_11) => { let prod_local_13 = (prod_local_4 | prod_local_11); { let prod_local_14 = Some(prod_local_13); prod_local_14 } },
    } } },
    } } },
    } } },
    } } } } },
    } } } }
}

pub fn multiply(a: u64, b: u64) -> Option<crate::Limbs> {
    { let _x_332 = 4294967295; { let _x_282 = (a & _x_332); { let _x_525 = 32; { let _x_526 = (a).checked_shr(_x_525); match _x_526 {
        None => None,
        Some(val_529) => { let _x_715 = 4294967295; { let _x_716 = (b & _x_715); { let _x_892 = 32; { let _x_893 = (b).checked_shr(_x_892); match _x_893 {
        None => None,
        Some(val_896) => { let _x_1063 = (_x_282).checked_mul(_x_716); match _x_1063 {
        None => None,
        Some(val_1066) => { let _x_1223 = 32; { let _x_1224 = (val_1066).checked_shr(_x_1223); match _x_1224 {
        None => None,
        Some(val_1227) => { let _x_1374 = (val_529).checked_mul(_x_716); match _x_1374 {
        None => None,
        Some(val_1377) => { let _x_1515 = (val_1377).checked_add(val_1227); match _x_1515 {
        None => None,
        Some(val_1518) => { let _x_1647 = (_x_282).checked_mul(val_896); match _x_1647 {
        None => None,
        Some(val_1650) => { let _x_1768 = 4294967295; { let _x_1769 = (val_1518 & _x_1768); { let _x_1770 = (val_1650).checked_add(_x_1769); match _x_1770 {
        None => None,
        Some(val_1773) => { let _x_1880 = 32; { let _x_1881 = (val_1518).checked_shr(_x_1880); match _x_1881 {
        None => None,
        Some(val_1884) => { let _x_1980 = 32; { let _x_1981 = (val_1773).checked_shr(_x_1980); match _x_1981 {
        None => None,
        Some(val_1984) => { let _x_2070 = (val_529).checked_mul(val_896); match _x_2070 {
        None => None,
        Some(val_2073) => { let _x_2150 = (val_2073).checked_add(val_1884); match _x_2150 {
        None => None,
        Some(val_2153) => { let _x_2221 = (val_2153).checked_add(val_1984); match _x_2221 {
        None => None,
        Some(val_2224) => { let _x_2282 = 32; { let _x_2283 = (val_2224).checked_shr(_x_2282); match _x_2283 {
        None => None,
        Some(val_2286) => { let _x_2332 = 4294967295; { let _x_2333 = (val_1066 & _x_2332); { let _x_2334 = convertUInt64ToUInt32(_x_2333); match _x_2334 {
        None => None,
        Some(val_2337) => { let _x_2371 = 4294967295; { let _x_2372 = (val_1773 & _x_2371); { let _x_2373 = convertUInt64ToUInt32(_x_2372); match _x_2373 {
        None => None,
        Some(val_2376) => { let _x_2398 = 4294967295; { let _x_2399 = (val_2224 & _x_2398); { let _x_2400 = convertUInt64ToUInt32(_x_2399); match _x_2400 {
        None => None,
        Some(val_2403) => { let _x_2413 = 4294967295; { let _x_2414 = (val_2286 & _x_2413); { let _x_2415 = convertUInt64ToUInt32(_x_2414); match _x_2415 {
        None => None,
        Some(val_2418) => { let _x_2421 = crate::Limbs { l0: val_2337, l1: val_2376, l2: val_2403, l3: val_2418 }; { let _x_2422 = Some(_x_2421); _x_2422 } },
    } } } },
    } } } },
    } } } },
    } } } },
    } } },
    } },
    } },
    } },
    } } },
    } } },
    } } } },
    } },
    } },
    } },
    } } },
    } },
    } } } } },
    } } } } }
}

pub fn negative(a: i16) -> bool {
    { let _x_8 = convertInt16ToUInt16(a); match _x_8 {
        None => { let _x_16 = true; _x_16 },
        Some(val_11) => { let _x_17 = false; _x_17 },
    } }
}

pub fn right(w: crate::Limbs) -> Option<crate::Limbs> {
    { let _x_121 = (w).l0; { let _x_156 = 1; { let _x_125 = (_x_121).checked_shr(_x_156); match _x_125 {
        None => None,
        Some(val_128) => { let _x_239 = (w).l1; { let _x_241 = 1; { let _x_242 = (_x_239).checked_shr(_x_241); match _x_242 {
        None => None,
        Some(val_245) => { let _x_315 = (w).l2; { let _x_317 = 1; { let _x_318 = (_x_315).checked_shr(_x_317); match _x_318 {
        None => None,
        Some(val_321) => { let _x_379 = (w).l3; { let _x_381 = 1; { let _x_382 = (_x_379).checked_shr(_x_381); match _x_382 {
        None => None,
        Some(val_385) => { let _x_428 = (w).l1; { let _x_430 = 1; { let _x_431 = (_x_428 & _x_430); { let _x_433 = 31; { let _x_434 = (_x_431).checked_shl(_x_433); match _x_434 {
        None => None,
        Some(val_437) => { let _x_465 = (w).l2; { let _x_467 = 1; { let _x_468 = (_x_465 & _x_467); { let _x_470 = 31; { let _x_471 = (_x_468).checked_shl(_x_470); match _x_471 {
        None => None,
        Some(val_474) => { let _x_487 = (w).l3; { let _x_489 = 1; { let _x_490 = (_x_487 & _x_489); { let _x_492 = 31; { let _x_493 = (_x_490).checked_shl(_x_492); match _x_493 {
        None => None,
        Some(val_496) => { let _x_500 = (val_128 | val_437); { let _x_501 = (val_245 | val_474); { let _x_502 = (val_321 | val_496); { let _x_503 = crate::Limbs { l0: _x_500, l1: _x_501, l2: _x_502, l3: val_385 }; { let _x_504 = Some(_x_503); _x_504 } } } } },
    } } } } } },
    } } } } } },
    } } } } } },
    } } } },
    } } } },
    } } } },
    } } } }
}

pub fn round(w: crate::Limbs, amount: i16) -> Option<u64> {
    { let _x_1 = negative(amount); match _x_1 {
        false => { let _x_2608 = 128; { let _x_2609 = _x_2608; { let _x_2610 = signedLess(_x_2609, amount); match _x_2610 {
        false => { let _x_2855 = convertInt16ToUInt8(amount); match _x_2855 {
        None => None,
        Some(val_2857) => { let _x_2909 = crate::Rounding { value: w, guard: _x_2610, sticky: _x_2610 }; { let _x_2923 = 1; { let _x_2924 = (val_2857 & _x_2923); { let _x_2925 = 0; { let _x_2926 = (_x_2924 == _x_2925); { let _y_2928 = match _x_2926 {
        false => { let _x_3093 = false; _x_3093 },
        true => { let _x_3094 = true; _x_3094 },
    }; match _y_2928 {
        false => { let _x_3087 = Some(_x_2909); { let _x_3088 = roundStep(_x_3087); match _x_3088 {
        None => { let _y_2914 = _x_3088; match _y_2914 {
        None => None,
        Some(val_2917) => { let val_2911 = val_2917; { let _x_3136 = (val_2911).value; { let _x_3137 = low64(_x_3136); match _x_3137 {
        None => _x_3137,
        Some(val_3140) => { let _x_3161 = (val_2911).guard; match _x_3161 {
        false => _x_3137,
        true => { let _x_3192 = (val_2911).sticky; match _x_3192 {
        false => { let _x_3201 = 1; { let _x_3202 = (val_3140 & _x_3201); { let _x_3203 = (_x_3202 == _x_3201); match _x_3203 {
        false => _x_3137,
        true => { let _x_3236 = 1; { let _x_3237 = (val_3140).checked_add(_x_3236); _x_3237 } },
    } } } },
        true => { let prod_local_1 = 1; { let prod_local_2 = (val_3140).checked_add(prod_local_1); prod_local_2 } },
    } },
    } },
    } } } },
    } },
        Some(val_3091) => { let val_2930 = val_3091; { let _x_2936 = 2; { let _x_2937 = (val_2857 & _x_2936); { let _x_2938 = 0; { let _x_2939 = (_x_2937 == _x_2938); { let _y_2941 = match _x_2939 {
        false => { let _x_3084 = false; _x_3084 },
        true => { let _x_3085 = true; _x_3085 },
    }; match _y_2941 {
        false => { let _x_3078 = Some(val_2930); { let _x_3079 = round2(_x_3078); match _x_3079 {
        None => { let prod_local_3 = _x_3079; match prod_local_3 {
        None => None,
        Some(prod_local_5) => { let prod_local_6 = prod_local_5; { let prod_local_7 = (prod_local_6).value; { let prod_local_8 = low64(prod_local_7); match prod_local_8 {
        None => prod_local_8,
        Some(prod_local_9) => { let prod_local_10 = (prod_local_6).guard; match prod_local_10 {
        false => prod_local_8,
        true => { let prod_local_12 = (prod_local_6).sticky; match prod_local_12 {
        false => { let prod_local_16 = 1; { let prod_local_17 = (prod_local_9 & prod_local_16); { let prod_local_18 = (prod_local_17 == prod_local_16); match prod_local_18 {
        false => prod_local_8,
        true => { let prod_local_20 = 1; { let prod_local_21 = (prod_local_9).checked_add(prod_local_20); prod_local_21 } },
    } } } },
        true => { let prod_local_23 = 1; { let prod_local_24 = (prod_local_9).checked_add(prod_local_23); prod_local_24 } },
    } },
    } },
    } } } },
    } },
        Some(val_3082) => { let val_2943 = val_3082; { let _x_2949 = 4; { let _x_2950 = (val_2857 & _x_2949); { let _x_2951 = 0; { let _x_2952 = (_x_2950 == _x_2951); { let _y_2954 = match _x_2952 {
        false => { let _x_3075 = false; _x_3075 },
        true => { let _x_3076 = true; _x_3076 },
    }; match _y_2954 {
        false => { let _x_3069 = Some(val_2943); { let _x_3070 = round4(_x_3069); match _x_3070 {
        None => { let prod_local_25 = _x_3070; match prod_local_25 {
        None => None,
        Some(prod_local_27) => { let prod_local_28 = prod_local_27; { let prod_local_29 = (prod_local_28).value; { let prod_local_30 = low64(prod_local_29); match prod_local_30 {
        None => prod_local_30,
        Some(prod_local_31) => { let prod_local_32 = (prod_local_28).guard; match prod_local_32 {
        false => prod_local_30,
        true => { let prod_local_34 = (prod_local_28).sticky; match prod_local_34 {
        false => { let prod_local_38 = 1; { let prod_local_39 = (prod_local_31 & prod_local_38); { let prod_local_40 = (prod_local_39 == prod_local_38); match prod_local_40 {
        false => prod_local_30,
        true => { let prod_local_42 = 1; { let prod_local_43 = (prod_local_31).checked_add(prod_local_42); prod_local_43 } },
    } } } },
        true => { let prod_local_45 = 1; { let prod_local_46 = (prod_local_31).checked_add(prod_local_45); prod_local_46 } },
    } },
    } },
    } } } },
    } },
        Some(val_3073) => { let val_2956 = val_3073; { let _x_2962 = 8; { let _x_2963 = (val_2857 & _x_2962); { let _x_2964 = 0; { let _x_2965 = (_x_2963 == _x_2964); { let _y_2967 = match _x_2965 {
        false => { let _x_3066 = false; _x_3066 },
        true => { let _x_3067 = true; _x_3067 },
    }; match _y_2967 {
        false => { let _x_3060 = Some(val_2956); { let _x_3061 = round8(_x_3060); match _x_3061 {
        None => { let prod_local_47 = _x_3061; match prod_local_47 {
        None => None,
        Some(prod_local_49) => { let prod_local_50 = prod_local_49; { let prod_local_51 = (prod_local_50).value; { let prod_local_52 = low64(prod_local_51); match prod_local_52 {
        None => prod_local_52,
        Some(prod_local_53) => { let prod_local_54 = (prod_local_50).guard; match prod_local_54 {
        false => prod_local_52,
        true => { let prod_local_56 = (prod_local_50).sticky; match prod_local_56 {
        false => { let prod_local_60 = 1; { let prod_local_61 = (prod_local_53 & prod_local_60); { let prod_local_62 = (prod_local_61 == prod_local_60); match prod_local_62 {
        false => prod_local_52,
        true => { let prod_local_64 = 1; { let prod_local_65 = (prod_local_53).checked_add(prod_local_64); prod_local_65 } },
    } } } },
        true => { let prod_local_67 = 1; { let prod_local_68 = (prod_local_53).checked_add(prod_local_67); prod_local_68 } },
    } },
    } },
    } } } },
    } },
        Some(val_3064) => { let val_2969 = val_3064; { let _x_2975 = 16; { let _x_2976 = (val_2857 & _x_2975); { let _x_2977 = 0; { let _x_2978 = (_x_2976 == _x_2977); { let _y_2980 = match _x_2978 {
        false => { let _x_3057 = false; _x_3057 },
        true => { let _x_3058 = true; _x_3058 },
    }; match _y_2980 {
        false => { let _x_3051 = Some(val_2969); { let _x_3052 = round16(_x_3051); match _x_3052 {
        None => { let prod_local_69 = _x_3052; match prod_local_69 {
        None => None,
        Some(prod_local_71) => { let prod_local_72 = prod_local_71; { let prod_local_73 = (prod_local_72).value; { let prod_local_74 = low64(prod_local_73); match prod_local_74 {
        None => prod_local_74,
        Some(prod_local_75) => { let prod_local_76 = (prod_local_72).guard; match prod_local_76 {
        false => prod_local_74,
        true => { let prod_local_78 = (prod_local_72).sticky; match prod_local_78 {
        false => { let prod_local_82 = 1; { let prod_local_83 = (prod_local_75 & prod_local_82); { let prod_local_84 = (prod_local_83 == prod_local_82); match prod_local_84 {
        false => prod_local_74,
        true => { let prod_local_86 = 1; { let prod_local_87 = (prod_local_75).checked_add(prod_local_86); prod_local_87 } },
    } } } },
        true => { let prod_local_89 = 1; { let prod_local_90 = (prod_local_75).checked_add(prod_local_89); prod_local_90 } },
    } },
    } },
    } } } },
    } },
        Some(val_3055) => { let val_2982 = val_3055; { let _x_2988 = 32; { let _x_2989 = (val_2857 & _x_2988); { let _x_2990 = 0; { let _x_2991 = (_x_2989 == _x_2990); { let _y_2993 = match _x_2991 {
        false => { let _x_3048 = false; _x_3048 },
        true => { let _x_3049 = true; _x_3049 },
    }; match _y_2993 {
        false => { let _x_3042 = Some(val_2982); { let _x_3043 = round32(_x_3042); match _x_3043 {
        None => { let prod_local_91 = _x_3043; match prod_local_91 {
        None => None,
        Some(prod_local_93) => { let prod_local_94 = prod_local_93; { let prod_local_95 = (prod_local_94).value; { let prod_local_96 = low64(prod_local_95); match prod_local_96 {
        None => prod_local_96,
        Some(prod_local_97) => { let prod_local_98 = (prod_local_94).guard; match prod_local_98 {
        false => prod_local_96,
        true => { let prod_local_100 = (prod_local_94).sticky; match prod_local_100 {
        false => { let prod_local_104 = 1; { let prod_local_105 = (prod_local_97 & prod_local_104); { let prod_local_106 = (prod_local_105 == prod_local_104); match prod_local_106 {
        false => prod_local_96,
        true => { let prod_local_108 = 1; { let prod_local_109 = (prod_local_97).checked_add(prod_local_108); prod_local_109 } },
    } } } },
        true => { let prod_local_111 = 1; { let prod_local_112 = (prod_local_97).checked_add(prod_local_111); prod_local_112 } },
    } },
    } },
    } } } },
    } },
        Some(val_3046) => { let val_2995 = val_3046; { let _x_3001 = 64; { let _x_3002 = (val_2857 & _x_3001); { let _x_3003 = 0; { let _x_3004 = (_x_3002 == _x_3003); { let _y_3006 = match _x_3004 {
        false => { let _x_3039 = false; _x_3039 },
        true => { let _x_3040 = true; _x_3040 },
    }; match _y_3006 {
        false => { let _x_3033 = Some(val_2995); { let _x_3034 = round64(_x_3033); match _x_3034 {
        None => { let prod_local_113 = _x_3034; match prod_local_113 {
        None => None,
        Some(prod_local_115) => { let prod_local_116 = prod_local_115; { let prod_local_117 = (prod_local_116).value; { let prod_local_118 = low64(prod_local_117); match prod_local_118 {
        None => prod_local_118,
        Some(prod_local_119) => { let prod_local_120 = (prod_local_116).guard; match prod_local_120 {
        false => prod_local_118,
        true => { let prod_local_122 = (prod_local_116).sticky; match prod_local_122 {
        false => { let prod_local_126 = 1; { let prod_local_127 = (prod_local_119 & prod_local_126); { let prod_local_128 = (prod_local_127 == prod_local_126); match prod_local_128 {
        false => prod_local_118,
        true => { let prod_local_130 = 1; { let prod_local_131 = (prod_local_119).checked_add(prod_local_130); prod_local_131 } },
    } } } },
        true => { let prod_local_133 = 1; { let prod_local_134 = (prod_local_119).checked_add(prod_local_133); prod_local_134 } },
    } },
    } },
    } } } },
    } },
        Some(val_3037) => { let val_3008 = val_3037; { let _x_3014 = 128; { let _x_3015 = (val_2857 & _x_3014); { let _x_3016 = 0; { let _x_3017 = (_x_3015 == _x_3016); { let _y_3019 = match _x_3017 {
        false => { let _x_3030 = false; _x_3030 },
        true => { let _x_3031 = true; _x_3031 },
    }; match _y_3019 {
        false => { let _x_3024 = Some(val_3008); { let _x_3025 = round128(_x_3024); match _x_3025 {
        None => { let prod_local_135 = _x_3025; match prod_local_135 {
        None => None,
        Some(prod_local_137) => { let prod_local_138 = prod_local_137; { let prod_local_139 = (prod_local_138).value; { let prod_local_140 = low64(prod_local_139); match prod_local_140 {
        None => prod_local_140,
        Some(prod_local_141) => { let prod_local_142 = (prod_local_138).guard; match prod_local_142 {
        false => prod_local_140,
        true => { let prod_local_144 = (prod_local_138).sticky; match prod_local_144 {
        false => { let prod_local_148 = 1; { let prod_local_149 = (prod_local_141 & prod_local_148); { let prod_local_150 = (prod_local_149 == prod_local_148); match prod_local_150 {
        false => prod_local_140,
        true => { let prod_local_152 = 1; { let prod_local_153 = (prod_local_141).checked_add(prod_local_152); prod_local_153 } },
    } } } },
        true => { let prod_local_155 = 1; { let prod_local_156 = (prod_local_141).checked_add(prod_local_155); prod_local_156 } },
    } },
    } },
    } } } },
    } },
        Some(val_3028) => { let val_3021 = val_3028; { let prod_local_157 = val_3021; { let prod_local_158 = (prod_local_157).value; { let prod_local_159 = low64(prod_local_158); match prod_local_159 {
        None => prod_local_159,
        Some(prod_local_160) => { let prod_local_161 = (prod_local_157).guard; match prod_local_161 {
        false => prod_local_159,
        true => { let prod_local_163 = (prod_local_157).sticky; match prod_local_163 {
        false => { let prod_local_167 = 1; { let prod_local_168 = (prod_local_160 & prod_local_167); { let prod_local_169 = (prod_local_168 == prod_local_167); match prod_local_169 {
        false => prod_local_159,
        true => { let prod_local_171 = 1; { let prod_local_172 = (prod_local_160).checked_add(prod_local_171); prod_local_172 } },
    } } } },
        true => { let prod_local_174 = 1; { let prod_local_175 = (prod_local_160).checked_add(prod_local_174); prod_local_175 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_176 = val_3008; { let prod_local_177 = prod_local_176; { let prod_local_178 = (prod_local_177).value; { let prod_local_179 = low64(prod_local_178); match prod_local_179 {
        None => prod_local_179,
        Some(prod_local_180) => { let prod_local_181 = (prod_local_177).guard; match prod_local_181 {
        false => prod_local_179,
        true => { let prod_local_183 = (prod_local_177).sticky; match prod_local_183 {
        false => { let prod_local_187 = 1; { let prod_local_188 = (prod_local_180 & prod_local_187); { let prod_local_189 = (prod_local_188 == prod_local_187); match prod_local_189 {
        false => prod_local_179,
        true => { let prod_local_191 = 1; { let prod_local_192 = (prod_local_180).checked_add(prod_local_191); prod_local_192 } },
    } } } },
        true => { let prod_local_194 = 1; { let prod_local_195 = (prod_local_180).checked_add(prod_local_194); prod_local_195 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_196 = val_2995; { let prod_local_200 = 128; { let prod_local_201 = (val_2857 & prod_local_200); { let prod_local_202 = 0; { let prod_local_203 = (prod_local_201 == prod_local_202); { let prod_local_207 = match prod_local_203 {
        false => { let prod_local_205 = false; prod_local_205 },
        true => { let prod_local_206 = true; prod_local_206 },
    }; match prod_local_207 {
        false => { let prod_local_209 = Some(prod_local_196); { let prod_local_210 = round128(prod_local_209); match prod_local_210 {
        None => { let prod_local_211 = prod_local_210; match prod_local_211 {
        None => None,
        Some(prod_local_213) => { let prod_local_214 = prod_local_213; { let prod_local_215 = (prod_local_214).value; { let prod_local_216 = low64(prod_local_215); match prod_local_216 {
        None => prod_local_216,
        Some(prod_local_217) => { let prod_local_218 = (prod_local_214).guard; match prod_local_218 {
        false => prod_local_216,
        true => { let prod_local_220 = (prod_local_214).sticky; match prod_local_220 {
        false => { let prod_local_224 = 1; { let prod_local_225 = (prod_local_217 & prod_local_224); { let prod_local_226 = (prod_local_225 == prod_local_224); match prod_local_226 {
        false => prod_local_216,
        true => { let prod_local_228 = 1; { let prod_local_229 = (prod_local_217).checked_add(prod_local_228); prod_local_229 } },
    } } } },
        true => { let prod_local_231 = 1; { let prod_local_232 = (prod_local_217).checked_add(prod_local_231); prod_local_232 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_233) => { let prod_local_234 = prod_local_233; { let prod_local_235 = prod_local_234; { let prod_local_236 = (prod_local_235).value; { let prod_local_237 = low64(prod_local_236); match prod_local_237 {
        None => prod_local_237,
        Some(prod_local_238) => { let prod_local_239 = (prod_local_235).guard; match prod_local_239 {
        false => prod_local_237,
        true => { let prod_local_241 = (prod_local_235).sticky; match prod_local_241 {
        false => { let prod_local_245 = 1; { let prod_local_246 = (prod_local_238 & prod_local_245); { let prod_local_247 = (prod_local_246 == prod_local_245); match prod_local_247 {
        false => prod_local_237,
        true => { let prod_local_249 = 1; { let prod_local_250 = (prod_local_238).checked_add(prod_local_249); prod_local_250 } },
    } } } },
        true => { let prod_local_252 = 1; { let prod_local_253 = (prod_local_238).checked_add(prod_local_252); prod_local_253 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_254 = prod_local_196; { let prod_local_255 = prod_local_254; { let prod_local_256 = (prod_local_255).value; { let prod_local_257 = low64(prod_local_256); match prod_local_257 {
        None => prod_local_257,
        Some(prod_local_258) => { let prod_local_259 = (prod_local_255).guard; match prod_local_259 {
        false => prod_local_257,
        true => { let prod_local_261 = (prod_local_255).sticky; match prod_local_261 {
        false => { let prod_local_265 = 1; { let prod_local_266 = (prod_local_258 & prod_local_265); { let prod_local_267 = (prod_local_266 == prod_local_265); match prod_local_267 {
        false => prod_local_257,
        true => { let prod_local_269 = 1; { let prod_local_270 = (prod_local_258).checked_add(prod_local_269); prod_local_270 } },
    } } } },
        true => { let prod_local_272 = 1; { let prod_local_273 = (prod_local_258).checked_add(prod_local_272); prod_local_273 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_274 = val_2982; { let prod_local_278 = 64; { let prod_local_279 = (val_2857 & prod_local_278); { let prod_local_280 = 0; { let prod_local_281 = (prod_local_279 == prod_local_280); { let prod_local_285 = match prod_local_281 {
        false => { let prod_local_283 = false; prod_local_283 },
        true => { let prod_local_284 = true; prod_local_284 },
    }; match prod_local_285 {
        false => { let prod_local_287 = Some(prod_local_274); { let prod_local_288 = round64(prod_local_287); match prod_local_288 {
        None => { let prod_local_289 = prod_local_288; match prod_local_289 {
        None => None,
        Some(prod_local_291) => { let prod_local_292 = prod_local_291; { let prod_local_293 = (prod_local_292).value; { let prod_local_294 = low64(prod_local_293); match prod_local_294 {
        None => prod_local_294,
        Some(prod_local_295) => { let prod_local_296 = (prod_local_292).guard; match prod_local_296 {
        false => prod_local_294,
        true => { let prod_local_298 = (prod_local_292).sticky; match prod_local_298 {
        false => { let prod_local_302 = 1; { let prod_local_303 = (prod_local_295 & prod_local_302); { let prod_local_304 = (prod_local_303 == prod_local_302); match prod_local_304 {
        false => prod_local_294,
        true => { let prod_local_306 = 1; { let prod_local_307 = (prod_local_295).checked_add(prod_local_306); prod_local_307 } },
    } } } },
        true => { let prod_local_309 = 1; { let prod_local_310 = (prod_local_295).checked_add(prod_local_309); prod_local_310 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_311) => { let prod_local_312 = prod_local_311; { let prod_local_316 = 128; { let prod_local_317 = (val_2857 & prod_local_316); { let prod_local_318 = 0; { let prod_local_319 = (prod_local_317 == prod_local_318); { let prod_local_323 = match prod_local_319 {
        false => { let prod_local_321 = false; prod_local_321 },
        true => { let prod_local_322 = true; prod_local_322 },
    }; match prod_local_323 {
        false => { let prod_local_325 = Some(prod_local_312); { let prod_local_326 = round128(prod_local_325); match prod_local_326 {
        None => { let prod_local_327 = prod_local_326; match prod_local_327 {
        None => None,
        Some(prod_local_329) => { let prod_local_330 = prod_local_329; { let prod_local_331 = (prod_local_330).value; { let prod_local_332 = low64(prod_local_331); match prod_local_332 {
        None => prod_local_332,
        Some(prod_local_333) => { let prod_local_334 = (prod_local_330).guard; match prod_local_334 {
        false => prod_local_332,
        true => { let prod_local_336 = (prod_local_330).sticky; match prod_local_336 {
        false => { let prod_local_340 = 1; { let prod_local_341 = (prod_local_333 & prod_local_340); { let prod_local_342 = (prod_local_341 == prod_local_340); match prod_local_342 {
        false => prod_local_332,
        true => { let prod_local_344 = 1; { let prod_local_345 = (prod_local_333).checked_add(prod_local_344); prod_local_345 } },
    } } } },
        true => { let prod_local_347 = 1; { let prod_local_348 = (prod_local_333).checked_add(prod_local_347); prod_local_348 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_349) => { let prod_local_350 = prod_local_349; { let prod_local_351 = prod_local_350; { let prod_local_352 = (prod_local_351).value; { let prod_local_353 = low64(prod_local_352); match prod_local_353 {
        None => prod_local_353,
        Some(prod_local_354) => { let prod_local_355 = (prod_local_351).guard; match prod_local_355 {
        false => prod_local_353,
        true => { let prod_local_357 = (prod_local_351).sticky; match prod_local_357 {
        false => { let prod_local_361 = 1; { let prod_local_362 = (prod_local_354 & prod_local_361); { let prod_local_363 = (prod_local_362 == prod_local_361); match prod_local_363 {
        false => prod_local_353,
        true => { let prod_local_365 = 1; { let prod_local_366 = (prod_local_354).checked_add(prod_local_365); prod_local_366 } },
    } } } },
        true => { let prod_local_368 = 1; { let prod_local_369 = (prod_local_354).checked_add(prod_local_368); prod_local_369 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_370 = prod_local_312; { let prod_local_371 = prod_local_370; { let prod_local_372 = (prod_local_371).value; { let prod_local_373 = low64(prod_local_372); match prod_local_373 {
        None => prod_local_373,
        Some(prod_local_374) => { let prod_local_375 = (prod_local_371).guard; match prod_local_375 {
        false => prod_local_373,
        true => { let prod_local_377 = (prod_local_371).sticky; match prod_local_377 {
        false => { let prod_local_381 = 1; { let prod_local_382 = (prod_local_374 & prod_local_381); { let prod_local_383 = (prod_local_382 == prod_local_381); match prod_local_383 {
        false => prod_local_373,
        true => { let prod_local_385 = 1; { let prod_local_386 = (prod_local_374).checked_add(prod_local_385); prod_local_386 } },
    } } } },
        true => { let prod_local_388 = 1; { let prod_local_389 = (prod_local_374).checked_add(prod_local_388); prod_local_389 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_390 = prod_local_274; { let prod_local_394 = 128; { let prod_local_395 = (val_2857 & prod_local_394); { let prod_local_396 = 0; { let prod_local_397 = (prod_local_395 == prod_local_396); { let prod_local_401 = match prod_local_397 {
        false => { let prod_local_399 = false; prod_local_399 },
        true => { let prod_local_400 = true; prod_local_400 },
    }; match prod_local_401 {
        false => { let prod_local_403 = Some(prod_local_390); { let prod_local_404 = round128(prod_local_403); match prod_local_404 {
        None => { let prod_local_405 = prod_local_404; match prod_local_405 {
        None => None,
        Some(prod_local_407) => { let prod_local_408 = prod_local_407; { let prod_local_409 = (prod_local_408).value; { let prod_local_410 = low64(prod_local_409); match prod_local_410 {
        None => prod_local_410,
        Some(prod_local_411) => { let prod_local_412 = (prod_local_408).guard; match prod_local_412 {
        false => prod_local_410,
        true => { let prod_local_414 = (prod_local_408).sticky; match prod_local_414 {
        false => { let prod_local_418 = 1; { let prod_local_419 = (prod_local_411 & prod_local_418); { let prod_local_420 = (prod_local_419 == prod_local_418); match prod_local_420 {
        false => prod_local_410,
        true => { let prod_local_422 = 1; { let prod_local_423 = (prod_local_411).checked_add(prod_local_422); prod_local_423 } },
    } } } },
        true => { let prod_local_425 = 1; { let prod_local_426 = (prod_local_411).checked_add(prod_local_425); prod_local_426 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_427) => { let prod_local_428 = prod_local_427; { let prod_local_429 = prod_local_428; { let prod_local_430 = (prod_local_429).value; { let prod_local_431 = low64(prod_local_430); match prod_local_431 {
        None => prod_local_431,
        Some(prod_local_432) => { let prod_local_433 = (prod_local_429).guard; match prod_local_433 {
        false => prod_local_431,
        true => { let prod_local_435 = (prod_local_429).sticky; match prod_local_435 {
        false => { let prod_local_439 = 1; { let prod_local_440 = (prod_local_432 & prod_local_439); { let prod_local_441 = (prod_local_440 == prod_local_439); match prod_local_441 {
        false => prod_local_431,
        true => { let prod_local_443 = 1; { let prod_local_444 = (prod_local_432).checked_add(prod_local_443); prod_local_444 } },
    } } } },
        true => { let prod_local_446 = 1; { let prod_local_447 = (prod_local_432).checked_add(prod_local_446); prod_local_447 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_448 = prod_local_390; { let prod_local_449 = prod_local_448; { let prod_local_450 = (prod_local_449).value; { let prod_local_451 = low64(prod_local_450); match prod_local_451 {
        None => prod_local_451,
        Some(prod_local_452) => { let prod_local_453 = (prod_local_449).guard; match prod_local_453 {
        false => prod_local_451,
        true => { let prod_local_455 = (prod_local_449).sticky; match prod_local_455 {
        false => { let prod_local_459 = 1; { let prod_local_460 = (prod_local_452 & prod_local_459); { let prod_local_461 = (prod_local_460 == prod_local_459); match prod_local_461 {
        false => prod_local_451,
        true => { let prod_local_463 = 1; { let prod_local_464 = (prod_local_452).checked_add(prod_local_463); prod_local_464 } },
    } } } },
        true => { let prod_local_466 = 1; { let prod_local_467 = (prod_local_452).checked_add(prod_local_466); prod_local_467 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_468 = val_2969; { let prod_local_472 = 32; { let prod_local_473 = (val_2857 & prod_local_472); { let prod_local_474 = 0; { let prod_local_475 = (prod_local_473 == prod_local_474); { let prod_local_479 = match prod_local_475 {
        false => { let prod_local_477 = false; prod_local_477 },
        true => { let prod_local_478 = true; prod_local_478 },
    }; match prod_local_479 {
        false => { let prod_local_481 = Some(prod_local_468); { let prod_local_482 = round32(prod_local_481); match prod_local_482 {
        None => { let prod_local_483 = prod_local_482; match prod_local_483 {
        None => None,
        Some(prod_local_485) => { let prod_local_486 = prod_local_485; { let prod_local_487 = (prod_local_486).value; { let prod_local_488 = low64(prod_local_487); match prod_local_488 {
        None => prod_local_488,
        Some(prod_local_489) => { let prod_local_490 = (prod_local_486).guard; match prod_local_490 {
        false => prod_local_488,
        true => { let prod_local_492 = (prod_local_486).sticky; match prod_local_492 {
        false => { let prod_local_496 = 1; { let prod_local_497 = (prod_local_489 & prod_local_496); { let prod_local_498 = (prod_local_497 == prod_local_496); match prod_local_498 {
        false => prod_local_488,
        true => { let prod_local_500 = 1; { let prod_local_501 = (prod_local_489).checked_add(prod_local_500); prod_local_501 } },
    } } } },
        true => { let prod_local_503 = 1; { let prod_local_504 = (prod_local_489).checked_add(prod_local_503); prod_local_504 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_505) => { let prod_local_506 = prod_local_505; { let prod_local_510 = 64; { let prod_local_511 = (val_2857 & prod_local_510); { let prod_local_512 = 0; { let prod_local_513 = (prod_local_511 == prod_local_512); { let prod_local_517 = match prod_local_513 {
        false => { let prod_local_515 = false; prod_local_515 },
        true => { let prod_local_516 = true; prod_local_516 },
    }; match prod_local_517 {
        false => { let prod_local_519 = Some(prod_local_506); { let prod_local_520 = round64(prod_local_519); match prod_local_520 {
        None => { let prod_local_521 = prod_local_520; match prod_local_521 {
        None => None,
        Some(prod_local_523) => { let prod_local_524 = prod_local_523; { let prod_local_525 = (prod_local_524).value; { let prod_local_526 = low64(prod_local_525); match prod_local_526 {
        None => prod_local_526,
        Some(prod_local_527) => { let prod_local_528 = (prod_local_524).guard; match prod_local_528 {
        false => prod_local_526,
        true => { let prod_local_530 = (prod_local_524).sticky; match prod_local_530 {
        false => { let prod_local_534 = 1; { let prod_local_535 = (prod_local_527 & prod_local_534); { let prod_local_536 = (prod_local_535 == prod_local_534); match prod_local_536 {
        false => prod_local_526,
        true => { let prod_local_538 = 1; { let prod_local_539 = (prod_local_527).checked_add(prod_local_538); prod_local_539 } },
    } } } },
        true => { let prod_local_541 = 1; { let prod_local_542 = (prod_local_527).checked_add(prod_local_541); prod_local_542 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_543) => { let prod_local_544 = prod_local_543; { let prod_local_548 = 128; { let prod_local_549 = (val_2857 & prod_local_548); { let prod_local_550 = 0; { let prod_local_551 = (prod_local_549 == prod_local_550); { let prod_local_555 = match prod_local_551 {
        false => { let prod_local_553 = false; prod_local_553 },
        true => { let prod_local_554 = true; prod_local_554 },
    }; match prod_local_555 {
        false => { let prod_local_557 = Some(prod_local_544); { let prod_local_558 = round128(prod_local_557); match prod_local_558 {
        None => { let prod_local_559 = prod_local_558; match prod_local_559 {
        None => None,
        Some(prod_local_561) => { let prod_local_562 = prod_local_561; { let prod_local_563 = (prod_local_562).value; { let prod_local_564 = low64(prod_local_563); match prod_local_564 {
        None => prod_local_564,
        Some(prod_local_565) => { let prod_local_566 = (prod_local_562).guard; match prod_local_566 {
        false => prod_local_564,
        true => { let prod_local_568 = (prod_local_562).sticky; match prod_local_568 {
        false => { let prod_local_572 = 1; { let prod_local_573 = (prod_local_565 & prod_local_572); { let prod_local_574 = (prod_local_573 == prod_local_572); match prod_local_574 {
        false => prod_local_564,
        true => { let prod_local_576 = 1; { let prod_local_577 = (prod_local_565).checked_add(prod_local_576); prod_local_577 } },
    } } } },
        true => { let prod_local_579 = 1; { let prod_local_580 = (prod_local_565).checked_add(prod_local_579); prod_local_580 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_581) => { let prod_local_582 = prod_local_581; { let prod_local_583 = prod_local_582; { let prod_local_584 = (prod_local_583).value; { let prod_local_585 = low64(prod_local_584); match prod_local_585 {
        None => prod_local_585,
        Some(prod_local_586) => { let prod_local_587 = (prod_local_583).guard; match prod_local_587 {
        false => prod_local_585,
        true => { let prod_local_589 = (prod_local_583).sticky; match prod_local_589 {
        false => { let prod_local_593 = 1; { let prod_local_594 = (prod_local_586 & prod_local_593); { let prod_local_595 = (prod_local_594 == prod_local_593); match prod_local_595 {
        false => prod_local_585,
        true => { let prod_local_597 = 1; { let prod_local_598 = (prod_local_586).checked_add(prod_local_597); prod_local_598 } },
    } } } },
        true => { let prod_local_600 = 1; { let prod_local_601 = (prod_local_586).checked_add(prod_local_600); prod_local_601 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_602 = prod_local_544; { let prod_local_603 = prod_local_602; { let prod_local_604 = (prod_local_603).value; { let prod_local_605 = low64(prod_local_604); match prod_local_605 {
        None => prod_local_605,
        Some(prod_local_606) => { let prod_local_607 = (prod_local_603).guard; match prod_local_607 {
        false => prod_local_605,
        true => { let prod_local_609 = (prod_local_603).sticky; match prod_local_609 {
        false => { let prod_local_613 = 1; { let prod_local_614 = (prod_local_606 & prod_local_613); { let prod_local_615 = (prod_local_614 == prod_local_613); match prod_local_615 {
        false => prod_local_605,
        true => { let prod_local_617 = 1; { let prod_local_618 = (prod_local_606).checked_add(prod_local_617); prod_local_618 } },
    } } } },
        true => { let prod_local_620 = 1; { let prod_local_621 = (prod_local_606).checked_add(prod_local_620); prod_local_621 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_622 = prod_local_506; { let prod_local_626 = 128; { let prod_local_627 = (val_2857 & prod_local_626); { let prod_local_628 = 0; { let prod_local_629 = (prod_local_627 == prod_local_628); { let prod_local_633 = match prod_local_629 {
        false => { let prod_local_631 = false; prod_local_631 },
        true => { let prod_local_632 = true; prod_local_632 },
    }; match prod_local_633 {
        false => { let prod_local_635 = Some(prod_local_622); { let prod_local_636 = round128(prod_local_635); match prod_local_636 {
        None => { let prod_local_637 = prod_local_636; match prod_local_637 {
        None => None,
        Some(prod_local_639) => { let prod_local_640 = prod_local_639; { let prod_local_641 = (prod_local_640).value; { let prod_local_642 = low64(prod_local_641); match prod_local_642 {
        None => prod_local_642,
        Some(prod_local_643) => { let prod_local_644 = (prod_local_640).guard; match prod_local_644 {
        false => prod_local_642,
        true => { let prod_local_646 = (prod_local_640).sticky; match prod_local_646 {
        false => { let prod_local_650 = 1; { let prod_local_651 = (prod_local_643 & prod_local_650); { let prod_local_652 = (prod_local_651 == prod_local_650); match prod_local_652 {
        false => prod_local_642,
        true => { let prod_local_654 = 1; { let prod_local_655 = (prod_local_643).checked_add(prod_local_654); prod_local_655 } },
    } } } },
        true => { let prod_local_657 = 1; { let prod_local_658 = (prod_local_643).checked_add(prod_local_657); prod_local_658 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_659) => { let prod_local_660 = prod_local_659; { let prod_local_661 = prod_local_660; { let prod_local_662 = (prod_local_661).value; { let prod_local_663 = low64(prod_local_662); match prod_local_663 {
        None => prod_local_663,
        Some(prod_local_664) => { let prod_local_665 = (prod_local_661).guard; match prod_local_665 {
        false => prod_local_663,
        true => { let prod_local_667 = (prod_local_661).sticky; match prod_local_667 {
        false => { let prod_local_671 = 1; { let prod_local_672 = (prod_local_664 & prod_local_671); { let prod_local_673 = (prod_local_672 == prod_local_671); match prod_local_673 {
        false => prod_local_663,
        true => { let prod_local_675 = 1; { let prod_local_676 = (prod_local_664).checked_add(prod_local_675); prod_local_676 } },
    } } } },
        true => { let prod_local_678 = 1; { let prod_local_679 = (prod_local_664).checked_add(prod_local_678); prod_local_679 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_680 = prod_local_622; { let prod_local_681 = prod_local_680; { let prod_local_682 = (prod_local_681).value; { let prod_local_683 = low64(prod_local_682); match prod_local_683 {
        None => prod_local_683,
        Some(prod_local_684) => { let prod_local_685 = (prod_local_681).guard; match prod_local_685 {
        false => prod_local_683,
        true => { let prod_local_687 = (prod_local_681).sticky; match prod_local_687 {
        false => { let prod_local_691 = 1; { let prod_local_692 = (prod_local_684 & prod_local_691); { let prod_local_693 = (prod_local_692 == prod_local_691); match prod_local_693 {
        false => prod_local_683,
        true => { let prod_local_695 = 1; { let prod_local_696 = (prod_local_684).checked_add(prod_local_695); prod_local_696 } },
    } } } },
        true => { let prod_local_698 = 1; { let prod_local_699 = (prod_local_684).checked_add(prod_local_698); prod_local_699 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_700 = prod_local_468; { let prod_local_704 = 64; { let prod_local_705 = (val_2857 & prod_local_704); { let prod_local_706 = 0; { let prod_local_707 = (prod_local_705 == prod_local_706); { let prod_local_711 = match prod_local_707 {
        false => { let prod_local_709 = false; prod_local_709 },
        true => { let prod_local_710 = true; prod_local_710 },
    }; match prod_local_711 {
        false => { let prod_local_713 = Some(prod_local_700); { let prod_local_714 = round64(prod_local_713); match prod_local_714 {
        None => { let prod_local_715 = prod_local_714; match prod_local_715 {
        None => None,
        Some(prod_local_717) => { let prod_local_718 = prod_local_717; { let prod_local_719 = (prod_local_718).value; { let prod_local_720 = low64(prod_local_719); match prod_local_720 {
        None => prod_local_720,
        Some(prod_local_721) => { let prod_local_722 = (prod_local_718).guard; match prod_local_722 {
        false => prod_local_720,
        true => { let prod_local_724 = (prod_local_718).sticky; match prod_local_724 {
        false => { let prod_local_728 = 1; { let prod_local_729 = (prod_local_721 & prod_local_728); { let prod_local_730 = (prod_local_729 == prod_local_728); match prod_local_730 {
        false => prod_local_720,
        true => { let prod_local_732 = 1; { let prod_local_733 = (prod_local_721).checked_add(prod_local_732); prod_local_733 } },
    } } } },
        true => { let prod_local_735 = 1; { let prod_local_736 = (prod_local_721).checked_add(prod_local_735); prod_local_736 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_737) => { let prod_local_738 = prod_local_737; { let prod_local_742 = 128; { let prod_local_743 = (val_2857 & prod_local_742); { let prod_local_744 = 0; { let prod_local_745 = (prod_local_743 == prod_local_744); { let prod_local_749 = match prod_local_745 {
        false => { let prod_local_747 = false; prod_local_747 },
        true => { let prod_local_748 = true; prod_local_748 },
    }; match prod_local_749 {
        false => { let prod_local_751 = Some(prod_local_738); { let prod_local_752 = round128(prod_local_751); match prod_local_752 {
        None => { let prod_local_753 = prod_local_752; match prod_local_753 {
        None => None,
        Some(prod_local_755) => { let prod_local_756 = prod_local_755; { let prod_local_757 = (prod_local_756).value; { let prod_local_758 = low64(prod_local_757); match prod_local_758 {
        None => prod_local_758,
        Some(prod_local_759) => { let prod_local_760 = (prod_local_756).guard; match prod_local_760 {
        false => prod_local_758,
        true => { let prod_local_762 = (prod_local_756).sticky; match prod_local_762 {
        false => { let prod_local_766 = 1; { let prod_local_767 = (prod_local_759 & prod_local_766); { let prod_local_768 = (prod_local_767 == prod_local_766); match prod_local_768 {
        false => prod_local_758,
        true => { let prod_local_770 = 1; { let prod_local_771 = (prod_local_759).checked_add(prod_local_770); prod_local_771 } },
    } } } },
        true => { let prod_local_773 = 1; { let prod_local_774 = (prod_local_759).checked_add(prod_local_773); prod_local_774 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_775) => { let prod_local_776 = prod_local_775; { let prod_local_777 = prod_local_776; { let prod_local_778 = (prod_local_777).value; { let prod_local_779 = low64(prod_local_778); match prod_local_779 {
        None => prod_local_779,
        Some(prod_local_780) => { let prod_local_781 = (prod_local_777).guard; match prod_local_781 {
        false => prod_local_779,
        true => { let prod_local_783 = (prod_local_777).sticky; match prod_local_783 {
        false => { let prod_local_787 = 1; { let prod_local_788 = (prod_local_780 & prod_local_787); { let prod_local_789 = (prod_local_788 == prod_local_787); match prod_local_789 {
        false => prod_local_779,
        true => { let prod_local_791 = 1; { let prod_local_792 = (prod_local_780).checked_add(prod_local_791); prod_local_792 } },
    } } } },
        true => { let prod_local_794 = 1; { let prod_local_795 = (prod_local_780).checked_add(prod_local_794); prod_local_795 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_796 = prod_local_738; { let prod_local_797 = prod_local_796; { let prod_local_798 = (prod_local_797).value; { let prod_local_799 = low64(prod_local_798); match prod_local_799 {
        None => prod_local_799,
        Some(prod_local_800) => { let prod_local_801 = (prod_local_797).guard; match prod_local_801 {
        false => prod_local_799,
        true => { let prod_local_803 = (prod_local_797).sticky; match prod_local_803 {
        false => { let prod_local_807 = 1; { let prod_local_808 = (prod_local_800 & prod_local_807); { let prod_local_809 = (prod_local_808 == prod_local_807); match prod_local_809 {
        false => prod_local_799,
        true => { let prod_local_811 = 1; { let prod_local_812 = (prod_local_800).checked_add(prod_local_811); prod_local_812 } },
    } } } },
        true => { let prod_local_814 = 1; { let prod_local_815 = (prod_local_800).checked_add(prod_local_814); prod_local_815 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_816 = prod_local_700; { let prod_local_820 = 128; { let prod_local_821 = (val_2857 & prod_local_820); { let prod_local_822 = 0; { let prod_local_823 = (prod_local_821 == prod_local_822); { let prod_local_827 = match prod_local_823 {
        false => { let prod_local_825 = false; prod_local_825 },
        true => { let prod_local_826 = true; prod_local_826 },
    }; match prod_local_827 {
        false => { let prod_local_829 = Some(prod_local_816); { let prod_local_830 = round128(prod_local_829); match prod_local_830 {
        None => { let prod_local_831 = prod_local_830; match prod_local_831 {
        None => None,
        Some(prod_local_833) => { let prod_local_834 = prod_local_833; { let prod_local_835 = (prod_local_834).value; { let prod_local_836 = low64(prod_local_835); match prod_local_836 {
        None => prod_local_836,
        Some(prod_local_837) => { let prod_local_838 = (prod_local_834).guard; match prod_local_838 {
        false => prod_local_836,
        true => { let prod_local_840 = (prod_local_834).sticky; match prod_local_840 {
        false => { let prod_local_844 = 1; { let prod_local_845 = (prod_local_837 & prod_local_844); { let prod_local_846 = (prod_local_845 == prod_local_844); match prod_local_846 {
        false => prod_local_836,
        true => { let prod_local_848 = 1; { let prod_local_849 = (prod_local_837).checked_add(prod_local_848); prod_local_849 } },
    } } } },
        true => { let prod_local_851 = 1; { let prod_local_852 = (prod_local_837).checked_add(prod_local_851); prod_local_852 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_853) => { let prod_local_854 = prod_local_853; { let prod_local_855 = prod_local_854; { let prod_local_856 = (prod_local_855).value; { let prod_local_857 = low64(prod_local_856); match prod_local_857 {
        None => prod_local_857,
        Some(prod_local_858) => { let prod_local_859 = (prod_local_855).guard; match prod_local_859 {
        false => prod_local_857,
        true => { let prod_local_861 = (prod_local_855).sticky; match prod_local_861 {
        false => { let prod_local_865 = 1; { let prod_local_866 = (prod_local_858 & prod_local_865); { let prod_local_867 = (prod_local_866 == prod_local_865); match prod_local_867 {
        false => prod_local_857,
        true => { let prod_local_869 = 1; { let prod_local_870 = (prod_local_858).checked_add(prod_local_869); prod_local_870 } },
    } } } },
        true => { let prod_local_872 = 1; { let prod_local_873 = (prod_local_858).checked_add(prod_local_872); prod_local_873 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_874 = prod_local_816; { let prod_local_875 = prod_local_874; { let prod_local_876 = (prod_local_875).value; { let prod_local_877 = low64(prod_local_876); match prod_local_877 {
        None => prod_local_877,
        Some(prod_local_878) => { let prod_local_879 = (prod_local_875).guard; match prod_local_879 {
        false => prod_local_877,
        true => { let prod_local_881 = (prod_local_875).sticky; match prod_local_881 {
        false => { let prod_local_885 = 1; { let prod_local_886 = (prod_local_878 & prod_local_885); { let prod_local_887 = (prod_local_886 == prod_local_885); match prod_local_887 {
        false => prod_local_877,
        true => { let prod_local_889 = 1; { let prod_local_890 = (prod_local_878).checked_add(prod_local_889); prod_local_890 } },
    } } } },
        true => { let prod_local_892 = 1; { let prod_local_893 = (prod_local_878).checked_add(prod_local_892); prod_local_893 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } } } } } },
    } } } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_894 = val_2956; { let prod_local_898 = 16; { let prod_local_899 = (val_2857 & prod_local_898); { let prod_local_900 = 0; { let prod_local_901 = (prod_local_899 == prod_local_900); { let prod_local_905 = match prod_local_901 {
        false => { let prod_local_903 = false; prod_local_903 },
        true => { let prod_local_904 = true; prod_local_904 },
    }; match prod_local_905 {
        false => { let prod_local_907 = Some(prod_local_894); { let prod_local_908 = round16(prod_local_907); match prod_local_908 {
        None => { let prod_local_909 = prod_local_908; match prod_local_909 {
        None => None,
        Some(prod_local_911) => { let prod_local_912 = prod_local_911; { let prod_local_913 = (prod_local_912).value; { let prod_local_914 = low64(prod_local_913); match prod_local_914 {
        None => prod_local_914,
        Some(prod_local_915) => { let prod_local_916 = (prod_local_912).guard; match prod_local_916 {
        false => prod_local_914,
        true => { let prod_local_918 = (prod_local_912).sticky; match prod_local_918 {
        false => { let prod_local_922 = 1; { let prod_local_923 = (prod_local_915 & prod_local_922); { let prod_local_924 = (prod_local_923 == prod_local_922); match prod_local_924 {
        false => prod_local_914,
        true => { let prod_local_926 = 1; { let prod_local_927 = (prod_local_915).checked_add(prod_local_926); prod_local_927 } },
    } } } },
        true => { let prod_local_929 = 1; { let prod_local_930 = (prod_local_915).checked_add(prod_local_929); prod_local_930 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_931) => { let prod_local_932 = prod_local_931; { let prod_local_936 = 32; { let prod_local_937 = (val_2857 & prod_local_936); { let prod_local_938 = 0; { let prod_local_939 = (prod_local_937 == prod_local_938); { let prod_local_943 = match prod_local_939 {
        false => { let prod_local_941 = false; prod_local_941 },
        true => { let prod_local_942 = true; prod_local_942 },
    }; match prod_local_943 {
        false => { let prod_local_945 = Some(prod_local_932); { let prod_local_946 = round32(prod_local_945); match prod_local_946 {
        None => { let prod_local_947 = prod_local_946; match prod_local_947 {
        None => None,
        Some(prod_local_949) => { let prod_local_950 = prod_local_949; { let prod_local_951 = (prod_local_950).value; { let prod_local_952 = low64(prod_local_951); match prod_local_952 {
        None => prod_local_952,
        Some(prod_local_953) => { let prod_local_954 = (prod_local_950).guard; match prod_local_954 {
        false => prod_local_952,
        true => { let prod_local_956 = (prod_local_950).sticky; match prod_local_956 {
        false => { let prod_local_960 = 1; { let prod_local_961 = (prod_local_953 & prod_local_960); { let prod_local_962 = (prod_local_961 == prod_local_960); match prod_local_962 {
        false => prod_local_952,
        true => { let prod_local_964 = 1; { let prod_local_965 = (prod_local_953).checked_add(prod_local_964); prod_local_965 } },
    } } } },
        true => { let prod_local_967 = 1; { let prod_local_968 = (prod_local_953).checked_add(prod_local_967); prod_local_968 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_969) => { let prod_local_970 = prod_local_969; { let prod_local_974 = 64; { let prod_local_975 = (val_2857 & prod_local_974); { let prod_local_976 = 0; { let prod_local_977 = (prod_local_975 == prod_local_976); { let prod_local_981 = match prod_local_977 {
        false => { let prod_local_979 = false; prod_local_979 },
        true => { let prod_local_980 = true; prod_local_980 },
    }; match prod_local_981 {
        false => { let prod_local_983 = Some(prod_local_970); { let prod_local_984 = round64(prod_local_983); match prod_local_984 {
        None => { let prod_local_985 = prod_local_984; match prod_local_985 {
        None => None,
        Some(prod_local_987) => { let prod_local_988 = prod_local_987; { let prod_local_989 = (prod_local_988).value; { let prod_local_990 = low64(prod_local_989); match prod_local_990 {
        None => prod_local_990,
        Some(prod_local_991) => { let prod_local_992 = (prod_local_988).guard; match prod_local_992 {
        false => prod_local_990,
        true => { let prod_local_994 = (prod_local_988).sticky; match prod_local_994 {
        false => { let prod_local_998 = 1; { let prod_local_999 = (prod_local_991 & prod_local_998); { let prod_local_1000 = (prod_local_999 == prod_local_998); match prod_local_1000 {
        false => prod_local_990,
        true => { let prod_local_1002 = 1; { let prod_local_1003 = (prod_local_991).checked_add(prod_local_1002); prod_local_1003 } },
    } } } },
        true => { let prod_local_1005 = 1; { let prod_local_1006 = (prod_local_991).checked_add(prod_local_1005); prod_local_1006 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_1007) => { let prod_local_1008 = prod_local_1007; { let prod_local_1012 = 128; { let prod_local_1013 = (val_2857 & prod_local_1012); { let prod_local_1014 = 0; { let prod_local_1015 = (prod_local_1013 == prod_local_1014); { let prod_local_1019 = match prod_local_1015 {
        false => { let prod_local_1017 = false; prod_local_1017 },
        true => { let prod_local_1018 = true; prod_local_1018 },
    }; match prod_local_1019 {
        false => { let prod_local_1021 = Some(prod_local_1008); { let prod_local_1022 = round128(prod_local_1021); match prod_local_1022 {
        None => { let prod_local_1023 = prod_local_1022; match prod_local_1023 {
        None => None,
        Some(prod_local_1025) => { let prod_local_1026 = prod_local_1025; { let prod_local_1027 = (prod_local_1026).value; { let prod_local_1028 = low64(prod_local_1027); match prod_local_1028 {
        None => prod_local_1028,
        Some(prod_local_1029) => { let prod_local_1030 = (prod_local_1026).guard; match prod_local_1030 {
        false => prod_local_1028,
        true => { let prod_local_1032 = (prod_local_1026).sticky; match prod_local_1032 {
        false => { let prod_local_1036 = 1; { let prod_local_1037 = (prod_local_1029 & prod_local_1036); { let prod_local_1038 = (prod_local_1037 == prod_local_1036); match prod_local_1038 {
        false => prod_local_1028,
        true => { let prod_local_1040 = 1; { let prod_local_1041 = (prod_local_1029).checked_add(prod_local_1040); prod_local_1041 } },
    } } } },
        true => { let prod_local_1043 = 1; { let prod_local_1044 = (prod_local_1029).checked_add(prod_local_1043); prod_local_1044 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_1045) => { let prod_local_1046 = prod_local_1045; { let prod_local_1047 = prod_local_1046; { let prod_local_1048 = (prod_local_1047).value; { let prod_local_1049 = low64(prod_local_1048); match prod_local_1049 {
        None => prod_local_1049,
        Some(prod_local_1050) => { let prod_local_1051 = (prod_local_1047).guard; match prod_local_1051 {
        false => prod_local_1049,
        true => { let prod_local_1053 = (prod_local_1047).sticky; match prod_local_1053 {
        false => { let prod_local_1057 = 1; { let prod_local_1058 = (prod_local_1050 & prod_local_1057); { let prod_local_1059 = (prod_local_1058 == prod_local_1057); match prod_local_1059 {
        false => prod_local_1049,
        true => { let prod_local_1061 = 1; { let prod_local_1062 = (prod_local_1050).checked_add(prod_local_1061); prod_local_1062 } },
    } } } },
        true => { let prod_local_1064 = 1; { let prod_local_1065 = (prod_local_1050).checked_add(prod_local_1064); prod_local_1065 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_1066 = prod_local_1008; { let prod_local_1067 = prod_local_1066; { let prod_local_1068 = (prod_local_1067).value; { let prod_local_1069 = low64(prod_local_1068); match prod_local_1069 {
        None => prod_local_1069,
        Some(prod_local_1070) => { let prod_local_1071 = (prod_local_1067).guard; match prod_local_1071 {
        false => prod_local_1069,
        true => { let prod_local_1073 = (prod_local_1067).sticky; match prod_local_1073 {
        false => { let prod_local_1077 = 1; { let prod_local_1078 = (prod_local_1070 & prod_local_1077); { let prod_local_1079 = (prod_local_1078 == prod_local_1077); match prod_local_1079 {
        false => prod_local_1069,
        true => { let prod_local_1081 = 1; { let prod_local_1082 = (prod_local_1070).checked_add(prod_local_1081); prod_local_1082 } },
    } } } },
        true => { let prod_local_1084 = 1; { let prod_local_1085 = (prod_local_1070).checked_add(prod_local_1084); prod_local_1085 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_1086 = prod_local_970; { let prod_local_1090 = 128; { let prod_local_1091 = (val_2857 & prod_local_1090); { let prod_local_1092 = 0; { let prod_local_1093 = (prod_local_1091 == prod_local_1092); { let prod_local_1097 = match prod_local_1093 {
        false => { let prod_local_1095 = false; prod_local_1095 },
        true => { let prod_local_1096 = true; prod_local_1096 },
    }; match prod_local_1097 {
        false => { let prod_local_1099 = Some(prod_local_1086); { let prod_local_1100 = round128(prod_local_1099); match prod_local_1100 {
        None => { let prod_local_1101 = prod_local_1100; match prod_local_1101 {
        None => None,
        Some(prod_local_1103) => { let prod_local_1104 = prod_local_1103; { let prod_local_1105 = (prod_local_1104).value; { let prod_local_1106 = low64(prod_local_1105); match prod_local_1106 {
        None => prod_local_1106,
        Some(prod_local_1107) => { let prod_local_1108 = (prod_local_1104).guard; match prod_local_1108 {
        false => prod_local_1106,
        true => { let prod_local_1110 = (prod_local_1104).sticky; match prod_local_1110 {
        false => { let prod_local_1114 = 1; { let prod_local_1115 = (prod_local_1107 & prod_local_1114); { let prod_local_1116 = (prod_local_1115 == prod_local_1114); match prod_local_1116 {
        false => prod_local_1106,
        true => { let prod_local_1118 = 1; { let prod_local_1119 = (prod_local_1107).checked_add(prod_local_1118); prod_local_1119 } },
    } } } },
        true => { let prod_local_1121 = 1; { let prod_local_1122 = (prod_local_1107).checked_add(prod_local_1121); prod_local_1122 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_1123) => { let prod_local_1124 = prod_local_1123; { let prod_local_1125 = prod_local_1124; { let prod_local_1126 = (prod_local_1125).value; { let prod_local_1127 = low64(prod_local_1126); match prod_local_1127 {
        None => prod_local_1127,
        Some(prod_local_1128) => { let prod_local_1129 = (prod_local_1125).guard; match prod_local_1129 {
        false => prod_local_1127,
        true => { let prod_local_1131 = (prod_local_1125).sticky; match prod_local_1131 {
        false => { let prod_local_1135 = 1; { let prod_local_1136 = (prod_local_1128 & prod_local_1135); { let prod_local_1137 = (prod_local_1136 == prod_local_1135); match prod_local_1137 {
        false => prod_local_1127,
        true => { let prod_local_1139 = 1; { let prod_local_1140 = (prod_local_1128).checked_add(prod_local_1139); prod_local_1140 } },
    } } } },
        true => { let prod_local_1142 = 1; { let prod_local_1143 = (prod_local_1128).checked_add(prod_local_1142); prod_local_1143 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_1144 = prod_local_1086; { let prod_local_1145 = prod_local_1144; { let prod_local_1146 = (prod_local_1145).value; { let prod_local_1147 = low64(prod_local_1146); match prod_local_1147 {
        None => prod_local_1147,
        Some(prod_local_1148) => { let prod_local_1149 = (prod_local_1145).guard; match prod_local_1149 {
        false => prod_local_1147,
        true => { let prod_local_1151 = (prod_local_1145).sticky; match prod_local_1151 {
        false => { let prod_local_1155 = 1; { let prod_local_1156 = (prod_local_1148 & prod_local_1155); { let prod_local_1157 = (prod_local_1156 == prod_local_1155); match prod_local_1157 {
        false => prod_local_1147,
        true => { let prod_local_1159 = 1; { let prod_local_1160 = (prod_local_1148).checked_add(prod_local_1159); prod_local_1160 } },
    } } } },
        true => { let prod_local_1162 = 1; { let prod_local_1163 = (prod_local_1148).checked_add(prod_local_1162); prod_local_1163 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_1164 = prod_local_932; { let prod_local_1168 = 64; { let prod_local_1169 = (val_2857 & prod_local_1168); { let prod_local_1170 = 0; { let prod_local_1171 = (prod_local_1169 == prod_local_1170); { let prod_local_1175 = match prod_local_1171 {
        false => { let prod_local_1173 = false; prod_local_1173 },
        true => { let prod_local_1174 = true; prod_local_1174 },
    }; match prod_local_1175 {
        false => { let prod_local_1177 = Some(prod_local_1164); { let prod_local_1178 = round64(prod_local_1177); match prod_local_1178 {
        None => { let prod_local_1179 = prod_local_1178; match prod_local_1179 {
        None => None,
        Some(prod_local_1181) => { let prod_local_1182 = prod_local_1181; { let prod_local_1183 = (prod_local_1182).value; { let prod_local_1184 = low64(prod_local_1183); match prod_local_1184 {
        None => prod_local_1184,
        Some(prod_local_1185) => { let prod_local_1186 = (prod_local_1182).guard; match prod_local_1186 {
        false => prod_local_1184,
        true => { let prod_local_1188 = (prod_local_1182).sticky; match prod_local_1188 {
        false => { let prod_local_1192 = 1; { let prod_local_1193 = (prod_local_1185 & prod_local_1192); { let prod_local_1194 = (prod_local_1193 == prod_local_1192); match prod_local_1194 {
        false => prod_local_1184,
        true => { let prod_local_1196 = 1; { let prod_local_1197 = (prod_local_1185).checked_add(prod_local_1196); prod_local_1197 } },
    } } } },
        true => { let prod_local_1199 = 1; { let prod_local_1200 = (prod_local_1185).checked_add(prod_local_1199); prod_local_1200 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_1201) => { let prod_local_1202 = prod_local_1201; { let prod_local_1206 = 128; { let prod_local_1207 = (val_2857 & prod_local_1206); { let prod_local_1208 = 0; { let prod_local_1209 = (prod_local_1207 == prod_local_1208); { let prod_local_1213 = match prod_local_1209 {
        false => { let prod_local_1211 = false; prod_local_1211 },
        true => { let prod_local_1212 = true; prod_local_1212 },
    }; match prod_local_1213 {
        false => { let prod_local_1215 = Some(prod_local_1202); { let prod_local_1216 = round128(prod_local_1215); match prod_local_1216 {
        None => { let prod_local_1217 = prod_local_1216; match prod_local_1217 {
        None => None,
        Some(prod_local_1219) => { let prod_local_1220 = prod_local_1219; { let prod_local_1221 = (prod_local_1220).value; { let prod_local_1222 = low64(prod_local_1221); match prod_local_1222 {
        None => prod_local_1222,
        Some(prod_local_1223) => { let prod_local_1224 = (prod_local_1220).guard; match prod_local_1224 {
        false => prod_local_1222,
        true => { let prod_local_1226 = (prod_local_1220).sticky; match prod_local_1226 {
        false => { let prod_local_1230 = 1; { let prod_local_1231 = (prod_local_1223 & prod_local_1230); { let prod_local_1232 = (prod_local_1231 == prod_local_1230); match prod_local_1232 {
        false => prod_local_1222,
        true => { let prod_local_1234 = 1; { let prod_local_1235 = (prod_local_1223).checked_add(prod_local_1234); prod_local_1235 } },
    } } } },
        true => { let prod_local_1237 = 1; { let prod_local_1238 = (prod_local_1223).checked_add(prod_local_1237); prod_local_1238 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_1239) => { let prod_local_1240 = prod_local_1239; { let prod_local_1241 = prod_local_1240; { let prod_local_1242 = (prod_local_1241).value; { let prod_local_1243 = low64(prod_local_1242); match prod_local_1243 {
        None => prod_local_1243,
        Some(prod_local_1244) => { let prod_local_1245 = (prod_local_1241).guard; match prod_local_1245 {
        false => prod_local_1243,
        true => { let prod_local_1247 = (prod_local_1241).sticky; match prod_local_1247 {
        false => { let prod_local_1251 = 1; { let prod_local_1252 = (prod_local_1244 & prod_local_1251); { let prod_local_1253 = (prod_local_1252 == prod_local_1251); match prod_local_1253 {
        false => prod_local_1243,
        true => { let prod_local_1255 = 1; { let prod_local_1256 = (prod_local_1244).checked_add(prod_local_1255); prod_local_1256 } },
    } } } },
        true => { let prod_local_1258 = 1; { let prod_local_1259 = (prod_local_1244).checked_add(prod_local_1258); prod_local_1259 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_1260 = prod_local_1202; { let prod_local_1261 = prod_local_1260; { let prod_local_1262 = (prod_local_1261).value; { let prod_local_1263 = low64(prod_local_1262); match prod_local_1263 {
        None => prod_local_1263,
        Some(prod_local_1264) => { let prod_local_1265 = (prod_local_1261).guard; match prod_local_1265 {
        false => prod_local_1263,
        true => { let prod_local_1267 = (prod_local_1261).sticky; match prod_local_1267 {
        false => { let prod_local_1271 = 1; { let prod_local_1272 = (prod_local_1264 & prod_local_1271); { let prod_local_1273 = (prod_local_1272 == prod_local_1271); match prod_local_1273 {
        false => prod_local_1263,
        true => { let prod_local_1275 = 1; { let prod_local_1276 = (prod_local_1264).checked_add(prod_local_1275); prod_local_1276 } },
    } } } },
        true => { let prod_local_1278 = 1; { let prod_local_1279 = (prod_local_1264).checked_add(prod_local_1278); prod_local_1279 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_1280 = prod_local_1164; { let prod_local_1284 = 128; { let prod_local_1285 = (val_2857 & prod_local_1284); { let prod_local_1286 = 0; { let prod_local_1287 = (prod_local_1285 == prod_local_1286); { let prod_local_1291 = match prod_local_1287 {
        false => { let prod_local_1289 = false; prod_local_1289 },
        true => { let prod_local_1290 = true; prod_local_1290 },
    }; match prod_local_1291 {
        false => { let prod_local_1293 = Some(prod_local_1280); { let prod_local_1294 = round128(prod_local_1293); match prod_local_1294 {
        None => { let prod_local_1295 = prod_local_1294; match prod_local_1295 {
        None => None,
        Some(prod_local_1297) => { let prod_local_1298 = prod_local_1297; { let prod_local_1299 = (prod_local_1298).value; { let prod_local_1300 = low64(prod_local_1299); match prod_local_1300 {
        None => prod_local_1300,
        Some(prod_local_1301) => { let prod_local_1302 = (prod_local_1298).guard; match prod_local_1302 {
        false => prod_local_1300,
        true => { let prod_local_1304 = (prod_local_1298).sticky; match prod_local_1304 {
        false => { let prod_local_1308 = 1; { let prod_local_1309 = (prod_local_1301 & prod_local_1308); { let prod_local_1310 = (prod_local_1309 == prod_local_1308); match prod_local_1310 {
        false => prod_local_1300,
        true => { let prod_local_1312 = 1; { let prod_local_1313 = (prod_local_1301).checked_add(prod_local_1312); prod_local_1313 } },
    } } } },
        true => { let prod_local_1315 = 1; { let prod_local_1316 = (prod_local_1301).checked_add(prod_local_1315); prod_local_1316 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_1317) => { let prod_local_1318 = prod_local_1317; { let prod_local_1319 = prod_local_1318; { let prod_local_1320 = (prod_local_1319).value; { let prod_local_1321 = low64(prod_local_1320); match prod_local_1321 {
        None => prod_local_1321,
        Some(prod_local_1322) => { let prod_local_1323 = (prod_local_1319).guard; match prod_local_1323 {
        false => prod_local_1321,
        true => { let prod_local_1325 = (prod_local_1319).sticky; match prod_local_1325 {
        false => { let prod_local_1329 = 1; { let prod_local_1330 = (prod_local_1322 & prod_local_1329); { let prod_local_1331 = (prod_local_1330 == prod_local_1329); match prod_local_1331 {
        false => prod_local_1321,
        true => { let prod_local_1333 = 1; { let prod_local_1334 = (prod_local_1322).checked_add(prod_local_1333); prod_local_1334 } },
    } } } },
        true => { let prod_local_1336 = 1; { let prod_local_1337 = (prod_local_1322).checked_add(prod_local_1336); prod_local_1337 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_1338 = prod_local_1280; { let prod_local_1339 = prod_local_1338; { let prod_local_1340 = (prod_local_1339).value; { let prod_local_1341 = low64(prod_local_1340); match prod_local_1341 {
        None => prod_local_1341,
        Some(prod_local_1342) => { let prod_local_1343 = (prod_local_1339).guard; match prod_local_1343 {
        false => prod_local_1341,
        true => { let prod_local_1345 = (prod_local_1339).sticky; match prod_local_1345 {
        false => { let prod_local_1349 = 1; { let prod_local_1350 = (prod_local_1342 & prod_local_1349); { let prod_local_1351 = (prod_local_1350 == prod_local_1349); match prod_local_1351 {
        false => prod_local_1341,
        true => { let prod_local_1353 = 1; { let prod_local_1354 = (prod_local_1342).checked_add(prod_local_1353); prod_local_1354 } },
    } } } },
        true => { let prod_local_1356 = 1; { let prod_local_1357 = (prod_local_1342).checked_add(prod_local_1356); prod_local_1357 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_1358 = prod_local_894; { let prod_local_1362 = 32; { let prod_local_1363 = (val_2857 & prod_local_1362); { let prod_local_1364 = 0; { let prod_local_1365 = (prod_local_1363 == prod_local_1364); { let prod_local_1369 = match prod_local_1365 {
        false => { let prod_local_1367 = false; prod_local_1367 },
        true => { let prod_local_1368 = true; prod_local_1368 },
    }; match prod_local_1369 {
        false => { let prod_local_1371 = Some(prod_local_1358); { let prod_local_1372 = round32(prod_local_1371); match prod_local_1372 {
        None => { let prod_local_1373 = prod_local_1372; match prod_local_1373 {
        None => None,
        Some(prod_local_1375) => { let prod_local_1376 = prod_local_1375; { let prod_local_1377 = (prod_local_1376).value; { let prod_local_1378 = low64(prod_local_1377); match prod_local_1378 {
        None => prod_local_1378,
        Some(prod_local_1379) => { let prod_local_1380 = (prod_local_1376).guard; match prod_local_1380 {
        false => prod_local_1378,
        true => { let prod_local_1382 = (prod_local_1376).sticky; match prod_local_1382 {
        false => { let prod_local_1386 = 1; { let prod_local_1387 = (prod_local_1379 & prod_local_1386); { let prod_local_1388 = (prod_local_1387 == prod_local_1386); match prod_local_1388 {
        false => prod_local_1378,
        true => { let prod_local_1390 = 1; { let prod_local_1391 = (prod_local_1379).checked_add(prod_local_1390); prod_local_1391 } },
    } } } },
        true => { let prod_local_1393 = 1; { let prod_local_1394 = (prod_local_1379).checked_add(prod_local_1393); prod_local_1394 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_1395) => { let prod_local_1396 = prod_local_1395; { let prod_local_1400 = 64; { let prod_local_1401 = (val_2857 & prod_local_1400); { let prod_local_1402 = 0; { let prod_local_1403 = (prod_local_1401 == prod_local_1402); { let prod_local_1407 = match prod_local_1403 {
        false => { let prod_local_1405 = false; prod_local_1405 },
        true => { let prod_local_1406 = true; prod_local_1406 },
    }; match prod_local_1407 {
        false => { let prod_local_1409 = Some(prod_local_1396); { let prod_local_1410 = round64(prod_local_1409); match prod_local_1410 {
        None => { let prod_local_1411 = prod_local_1410; match prod_local_1411 {
        None => None,
        Some(prod_local_1413) => { let prod_local_1414 = prod_local_1413; { let prod_local_1415 = (prod_local_1414).value; { let prod_local_1416 = low64(prod_local_1415); match prod_local_1416 {
        None => prod_local_1416,
        Some(prod_local_1417) => { let prod_local_1418 = (prod_local_1414).guard; match prod_local_1418 {
        false => prod_local_1416,
        true => { let prod_local_1420 = (prod_local_1414).sticky; match prod_local_1420 {
        false => { let prod_local_1424 = 1; { let prod_local_1425 = (prod_local_1417 & prod_local_1424); { let prod_local_1426 = (prod_local_1425 == prod_local_1424); match prod_local_1426 {
        false => prod_local_1416,
        true => { let prod_local_1428 = 1; { let prod_local_1429 = (prod_local_1417).checked_add(prod_local_1428); prod_local_1429 } },
    } } } },
        true => { let prod_local_1431 = 1; { let prod_local_1432 = (prod_local_1417).checked_add(prod_local_1431); prod_local_1432 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_1433) => { let prod_local_1434 = prod_local_1433; { let prod_local_1438 = 128; { let prod_local_1439 = (val_2857 & prod_local_1438); { let prod_local_1440 = 0; { let prod_local_1441 = (prod_local_1439 == prod_local_1440); { let prod_local_1445 = match prod_local_1441 {
        false => { let prod_local_1443 = false; prod_local_1443 },
        true => { let prod_local_1444 = true; prod_local_1444 },
    }; match prod_local_1445 {
        false => { let prod_local_1447 = Some(prod_local_1434); { let prod_local_1448 = round128(prod_local_1447); match prod_local_1448 {
        None => { let prod_local_1449 = prod_local_1448; match prod_local_1449 {
        None => None,
        Some(prod_local_1451) => { let prod_local_1452 = prod_local_1451; { let prod_local_1453 = (prod_local_1452).value; { let prod_local_1454 = low64(prod_local_1453); match prod_local_1454 {
        None => prod_local_1454,
        Some(prod_local_1455) => { let prod_local_1456 = (prod_local_1452).guard; match prod_local_1456 {
        false => prod_local_1454,
        true => { let prod_local_1458 = (prod_local_1452).sticky; match prod_local_1458 {
        false => { let prod_local_1462 = 1; { let prod_local_1463 = (prod_local_1455 & prod_local_1462); { let prod_local_1464 = (prod_local_1463 == prod_local_1462); match prod_local_1464 {
        false => prod_local_1454,
        true => { let prod_local_1466 = 1; { let prod_local_1467 = (prod_local_1455).checked_add(prod_local_1466); prod_local_1467 } },
    } } } },
        true => { let prod_local_1469 = 1; { let prod_local_1470 = (prod_local_1455).checked_add(prod_local_1469); prod_local_1470 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_1471) => { let prod_local_1472 = prod_local_1471; { let prod_local_1473 = prod_local_1472; { let prod_local_1474 = (prod_local_1473).value; { let prod_local_1475 = low64(prod_local_1474); match prod_local_1475 {
        None => prod_local_1475,
        Some(prod_local_1476) => { let prod_local_1477 = (prod_local_1473).guard; match prod_local_1477 {
        false => prod_local_1475,
        true => { let prod_local_1479 = (prod_local_1473).sticky; match prod_local_1479 {
        false => { let prod_local_1483 = 1; { let prod_local_1484 = (prod_local_1476 & prod_local_1483); { let prod_local_1485 = (prod_local_1484 == prod_local_1483); match prod_local_1485 {
        false => prod_local_1475,
        true => { let prod_local_1487 = 1; { let prod_local_1488 = (prod_local_1476).checked_add(prod_local_1487); prod_local_1488 } },
    } } } },
        true => { let prod_local_1490 = 1; { let prod_local_1491 = (prod_local_1476).checked_add(prod_local_1490); prod_local_1491 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_1492 = prod_local_1434; { let prod_local_1493 = prod_local_1492; { let prod_local_1494 = (prod_local_1493).value; { let prod_local_1495 = low64(prod_local_1494); match prod_local_1495 {
        None => prod_local_1495,
        Some(prod_local_1496) => { let prod_local_1497 = (prod_local_1493).guard; match prod_local_1497 {
        false => prod_local_1495,
        true => { let prod_local_1499 = (prod_local_1493).sticky; match prod_local_1499 {
        false => { let prod_local_1503 = 1; { let prod_local_1504 = (prod_local_1496 & prod_local_1503); { let prod_local_1505 = (prod_local_1504 == prod_local_1503); match prod_local_1505 {
        false => prod_local_1495,
        true => { let prod_local_1507 = 1; { let prod_local_1508 = (prod_local_1496).checked_add(prod_local_1507); prod_local_1508 } },
    } } } },
        true => { let prod_local_1510 = 1; { let prod_local_1511 = (prod_local_1496).checked_add(prod_local_1510); prod_local_1511 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_1512 = prod_local_1396; { let prod_local_1516 = 128; { let prod_local_1517 = (val_2857 & prod_local_1516); { let prod_local_1518 = 0; { let prod_local_1519 = (prod_local_1517 == prod_local_1518); { let prod_local_1523 = match prod_local_1519 {
        false => { let prod_local_1521 = false; prod_local_1521 },
        true => { let prod_local_1522 = true; prod_local_1522 },
    }; match prod_local_1523 {
        false => { let prod_local_1525 = Some(prod_local_1512); { let prod_local_1526 = round128(prod_local_1525); match prod_local_1526 {
        None => { let prod_local_1527 = prod_local_1526; match prod_local_1527 {
        None => None,
        Some(prod_local_1529) => { let prod_local_1530 = prod_local_1529; { let prod_local_1531 = (prod_local_1530).value; { let prod_local_1532 = low64(prod_local_1531); match prod_local_1532 {
        None => prod_local_1532,
        Some(prod_local_1533) => { let prod_local_1534 = (prod_local_1530).guard; match prod_local_1534 {
        false => prod_local_1532,
        true => { let prod_local_1536 = (prod_local_1530).sticky; match prod_local_1536 {
        false => { let prod_local_1540 = 1; { let prod_local_1541 = (prod_local_1533 & prod_local_1540); { let prod_local_1542 = (prod_local_1541 == prod_local_1540); match prod_local_1542 {
        false => prod_local_1532,
        true => { let prod_local_1544 = 1; { let prod_local_1545 = (prod_local_1533).checked_add(prod_local_1544); prod_local_1545 } },
    } } } },
        true => { let prod_local_1547 = 1; { let prod_local_1548 = (prod_local_1533).checked_add(prod_local_1547); prod_local_1548 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_1549) => { let prod_local_1550 = prod_local_1549; { let prod_local_1551 = prod_local_1550; { let prod_local_1552 = (prod_local_1551).value; { let prod_local_1553 = low64(prod_local_1552); match prod_local_1553 {
        None => prod_local_1553,
        Some(prod_local_1554) => { let prod_local_1555 = (prod_local_1551).guard; match prod_local_1555 {
        false => prod_local_1553,
        true => { let prod_local_1557 = (prod_local_1551).sticky; match prod_local_1557 {
        false => { let prod_local_1561 = 1; { let prod_local_1562 = (prod_local_1554 & prod_local_1561); { let prod_local_1563 = (prod_local_1562 == prod_local_1561); match prod_local_1563 {
        false => prod_local_1553,
        true => { let prod_local_1565 = 1; { let prod_local_1566 = (prod_local_1554).checked_add(prod_local_1565); prod_local_1566 } },
    } } } },
        true => { let prod_local_1568 = 1; { let prod_local_1569 = (prod_local_1554).checked_add(prod_local_1568); prod_local_1569 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_1570 = prod_local_1512; { let prod_local_1571 = prod_local_1570; { let prod_local_1572 = (prod_local_1571).value; { let prod_local_1573 = low64(prod_local_1572); match prod_local_1573 {
        None => prod_local_1573,
        Some(prod_local_1574) => { let prod_local_1575 = (prod_local_1571).guard; match prod_local_1575 {
        false => prod_local_1573,
        true => { let prod_local_1577 = (prod_local_1571).sticky; match prod_local_1577 {
        false => { let prod_local_1581 = 1; { let prod_local_1582 = (prod_local_1574 & prod_local_1581); { let prod_local_1583 = (prod_local_1582 == prod_local_1581); match prod_local_1583 {
        false => prod_local_1573,
        true => { let prod_local_1585 = 1; { let prod_local_1586 = (prod_local_1574).checked_add(prod_local_1585); prod_local_1586 } },
    } } } },
        true => { let prod_local_1588 = 1; { let prod_local_1589 = (prod_local_1574).checked_add(prod_local_1588); prod_local_1589 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_1590 = prod_local_1358; { let prod_local_1594 = 64; { let prod_local_1595 = (val_2857 & prod_local_1594); { let prod_local_1596 = 0; { let prod_local_1597 = (prod_local_1595 == prod_local_1596); { let prod_local_1601 = match prod_local_1597 {
        false => { let prod_local_1599 = false; prod_local_1599 },
        true => { let prod_local_1600 = true; prod_local_1600 },
    }; match prod_local_1601 {
        false => { let prod_local_1603 = Some(prod_local_1590); { let prod_local_1604 = round64(prod_local_1603); match prod_local_1604 {
        None => { let prod_local_1605 = prod_local_1604; match prod_local_1605 {
        None => None,
        Some(prod_local_1607) => { let prod_local_1608 = prod_local_1607; { let prod_local_1609 = (prod_local_1608).value; { let prod_local_1610 = low64(prod_local_1609); match prod_local_1610 {
        None => prod_local_1610,
        Some(prod_local_1611) => { let prod_local_1612 = (prod_local_1608).guard; match prod_local_1612 {
        false => prod_local_1610,
        true => { let prod_local_1614 = (prod_local_1608).sticky; match prod_local_1614 {
        false => { let prod_local_1618 = 1; { let prod_local_1619 = (prod_local_1611 & prod_local_1618); { let prod_local_1620 = (prod_local_1619 == prod_local_1618); match prod_local_1620 {
        false => prod_local_1610,
        true => { let prod_local_1622 = 1; { let prod_local_1623 = (prod_local_1611).checked_add(prod_local_1622); prod_local_1623 } },
    } } } },
        true => { let prod_local_1625 = 1; { let prod_local_1626 = (prod_local_1611).checked_add(prod_local_1625); prod_local_1626 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_1627) => { let prod_local_1628 = prod_local_1627; { let prod_local_1632 = 128; { let prod_local_1633 = (val_2857 & prod_local_1632); { let prod_local_1634 = 0; { let prod_local_1635 = (prod_local_1633 == prod_local_1634); { let prod_local_1639 = match prod_local_1635 {
        false => { let prod_local_1637 = false; prod_local_1637 },
        true => { let prod_local_1638 = true; prod_local_1638 },
    }; match prod_local_1639 {
        false => { let prod_local_1641 = Some(prod_local_1628); { let prod_local_1642 = round128(prod_local_1641); match prod_local_1642 {
        None => { let prod_local_1643 = prod_local_1642; match prod_local_1643 {
        None => None,
        Some(prod_local_1645) => { let prod_local_1646 = prod_local_1645; { let prod_local_1647 = (prod_local_1646).value; { let prod_local_1648 = low64(prod_local_1647); match prod_local_1648 {
        None => prod_local_1648,
        Some(prod_local_1649) => { let prod_local_1650 = (prod_local_1646).guard; match prod_local_1650 {
        false => prod_local_1648,
        true => { let prod_local_1652 = (prod_local_1646).sticky; match prod_local_1652 {
        false => { let prod_local_1656 = 1; { let prod_local_1657 = (prod_local_1649 & prod_local_1656); { let prod_local_1658 = (prod_local_1657 == prod_local_1656); match prod_local_1658 {
        false => prod_local_1648,
        true => { let prod_local_1660 = 1; { let prod_local_1661 = (prod_local_1649).checked_add(prod_local_1660); prod_local_1661 } },
    } } } },
        true => { let prod_local_1663 = 1; { let prod_local_1664 = (prod_local_1649).checked_add(prod_local_1663); prod_local_1664 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_1665) => { let prod_local_1666 = prod_local_1665; { let prod_local_1667 = prod_local_1666; { let prod_local_1668 = (prod_local_1667).value; { let prod_local_1669 = low64(prod_local_1668); match prod_local_1669 {
        None => prod_local_1669,
        Some(prod_local_1670) => { let prod_local_1671 = (prod_local_1667).guard; match prod_local_1671 {
        false => prod_local_1669,
        true => { let prod_local_1673 = (prod_local_1667).sticky; match prod_local_1673 {
        false => { let prod_local_1677 = 1; { let prod_local_1678 = (prod_local_1670 & prod_local_1677); { let prod_local_1679 = (prod_local_1678 == prod_local_1677); match prod_local_1679 {
        false => prod_local_1669,
        true => { let prod_local_1681 = 1; { let prod_local_1682 = (prod_local_1670).checked_add(prod_local_1681); prod_local_1682 } },
    } } } },
        true => { let prod_local_1684 = 1; { let prod_local_1685 = (prod_local_1670).checked_add(prod_local_1684); prod_local_1685 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_1686 = prod_local_1628; { let prod_local_1687 = prod_local_1686; { let prod_local_1688 = (prod_local_1687).value; { let prod_local_1689 = low64(prod_local_1688); match prod_local_1689 {
        None => prod_local_1689,
        Some(prod_local_1690) => { let prod_local_1691 = (prod_local_1687).guard; match prod_local_1691 {
        false => prod_local_1689,
        true => { let prod_local_1693 = (prod_local_1687).sticky; match prod_local_1693 {
        false => { let prod_local_1697 = 1; { let prod_local_1698 = (prod_local_1690 & prod_local_1697); { let prod_local_1699 = (prod_local_1698 == prod_local_1697); match prod_local_1699 {
        false => prod_local_1689,
        true => { let prod_local_1701 = 1; { let prod_local_1702 = (prod_local_1690).checked_add(prod_local_1701); prod_local_1702 } },
    } } } },
        true => { let prod_local_1704 = 1; { let prod_local_1705 = (prod_local_1690).checked_add(prod_local_1704); prod_local_1705 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_1706 = prod_local_1590; { let prod_local_1710 = 128; { let prod_local_1711 = (val_2857 & prod_local_1710); { let prod_local_1712 = 0; { let prod_local_1713 = (prod_local_1711 == prod_local_1712); { let prod_local_1717 = match prod_local_1713 {
        false => { let prod_local_1715 = false; prod_local_1715 },
        true => { let prod_local_1716 = true; prod_local_1716 },
    }; match prod_local_1717 {
        false => { let prod_local_1719 = Some(prod_local_1706); { let prod_local_1720 = round128(prod_local_1719); match prod_local_1720 {
        None => { let prod_local_1721 = prod_local_1720; match prod_local_1721 {
        None => None,
        Some(prod_local_1723) => { let prod_local_1724 = prod_local_1723; { let prod_local_1725 = (prod_local_1724).value; { let prod_local_1726 = low64(prod_local_1725); match prod_local_1726 {
        None => prod_local_1726,
        Some(prod_local_1727) => { let prod_local_1728 = (prod_local_1724).guard; match prod_local_1728 {
        false => prod_local_1726,
        true => { let prod_local_1730 = (prod_local_1724).sticky; match prod_local_1730 {
        false => { let prod_local_1734 = 1; { let prod_local_1735 = (prod_local_1727 & prod_local_1734); { let prod_local_1736 = (prod_local_1735 == prod_local_1734); match prod_local_1736 {
        false => prod_local_1726,
        true => { let prod_local_1738 = 1; { let prod_local_1739 = (prod_local_1727).checked_add(prod_local_1738); prod_local_1739 } },
    } } } },
        true => { let prod_local_1741 = 1; { let prod_local_1742 = (prod_local_1727).checked_add(prod_local_1741); prod_local_1742 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_1743) => { let prod_local_1744 = prod_local_1743; { let prod_local_1745 = prod_local_1744; { let prod_local_1746 = (prod_local_1745).value; { let prod_local_1747 = low64(prod_local_1746); match prod_local_1747 {
        None => prod_local_1747,
        Some(prod_local_1748) => { let prod_local_1749 = (prod_local_1745).guard; match prod_local_1749 {
        false => prod_local_1747,
        true => { let prod_local_1751 = (prod_local_1745).sticky; match prod_local_1751 {
        false => { let prod_local_1755 = 1; { let prod_local_1756 = (prod_local_1748 & prod_local_1755); { let prod_local_1757 = (prod_local_1756 == prod_local_1755); match prod_local_1757 {
        false => prod_local_1747,
        true => { let prod_local_1759 = 1; { let prod_local_1760 = (prod_local_1748).checked_add(prod_local_1759); prod_local_1760 } },
    } } } },
        true => { let prod_local_1762 = 1; { let prod_local_1763 = (prod_local_1748).checked_add(prod_local_1762); prod_local_1763 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_1764 = prod_local_1706; { let prod_local_1765 = prod_local_1764; { let prod_local_1766 = (prod_local_1765).value; { let prod_local_1767 = low64(prod_local_1766); match prod_local_1767 {
        None => prod_local_1767,
        Some(prod_local_1768) => { let prod_local_1769 = (prod_local_1765).guard; match prod_local_1769 {
        false => prod_local_1767,
        true => { let prod_local_1771 = (prod_local_1765).sticky; match prod_local_1771 {
        false => { let prod_local_1775 = 1; { let prod_local_1776 = (prod_local_1768 & prod_local_1775); { let prod_local_1777 = (prod_local_1776 == prod_local_1775); match prod_local_1777 {
        false => prod_local_1767,
        true => { let prod_local_1779 = 1; { let prod_local_1780 = (prod_local_1768).checked_add(prod_local_1779); prod_local_1780 } },
    } } } },
        true => { let prod_local_1782 = 1; { let prod_local_1783 = (prod_local_1768).checked_add(prod_local_1782); prod_local_1783 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } } } } } },
    } } } } } } },
    } } } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_1784 = val_2943; { let prod_local_1788 = 8; { let prod_local_1789 = (val_2857 & prod_local_1788); { let prod_local_1790 = 0; { let prod_local_1791 = (prod_local_1789 == prod_local_1790); { let prod_local_1795 = match prod_local_1791 {
        false => { let prod_local_1793 = false; prod_local_1793 },
        true => { let prod_local_1794 = true; prod_local_1794 },
    }; match prod_local_1795 {
        false => { let prod_local_1797 = Some(prod_local_1784); { let prod_local_1798 = round8(prod_local_1797); match prod_local_1798 {
        None => { let prod_local_1799 = prod_local_1798; match prod_local_1799 {
        None => None,
        Some(prod_local_1801) => { let prod_local_1802 = prod_local_1801; { let prod_local_1803 = (prod_local_1802).value; { let prod_local_1804 = low64(prod_local_1803); match prod_local_1804 {
        None => prod_local_1804,
        Some(prod_local_1805) => { let prod_local_1806 = (prod_local_1802).guard; match prod_local_1806 {
        false => prod_local_1804,
        true => { let prod_local_1808 = (prod_local_1802).sticky; match prod_local_1808 {
        false => { let prod_local_1812 = 1; { let prod_local_1813 = (prod_local_1805 & prod_local_1812); { let prod_local_1814 = (prod_local_1813 == prod_local_1812); match prod_local_1814 {
        false => prod_local_1804,
        true => { let prod_local_1816 = 1; { let prod_local_1817 = (prod_local_1805).checked_add(prod_local_1816); prod_local_1817 } },
    } } } },
        true => { let prod_local_1819 = 1; { let prod_local_1820 = (prod_local_1805).checked_add(prod_local_1819); prod_local_1820 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_1821) => { let prod_local_1822 = prod_local_1821; { let prod_local_1826 = 16; { let prod_local_1827 = (val_2857 & prod_local_1826); { let prod_local_1828 = 0; { let prod_local_1829 = (prod_local_1827 == prod_local_1828); { let prod_local_1833 = match prod_local_1829 {
        false => { let prod_local_1831 = false; prod_local_1831 },
        true => { let prod_local_1832 = true; prod_local_1832 },
    }; match prod_local_1833 {
        false => { let prod_local_1835 = Some(prod_local_1822); { let prod_local_1836 = round16(prod_local_1835); match prod_local_1836 {
        None => { let prod_local_1837 = prod_local_1836; match prod_local_1837 {
        None => None,
        Some(prod_local_1839) => { let prod_local_1840 = prod_local_1839; { let prod_local_1841 = (prod_local_1840).value; { let prod_local_1842 = low64(prod_local_1841); match prod_local_1842 {
        None => prod_local_1842,
        Some(prod_local_1843) => { let prod_local_1844 = (prod_local_1840).guard; match prod_local_1844 {
        false => prod_local_1842,
        true => { let prod_local_1846 = (prod_local_1840).sticky; match prod_local_1846 {
        false => { let prod_local_1850 = 1; { let prod_local_1851 = (prod_local_1843 & prod_local_1850); { let prod_local_1852 = (prod_local_1851 == prod_local_1850); match prod_local_1852 {
        false => prod_local_1842,
        true => { let prod_local_1854 = 1; { let prod_local_1855 = (prod_local_1843).checked_add(prod_local_1854); prod_local_1855 } },
    } } } },
        true => { let prod_local_1857 = 1; { let prod_local_1858 = (prod_local_1843).checked_add(prod_local_1857); prod_local_1858 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_1859) => { let prod_local_1860 = prod_local_1859; { let prod_local_1864 = 32; { let prod_local_1865 = (val_2857 & prod_local_1864); { let prod_local_1866 = 0; { let prod_local_1867 = (prod_local_1865 == prod_local_1866); { let prod_local_1871 = match prod_local_1867 {
        false => { let prod_local_1869 = false; prod_local_1869 },
        true => { let prod_local_1870 = true; prod_local_1870 },
    }; match prod_local_1871 {
        false => { let prod_local_1873 = Some(prod_local_1860); { let prod_local_1874 = round32(prod_local_1873); match prod_local_1874 {
        None => { let prod_local_1875 = prod_local_1874; match prod_local_1875 {
        None => None,
        Some(prod_local_1877) => { let prod_local_1878 = prod_local_1877; { let prod_local_1879 = (prod_local_1878).value; { let prod_local_1880 = low64(prod_local_1879); match prod_local_1880 {
        None => prod_local_1880,
        Some(prod_local_1881) => { let prod_local_1882 = (prod_local_1878).guard; match prod_local_1882 {
        false => prod_local_1880,
        true => { let prod_local_1884 = (prod_local_1878).sticky; match prod_local_1884 {
        false => { let prod_local_1888 = 1; { let prod_local_1889 = (prod_local_1881 & prod_local_1888); { let prod_local_1890 = (prod_local_1889 == prod_local_1888); match prod_local_1890 {
        false => prod_local_1880,
        true => { let prod_local_1892 = 1; { let prod_local_1893 = (prod_local_1881).checked_add(prod_local_1892); prod_local_1893 } },
    } } } },
        true => { let prod_local_1895 = 1; { let prod_local_1896 = (prod_local_1881).checked_add(prod_local_1895); prod_local_1896 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_1897) => { let prod_local_1898 = prod_local_1897; { let prod_local_1902 = 64; { let prod_local_1903 = (val_2857 & prod_local_1902); { let prod_local_1904 = 0; { let prod_local_1905 = (prod_local_1903 == prod_local_1904); { let prod_local_1909 = match prod_local_1905 {
        false => { let prod_local_1907 = false; prod_local_1907 },
        true => { let prod_local_1908 = true; prod_local_1908 },
    }; match prod_local_1909 {
        false => { let prod_local_1911 = Some(prod_local_1898); { let prod_local_1912 = round64(prod_local_1911); match prod_local_1912 {
        None => { let prod_local_1913 = prod_local_1912; match prod_local_1913 {
        None => None,
        Some(prod_local_1915) => { let prod_local_1916 = prod_local_1915; { let prod_local_1917 = (prod_local_1916).value; { let prod_local_1918 = low64(prod_local_1917); match prod_local_1918 {
        None => prod_local_1918,
        Some(prod_local_1919) => { let prod_local_1920 = (prod_local_1916).guard; match prod_local_1920 {
        false => prod_local_1918,
        true => { let prod_local_1922 = (prod_local_1916).sticky; match prod_local_1922 {
        false => { let prod_local_1926 = 1; { let prod_local_1927 = (prod_local_1919 & prod_local_1926); { let prod_local_1928 = (prod_local_1927 == prod_local_1926); match prod_local_1928 {
        false => prod_local_1918,
        true => { let prod_local_1930 = 1; { let prod_local_1931 = (prod_local_1919).checked_add(prod_local_1930); prod_local_1931 } },
    } } } },
        true => { let prod_local_1933 = 1; { let prod_local_1934 = (prod_local_1919).checked_add(prod_local_1933); prod_local_1934 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_1935) => { let prod_local_1936 = prod_local_1935; { let prod_local_1940 = 128; { let prod_local_1941 = (val_2857 & prod_local_1940); { let prod_local_1942 = 0; { let prod_local_1943 = (prod_local_1941 == prod_local_1942); { let prod_local_1947 = match prod_local_1943 {
        false => { let prod_local_1945 = false; prod_local_1945 },
        true => { let prod_local_1946 = true; prod_local_1946 },
    }; match prod_local_1947 {
        false => { let prod_local_1949 = Some(prod_local_1936); { let prod_local_1950 = round128(prod_local_1949); match prod_local_1950 {
        None => { let prod_local_1951 = prod_local_1950; match prod_local_1951 {
        None => None,
        Some(prod_local_1953) => { let prod_local_1954 = prod_local_1953; { let prod_local_1955 = (prod_local_1954).value; { let prod_local_1956 = low64(prod_local_1955); match prod_local_1956 {
        None => prod_local_1956,
        Some(prod_local_1957) => { let prod_local_1958 = (prod_local_1954).guard; match prod_local_1958 {
        false => prod_local_1956,
        true => { let prod_local_1960 = (prod_local_1954).sticky; match prod_local_1960 {
        false => { let prod_local_1964 = 1; { let prod_local_1965 = (prod_local_1957 & prod_local_1964); { let prod_local_1966 = (prod_local_1965 == prod_local_1964); match prod_local_1966 {
        false => prod_local_1956,
        true => { let prod_local_1968 = 1; { let prod_local_1969 = (prod_local_1957).checked_add(prod_local_1968); prod_local_1969 } },
    } } } },
        true => { let prod_local_1971 = 1; { let prod_local_1972 = (prod_local_1957).checked_add(prod_local_1971); prod_local_1972 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_1973) => { let prod_local_1974 = prod_local_1973; { let prod_local_1975 = prod_local_1974; { let prod_local_1976 = (prod_local_1975).value; { let prod_local_1977 = low64(prod_local_1976); match prod_local_1977 {
        None => prod_local_1977,
        Some(prod_local_1978) => { let prod_local_1979 = (prod_local_1975).guard; match prod_local_1979 {
        false => prod_local_1977,
        true => { let prod_local_1981 = (prod_local_1975).sticky; match prod_local_1981 {
        false => { let prod_local_1985 = 1; { let prod_local_1986 = (prod_local_1978 & prod_local_1985); { let prod_local_1987 = (prod_local_1986 == prod_local_1985); match prod_local_1987 {
        false => prod_local_1977,
        true => { let prod_local_1989 = 1; { let prod_local_1990 = (prod_local_1978).checked_add(prod_local_1989); prod_local_1990 } },
    } } } },
        true => { let prod_local_1992 = 1; { let prod_local_1993 = (prod_local_1978).checked_add(prod_local_1992); prod_local_1993 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_1994 = prod_local_1936; { let prod_local_1995 = prod_local_1994; { let prod_local_1996 = (prod_local_1995).value; { let prod_local_1997 = low64(prod_local_1996); match prod_local_1997 {
        None => prod_local_1997,
        Some(prod_local_1998) => { let prod_local_1999 = (prod_local_1995).guard; match prod_local_1999 {
        false => prod_local_1997,
        true => { let prod_local_2001 = (prod_local_1995).sticky; match prod_local_2001 {
        false => { let prod_local_2005 = 1; { let prod_local_2006 = (prod_local_1998 & prod_local_2005); { let prod_local_2007 = (prod_local_2006 == prod_local_2005); match prod_local_2007 {
        false => prod_local_1997,
        true => { let prod_local_2009 = 1; { let prod_local_2010 = (prod_local_1998).checked_add(prod_local_2009); prod_local_2010 } },
    } } } },
        true => { let prod_local_2012 = 1; { let prod_local_2013 = (prod_local_1998).checked_add(prod_local_2012); prod_local_2013 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_2014 = prod_local_1898; { let prod_local_2018 = 128; { let prod_local_2019 = (val_2857 & prod_local_2018); { let prod_local_2020 = 0; { let prod_local_2021 = (prod_local_2019 == prod_local_2020); { let prod_local_2025 = match prod_local_2021 {
        false => { let prod_local_2023 = false; prod_local_2023 },
        true => { let prod_local_2024 = true; prod_local_2024 },
    }; match prod_local_2025 {
        false => { let prod_local_2027 = Some(prod_local_2014); { let prod_local_2028 = round128(prod_local_2027); match prod_local_2028 {
        None => { let prod_local_2029 = prod_local_2028; match prod_local_2029 {
        None => None,
        Some(prod_local_2031) => { let prod_local_2032 = prod_local_2031; { let prod_local_2033 = (prod_local_2032).value; { let prod_local_2034 = low64(prod_local_2033); match prod_local_2034 {
        None => prod_local_2034,
        Some(prod_local_2035) => { let prod_local_2036 = (prod_local_2032).guard; match prod_local_2036 {
        false => prod_local_2034,
        true => { let prod_local_2038 = (prod_local_2032).sticky; match prod_local_2038 {
        false => { let prod_local_2042 = 1; { let prod_local_2043 = (prod_local_2035 & prod_local_2042); { let prod_local_2044 = (prod_local_2043 == prod_local_2042); match prod_local_2044 {
        false => prod_local_2034,
        true => { let prod_local_2046 = 1; { let prod_local_2047 = (prod_local_2035).checked_add(prod_local_2046); prod_local_2047 } },
    } } } },
        true => { let prod_local_2049 = 1; { let prod_local_2050 = (prod_local_2035).checked_add(prod_local_2049); prod_local_2050 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_2051) => { let prod_local_2052 = prod_local_2051; { let prod_local_2053 = prod_local_2052; { let prod_local_2054 = (prod_local_2053).value; { let prod_local_2055 = low64(prod_local_2054); match prod_local_2055 {
        None => prod_local_2055,
        Some(prod_local_2056) => { let prod_local_2057 = (prod_local_2053).guard; match prod_local_2057 {
        false => prod_local_2055,
        true => { let prod_local_2059 = (prod_local_2053).sticky; match prod_local_2059 {
        false => { let prod_local_2063 = 1; { let prod_local_2064 = (prod_local_2056 & prod_local_2063); { let prod_local_2065 = (prod_local_2064 == prod_local_2063); match prod_local_2065 {
        false => prod_local_2055,
        true => { let prod_local_2067 = 1; { let prod_local_2068 = (prod_local_2056).checked_add(prod_local_2067); prod_local_2068 } },
    } } } },
        true => { let prod_local_2070 = 1; { let prod_local_2071 = (prod_local_2056).checked_add(prod_local_2070); prod_local_2071 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_2072 = prod_local_2014; { let prod_local_2073 = prod_local_2072; { let prod_local_2074 = (prod_local_2073).value; { let prod_local_2075 = low64(prod_local_2074); match prod_local_2075 {
        None => prod_local_2075,
        Some(prod_local_2076) => { let prod_local_2077 = (prod_local_2073).guard; match prod_local_2077 {
        false => prod_local_2075,
        true => { let prod_local_2079 = (prod_local_2073).sticky; match prod_local_2079 {
        false => { let prod_local_2083 = 1; { let prod_local_2084 = (prod_local_2076 & prod_local_2083); { let prod_local_2085 = (prod_local_2084 == prod_local_2083); match prod_local_2085 {
        false => prod_local_2075,
        true => { let prod_local_2087 = 1; { let prod_local_2088 = (prod_local_2076).checked_add(prod_local_2087); prod_local_2088 } },
    } } } },
        true => { let prod_local_2090 = 1; { let prod_local_2091 = (prod_local_2076).checked_add(prod_local_2090); prod_local_2091 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_2092 = prod_local_1860; { let prod_local_2096 = 64; { let prod_local_2097 = (val_2857 & prod_local_2096); { let prod_local_2098 = 0; { let prod_local_2099 = (prod_local_2097 == prod_local_2098); { let prod_local_2103 = match prod_local_2099 {
        false => { let prod_local_2101 = false; prod_local_2101 },
        true => { let prod_local_2102 = true; prod_local_2102 },
    }; match prod_local_2103 {
        false => { let prod_local_2105 = Some(prod_local_2092); { let prod_local_2106 = round64(prod_local_2105); match prod_local_2106 {
        None => { let prod_local_2107 = prod_local_2106; match prod_local_2107 {
        None => None,
        Some(prod_local_2109) => { let prod_local_2110 = prod_local_2109; { let prod_local_2111 = (prod_local_2110).value; { let prod_local_2112 = low64(prod_local_2111); match prod_local_2112 {
        None => prod_local_2112,
        Some(prod_local_2113) => { let prod_local_2114 = (prod_local_2110).guard; match prod_local_2114 {
        false => prod_local_2112,
        true => { let prod_local_2116 = (prod_local_2110).sticky; match prod_local_2116 {
        false => { let prod_local_2120 = 1; { let prod_local_2121 = (prod_local_2113 & prod_local_2120); { let prod_local_2122 = (prod_local_2121 == prod_local_2120); match prod_local_2122 {
        false => prod_local_2112,
        true => { let prod_local_2124 = 1; { let prod_local_2125 = (prod_local_2113).checked_add(prod_local_2124); prod_local_2125 } },
    } } } },
        true => { let prod_local_2127 = 1; { let prod_local_2128 = (prod_local_2113).checked_add(prod_local_2127); prod_local_2128 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_2129) => { let prod_local_2130 = prod_local_2129; { let prod_local_2134 = 128; { let prod_local_2135 = (val_2857 & prod_local_2134); { let prod_local_2136 = 0; { let prod_local_2137 = (prod_local_2135 == prod_local_2136); { let prod_local_2141 = match prod_local_2137 {
        false => { let prod_local_2139 = false; prod_local_2139 },
        true => { let prod_local_2140 = true; prod_local_2140 },
    }; match prod_local_2141 {
        false => { let prod_local_2143 = Some(prod_local_2130); { let prod_local_2144 = round128(prod_local_2143); match prod_local_2144 {
        None => { let prod_local_2145 = prod_local_2144; match prod_local_2145 {
        None => None,
        Some(prod_local_2147) => { let prod_local_2148 = prod_local_2147; { let prod_local_2149 = (prod_local_2148).value; { let prod_local_2150 = low64(prod_local_2149); match prod_local_2150 {
        None => prod_local_2150,
        Some(prod_local_2151) => { let prod_local_2152 = (prod_local_2148).guard; match prod_local_2152 {
        false => prod_local_2150,
        true => { let prod_local_2154 = (prod_local_2148).sticky; match prod_local_2154 {
        false => { let prod_local_2158 = 1; { let prod_local_2159 = (prod_local_2151 & prod_local_2158); { let prod_local_2160 = (prod_local_2159 == prod_local_2158); match prod_local_2160 {
        false => prod_local_2150,
        true => { let prod_local_2162 = 1; { let prod_local_2163 = (prod_local_2151).checked_add(prod_local_2162); prod_local_2163 } },
    } } } },
        true => { let prod_local_2165 = 1; { let prod_local_2166 = (prod_local_2151).checked_add(prod_local_2165); prod_local_2166 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_2167) => { let prod_local_2168 = prod_local_2167; { let prod_local_2169 = prod_local_2168; { let prod_local_2170 = (prod_local_2169).value; { let prod_local_2171 = low64(prod_local_2170); match prod_local_2171 {
        None => prod_local_2171,
        Some(prod_local_2172) => { let prod_local_2173 = (prod_local_2169).guard; match prod_local_2173 {
        false => prod_local_2171,
        true => { let prod_local_2175 = (prod_local_2169).sticky; match prod_local_2175 {
        false => { let prod_local_2179 = 1; { let prod_local_2180 = (prod_local_2172 & prod_local_2179); { let prod_local_2181 = (prod_local_2180 == prod_local_2179); match prod_local_2181 {
        false => prod_local_2171,
        true => { let prod_local_2183 = 1; { let prod_local_2184 = (prod_local_2172).checked_add(prod_local_2183); prod_local_2184 } },
    } } } },
        true => { let prod_local_2186 = 1; { let prod_local_2187 = (prod_local_2172).checked_add(prod_local_2186); prod_local_2187 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_2188 = prod_local_2130; { let prod_local_2189 = prod_local_2188; { let prod_local_2190 = (prod_local_2189).value; { let prod_local_2191 = low64(prod_local_2190); match prod_local_2191 {
        None => prod_local_2191,
        Some(prod_local_2192) => { let prod_local_2193 = (prod_local_2189).guard; match prod_local_2193 {
        false => prod_local_2191,
        true => { let prod_local_2195 = (prod_local_2189).sticky; match prod_local_2195 {
        false => { let prod_local_2199 = 1; { let prod_local_2200 = (prod_local_2192 & prod_local_2199); { let prod_local_2201 = (prod_local_2200 == prod_local_2199); match prod_local_2201 {
        false => prod_local_2191,
        true => { let prod_local_2203 = 1; { let prod_local_2204 = (prod_local_2192).checked_add(prod_local_2203); prod_local_2204 } },
    } } } },
        true => { let prod_local_2206 = 1; { let prod_local_2207 = (prod_local_2192).checked_add(prod_local_2206); prod_local_2207 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_2208 = prod_local_2092; { let prod_local_2212 = 128; { let prod_local_2213 = (val_2857 & prod_local_2212); { let prod_local_2214 = 0; { let prod_local_2215 = (prod_local_2213 == prod_local_2214); { let prod_local_2219 = match prod_local_2215 {
        false => { let prod_local_2217 = false; prod_local_2217 },
        true => { let prod_local_2218 = true; prod_local_2218 },
    }; match prod_local_2219 {
        false => { let prod_local_2221 = Some(prod_local_2208); { let prod_local_2222 = round128(prod_local_2221); match prod_local_2222 {
        None => { let prod_local_2223 = prod_local_2222; match prod_local_2223 {
        None => None,
        Some(prod_local_2225) => { let prod_local_2226 = prod_local_2225; { let prod_local_2227 = (prod_local_2226).value; { let prod_local_2228 = low64(prod_local_2227); match prod_local_2228 {
        None => prod_local_2228,
        Some(prod_local_2229) => { let prod_local_2230 = (prod_local_2226).guard; match prod_local_2230 {
        false => prod_local_2228,
        true => { let prod_local_2232 = (prod_local_2226).sticky; match prod_local_2232 {
        false => { let prod_local_2236 = 1; { let prod_local_2237 = (prod_local_2229 & prod_local_2236); { let prod_local_2238 = (prod_local_2237 == prod_local_2236); match prod_local_2238 {
        false => prod_local_2228,
        true => { let prod_local_2240 = 1; { let prod_local_2241 = (prod_local_2229).checked_add(prod_local_2240); prod_local_2241 } },
    } } } },
        true => { let prod_local_2243 = 1; { let prod_local_2244 = (prod_local_2229).checked_add(prod_local_2243); prod_local_2244 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_2245) => { let prod_local_2246 = prod_local_2245; { let prod_local_2247 = prod_local_2246; { let prod_local_2248 = (prod_local_2247).value; { let prod_local_2249 = low64(prod_local_2248); match prod_local_2249 {
        None => prod_local_2249,
        Some(prod_local_2250) => { let prod_local_2251 = (prod_local_2247).guard; match prod_local_2251 {
        false => prod_local_2249,
        true => { let prod_local_2253 = (prod_local_2247).sticky; match prod_local_2253 {
        false => { let prod_local_2257 = 1; { let prod_local_2258 = (prod_local_2250 & prod_local_2257); { let prod_local_2259 = (prod_local_2258 == prod_local_2257); match prod_local_2259 {
        false => prod_local_2249,
        true => { let prod_local_2261 = 1; { let prod_local_2262 = (prod_local_2250).checked_add(prod_local_2261); prod_local_2262 } },
    } } } },
        true => { let prod_local_2264 = 1; { let prod_local_2265 = (prod_local_2250).checked_add(prod_local_2264); prod_local_2265 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_2266 = prod_local_2208; { let prod_local_2267 = prod_local_2266; { let prod_local_2268 = (prod_local_2267).value; { let prod_local_2269 = low64(prod_local_2268); match prod_local_2269 {
        None => prod_local_2269,
        Some(prod_local_2270) => { let prod_local_2271 = (prod_local_2267).guard; match prod_local_2271 {
        false => prod_local_2269,
        true => { let prod_local_2273 = (prod_local_2267).sticky; match prod_local_2273 {
        false => { let prod_local_2277 = 1; { let prod_local_2278 = (prod_local_2270 & prod_local_2277); { let prod_local_2279 = (prod_local_2278 == prod_local_2277); match prod_local_2279 {
        false => prod_local_2269,
        true => { let prod_local_2281 = 1; { let prod_local_2282 = (prod_local_2270).checked_add(prod_local_2281); prod_local_2282 } },
    } } } },
        true => { let prod_local_2284 = 1; { let prod_local_2285 = (prod_local_2270).checked_add(prod_local_2284); prod_local_2285 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_2286 = prod_local_1822; { let prod_local_2290 = 32; { let prod_local_2291 = (val_2857 & prod_local_2290); { let prod_local_2292 = 0; { let prod_local_2293 = (prod_local_2291 == prod_local_2292); { let prod_local_2297 = match prod_local_2293 {
        false => { let prod_local_2295 = false; prod_local_2295 },
        true => { let prod_local_2296 = true; prod_local_2296 },
    }; match prod_local_2297 {
        false => { let prod_local_2299 = Some(prod_local_2286); { let prod_local_2300 = round32(prod_local_2299); match prod_local_2300 {
        None => { let prod_local_2301 = prod_local_2300; match prod_local_2301 {
        None => None,
        Some(prod_local_2303) => { let prod_local_2304 = prod_local_2303; { let prod_local_2305 = (prod_local_2304).value; { let prod_local_2306 = low64(prod_local_2305); match prod_local_2306 {
        None => prod_local_2306,
        Some(prod_local_2307) => { let prod_local_2308 = (prod_local_2304).guard; match prod_local_2308 {
        false => prod_local_2306,
        true => { let prod_local_2310 = (prod_local_2304).sticky; match prod_local_2310 {
        false => { let prod_local_2314 = 1; { let prod_local_2315 = (prod_local_2307 & prod_local_2314); { let prod_local_2316 = (prod_local_2315 == prod_local_2314); match prod_local_2316 {
        false => prod_local_2306,
        true => { let prod_local_2318 = 1; { let prod_local_2319 = (prod_local_2307).checked_add(prod_local_2318); prod_local_2319 } },
    } } } },
        true => { let prod_local_2321 = 1; { let prod_local_2322 = (prod_local_2307).checked_add(prod_local_2321); prod_local_2322 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_2323) => { let prod_local_2324 = prod_local_2323; { let prod_local_2328 = 64; { let prod_local_2329 = (val_2857 & prod_local_2328); { let prod_local_2330 = 0; { let prod_local_2331 = (prod_local_2329 == prod_local_2330); { let prod_local_2335 = match prod_local_2331 {
        false => { let prod_local_2333 = false; prod_local_2333 },
        true => { let prod_local_2334 = true; prod_local_2334 },
    }; match prod_local_2335 {
        false => { let prod_local_2337 = Some(prod_local_2324); { let prod_local_2338 = round64(prod_local_2337); match prod_local_2338 {
        None => { let prod_local_2339 = prod_local_2338; match prod_local_2339 {
        None => None,
        Some(prod_local_2341) => { let prod_local_2342 = prod_local_2341; { let prod_local_2343 = (prod_local_2342).value; { let prod_local_2344 = low64(prod_local_2343); match prod_local_2344 {
        None => prod_local_2344,
        Some(prod_local_2345) => { let prod_local_2346 = (prod_local_2342).guard; match prod_local_2346 {
        false => prod_local_2344,
        true => { let prod_local_2348 = (prod_local_2342).sticky; match prod_local_2348 {
        false => { let prod_local_2352 = 1; { let prod_local_2353 = (prod_local_2345 & prod_local_2352); { let prod_local_2354 = (prod_local_2353 == prod_local_2352); match prod_local_2354 {
        false => prod_local_2344,
        true => { let prod_local_2356 = 1; { let prod_local_2357 = (prod_local_2345).checked_add(prod_local_2356); prod_local_2357 } },
    } } } },
        true => { let prod_local_2359 = 1; { let prod_local_2360 = (prod_local_2345).checked_add(prod_local_2359); prod_local_2360 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_2361) => { let prod_local_2362 = prod_local_2361; { let prod_local_2366 = 128; { let prod_local_2367 = (val_2857 & prod_local_2366); { let prod_local_2368 = 0; { let prod_local_2369 = (prod_local_2367 == prod_local_2368); { let prod_local_2373 = match prod_local_2369 {
        false => { let prod_local_2371 = false; prod_local_2371 },
        true => { let prod_local_2372 = true; prod_local_2372 },
    }; match prod_local_2373 {
        false => { let prod_local_2375 = Some(prod_local_2362); { let prod_local_2376 = round128(prod_local_2375); match prod_local_2376 {
        None => { let prod_local_2377 = prod_local_2376; match prod_local_2377 {
        None => None,
        Some(prod_local_2379) => { let prod_local_2380 = prod_local_2379; { let prod_local_2381 = (prod_local_2380).value; { let prod_local_2382 = low64(prod_local_2381); match prod_local_2382 {
        None => prod_local_2382,
        Some(prod_local_2383) => { let prod_local_2384 = (prod_local_2380).guard; match prod_local_2384 {
        false => prod_local_2382,
        true => { let prod_local_2386 = (prod_local_2380).sticky; match prod_local_2386 {
        false => { let prod_local_2390 = 1; { let prod_local_2391 = (prod_local_2383 & prod_local_2390); { let prod_local_2392 = (prod_local_2391 == prod_local_2390); match prod_local_2392 {
        false => prod_local_2382,
        true => { let prod_local_2394 = 1; { let prod_local_2395 = (prod_local_2383).checked_add(prod_local_2394); prod_local_2395 } },
    } } } },
        true => { let prod_local_2397 = 1; { let prod_local_2398 = (prod_local_2383).checked_add(prod_local_2397); prod_local_2398 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_2399) => { let prod_local_2400 = prod_local_2399; { let prod_local_2401 = prod_local_2400; { let prod_local_2402 = (prod_local_2401).value; { let prod_local_2403 = low64(prod_local_2402); match prod_local_2403 {
        None => prod_local_2403,
        Some(prod_local_2404) => { let prod_local_2405 = (prod_local_2401).guard; match prod_local_2405 {
        false => prod_local_2403,
        true => { let prod_local_2407 = (prod_local_2401).sticky; match prod_local_2407 {
        false => { let prod_local_2411 = 1; { let prod_local_2412 = (prod_local_2404 & prod_local_2411); { let prod_local_2413 = (prod_local_2412 == prod_local_2411); match prod_local_2413 {
        false => prod_local_2403,
        true => { let prod_local_2415 = 1; { let prod_local_2416 = (prod_local_2404).checked_add(prod_local_2415); prod_local_2416 } },
    } } } },
        true => { let prod_local_2418 = 1; { let prod_local_2419 = (prod_local_2404).checked_add(prod_local_2418); prod_local_2419 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_2420 = prod_local_2362; { let prod_local_2421 = prod_local_2420; { let prod_local_2422 = (prod_local_2421).value; { let prod_local_2423 = low64(prod_local_2422); match prod_local_2423 {
        None => prod_local_2423,
        Some(prod_local_2424) => { let prod_local_2425 = (prod_local_2421).guard; match prod_local_2425 {
        false => prod_local_2423,
        true => { let prod_local_2427 = (prod_local_2421).sticky; match prod_local_2427 {
        false => { let prod_local_2431 = 1; { let prod_local_2432 = (prod_local_2424 & prod_local_2431); { let prod_local_2433 = (prod_local_2432 == prod_local_2431); match prod_local_2433 {
        false => prod_local_2423,
        true => { let prod_local_2435 = 1; { let prod_local_2436 = (prod_local_2424).checked_add(prod_local_2435); prod_local_2436 } },
    } } } },
        true => { let prod_local_2438 = 1; { let prod_local_2439 = (prod_local_2424).checked_add(prod_local_2438); prod_local_2439 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_2440 = prod_local_2324; { let prod_local_2444 = 128; { let prod_local_2445 = (val_2857 & prod_local_2444); { let prod_local_2446 = 0; { let prod_local_2447 = (prod_local_2445 == prod_local_2446); { let prod_local_2451 = match prod_local_2447 {
        false => { let prod_local_2449 = false; prod_local_2449 },
        true => { let prod_local_2450 = true; prod_local_2450 },
    }; match prod_local_2451 {
        false => { let prod_local_2453 = Some(prod_local_2440); { let prod_local_2454 = round128(prod_local_2453); match prod_local_2454 {
        None => { let prod_local_2455 = prod_local_2454; match prod_local_2455 {
        None => None,
        Some(prod_local_2457) => { let prod_local_2458 = prod_local_2457; { let prod_local_2459 = (prod_local_2458).value; { let prod_local_2460 = low64(prod_local_2459); match prod_local_2460 {
        None => prod_local_2460,
        Some(prod_local_2461) => { let prod_local_2462 = (prod_local_2458).guard; match prod_local_2462 {
        false => prod_local_2460,
        true => { let prod_local_2464 = (prod_local_2458).sticky; match prod_local_2464 {
        false => { let prod_local_2468 = 1; { let prod_local_2469 = (prod_local_2461 & prod_local_2468); { let prod_local_2470 = (prod_local_2469 == prod_local_2468); match prod_local_2470 {
        false => prod_local_2460,
        true => { let prod_local_2472 = 1; { let prod_local_2473 = (prod_local_2461).checked_add(prod_local_2472); prod_local_2473 } },
    } } } },
        true => { let prod_local_2475 = 1; { let prod_local_2476 = (prod_local_2461).checked_add(prod_local_2475); prod_local_2476 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_2477) => { let prod_local_2478 = prod_local_2477; { let prod_local_2479 = prod_local_2478; { let prod_local_2480 = (prod_local_2479).value; { let prod_local_2481 = low64(prod_local_2480); match prod_local_2481 {
        None => prod_local_2481,
        Some(prod_local_2482) => { let prod_local_2483 = (prod_local_2479).guard; match prod_local_2483 {
        false => prod_local_2481,
        true => { let prod_local_2485 = (prod_local_2479).sticky; match prod_local_2485 {
        false => { let prod_local_2489 = 1; { let prod_local_2490 = (prod_local_2482 & prod_local_2489); { let prod_local_2491 = (prod_local_2490 == prod_local_2489); match prod_local_2491 {
        false => prod_local_2481,
        true => { let prod_local_2493 = 1; { let prod_local_2494 = (prod_local_2482).checked_add(prod_local_2493); prod_local_2494 } },
    } } } },
        true => { let prod_local_2496 = 1; { let prod_local_2497 = (prod_local_2482).checked_add(prod_local_2496); prod_local_2497 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_2498 = prod_local_2440; { let prod_local_2499 = prod_local_2498; { let prod_local_2500 = (prod_local_2499).value; { let prod_local_2501 = low64(prod_local_2500); match prod_local_2501 {
        None => prod_local_2501,
        Some(prod_local_2502) => { let prod_local_2503 = (prod_local_2499).guard; match prod_local_2503 {
        false => prod_local_2501,
        true => { let prod_local_2505 = (prod_local_2499).sticky; match prod_local_2505 {
        false => { let prod_local_2509 = 1; { let prod_local_2510 = (prod_local_2502 & prod_local_2509); { let prod_local_2511 = (prod_local_2510 == prod_local_2509); match prod_local_2511 {
        false => prod_local_2501,
        true => { let prod_local_2513 = 1; { let prod_local_2514 = (prod_local_2502).checked_add(prod_local_2513); prod_local_2514 } },
    } } } },
        true => { let prod_local_2516 = 1; { let prod_local_2517 = (prod_local_2502).checked_add(prod_local_2516); prod_local_2517 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_2518 = prod_local_2286; { let prod_local_2522 = 64; { let prod_local_2523 = (val_2857 & prod_local_2522); { let prod_local_2524 = 0; { let prod_local_2525 = (prod_local_2523 == prod_local_2524); { let prod_local_2529 = match prod_local_2525 {
        false => { let prod_local_2527 = false; prod_local_2527 },
        true => { let prod_local_2528 = true; prod_local_2528 },
    }; match prod_local_2529 {
        false => { let prod_local_2531 = Some(prod_local_2518); { let prod_local_2532 = round64(prod_local_2531); match prod_local_2532 {
        None => { let prod_local_2533 = prod_local_2532; match prod_local_2533 {
        None => None,
        Some(prod_local_2535) => { let prod_local_2536 = prod_local_2535; { let prod_local_2537 = (prod_local_2536).value; { let prod_local_2538 = low64(prod_local_2537); match prod_local_2538 {
        None => prod_local_2538,
        Some(prod_local_2539) => { let prod_local_2540 = (prod_local_2536).guard; match prod_local_2540 {
        false => prod_local_2538,
        true => { let prod_local_2542 = (prod_local_2536).sticky; match prod_local_2542 {
        false => { let prod_local_2546 = 1; { let prod_local_2547 = (prod_local_2539 & prod_local_2546); { let prod_local_2548 = (prod_local_2547 == prod_local_2546); match prod_local_2548 {
        false => prod_local_2538,
        true => { let prod_local_2550 = 1; { let prod_local_2551 = (prod_local_2539).checked_add(prod_local_2550); prod_local_2551 } },
    } } } },
        true => { let prod_local_2553 = 1; { let prod_local_2554 = (prod_local_2539).checked_add(prod_local_2553); prod_local_2554 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_2555) => { let prod_local_2556 = prod_local_2555; { let prod_local_2560 = 128; { let prod_local_2561 = (val_2857 & prod_local_2560); { let prod_local_2562 = 0; { let prod_local_2563 = (prod_local_2561 == prod_local_2562); { let prod_local_2567 = match prod_local_2563 {
        false => { let prod_local_2565 = false; prod_local_2565 },
        true => { let prod_local_2566 = true; prod_local_2566 },
    }; match prod_local_2567 {
        false => { let prod_local_2569 = Some(prod_local_2556); { let prod_local_2570 = round128(prod_local_2569); match prod_local_2570 {
        None => { let prod_local_2571 = prod_local_2570; match prod_local_2571 {
        None => None,
        Some(prod_local_2573) => { let prod_local_2574 = prod_local_2573; { let prod_local_2575 = (prod_local_2574).value; { let prod_local_2576 = low64(prod_local_2575); match prod_local_2576 {
        None => prod_local_2576,
        Some(prod_local_2577) => { let prod_local_2578 = (prod_local_2574).guard; match prod_local_2578 {
        false => prod_local_2576,
        true => { let prod_local_2580 = (prod_local_2574).sticky; match prod_local_2580 {
        false => { let prod_local_2584 = 1; { let prod_local_2585 = (prod_local_2577 & prod_local_2584); { let prod_local_2586 = (prod_local_2585 == prod_local_2584); match prod_local_2586 {
        false => prod_local_2576,
        true => { let prod_local_2588 = 1; { let prod_local_2589 = (prod_local_2577).checked_add(prod_local_2588); prod_local_2589 } },
    } } } },
        true => { let prod_local_2591 = 1; { let prod_local_2592 = (prod_local_2577).checked_add(prod_local_2591); prod_local_2592 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_2593) => { let prod_local_2594 = prod_local_2593; { let prod_local_2595 = prod_local_2594; { let prod_local_2596 = (prod_local_2595).value; { let prod_local_2597 = low64(prod_local_2596); match prod_local_2597 {
        None => prod_local_2597,
        Some(prod_local_2598) => { let prod_local_2599 = (prod_local_2595).guard; match prod_local_2599 {
        false => prod_local_2597,
        true => { let prod_local_2601 = (prod_local_2595).sticky; match prod_local_2601 {
        false => { let prod_local_2605 = 1; { let prod_local_2606 = (prod_local_2598 & prod_local_2605); { let prod_local_2607 = (prod_local_2606 == prod_local_2605); match prod_local_2607 {
        false => prod_local_2597,
        true => { let prod_local_2609 = 1; { let prod_local_2610 = (prod_local_2598).checked_add(prod_local_2609); prod_local_2610 } },
    } } } },
        true => { let prod_local_2612 = 1; { let prod_local_2613 = (prod_local_2598).checked_add(prod_local_2612); prod_local_2613 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_2614 = prod_local_2556; { let prod_local_2615 = prod_local_2614; { let prod_local_2616 = (prod_local_2615).value; { let prod_local_2617 = low64(prod_local_2616); match prod_local_2617 {
        None => prod_local_2617,
        Some(prod_local_2618) => { let prod_local_2619 = (prod_local_2615).guard; match prod_local_2619 {
        false => prod_local_2617,
        true => { let prod_local_2621 = (prod_local_2615).sticky; match prod_local_2621 {
        false => { let prod_local_2625 = 1; { let prod_local_2626 = (prod_local_2618 & prod_local_2625); { let prod_local_2627 = (prod_local_2626 == prod_local_2625); match prod_local_2627 {
        false => prod_local_2617,
        true => { let prod_local_2629 = 1; { let prod_local_2630 = (prod_local_2618).checked_add(prod_local_2629); prod_local_2630 } },
    } } } },
        true => { let prod_local_2632 = 1; { let prod_local_2633 = (prod_local_2618).checked_add(prod_local_2632); prod_local_2633 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_2634 = prod_local_2518; { let prod_local_2638 = 128; { let prod_local_2639 = (val_2857 & prod_local_2638); { let prod_local_2640 = 0; { let prod_local_2641 = (prod_local_2639 == prod_local_2640); { let prod_local_2645 = match prod_local_2641 {
        false => { let prod_local_2643 = false; prod_local_2643 },
        true => { let prod_local_2644 = true; prod_local_2644 },
    }; match prod_local_2645 {
        false => { let prod_local_2647 = Some(prod_local_2634); { let prod_local_2648 = round128(prod_local_2647); match prod_local_2648 {
        None => { let prod_local_2649 = prod_local_2648; match prod_local_2649 {
        None => None,
        Some(prod_local_2651) => { let prod_local_2652 = prod_local_2651; { let prod_local_2653 = (prod_local_2652).value; { let prod_local_2654 = low64(prod_local_2653); match prod_local_2654 {
        None => prod_local_2654,
        Some(prod_local_2655) => { let prod_local_2656 = (prod_local_2652).guard; match prod_local_2656 {
        false => prod_local_2654,
        true => { let prod_local_2658 = (prod_local_2652).sticky; match prod_local_2658 {
        false => { let prod_local_2662 = 1; { let prod_local_2663 = (prod_local_2655 & prod_local_2662); { let prod_local_2664 = (prod_local_2663 == prod_local_2662); match prod_local_2664 {
        false => prod_local_2654,
        true => { let prod_local_2666 = 1; { let prod_local_2667 = (prod_local_2655).checked_add(prod_local_2666); prod_local_2667 } },
    } } } },
        true => { let prod_local_2669 = 1; { let prod_local_2670 = (prod_local_2655).checked_add(prod_local_2669); prod_local_2670 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_2671) => { let prod_local_2672 = prod_local_2671; { let prod_local_2673 = prod_local_2672; { let prod_local_2674 = (prod_local_2673).value; { let prod_local_2675 = low64(prod_local_2674); match prod_local_2675 {
        None => prod_local_2675,
        Some(prod_local_2676) => { let prod_local_2677 = (prod_local_2673).guard; match prod_local_2677 {
        false => prod_local_2675,
        true => { let prod_local_2679 = (prod_local_2673).sticky; match prod_local_2679 {
        false => { let prod_local_2683 = 1; { let prod_local_2684 = (prod_local_2676 & prod_local_2683); { let prod_local_2685 = (prod_local_2684 == prod_local_2683); match prod_local_2685 {
        false => prod_local_2675,
        true => { let prod_local_2687 = 1; { let prod_local_2688 = (prod_local_2676).checked_add(prod_local_2687); prod_local_2688 } },
    } } } },
        true => { let prod_local_2690 = 1; { let prod_local_2691 = (prod_local_2676).checked_add(prod_local_2690); prod_local_2691 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_2692 = prod_local_2634; { let prod_local_2693 = prod_local_2692; { let prod_local_2694 = (prod_local_2693).value; { let prod_local_2695 = low64(prod_local_2694); match prod_local_2695 {
        None => prod_local_2695,
        Some(prod_local_2696) => { let prod_local_2697 = (prod_local_2693).guard; match prod_local_2697 {
        false => prod_local_2695,
        true => { let prod_local_2699 = (prod_local_2693).sticky; match prod_local_2699 {
        false => { let prod_local_2703 = 1; { let prod_local_2704 = (prod_local_2696 & prod_local_2703); { let prod_local_2705 = (prod_local_2704 == prod_local_2703); match prod_local_2705 {
        false => prod_local_2695,
        true => { let prod_local_2707 = 1; { let prod_local_2708 = (prod_local_2696).checked_add(prod_local_2707); prod_local_2708 } },
    } } } },
        true => { let prod_local_2710 = 1; { let prod_local_2711 = (prod_local_2696).checked_add(prod_local_2710); prod_local_2711 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } } } } } },
    } } } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_2712 = prod_local_1784; { let prod_local_2716 = 16; { let prod_local_2717 = (val_2857 & prod_local_2716); { let prod_local_2718 = 0; { let prod_local_2719 = (prod_local_2717 == prod_local_2718); { let prod_local_2723 = match prod_local_2719 {
        false => { let prod_local_2721 = false; prod_local_2721 },
        true => { let prod_local_2722 = true; prod_local_2722 },
    }; match prod_local_2723 {
        false => { let prod_local_2725 = Some(prod_local_2712); { let prod_local_2726 = round16(prod_local_2725); match prod_local_2726 {
        None => { let prod_local_2727 = prod_local_2726; match prod_local_2727 {
        None => None,
        Some(prod_local_2729) => { let prod_local_2730 = prod_local_2729; { let prod_local_2731 = (prod_local_2730).value; { let prod_local_2732 = low64(prod_local_2731); match prod_local_2732 {
        None => prod_local_2732,
        Some(prod_local_2733) => { let prod_local_2734 = (prod_local_2730).guard; match prod_local_2734 {
        false => prod_local_2732,
        true => { let prod_local_2736 = (prod_local_2730).sticky; match prod_local_2736 {
        false => { let prod_local_2740 = 1; { let prod_local_2741 = (prod_local_2733 & prod_local_2740); { let prod_local_2742 = (prod_local_2741 == prod_local_2740); match prod_local_2742 {
        false => prod_local_2732,
        true => { let prod_local_2744 = 1; { let prod_local_2745 = (prod_local_2733).checked_add(prod_local_2744); prod_local_2745 } },
    } } } },
        true => { let prod_local_2747 = 1; { let prod_local_2748 = (prod_local_2733).checked_add(prod_local_2747); prod_local_2748 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_2749) => { let prod_local_2750 = prod_local_2749; { let prod_local_2754 = 32; { let prod_local_2755 = (val_2857 & prod_local_2754); { let prod_local_2756 = 0; { let prod_local_2757 = (prod_local_2755 == prod_local_2756); { let prod_local_2761 = match prod_local_2757 {
        false => { let prod_local_2759 = false; prod_local_2759 },
        true => { let prod_local_2760 = true; prod_local_2760 },
    }; match prod_local_2761 {
        false => { let prod_local_2763 = Some(prod_local_2750); { let prod_local_2764 = round32(prod_local_2763); match prod_local_2764 {
        None => { let prod_local_2765 = prod_local_2764; match prod_local_2765 {
        None => None,
        Some(prod_local_2767) => { let prod_local_2768 = prod_local_2767; { let prod_local_2769 = (prod_local_2768).value; { let prod_local_2770 = low64(prod_local_2769); match prod_local_2770 {
        None => prod_local_2770,
        Some(prod_local_2771) => { let prod_local_2772 = (prod_local_2768).guard; match prod_local_2772 {
        false => prod_local_2770,
        true => { let prod_local_2774 = (prod_local_2768).sticky; match prod_local_2774 {
        false => { let prod_local_2778 = 1; { let prod_local_2779 = (prod_local_2771 & prod_local_2778); { let prod_local_2780 = (prod_local_2779 == prod_local_2778); match prod_local_2780 {
        false => prod_local_2770,
        true => { let prod_local_2782 = 1; { let prod_local_2783 = (prod_local_2771).checked_add(prod_local_2782); prod_local_2783 } },
    } } } },
        true => { let prod_local_2785 = 1; { let prod_local_2786 = (prod_local_2771).checked_add(prod_local_2785); prod_local_2786 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_2787) => { let prod_local_2788 = prod_local_2787; { let prod_local_2792 = 64; { let prod_local_2793 = (val_2857 & prod_local_2792); { let prod_local_2794 = 0; { let prod_local_2795 = (prod_local_2793 == prod_local_2794); { let prod_local_2799 = match prod_local_2795 {
        false => { let prod_local_2797 = false; prod_local_2797 },
        true => { let prod_local_2798 = true; prod_local_2798 },
    }; match prod_local_2799 {
        false => { let prod_local_2801 = Some(prod_local_2788); { let prod_local_2802 = round64(prod_local_2801); match prod_local_2802 {
        None => { let prod_local_2803 = prod_local_2802; match prod_local_2803 {
        None => None,
        Some(prod_local_2805) => { let prod_local_2806 = prod_local_2805; { let prod_local_2807 = (prod_local_2806).value; { let prod_local_2808 = low64(prod_local_2807); match prod_local_2808 {
        None => prod_local_2808,
        Some(prod_local_2809) => { let prod_local_2810 = (prod_local_2806).guard; match prod_local_2810 {
        false => prod_local_2808,
        true => { let prod_local_2812 = (prod_local_2806).sticky; match prod_local_2812 {
        false => { let prod_local_2816 = 1; { let prod_local_2817 = (prod_local_2809 & prod_local_2816); { let prod_local_2818 = (prod_local_2817 == prod_local_2816); match prod_local_2818 {
        false => prod_local_2808,
        true => { let prod_local_2820 = 1; { let prod_local_2821 = (prod_local_2809).checked_add(prod_local_2820); prod_local_2821 } },
    } } } },
        true => { let prod_local_2823 = 1; { let prod_local_2824 = (prod_local_2809).checked_add(prod_local_2823); prod_local_2824 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_2825) => { let prod_local_2826 = prod_local_2825; { let prod_local_2830 = 128; { let prod_local_2831 = (val_2857 & prod_local_2830); { let prod_local_2832 = 0; { let prod_local_2833 = (prod_local_2831 == prod_local_2832); { let prod_local_2837 = match prod_local_2833 {
        false => { let prod_local_2835 = false; prod_local_2835 },
        true => { let prod_local_2836 = true; prod_local_2836 },
    }; match prod_local_2837 {
        false => { let prod_local_2839 = Some(prod_local_2826); { let prod_local_2840 = round128(prod_local_2839); match prod_local_2840 {
        None => { let prod_local_2841 = prod_local_2840; match prod_local_2841 {
        None => None,
        Some(prod_local_2843) => { let prod_local_2844 = prod_local_2843; { let prod_local_2845 = (prod_local_2844).value; { let prod_local_2846 = low64(prod_local_2845); match prod_local_2846 {
        None => prod_local_2846,
        Some(prod_local_2847) => { let prod_local_2848 = (prod_local_2844).guard; match prod_local_2848 {
        false => prod_local_2846,
        true => { let prod_local_2850 = (prod_local_2844).sticky; match prod_local_2850 {
        false => { let prod_local_2854 = 1; { let prod_local_2855 = (prod_local_2847 & prod_local_2854); { let prod_local_2856 = (prod_local_2855 == prod_local_2854); match prod_local_2856 {
        false => prod_local_2846,
        true => { let prod_local_2858 = 1; { let prod_local_2859 = (prod_local_2847).checked_add(prod_local_2858); prod_local_2859 } },
    } } } },
        true => { let prod_local_2861 = 1; { let prod_local_2862 = (prod_local_2847).checked_add(prod_local_2861); prod_local_2862 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_2863) => { let prod_local_2864 = prod_local_2863; { let prod_local_2865 = prod_local_2864; { let prod_local_2866 = (prod_local_2865).value; { let prod_local_2867 = low64(prod_local_2866); match prod_local_2867 {
        None => prod_local_2867,
        Some(prod_local_2868) => { let prod_local_2869 = (prod_local_2865).guard; match prod_local_2869 {
        false => prod_local_2867,
        true => { let prod_local_2871 = (prod_local_2865).sticky; match prod_local_2871 {
        false => { let prod_local_2875 = 1; { let prod_local_2876 = (prod_local_2868 & prod_local_2875); { let prod_local_2877 = (prod_local_2876 == prod_local_2875); match prod_local_2877 {
        false => prod_local_2867,
        true => { let prod_local_2879 = 1; { let prod_local_2880 = (prod_local_2868).checked_add(prod_local_2879); prod_local_2880 } },
    } } } },
        true => { let prod_local_2882 = 1; { let prod_local_2883 = (prod_local_2868).checked_add(prod_local_2882); prod_local_2883 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_2884 = prod_local_2826; { let prod_local_2885 = prod_local_2884; { let prod_local_2886 = (prod_local_2885).value; { let prod_local_2887 = low64(prod_local_2886); match prod_local_2887 {
        None => prod_local_2887,
        Some(prod_local_2888) => { let prod_local_2889 = (prod_local_2885).guard; match prod_local_2889 {
        false => prod_local_2887,
        true => { let prod_local_2891 = (prod_local_2885).sticky; match prod_local_2891 {
        false => { let prod_local_2895 = 1; { let prod_local_2896 = (prod_local_2888 & prod_local_2895); { let prod_local_2897 = (prod_local_2896 == prod_local_2895); match prod_local_2897 {
        false => prod_local_2887,
        true => { let prod_local_2899 = 1; { let prod_local_2900 = (prod_local_2888).checked_add(prod_local_2899); prod_local_2900 } },
    } } } },
        true => { let prod_local_2902 = 1; { let prod_local_2903 = (prod_local_2888).checked_add(prod_local_2902); prod_local_2903 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_2904 = prod_local_2788; { let prod_local_2908 = 128; { let prod_local_2909 = (val_2857 & prod_local_2908); { let prod_local_2910 = 0; { let prod_local_2911 = (prod_local_2909 == prod_local_2910); { let prod_local_2915 = match prod_local_2911 {
        false => { let prod_local_2913 = false; prod_local_2913 },
        true => { let prod_local_2914 = true; prod_local_2914 },
    }; match prod_local_2915 {
        false => { let prod_local_2917 = Some(prod_local_2904); { let prod_local_2918 = round128(prod_local_2917); match prod_local_2918 {
        None => { let prod_local_2919 = prod_local_2918; match prod_local_2919 {
        None => None,
        Some(prod_local_2921) => { let prod_local_2922 = prod_local_2921; { let prod_local_2923 = (prod_local_2922).value; { let prod_local_2924 = low64(prod_local_2923); match prod_local_2924 {
        None => prod_local_2924,
        Some(prod_local_2925) => { let prod_local_2926 = (prod_local_2922).guard; match prod_local_2926 {
        false => prod_local_2924,
        true => { let prod_local_2928 = (prod_local_2922).sticky; match prod_local_2928 {
        false => { let prod_local_2932 = 1; { let prod_local_2933 = (prod_local_2925 & prod_local_2932); { let prod_local_2934 = (prod_local_2933 == prod_local_2932); match prod_local_2934 {
        false => prod_local_2924,
        true => { let prod_local_2936 = 1; { let prod_local_2937 = (prod_local_2925).checked_add(prod_local_2936); prod_local_2937 } },
    } } } },
        true => { let prod_local_2939 = 1; { let prod_local_2940 = (prod_local_2925).checked_add(prod_local_2939); prod_local_2940 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_2941) => { let prod_local_2942 = prod_local_2941; { let prod_local_2943 = prod_local_2942; { let prod_local_2944 = (prod_local_2943).value; { let prod_local_2945 = low64(prod_local_2944); match prod_local_2945 {
        None => prod_local_2945,
        Some(prod_local_2946) => { let prod_local_2947 = (prod_local_2943).guard; match prod_local_2947 {
        false => prod_local_2945,
        true => { let prod_local_2949 = (prod_local_2943).sticky; match prod_local_2949 {
        false => { let prod_local_2953 = 1; { let prod_local_2954 = (prod_local_2946 & prod_local_2953); { let prod_local_2955 = (prod_local_2954 == prod_local_2953); match prod_local_2955 {
        false => prod_local_2945,
        true => { let prod_local_2957 = 1; { let prod_local_2958 = (prod_local_2946).checked_add(prod_local_2957); prod_local_2958 } },
    } } } },
        true => { let prod_local_2960 = 1; { let prod_local_2961 = (prod_local_2946).checked_add(prod_local_2960); prod_local_2961 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_2962 = prod_local_2904; { let prod_local_2963 = prod_local_2962; { let prod_local_2964 = (prod_local_2963).value; { let prod_local_2965 = low64(prod_local_2964); match prod_local_2965 {
        None => prod_local_2965,
        Some(prod_local_2966) => { let prod_local_2967 = (prod_local_2963).guard; match prod_local_2967 {
        false => prod_local_2965,
        true => { let prod_local_2969 = (prod_local_2963).sticky; match prod_local_2969 {
        false => { let prod_local_2973 = 1; { let prod_local_2974 = (prod_local_2966 & prod_local_2973); { let prod_local_2975 = (prod_local_2974 == prod_local_2973); match prod_local_2975 {
        false => prod_local_2965,
        true => { let prod_local_2977 = 1; { let prod_local_2978 = (prod_local_2966).checked_add(prod_local_2977); prod_local_2978 } },
    } } } },
        true => { let prod_local_2980 = 1; { let prod_local_2981 = (prod_local_2966).checked_add(prod_local_2980); prod_local_2981 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_2982 = prod_local_2750; { let prod_local_2986 = 64; { let prod_local_2987 = (val_2857 & prod_local_2986); { let prod_local_2988 = 0; { let prod_local_2989 = (prod_local_2987 == prod_local_2988); { let prod_local_2993 = match prod_local_2989 {
        false => { let prod_local_2991 = false; prod_local_2991 },
        true => { let prod_local_2992 = true; prod_local_2992 },
    }; match prod_local_2993 {
        false => { let prod_local_2995 = Some(prod_local_2982); { let prod_local_2996 = round64(prod_local_2995); match prod_local_2996 {
        None => { let prod_local_2997 = prod_local_2996; match prod_local_2997 {
        None => None,
        Some(prod_local_2999) => { let prod_local_3000 = prod_local_2999; { let prod_local_3001 = (prod_local_3000).value; { let prod_local_3002 = low64(prod_local_3001); match prod_local_3002 {
        None => prod_local_3002,
        Some(prod_local_3003) => { let prod_local_3004 = (prod_local_3000).guard; match prod_local_3004 {
        false => prod_local_3002,
        true => { let prod_local_3006 = (prod_local_3000).sticky; match prod_local_3006 {
        false => { let prod_local_3010 = 1; { let prod_local_3011 = (prod_local_3003 & prod_local_3010); { let prod_local_3012 = (prod_local_3011 == prod_local_3010); match prod_local_3012 {
        false => prod_local_3002,
        true => { let prod_local_3014 = 1; { let prod_local_3015 = (prod_local_3003).checked_add(prod_local_3014); prod_local_3015 } },
    } } } },
        true => { let prod_local_3017 = 1; { let prod_local_3018 = (prod_local_3003).checked_add(prod_local_3017); prod_local_3018 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_3019) => { let prod_local_3020 = prod_local_3019; { let prod_local_3024 = 128; { let prod_local_3025 = (val_2857 & prod_local_3024); { let prod_local_3026 = 0; { let prod_local_3027 = (prod_local_3025 == prod_local_3026); { let prod_local_3031 = match prod_local_3027 {
        false => { let prod_local_3029 = false; prod_local_3029 },
        true => { let prod_local_3030 = true; prod_local_3030 },
    }; match prod_local_3031 {
        false => { let prod_local_3033 = Some(prod_local_3020); { let prod_local_3034 = round128(prod_local_3033); match prod_local_3034 {
        None => { let prod_local_3035 = prod_local_3034; match prod_local_3035 {
        None => None,
        Some(prod_local_3037) => { let prod_local_3038 = prod_local_3037; { let prod_local_3039 = (prod_local_3038).value; { let prod_local_3040 = low64(prod_local_3039); match prod_local_3040 {
        None => prod_local_3040,
        Some(prod_local_3041) => { let prod_local_3042 = (prod_local_3038).guard; match prod_local_3042 {
        false => prod_local_3040,
        true => { let prod_local_3044 = (prod_local_3038).sticky; match prod_local_3044 {
        false => { let prod_local_3048 = 1; { let prod_local_3049 = (prod_local_3041 & prod_local_3048); { let prod_local_3050 = (prod_local_3049 == prod_local_3048); match prod_local_3050 {
        false => prod_local_3040,
        true => { let prod_local_3052 = 1; { let prod_local_3053 = (prod_local_3041).checked_add(prod_local_3052); prod_local_3053 } },
    } } } },
        true => { let prod_local_3055 = 1; { let prod_local_3056 = (prod_local_3041).checked_add(prod_local_3055); prod_local_3056 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_3057) => { let prod_local_3058 = prod_local_3057; { let prod_local_3059 = prod_local_3058; { let prod_local_3060 = (prod_local_3059).value; { let prod_local_3061 = low64(prod_local_3060); match prod_local_3061 {
        None => prod_local_3061,
        Some(prod_local_3062) => { let prod_local_3063 = (prod_local_3059).guard; match prod_local_3063 {
        false => prod_local_3061,
        true => { let prod_local_3065 = (prod_local_3059).sticky; match prod_local_3065 {
        false => { let prod_local_3069 = 1; { let prod_local_3070 = (prod_local_3062 & prod_local_3069); { let prod_local_3071 = (prod_local_3070 == prod_local_3069); match prod_local_3071 {
        false => prod_local_3061,
        true => { let prod_local_3073 = 1; { let prod_local_3074 = (prod_local_3062).checked_add(prod_local_3073); prod_local_3074 } },
    } } } },
        true => { let prod_local_3076 = 1; { let prod_local_3077 = (prod_local_3062).checked_add(prod_local_3076); prod_local_3077 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_3078 = prod_local_3020; { let prod_local_3079 = prod_local_3078; { let prod_local_3080 = (prod_local_3079).value; { let prod_local_3081 = low64(prod_local_3080); match prod_local_3081 {
        None => prod_local_3081,
        Some(prod_local_3082) => { let prod_local_3083 = (prod_local_3079).guard; match prod_local_3083 {
        false => prod_local_3081,
        true => { let prod_local_3085 = (prod_local_3079).sticky; match prod_local_3085 {
        false => { let prod_local_3089 = 1; { let prod_local_3090 = (prod_local_3082 & prod_local_3089); { let prod_local_3091 = (prod_local_3090 == prod_local_3089); match prod_local_3091 {
        false => prod_local_3081,
        true => { let prod_local_3093 = 1; { let prod_local_3094 = (prod_local_3082).checked_add(prod_local_3093); prod_local_3094 } },
    } } } },
        true => { let prod_local_3096 = 1; { let prod_local_3097 = (prod_local_3082).checked_add(prod_local_3096); prod_local_3097 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_3098 = prod_local_2982; { let prod_local_3102 = 128; { let prod_local_3103 = (val_2857 & prod_local_3102); { let prod_local_3104 = 0; { let prod_local_3105 = (prod_local_3103 == prod_local_3104); { let prod_local_3109 = match prod_local_3105 {
        false => { let prod_local_3107 = false; prod_local_3107 },
        true => { let prod_local_3108 = true; prod_local_3108 },
    }; match prod_local_3109 {
        false => { let prod_local_3111 = Some(prod_local_3098); { let prod_local_3112 = round128(prod_local_3111); match prod_local_3112 {
        None => { let prod_local_3113 = prod_local_3112; match prod_local_3113 {
        None => None,
        Some(prod_local_3115) => { let prod_local_3116 = prod_local_3115; { let prod_local_3117 = (prod_local_3116).value; { let prod_local_3118 = low64(prod_local_3117); match prod_local_3118 {
        None => prod_local_3118,
        Some(prod_local_3119) => { let prod_local_3120 = (prod_local_3116).guard; match prod_local_3120 {
        false => prod_local_3118,
        true => { let prod_local_3122 = (prod_local_3116).sticky; match prod_local_3122 {
        false => { let prod_local_3126 = 1; { let prod_local_3127 = (prod_local_3119 & prod_local_3126); { let prod_local_3128 = (prod_local_3127 == prod_local_3126); match prod_local_3128 {
        false => prod_local_3118,
        true => { let prod_local_3130 = 1; { let prod_local_3131 = (prod_local_3119).checked_add(prod_local_3130); prod_local_3131 } },
    } } } },
        true => { let prod_local_3133 = 1; { let prod_local_3134 = (prod_local_3119).checked_add(prod_local_3133); prod_local_3134 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_3135) => { let prod_local_3136 = prod_local_3135; { let prod_local_3137 = prod_local_3136; { let prod_local_3138 = (prod_local_3137).value; { let prod_local_3139 = low64(prod_local_3138); match prod_local_3139 {
        None => prod_local_3139,
        Some(prod_local_3140) => { let prod_local_3141 = (prod_local_3137).guard; match prod_local_3141 {
        false => prod_local_3139,
        true => { let prod_local_3143 = (prod_local_3137).sticky; match prod_local_3143 {
        false => { let prod_local_3147 = 1; { let prod_local_3148 = (prod_local_3140 & prod_local_3147); { let prod_local_3149 = (prod_local_3148 == prod_local_3147); match prod_local_3149 {
        false => prod_local_3139,
        true => { let prod_local_3151 = 1; { let prod_local_3152 = (prod_local_3140).checked_add(prod_local_3151); prod_local_3152 } },
    } } } },
        true => { let prod_local_3154 = 1; { let prod_local_3155 = (prod_local_3140).checked_add(prod_local_3154); prod_local_3155 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_3156 = prod_local_3098; { let prod_local_3157 = prod_local_3156; { let prod_local_3158 = (prod_local_3157).value; { let prod_local_3159 = low64(prod_local_3158); match prod_local_3159 {
        None => prod_local_3159,
        Some(prod_local_3160) => { let prod_local_3161 = (prod_local_3157).guard; match prod_local_3161 {
        false => prod_local_3159,
        true => { let prod_local_3163 = (prod_local_3157).sticky; match prod_local_3163 {
        false => { let prod_local_3167 = 1; { let prod_local_3168 = (prod_local_3160 & prod_local_3167); { let prod_local_3169 = (prod_local_3168 == prod_local_3167); match prod_local_3169 {
        false => prod_local_3159,
        true => { let prod_local_3171 = 1; { let prod_local_3172 = (prod_local_3160).checked_add(prod_local_3171); prod_local_3172 } },
    } } } },
        true => { let prod_local_3174 = 1; { let prod_local_3175 = (prod_local_3160).checked_add(prod_local_3174); prod_local_3175 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_3176 = prod_local_2712; { let prod_local_3180 = 32; { let prod_local_3181 = (val_2857 & prod_local_3180); { let prod_local_3182 = 0; { let prod_local_3183 = (prod_local_3181 == prod_local_3182); { let prod_local_3187 = match prod_local_3183 {
        false => { let prod_local_3185 = false; prod_local_3185 },
        true => { let prod_local_3186 = true; prod_local_3186 },
    }; match prod_local_3187 {
        false => { let prod_local_3189 = Some(prod_local_3176); { let prod_local_3190 = round32(prod_local_3189); match prod_local_3190 {
        None => { let prod_local_3191 = prod_local_3190; match prod_local_3191 {
        None => None,
        Some(prod_local_3193) => { let prod_local_3194 = prod_local_3193; { let prod_local_3195 = (prod_local_3194).value; { let prod_local_3196 = low64(prod_local_3195); match prod_local_3196 {
        None => prod_local_3196,
        Some(prod_local_3197) => { let prod_local_3198 = (prod_local_3194).guard; match prod_local_3198 {
        false => prod_local_3196,
        true => { let prod_local_3200 = (prod_local_3194).sticky; match prod_local_3200 {
        false => { let prod_local_3204 = 1; { let prod_local_3205 = (prod_local_3197 & prod_local_3204); { let prod_local_3206 = (prod_local_3205 == prod_local_3204); match prod_local_3206 {
        false => prod_local_3196,
        true => { let prod_local_3208 = 1; { let prod_local_3209 = (prod_local_3197).checked_add(prod_local_3208); prod_local_3209 } },
    } } } },
        true => { let prod_local_3211 = 1; { let prod_local_3212 = (prod_local_3197).checked_add(prod_local_3211); prod_local_3212 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_3213) => { let prod_local_3214 = prod_local_3213; { let prod_local_3218 = 64; { let prod_local_3219 = (val_2857 & prod_local_3218); { let prod_local_3220 = 0; { let prod_local_3221 = (prod_local_3219 == prod_local_3220); { let prod_local_3225 = match prod_local_3221 {
        false => { let prod_local_3223 = false; prod_local_3223 },
        true => { let prod_local_3224 = true; prod_local_3224 },
    }; match prod_local_3225 {
        false => { let prod_local_3227 = Some(prod_local_3214); { let prod_local_3228 = round64(prod_local_3227); match prod_local_3228 {
        None => { let prod_local_3229 = prod_local_3228; match prod_local_3229 {
        None => None,
        Some(prod_local_3231) => { let prod_local_3232 = prod_local_3231; { let prod_local_3233 = (prod_local_3232).value; { let prod_local_3234 = low64(prod_local_3233); match prod_local_3234 {
        None => prod_local_3234,
        Some(prod_local_3235) => { let prod_local_3236 = (prod_local_3232).guard; match prod_local_3236 {
        false => prod_local_3234,
        true => { let prod_local_3238 = (prod_local_3232).sticky; match prod_local_3238 {
        false => { let prod_local_3242 = 1; { let prod_local_3243 = (prod_local_3235 & prod_local_3242); { let prod_local_3244 = (prod_local_3243 == prod_local_3242); match prod_local_3244 {
        false => prod_local_3234,
        true => { let prod_local_3246 = 1; { let prod_local_3247 = (prod_local_3235).checked_add(prod_local_3246); prod_local_3247 } },
    } } } },
        true => { let prod_local_3249 = 1; { let prod_local_3250 = (prod_local_3235).checked_add(prod_local_3249); prod_local_3250 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_3251) => { let prod_local_3252 = prod_local_3251; { let prod_local_3256 = 128; { let prod_local_3257 = (val_2857 & prod_local_3256); { let prod_local_3258 = 0; { let prod_local_3259 = (prod_local_3257 == prod_local_3258); { let prod_local_3263 = match prod_local_3259 {
        false => { let prod_local_3261 = false; prod_local_3261 },
        true => { let prod_local_3262 = true; prod_local_3262 },
    }; match prod_local_3263 {
        false => { let prod_local_3265 = Some(prod_local_3252); { let prod_local_3266 = round128(prod_local_3265); match prod_local_3266 {
        None => { let prod_local_3267 = prod_local_3266; match prod_local_3267 {
        None => None,
        Some(prod_local_3269) => { let prod_local_3270 = prod_local_3269; { let prod_local_3271 = (prod_local_3270).value; { let prod_local_3272 = low64(prod_local_3271); match prod_local_3272 {
        None => prod_local_3272,
        Some(prod_local_3273) => { let prod_local_3274 = (prod_local_3270).guard; match prod_local_3274 {
        false => prod_local_3272,
        true => { let prod_local_3276 = (prod_local_3270).sticky; match prod_local_3276 {
        false => { let prod_local_3280 = 1; { let prod_local_3281 = (prod_local_3273 & prod_local_3280); { let prod_local_3282 = (prod_local_3281 == prod_local_3280); match prod_local_3282 {
        false => prod_local_3272,
        true => { let prod_local_3284 = 1; { let prod_local_3285 = (prod_local_3273).checked_add(prod_local_3284); prod_local_3285 } },
    } } } },
        true => { let prod_local_3287 = 1; { let prod_local_3288 = (prod_local_3273).checked_add(prod_local_3287); prod_local_3288 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_3289) => { let prod_local_3290 = prod_local_3289; { let prod_local_3291 = prod_local_3290; { let prod_local_3292 = (prod_local_3291).value; { let prod_local_3293 = low64(prod_local_3292); match prod_local_3293 {
        None => prod_local_3293,
        Some(prod_local_3294) => { let prod_local_3295 = (prod_local_3291).guard; match prod_local_3295 {
        false => prod_local_3293,
        true => { let prod_local_3297 = (prod_local_3291).sticky; match prod_local_3297 {
        false => { let prod_local_3301 = 1; { let prod_local_3302 = (prod_local_3294 & prod_local_3301); { let prod_local_3303 = (prod_local_3302 == prod_local_3301); match prod_local_3303 {
        false => prod_local_3293,
        true => { let prod_local_3305 = 1; { let prod_local_3306 = (prod_local_3294).checked_add(prod_local_3305); prod_local_3306 } },
    } } } },
        true => { let prod_local_3308 = 1; { let prod_local_3309 = (prod_local_3294).checked_add(prod_local_3308); prod_local_3309 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_3310 = prod_local_3252; { let prod_local_3311 = prod_local_3310; { let prod_local_3312 = (prod_local_3311).value; { let prod_local_3313 = low64(prod_local_3312); match prod_local_3313 {
        None => prod_local_3313,
        Some(prod_local_3314) => { let prod_local_3315 = (prod_local_3311).guard; match prod_local_3315 {
        false => prod_local_3313,
        true => { let prod_local_3317 = (prod_local_3311).sticky; match prod_local_3317 {
        false => { let prod_local_3321 = 1; { let prod_local_3322 = (prod_local_3314 & prod_local_3321); { let prod_local_3323 = (prod_local_3322 == prod_local_3321); match prod_local_3323 {
        false => prod_local_3313,
        true => { let prod_local_3325 = 1; { let prod_local_3326 = (prod_local_3314).checked_add(prod_local_3325); prod_local_3326 } },
    } } } },
        true => { let prod_local_3328 = 1; { let prod_local_3329 = (prod_local_3314).checked_add(prod_local_3328); prod_local_3329 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_3330 = prod_local_3214; { let prod_local_3334 = 128; { let prod_local_3335 = (val_2857 & prod_local_3334); { let prod_local_3336 = 0; { let prod_local_3337 = (prod_local_3335 == prod_local_3336); { let prod_local_3341 = match prod_local_3337 {
        false => { let prod_local_3339 = false; prod_local_3339 },
        true => { let prod_local_3340 = true; prod_local_3340 },
    }; match prod_local_3341 {
        false => { let prod_local_3343 = Some(prod_local_3330); { let prod_local_3344 = round128(prod_local_3343); match prod_local_3344 {
        None => { let prod_local_3345 = prod_local_3344; match prod_local_3345 {
        None => None,
        Some(prod_local_3347) => { let prod_local_3348 = prod_local_3347; { let prod_local_3349 = (prod_local_3348).value; { let prod_local_3350 = low64(prod_local_3349); match prod_local_3350 {
        None => prod_local_3350,
        Some(prod_local_3351) => { let prod_local_3352 = (prod_local_3348).guard; match prod_local_3352 {
        false => prod_local_3350,
        true => { let prod_local_3354 = (prod_local_3348).sticky; match prod_local_3354 {
        false => { let prod_local_3358 = 1; { let prod_local_3359 = (prod_local_3351 & prod_local_3358); { let prod_local_3360 = (prod_local_3359 == prod_local_3358); match prod_local_3360 {
        false => prod_local_3350,
        true => { let prod_local_3362 = 1; { let prod_local_3363 = (prod_local_3351).checked_add(prod_local_3362); prod_local_3363 } },
    } } } },
        true => { let prod_local_3365 = 1; { let prod_local_3366 = (prod_local_3351).checked_add(prod_local_3365); prod_local_3366 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_3367) => { let prod_local_3368 = prod_local_3367; { let prod_local_3369 = prod_local_3368; { let prod_local_3370 = (prod_local_3369).value; { let prod_local_3371 = low64(prod_local_3370); match prod_local_3371 {
        None => prod_local_3371,
        Some(prod_local_3372) => { let prod_local_3373 = (prod_local_3369).guard; match prod_local_3373 {
        false => prod_local_3371,
        true => { let prod_local_3375 = (prod_local_3369).sticky; match prod_local_3375 {
        false => { let prod_local_3379 = 1; { let prod_local_3380 = (prod_local_3372 & prod_local_3379); { let prod_local_3381 = (prod_local_3380 == prod_local_3379); match prod_local_3381 {
        false => prod_local_3371,
        true => { let prod_local_3383 = 1; { let prod_local_3384 = (prod_local_3372).checked_add(prod_local_3383); prod_local_3384 } },
    } } } },
        true => { let prod_local_3386 = 1; { let prod_local_3387 = (prod_local_3372).checked_add(prod_local_3386); prod_local_3387 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_3388 = prod_local_3330; { let prod_local_3389 = prod_local_3388; { let prod_local_3390 = (prod_local_3389).value; { let prod_local_3391 = low64(prod_local_3390); match prod_local_3391 {
        None => prod_local_3391,
        Some(prod_local_3392) => { let prod_local_3393 = (prod_local_3389).guard; match prod_local_3393 {
        false => prod_local_3391,
        true => { let prod_local_3395 = (prod_local_3389).sticky; match prod_local_3395 {
        false => { let prod_local_3399 = 1; { let prod_local_3400 = (prod_local_3392 & prod_local_3399); { let prod_local_3401 = (prod_local_3400 == prod_local_3399); match prod_local_3401 {
        false => prod_local_3391,
        true => { let prod_local_3403 = 1; { let prod_local_3404 = (prod_local_3392).checked_add(prod_local_3403); prod_local_3404 } },
    } } } },
        true => { let prod_local_3406 = 1; { let prod_local_3407 = (prod_local_3392).checked_add(prod_local_3406); prod_local_3407 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_3408 = prod_local_3176; { let prod_local_3412 = 64; { let prod_local_3413 = (val_2857 & prod_local_3412); { let prod_local_3414 = 0; { let prod_local_3415 = (prod_local_3413 == prod_local_3414); { let prod_local_3419 = match prod_local_3415 {
        false => { let prod_local_3417 = false; prod_local_3417 },
        true => { let prod_local_3418 = true; prod_local_3418 },
    }; match prod_local_3419 {
        false => { let prod_local_3421 = Some(prod_local_3408); { let prod_local_3422 = round64(prod_local_3421); match prod_local_3422 {
        None => { let prod_local_3423 = prod_local_3422; match prod_local_3423 {
        None => None,
        Some(prod_local_3425) => { let prod_local_3426 = prod_local_3425; { let prod_local_3427 = (prod_local_3426).value; { let prod_local_3428 = low64(prod_local_3427); match prod_local_3428 {
        None => prod_local_3428,
        Some(prod_local_3429) => { let prod_local_3430 = (prod_local_3426).guard; match prod_local_3430 {
        false => prod_local_3428,
        true => { let prod_local_3432 = (prod_local_3426).sticky; match prod_local_3432 {
        false => { let prod_local_3436 = 1; { let prod_local_3437 = (prod_local_3429 & prod_local_3436); { let prod_local_3438 = (prod_local_3437 == prod_local_3436); match prod_local_3438 {
        false => prod_local_3428,
        true => { let prod_local_3440 = 1; { let prod_local_3441 = (prod_local_3429).checked_add(prod_local_3440); prod_local_3441 } },
    } } } },
        true => { let prod_local_3443 = 1; { let prod_local_3444 = (prod_local_3429).checked_add(prod_local_3443); prod_local_3444 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_3445) => { let prod_local_3446 = prod_local_3445; { let prod_local_3450 = 128; { let prod_local_3451 = (val_2857 & prod_local_3450); { let prod_local_3452 = 0; { let prod_local_3453 = (prod_local_3451 == prod_local_3452); { let prod_local_3457 = match prod_local_3453 {
        false => { let prod_local_3455 = false; prod_local_3455 },
        true => { let prod_local_3456 = true; prod_local_3456 },
    }; match prod_local_3457 {
        false => { let prod_local_3459 = Some(prod_local_3446); { let prod_local_3460 = round128(prod_local_3459); match prod_local_3460 {
        None => { let prod_local_3461 = prod_local_3460; match prod_local_3461 {
        None => None,
        Some(prod_local_3463) => { let prod_local_3464 = prod_local_3463; { let prod_local_3465 = (prod_local_3464).value; { let prod_local_3466 = low64(prod_local_3465); match prod_local_3466 {
        None => prod_local_3466,
        Some(prod_local_3467) => { let prod_local_3468 = (prod_local_3464).guard; match prod_local_3468 {
        false => prod_local_3466,
        true => { let prod_local_3470 = (prod_local_3464).sticky; match prod_local_3470 {
        false => { let prod_local_3474 = 1; { let prod_local_3475 = (prod_local_3467 & prod_local_3474); { let prod_local_3476 = (prod_local_3475 == prod_local_3474); match prod_local_3476 {
        false => prod_local_3466,
        true => { let prod_local_3478 = 1; { let prod_local_3479 = (prod_local_3467).checked_add(prod_local_3478); prod_local_3479 } },
    } } } },
        true => { let prod_local_3481 = 1; { let prod_local_3482 = (prod_local_3467).checked_add(prod_local_3481); prod_local_3482 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_3483) => { let prod_local_3484 = prod_local_3483; { let prod_local_3485 = prod_local_3484; { let prod_local_3486 = (prod_local_3485).value; { let prod_local_3487 = low64(prod_local_3486); match prod_local_3487 {
        None => prod_local_3487,
        Some(prod_local_3488) => { let prod_local_3489 = (prod_local_3485).guard; match prod_local_3489 {
        false => prod_local_3487,
        true => { let prod_local_3491 = (prod_local_3485).sticky; match prod_local_3491 {
        false => { let prod_local_3495 = 1; { let prod_local_3496 = (prod_local_3488 & prod_local_3495); { let prod_local_3497 = (prod_local_3496 == prod_local_3495); match prod_local_3497 {
        false => prod_local_3487,
        true => { let prod_local_3499 = 1; { let prod_local_3500 = (prod_local_3488).checked_add(prod_local_3499); prod_local_3500 } },
    } } } },
        true => { let prod_local_3502 = 1; { let prod_local_3503 = (prod_local_3488).checked_add(prod_local_3502); prod_local_3503 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_3504 = prod_local_3446; { let prod_local_3505 = prod_local_3504; { let prod_local_3506 = (prod_local_3505).value; { let prod_local_3507 = low64(prod_local_3506); match prod_local_3507 {
        None => prod_local_3507,
        Some(prod_local_3508) => { let prod_local_3509 = (prod_local_3505).guard; match prod_local_3509 {
        false => prod_local_3507,
        true => { let prod_local_3511 = (prod_local_3505).sticky; match prod_local_3511 {
        false => { let prod_local_3515 = 1; { let prod_local_3516 = (prod_local_3508 & prod_local_3515); { let prod_local_3517 = (prod_local_3516 == prod_local_3515); match prod_local_3517 {
        false => prod_local_3507,
        true => { let prod_local_3519 = 1; { let prod_local_3520 = (prod_local_3508).checked_add(prod_local_3519); prod_local_3520 } },
    } } } },
        true => { let prod_local_3522 = 1; { let prod_local_3523 = (prod_local_3508).checked_add(prod_local_3522); prod_local_3523 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_3524 = prod_local_3408; { let prod_local_3528 = 128; { let prod_local_3529 = (val_2857 & prod_local_3528); { let prod_local_3530 = 0; { let prod_local_3531 = (prod_local_3529 == prod_local_3530); { let prod_local_3535 = match prod_local_3531 {
        false => { let prod_local_3533 = false; prod_local_3533 },
        true => { let prod_local_3534 = true; prod_local_3534 },
    }; match prod_local_3535 {
        false => { let prod_local_3537 = Some(prod_local_3524); { let prod_local_3538 = round128(prod_local_3537); match prod_local_3538 {
        None => { let prod_local_3539 = prod_local_3538; match prod_local_3539 {
        None => None,
        Some(prod_local_3541) => { let prod_local_3542 = prod_local_3541; { let prod_local_3543 = (prod_local_3542).value; { let prod_local_3544 = low64(prod_local_3543); match prod_local_3544 {
        None => prod_local_3544,
        Some(prod_local_3545) => { let prod_local_3546 = (prod_local_3542).guard; match prod_local_3546 {
        false => prod_local_3544,
        true => { let prod_local_3548 = (prod_local_3542).sticky; match prod_local_3548 {
        false => { let prod_local_3552 = 1; { let prod_local_3553 = (prod_local_3545 & prod_local_3552); { let prod_local_3554 = (prod_local_3553 == prod_local_3552); match prod_local_3554 {
        false => prod_local_3544,
        true => { let prod_local_3556 = 1; { let prod_local_3557 = (prod_local_3545).checked_add(prod_local_3556); prod_local_3557 } },
    } } } },
        true => { let prod_local_3559 = 1; { let prod_local_3560 = (prod_local_3545).checked_add(prod_local_3559); prod_local_3560 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_3561) => { let prod_local_3562 = prod_local_3561; { let prod_local_3563 = prod_local_3562; { let prod_local_3564 = (prod_local_3563).value; { let prod_local_3565 = low64(prod_local_3564); match prod_local_3565 {
        None => prod_local_3565,
        Some(prod_local_3566) => { let prod_local_3567 = (prod_local_3563).guard; match prod_local_3567 {
        false => prod_local_3565,
        true => { let prod_local_3569 = (prod_local_3563).sticky; match prod_local_3569 {
        false => { let prod_local_3573 = 1; { let prod_local_3574 = (prod_local_3566 & prod_local_3573); { let prod_local_3575 = (prod_local_3574 == prod_local_3573); match prod_local_3575 {
        false => prod_local_3565,
        true => { let prod_local_3577 = 1; { let prod_local_3578 = (prod_local_3566).checked_add(prod_local_3577); prod_local_3578 } },
    } } } },
        true => { let prod_local_3580 = 1; { let prod_local_3581 = (prod_local_3566).checked_add(prod_local_3580); prod_local_3581 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_3582 = prod_local_3524; { let prod_local_3583 = prod_local_3582; { let prod_local_3584 = (prod_local_3583).value; { let prod_local_3585 = low64(prod_local_3584); match prod_local_3585 {
        None => prod_local_3585,
        Some(prod_local_3586) => { let prod_local_3587 = (prod_local_3583).guard; match prod_local_3587 {
        false => prod_local_3585,
        true => { let prod_local_3589 = (prod_local_3583).sticky; match prod_local_3589 {
        false => { let prod_local_3593 = 1; { let prod_local_3594 = (prod_local_3586 & prod_local_3593); { let prod_local_3595 = (prod_local_3594 == prod_local_3593); match prod_local_3595 {
        false => prod_local_3585,
        true => { let prod_local_3597 = 1; { let prod_local_3598 = (prod_local_3586).checked_add(prod_local_3597); prod_local_3598 } },
    } } } },
        true => { let prod_local_3600 = 1; { let prod_local_3601 = (prod_local_3586).checked_add(prod_local_3600); prod_local_3601 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } } } } } },
    } } } } } } },
    } } } } } } },
    } } } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_3602 = val_2930; { let prod_local_3606 = 4; { let prod_local_3607 = (val_2857 & prod_local_3606); { let prod_local_3608 = 0; { let prod_local_3609 = (prod_local_3607 == prod_local_3608); { let prod_local_3613 = match prod_local_3609 {
        false => { let prod_local_3611 = false; prod_local_3611 },
        true => { let prod_local_3612 = true; prod_local_3612 },
    }; match prod_local_3613 {
        false => { let prod_local_3615 = Some(prod_local_3602); { let prod_local_3616 = round4(prod_local_3615); match prod_local_3616 {
        None => { let prod_local_3617 = prod_local_3616; match prod_local_3617 {
        None => None,
        Some(prod_local_3619) => { let prod_local_3620 = prod_local_3619; { let prod_local_3621 = (prod_local_3620).value; { let prod_local_3622 = low64(prod_local_3621); match prod_local_3622 {
        None => prod_local_3622,
        Some(prod_local_3623) => { let prod_local_3624 = (prod_local_3620).guard; match prod_local_3624 {
        false => prod_local_3622,
        true => { let prod_local_3626 = (prod_local_3620).sticky; match prod_local_3626 {
        false => { let prod_local_3630 = 1; { let prod_local_3631 = (prod_local_3623 & prod_local_3630); { let prod_local_3632 = (prod_local_3631 == prod_local_3630); match prod_local_3632 {
        false => prod_local_3622,
        true => { let prod_local_3634 = 1; { let prod_local_3635 = (prod_local_3623).checked_add(prod_local_3634); prod_local_3635 } },
    } } } },
        true => { let prod_local_3637 = 1; { let prod_local_3638 = (prod_local_3623).checked_add(prod_local_3637); prod_local_3638 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_3639) => { let prod_local_3640 = prod_local_3639; { let prod_local_3644 = 8; { let prod_local_3645 = (val_2857 & prod_local_3644); { let prod_local_3646 = 0; { let prod_local_3647 = (prod_local_3645 == prod_local_3646); { let prod_local_3651 = match prod_local_3647 {
        false => { let prod_local_3649 = false; prod_local_3649 },
        true => { let prod_local_3650 = true; prod_local_3650 },
    }; match prod_local_3651 {
        false => { let prod_local_3653 = Some(prod_local_3640); { let prod_local_3654 = round8(prod_local_3653); match prod_local_3654 {
        None => { let prod_local_3655 = prod_local_3654; match prod_local_3655 {
        None => None,
        Some(prod_local_3657) => { let prod_local_3658 = prod_local_3657; { let prod_local_3659 = (prod_local_3658).value; { let prod_local_3660 = low64(prod_local_3659); match prod_local_3660 {
        None => prod_local_3660,
        Some(prod_local_3661) => { let prod_local_3662 = (prod_local_3658).guard; match prod_local_3662 {
        false => prod_local_3660,
        true => { let prod_local_3664 = (prod_local_3658).sticky; match prod_local_3664 {
        false => { let prod_local_3668 = 1; { let prod_local_3669 = (prod_local_3661 & prod_local_3668); { let prod_local_3670 = (prod_local_3669 == prod_local_3668); match prod_local_3670 {
        false => prod_local_3660,
        true => { let prod_local_3672 = 1; { let prod_local_3673 = (prod_local_3661).checked_add(prod_local_3672); prod_local_3673 } },
    } } } },
        true => { let prod_local_3675 = 1; { let prod_local_3676 = (prod_local_3661).checked_add(prod_local_3675); prod_local_3676 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_3677) => { let prod_local_3678 = prod_local_3677; { let prod_local_3682 = 16; { let prod_local_3683 = (val_2857 & prod_local_3682); { let prod_local_3684 = 0; { let prod_local_3685 = (prod_local_3683 == prod_local_3684); { let prod_local_3689 = match prod_local_3685 {
        false => { let prod_local_3687 = false; prod_local_3687 },
        true => { let prod_local_3688 = true; prod_local_3688 },
    }; match prod_local_3689 {
        false => { let prod_local_3691 = Some(prod_local_3678); { let prod_local_3692 = round16(prod_local_3691); match prod_local_3692 {
        None => { let prod_local_3693 = prod_local_3692; match prod_local_3693 {
        None => None,
        Some(prod_local_3695) => { let prod_local_3696 = prod_local_3695; { let prod_local_3697 = (prod_local_3696).value; { let prod_local_3698 = low64(prod_local_3697); match prod_local_3698 {
        None => prod_local_3698,
        Some(prod_local_3699) => { let prod_local_3700 = (prod_local_3696).guard; match prod_local_3700 {
        false => prod_local_3698,
        true => { let prod_local_3702 = (prod_local_3696).sticky; match prod_local_3702 {
        false => { let prod_local_3706 = 1; { let prod_local_3707 = (prod_local_3699 & prod_local_3706); { let prod_local_3708 = (prod_local_3707 == prod_local_3706); match prod_local_3708 {
        false => prod_local_3698,
        true => { let prod_local_3710 = 1; { let prod_local_3711 = (prod_local_3699).checked_add(prod_local_3710); prod_local_3711 } },
    } } } },
        true => { let prod_local_3713 = 1; { let prod_local_3714 = (prod_local_3699).checked_add(prod_local_3713); prod_local_3714 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_3715) => { let prod_local_3716 = prod_local_3715; { let prod_local_3720 = 32; { let prod_local_3721 = (val_2857 & prod_local_3720); { let prod_local_3722 = 0; { let prod_local_3723 = (prod_local_3721 == prod_local_3722); { let prod_local_3727 = match prod_local_3723 {
        false => { let prod_local_3725 = false; prod_local_3725 },
        true => { let prod_local_3726 = true; prod_local_3726 },
    }; match prod_local_3727 {
        false => { let prod_local_3729 = Some(prod_local_3716); { let prod_local_3730 = round32(prod_local_3729); match prod_local_3730 {
        None => { let prod_local_3731 = prod_local_3730; match prod_local_3731 {
        None => None,
        Some(prod_local_3733) => { let prod_local_3734 = prod_local_3733; { let prod_local_3735 = (prod_local_3734).value; { let prod_local_3736 = low64(prod_local_3735); match prod_local_3736 {
        None => prod_local_3736,
        Some(prod_local_3737) => { let prod_local_3738 = (prod_local_3734).guard; match prod_local_3738 {
        false => prod_local_3736,
        true => { let prod_local_3740 = (prod_local_3734).sticky; match prod_local_3740 {
        false => { let prod_local_3744 = 1; { let prod_local_3745 = (prod_local_3737 & prod_local_3744); { let prod_local_3746 = (prod_local_3745 == prod_local_3744); match prod_local_3746 {
        false => prod_local_3736,
        true => { let prod_local_3748 = 1; { let prod_local_3749 = (prod_local_3737).checked_add(prod_local_3748); prod_local_3749 } },
    } } } },
        true => { let prod_local_3751 = 1; { let prod_local_3752 = (prod_local_3737).checked_add(prod_local_3751); prod_local_3752 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_3753) => { let prod_local_3754 = prod_local_3753; { let prod_local_3758 = 64; { let prod_local_3759 = (val_2857 & prod_local_3758); { let prod_local_3760 = 0; { let prod_local_3761 = (prod_local_3759 == prod_local_3760); { let prod_local_3765 = match prod_local_3761 {
        false => { let prod_local_3763 = false; prod_local_3763 },
        true => { let prod_local_3764 = true; prod_local_3764 },
    }; match prod_local_3765 {
        false => { let prod_local_3767 = Some(prod_local_3754); { let prod_local_3768 = round64(prod_local_3767); match prod_local_3768 {
        None => { let prod_local_3769 = prod_local_3768; match prod_local_3769 {
        None => None,
        Some(prod_local_3771) => { let prod_local_3772 = prod_local_3771; { let prod_local_3773 = (prod_local_3772).value; { let prod_local_3774 = low64(prod_local_3773); match prod_local_3774 {
        None => prod_local_3774,
        Some(prod_local_3775) => { let prod_local_3776 = (prod_local_3772).guard; match prod_local_3776 {
        false => prod_local_3774,
        true => { let prod_local_3778 = (prod_local_3772).sticky; match prod_local_3778 {
        false => { let prod_local_3782 = 1; { let prod_local_3783 = (prod_local_3775 & prod_local_3782); { let prod_local_3784 = (prod_local_3783 == prod_local_3782); match prod_local_3784 {
        false => prod_local_3774,
        true => { let prod_local_3786 = 1; { let prod_local_3787 = (prod_local_3775).checked_add(prod_local_3786); prod_local_3787 } },
    } } } },
        true => { let prod_local_3789 = 1; { let prod_local_3790 = (prod_local_3775).checked_add(prod_local_3789); prod_local_3790 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_3791) => { let prod_local_3792 = prod_local_3791; { let prod_local_3796 = 128; { let prod_local_3797 = (val_2857 & prod_local_3796); { let prod_local_3798 = 0; { let prod_local_3799 = (prod_local_3797 == prod_local_3798); { let prod_local_3803 = match prod_local_3799 {
        false => { let prod_local_3801 = false; prod_local_3801 },
        true => { let prod_local_3802 = true; prod_local_3802 },
    }; match prod_local_3803 {
        false => { let prod_local_3805 = Some(prod_local_3792); { let prod_local_3806 = round128(prod_local_3805); match prod_local_3806 {
        None => { let prod_local_3807 = prod_local_3806; match prod_local_3807 {
        None => None,
        Some(prod_local_3809) => { let prod_local_3810 = prod_local_3809; { let prod_local_3811 = (prod_local_3810).value; { let prod_local_3812 = low64(prod_local_3811); match prod_local_3812 {
        None => prod_local_3812,
        Some(prod_local_3813) => { let prod_local_3814 = (prod_local_3810).guard; match prod_local_3814 {
        false => prod_local_3812,
        true => { let prod_local_3816 = (prod_local_3810).sticky; match prod_local_3816 {
        false => { let prod_local_3820 = 1; { let prod_local_3821 = (prod_local_3813 & prod_local_3820); { let prod_local_3822 = (prod_local_3821 == prod_local_3820); match prod_local_3822 {
        false => prod_local_3812,
        true => { let prod_local_3824 = 1; { let prod_local_3825 = (prod_local_3813).checked_add(prod_local_3824); prod_local_3825 } },
    } } } },
        true => { let prod_local_3827 = 1; { let prod_local_3828 = (prod_local_3813).checked_add(prod_local_3827); prod_local_3828 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_3829) => { let prod_local_3830 = prod_local_3829; { let prod_local_3831 = prod_local_3830; { let prod_local_3832 = (prod_local_3831).value; { let prod_local_3833 = low64(prod_local_3832); match prod_local_3833 {
        None => prod_local_3833,
        Some(prod_local_3834) => { let prod_local_3835 = (prod_local_3831).guard; match prod_local_3835 {
        false => prod_local_3833,
        true => { let prod_local_3837 = (prod_local_3831).sticky; match prod_local_3837 {
        false => { let prod_local_3841 = 1; { let prod_local_3842 = (prod_local_3834 & prod_local_3841); { let prod_local_3843 = (prod_local_3842 == prod_local_3841); match prod_local_3843 {
        false => prod_local_3833,
        true => { let prod_local_3845 = 1; { let prod_local_3846 = (prod_local_3834).checked_add(prod_local_3845); prod_local_3846 } },
    } } } },
        true => { let prod_local_3848 = 1; { let prod_local_3849 = (prod_local_3834).checked_add(prod_local_3848); prod_local_3849 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_3850 = prod_local_3792; { let prod_local_3851 = prod_local_3850; { let prod_local_3852 = (prod_local_3851).value; { let prod_local_3853 = low64(prod_local_3852); match prod_local_3853 {
        None => prod_local_3853,
        Some(prod_local_3854) => { let prod_local_3855 = (prod_local_3851).guard; match prod_local_3855 {
        false => prod_local_3853,
        true => { let prod_local_3857 = (prod_local_3851).sticky; match prod_local_3857 {
        false => { let prod_local_3861 = 1; { let prod_local_3862 = (prod_local_3854 & prod_local_3861); { let prod_local_3863 = (prod_local_3862 == prod_local_3861); match prod_local_3863 {
        false => prod_local_3853,
        true => { let prod_local_3865 = 1; { let prod_local_3866 = (prod_local_3854).checked_add(prod_local_3865); prod_local_3866 } },
    } } } },
        true => { let prod_local_3868 = 1; { let prod_local_3869 = (prod_local_3854).checked_add(prod_local_3868); prod_local_3869 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_3870 = prod_local_3754; { let prod_local_3874 = 128; { let prod_local_3875 = (val_2857 & prod_local_3874); { let prod_local_3876 = 0; { let prod_local_3877 = (prod_local_3875 == prod_local_3876); { let prod_local_3881 = match prod_local_3877 {
        false => { let prod_local_3879 = false; prod_local_3879 },
        true => { let prod_local_3880 = true; prod_local_3880 },
    }; match prod_local_3881 {
        false => { let prod_local_3883 = Some(prod_local_3870); { let prod_local_3884 = round128(prod_local_3883); match prod_local_3884 {
        None => { let prod_local_3885 = prod_local_3884; match prod_local_3885 {
        None => None,
        Some(prod_local_3887) => { let prod_local_3888 = prod_local_3887; { let prod_local_3889 = (prod_local_3888).value; { let prod_local_3890 = low64(prod_local_3889); match prod_local_3890 {
        None => prod_local_3890,
        Some(prod_local_3891) => { let prod_local_3892 = (prod_local_3888).guard; match prod_local_3892 {
        false => prod_local_3890,
        true => { let prod_local_3894 = (prod_local_3888).sticky; match prod_local_3894 {
        false => { let prod_local_3898 = 1; { let prod_local_3899 = (prod_local_3891 & prod_local_3898); { let prod_local_3900 = (prod_local_3899 == prod_local_3898); match prod_local_3900 {
        false => prod_local_3890,
        true => { let prod_local_3902 = 1; { let prod_local_3903 = (prod_local_3891).checked_add(prod_local_3902); prod_local_3903 } },
    } } } },
        true => { let prod_local_3905 = 1; { let prod_local_3906 = (prod_local_3891).checked_add(prod_local_3905); prod_local_3906 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_3907) => { let prod_local_3908 = prod_local_3907; { let prod_local_3909 = prod_local_3908; { let prod_local_3910 = (prod_local_3909).value; { let prod_local_3911 = low64(prod_local_3910); match prod_local_3911 {
        None => prod_local_3911,
        Some(prod_local_3912) => { let prod_local_3913 = (prod_local_3909).guard; match prod_local_3913 {
        false => prod_local_3911,
        true => { let prod_local_3915 = (prod_local_3909).sticky; match prod_local_3915 {
        false => { let prod_local_3919 = 1; { let prod_local_3920 = (prod_local_3912 & prod_local_3919); { let prod_local_3921 = (prod_local_3920 == prod_local_3919); match prod_local_3921 {
        false => prod_local_3911,
        true => { let prod_local_3923 = 1; { let prod_local_3924 = (prod_local_3912).checked_add(prod_local_3923); prod_local_3924 } },
    } } } },
        true => { let prod_local_3926 = 1; { let prod_local_3927 = (prod_local_3912).checked_add(prod_local_3926); prod_local_3927 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_3928 = prod_local_3870; { let prod_local_3929 = prod_local_3928; { let prod_local_3930 = (prod_local_3929).value; { let prod_local_3931 = low64(prod_local_3930); match prod_local_3931 {
        None => prod_local_3931,
        Some(prod_local_3932) => { let prod_local_3933 = (prod_local_3929).guard; match prod_local_3933 {
        false => prod_local_3931,
        true => { let prod_local_3935 = (prod_local_3929).sticky; match prod_local_3935 {
        false => { let prod_local_3939 = 1; { let prod_local_3940 = (prod_local_3932 & prod_local_3939); { let prod_local_3941 = (prod_local_3940 == prod_local_3939); match prod_local_3941 {
        false => prod_local_3931,
        true => { let prod_local_3943 = 1; { let prod_local_3944 = (prod_local_3932).checked_add(prod_local_3943); prod_local_3944 } },
    } } } },
        true => { let prod_local_3946 = 1; { let prod_local_3947 = (prod_local_3932).checked_add(prod_local_3946); prod_local_3947 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_3948 = prod_local_3716; { let prod_local_3952 = 64; { let prod_local_3953 = (val_2857 & prod_local_3952); { let prod_local_3954 = 0; { let prod_local_3955 = (prod_local_3953 == prod_local_3954); { let prod_local_3959 = match prod_local_3955 {
        false => { let prod_local_3957 = false; prod_local_3957 },
        true => { let prod_local_3958 = true; prod_local_3958 },
    }; match prod_local_3959 {
        false => { let prod_local_3961 = Some(prod_local_3948); { let prod_local_3962 = round64(prod_local_3961); match prod_local_3962 {
        None => { let prod_local_3963 = prod_local_3962; match prod_local_3963 {
        None => None,
        Some(prod_local_3965) => { let prod_local_3966 = prod_local_3965; { let prod_local_3967 = (prod_local_3966).value; { let prod_local_3968 = low64(prod_local_3967); match prod_local_3968 {
        None => prod_local_3968,
        Some(prod_local_3969) => { let prod_local_3970 = (prod_local_3966).guard; match prod_local_3970 {
        false => prod_local_3968,
        true => { let prod_local_3972 = (prod_local_3966).sticky; match prod_local_3972 {
        false => { let prod_local_3976 = 1; { let prod_local_3977 = (prod_local_3969 & prod_local_3976); { let prod_local_3978 = (prod_local_3977 == prod_local_3976); match prod_local_3978 {
        false => prod_local_3968,
        true => { let prod_local_3980 = 1; { let prod_local_3981 = (prod_local_3969).checked_add(prod_local_3980); prod_local_3981 } },
    } } } },
        true => { let prod_local_3983 = 1; { let prod_local_3984 = (prod_local_3969).checked_add(prod_local_3983); prod_local_3984 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_3985) => { let prod_local_3986 = prod_local_3985; { let prod_local_3990 = 128; { let prod_local_3991 = (val_2857 & prod_local_3990); { let prod_local_3992 = 0; { let prod_local_3993 = (prod_local_3991 == prod_local_3992); { let prod_local_3997 = match prod_local_3993 {
        false => { let prod_local_3995 = false; prod_local_3995 },
        true => { let prod_local_3996 = true; prod_local_3996 },
    }; match prod_local_3997 {
        false => { let prod_local_3999 = Some(prod_local_3986); { let prod_local_4000 = round128(prod_local_3999); match prod_local_4000 {
        None => { let prod_local_4001 = prod_local_4000; match prod_local_4001 {
        None => None,
        Some(prod_local_4003) => { let prod_local_4004 = prod_local_4003; { let prod_local_4005 = (prod_local_4004).value; { let prod_local_4006 = low64(prod_local_4005); match prod_local_4006 {
        None => prod_local_4006,
        Some(prod_local_4007) => { let prod_local_4008 = (prod_local_4004).guard; match prod_local_4008 {
        false => prod_local_4006,
        true => { let prod_local_4010 = (prod_local_4004).sticky; match prod_local_4010 {
        false => { let prod_local_4014 = 1; { let prod_local_4015 = (prod_local_4007 & prod_local_4014); { let prod_local_4016 = (prod_local_4015 == prod_local_4014); match prod_local_4016 {
        false => prod_local_4006,
        true => { let prod_local_4018 = 1; { let prod_local_4019 = (prod_local_4007).checked_add(prod_local_4018); prod_local_4019 } },
    } } } },
        true => { let prod_local_4021 = 1; { let prod_local_4022 = (prod_local_4007).checked_add(prod_local_4021); prod_local_4022 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_4023) => { let prod_local_4024 = prod_local_4023; { let prod_local_4025 = prod_local_4024; { let prod_local_4026 = (prod_local_4025).value; { let prod_local_4027 = low64(prod_local_4026); match prod_local_4027 {
        None => prod_local_4027,
        Some(prod_local_4028) => { let prod_local_4029 = (prod_local_4025).guard; match prod_local_4029 {
        false => prod_local_4027,
        true => { let prod_local_4031 = (prod_local_4025).sticky; match prod_local_4031 {
        false => { let prod_local_4035 = 1; { let prod_local_4036 = (prod_local_4028 & prod_local_4035); { let prod_local_4037 = (prod_local_4036 == prod_local_4035); match prod_local_4037 {
        false => prod_local_4027,
        true => { let prod_local_4039 = 1; { let prod_local_4040 = (prod_local_4028).checked_add(prod_local_4039); prod_local_4040 } },
    } } } },
        true => { let prod_local_4042 = 1; { let prod_local_4043 = (prod_local_4028).checked_add(prod_local_4042); prod_local_4043 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_4044 = prod_local_3986; { let prod_local_4045 = prod_local_4044; { let prod_local_4046 = (prod_local_4045).value; { let prod_local_4047 = low64(prod_local_4046); match prod_local_4047 {
        None => prod_local_4047,
        Some(prod_local_4048) => { let prod_local_4049 = (prod_local_4045).guard; match prod_local_4049 {
        false => prod_local_4047,
        true => { let prod_local_4051 = (prod_local_4045).sticky; match prod_local_4051 {
        false => { let prod_local_4055 = 1; { let prod_local_4056 = (prod_local_4048 & prod_local_4055); { let prod_local_4057 = (prod_local_4056 == prod_local_4055); match prod_local_4057 {
        false => prod_local_4047,
        true => { let prod_local_4059 = 1; { let prod_local_4060 = (prod_local_4048).checked_add(prod_local_4059); prod_local_4060 } },
    } } } },
        true => { let prod_local_4062 = 1; { let prod_local_4063 = (prod_local_4048).checked_add(prod_local_4062); prod_local_4063 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_4064 = prod_local_3948; { let prod_local_4068 = 128; { let prod_local_4069 = (val_2857 & prod_local_4068); { let prod_local_4070 = 0; { let prod_local_4071 = (prod_local_4069 == prod_local_4070); { let prod_local_4075 = match prod_local_4071 {
        false => { let prod_local_4073 = false; prod_local_4073 },
        true => { let prod_local_4074 = true; prod_local_4074 },
    }; match prod_local_4075 {
        false => { let prod_local_4077 = Some(prod_local_4064); { let prod_local_4078 = round128(prod_local_4077); match prod_local_4078 {
        None => { let prod_local_4079 = prod_local_4078; match prod_local_4079 {
        None => None,
        Some(prod_local_4081) => { let prod_local_4082 = prod_local_4081; { let prod_local_4083 = (prod_local_4082).value; { let prod_local_4084 = low64(prod_local_4083); match prod_local_4084 {
        None => prod_local_4084,
        Some(prod_local_4085) => { let prod_local_4086 = (prod_local_4082).guard; match prod_local_4086 {
        false => prod_local_4084,
        true => { let prod_local_4088 = (prod_local_4082).sticky; match prod_local_4088 {
        false => { let prod_local_4092 = 1; { let prod_local_4093 = (prod_local_4085 & prod_local_4092); { let prod_local_4094 = (prod_local_4093 == prod_local_4092); match prod_local_4094 {
        false => prod_local_4084,
        true => { let prod_local_4096 = 1; { let prod_local_4097 = (prod_local_4085).checked_add(prod_local_4096); prod_local_4097 } },
    } } } },
        true => { let prod_local_4099 = 1; { let prod_local_4100 = (prod_local_4085).checked_add(prod_local_4099); prod_local_4100 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_4101) => { let prod_local_4102 = prod_local_4101; { let prod_local_4103 = prod_local_4102; { let prod_local_4104 = (prod_local_4103).value; { let prod_local_4105 = low64(prod_local_4104); match prod_local_4105 {
        None => prod_local_4105,
        Some(prod_local_4106) => { let prod_local_4107 = (prod_local_4103).guard; match prod_local_4107 {
        false => prod_local_4105,
        true => { let prod_local_4109 = (prod_local_4103).sticky; match prod_local_4109 {
        false => { let prod_local_4113 = 1; { let prod_local_4114 = (prod_local_4106 & prod_local_4113); { let prod_local_4115 = (prod_local_4114 == prod_local_4113); match prod_local_4115 {
        false => prod_local_4105,
        true => { let prod_local_4117 = 1; { let prod_local_4118 = (prod_local_4106).checked_add(prod_local_4117); prod_local_4118 } },
    } } } },
        true => { let prod_local_4120 = 1; { let prod_local_4121 = (prod_local_4106).checked_add(prod_local_4120); prod_local_4121 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_4122 = prod_local_4064; { let prod_local_4123 = prod_local_4122; { let prod_local_4124 = (prod_local_4123).value; { let prod_local_4125 = low64(prod_local_4124); match prod_local_4125 {
        None => prod_local_4125,
        Some(prod_local_4126) => { let prod_local_4127 = (prod_local_4123).guard; match prod_local_4127 {
        false => prod_local_4125,
        true => { let prod_local_4129 = (prod_local_4123).sticky; match prod_local_4129 {
        false => { let prod_local_4133 = 1; { let prod_local_4134 = (prod_local_4126 & prod_local_4133); { let prod_local_4135 = (prod_local_4134 == prod_local_4133); match prod_local_4135 {
        false => prod_local_4125,
        true => { let prod_local_4137 = 1; { let prod_local_4138 = (prod_local_4126).checked_add(prod_local_4137); prod_local_4138 } },
    } } } },
        true => { let prod_local_4140 = 1; { let prod_local_4141 = (prod_local_4126).checked_add(prod_local_4140); prod_local_4141 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_4142 = prod_local_3678; { let prod_local_4146 = 32; { let prod_local_4147 = (val_2857 & prod_local_4146); { let prod_local_4148 = 0; { let prod_local_4149 = (prod_local_4147 == prod_local_4148); { let prod_local_4153 = match prod_local_4149 {
        false => { let prod_local_4151 = false; prod_local_4151 },
        true => { let prod_local_4152 = true; prod_local_4152 },
    }; match prod_local_4153 {
        false => { let prod_local_4155 = Some(prod_local_4142); { let prod_local_4156 = round32(prod_local_4155); match prod_local_4156 {
        None => { let prod_local_4157 = prod_local_4156; match prod_local_4157 {
        None => None,
        Some(prod_local_4159) => { let prod_local_4160 = prod_local_4159; { let prod_local_4161 = (prod_local_4160).value; { let prod_local_4162 = low64(prod_local_4161); match prod_local_4162 {
        None => prod_local_4162,
        Some(prod_local_4163) => { let prod_local_4164 = (prod_local_4160).guard; match prod_local_4164 {
        false => prod_local_4162,
        true => { let prod_local_4166 = (prod_local_4160).sticky; match prod_local_4166 {
        false => { let prod_local_4170 = 1; { let prod_local_4171 = (prod_local_4163 & prod_local_4170); { let prod_local_4172 = (prod_local_4171 == prod_local_4170); match prod_local_4172 {
        false => prod_local_4162,
        true => { let prod_local_4174 = 1; { let prod_local_4175 = (prod_local_4163).checked_add(prod_local_4174); prod_local_4175 } },
    } } } },
        true => { let prod_local_4177 = 1; { let prod_local_4178 = (prod_local_4163).checked_add(prod_local_4177); prod_local_4178 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_4179) => { let prod_local_4180 = prod_local_4179; { let prod_local_4184 = 64; { let prod_local_4185 = (val_2857 & prod_local_4184); { let prod_local_4186 = 0; { let prod_local_4187 = (prod_local_4185 == prod_local_4186); { let prod_local_4191 = match prod_local_4187 {
        false => { let prod_local_4189 = false; prod_local_4189 },
        true => { let prod_local_4190 = true; prod_local_4190 },
    }; match prod_local_4191 {
        false => { let prod_local_4193 = Some(prod_local_4180); { let prod_local_4194 = round64(prod_local_4193); match prod_local_4194 {
        None => { let prod_local_4195 = prod_local_4194; match prod_local_4195 {
        None => None,
        Some(prod_local_4197) => { let prod_local_4198 = prod_local_4197; { let prod_local_4199 = (prod_local_4198).value; { let prod_local_4200 = low64(prod_local_4199); match prod_local_4200 {
        None => prod_local_4200,
        Some(prod_local_4201) => { let prod_local_4202 = (prod_local_4198).guard; match prod_local_4202 {
        false => prod_local_4200,
        true => { let prod_local_4204 = (prod_local_4198).sticky; match prod_local_4204 {
        false => { let prod_local_4208 = 1; { let prod_local_4209 = (prod_local_4201 & prod_local_4208); { let prod_local_4210 = (prod_local_4209 == prod_local_4208); match prod_local_4210 {
        false => prod_local_4200,
        true => { let prod_local_4212 = 1; { let prod_local_4213 = (prod_local_4201).checked_add(prod_local_4212); prod_local_4213 } },
    } } } },
        true => { let prod_local_4215 = 1; { let prod_local_4216 = (prod_local_4201).checked_add(prod_local_4215); prod_local_4216 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_4217) => { let prod_local_4218 = prod_local_4217; { let prod_local_4222 = 128; { let prod_local_4223 = (val_2857 & prod_local_4222); { let prod_local_4224 = 0; { let prod_local_4225 = (prod_local_4223 == prod_local_4224); { let prod_local_4229 = match prod_local_4225 {
        false => { let prod_local_4227 = false; prod_local_4227 },
        true => { let prod_local_4228 = true; prod_local_4228 },
    }; match prod_local_4229 {
        false => { let prod_local_4231 = Some(prod_local_4218); { let prod_local_4232 = round128(prod_local_4231); match prod_local_4232 {
        None => { let prod_local_4233 = prod_local_4232; match prod_local_4233 {
        None => None,
        Some(prod_local_4235) => { let prod_local_4236 = prod_local_4235; { let prod_local_4237 = (prod_local_4236).value; { let prod_local_4238 = low64(prod_local_4237); match prod_local_4238 {
        None => prod_local_4238,
        Some(prod_local_4239) => { let prod_local_4240 = (prod_local_4236).guard; match prod_local_4240 {
        false => prod_local_4238,
        true => { let prod_local_4242 = (prod_local_4236).sticky; match prod_local_4242 {
        false => { let prod_local_4246 = 1; { let prod_local_4247 = (prod_local_4239 & prod_local_4246); { let prod_local_4248 = (prod_local_4247 == prod_local_4246); match prod_local_4248 {
        false => prod_local_4238,
        true => { let prod_local_4250 = 1; { let prod_local_4251 = (prod_local_4239).checked_add(prod_local_4250); prod_local_4251 } },
    } } } },
        true => { let prod_local_4253 = 1; { let prod_local_4254 = (prod_local_4239).checked_add(prod_local_4253); prod_local_4254 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_4255) => { let prod_local_4256 = prod_local_4255; { let prod_local_4257 = prod_local_4256; { let prod_local_4258 = (prod_local_4257).value; { let prod_local_4259 = low64(prod_local_4258); match prod_local_4259 {
        None => prod_local_4259,
        Some(prod_local_4260) => { let prod_local_4261 = (prod_local_4257).guard; match prod_local_4261 {
        false => prod_local_4259,
        true => { let prod_local_4263 = (prod_local_4257).sticky; match prod_local_4263 {
        false => { let prod_local_4267 = 1; { let prod_local_4268 = (prod_local_4260 & prod_local_4267); { let prod_local_4269 = (prod_local_4268 == prod_local_4267); match prod_local_4269 {
        false => prod_local_4259,
        true => { let prod_local_4271 = 1; { let prod_local_4272 = (prod_local_4260).checked_add(prod_local_4271); prod_local_4272 } },
    } } } },
        true => { let prod_local_4274 = 1; { let prod_local_4275 = (prod_local_4260).checked_add(prod_local_4274); prod_local_4275 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_4276 = prod_local_4218; { let prod_local_4277 = prod_local_4276; { let prod_local_4278 = (prod_local_4277).value; { let prod_local_4279 = low64(prod_local_4278); match prod_local_4279 {
        None => prod_local_4279,
        Some(prod_local_4280) => { let prod_local_4281 = (prod_local_4277).guard; match prod_local_4281 {
        false => prod_local_4279,
        true => { let prod_local_4283 = (prod_local_4277).sticky; match prod_local_4283 {
        false => { let prod_local_4287 = 1; { let prod_local_4288 = (prod_local_4280 & prod_local_4287); { let prod_local_4289 = (prod_local_4288 == prod_local_4287); match prod_local_4289 {
        false => prod_local_4279,
        true => { let prod_local_4291 = 1; { let prod_local_4292 = (prod_local_4280).checked_add(prod_local_4291); prod_local_4292 } },
    } } } },
        true => { let prod_local_4294 = 1; { let prod_local_4295 = (prod_local_4280).checked_add(prod_local_4294); prod_local_4295 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_4296 = prod_local_4180; { let prod_local_4300 = 128; { let prod_local_4301 = (val_2857 & prod_local_4300); { let prod_local_4302 = 0; { let prod_local_4303 = (prod_local_4301 == prod_local_4302); { let prod_local_4307 = match prod_local_4303 {
        false => { let prod_local_4305 = false; prod_local_4305 },
        true => { let prod_local_4306 = true; prod_local_4306 },
    }; match prod_local_4307 {
        false => { let prod_local_4309 = Some(prod_local_4296); { let prod_local_4310 = round128(prod_local_4309); match prod_local_4310 {
        None => { let prod_local_4311 = prod_local_4310; match prod_local_4311 {
        None => None,
        Some(prod_local_4313) => { let prod_local_4314 = prod_local_4313; { let prod_local_4315 = (prod_local_4314).value; { let prod_local_4316 = low64(prod_local_4315); match prod_local_4316 {
        None => prod_local_4316,
        Some(prod_local_4317) => { let prod_local_4318 = (prod_local_4314).guard; match prod_local_4318 {
        false => prod_local_4316,
        true => { let prod_local_4320 = (prod_local_4314).sticky; match prod_local_4320 {
        false => { let prod_local_4324 = 1; { let prod_local_4325 = (prod_local_4317 & prod_local_4324); { let prod_local_4326 = (prod_local_4325 == prod_local_4324); match prod_local_4326 {
        false => prod_local_4316,
        true => { let prod_local_4328 = 1; { let prod_local_4329 = (prod_local_4317).checked_add(prod_local_4328); prod_local_4329 } },
    } } } },
        true => { let prod_local_4331 = 1; { let prod_local_4332 = (prod_local_4317).checked_add(prod_local_4331); prod_local_4332 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_4333) => { let prod_local_4334 = prod_local_4333; { let prod_local_4335 = prod_local_4334; { let prod_local_4336 = (prod_local_4335).value; { let prod_local_4337 = low64(prod_local_4336); match prod_local_4337 {
        None => prod_local_4337,
        Some(prod_local_4338) => { let prod_local_4339 = (prod_local_4335).guard; match prod_local_4339 {
        false => prod_local_4337,
        true => { let prod_local_4341 = (prod_local_4335).sticky; match prod_local_4341 {
        false => { let prod_local_4345 = 1; { let prod_local_4346 = (prod_local_4338 & prod_local_4345); { let prod_local_4347 = (prod_local_4346 == prod_local_4345); match prod_local_4347 {
        false => prod_local_4337,
        true => { let prod_local_4349 = 1; { let prod_local_4350 = (prod_local_4338).checked_add(prod_local_4349); prod_local_4350 } },
    } } } },
        true => { let prod_local_4352 = 1; { let prod_local_4353 = (prod_local_4338).checked_add(prod_local_4352); prod_local_4353 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_4354 = prod_local_4296; { let prod_local_4355 = prod_local_4354; { let prod_local_4356 = (prod_local_4355).value; { let prod_local_4357 = low64(prod_local_4356); match prod_local_4357 {
        None => prod_local_4357,
        Some(prod_local_4358) => { let prod_local_4359 = (prod_local_4355).guard; match prod_local_4359 {
        false => prod_local_4357,
        true => { let prod_local_4361 = (prod_local_4355).sticky; match prod_local_4361 {
        false => { let prod_local_4365 = 1; { let prod_local_4366 = (prod_local_4358 & prod_local_4365); { let prod_local_4367 = (prod_local_4366 == prod_local_4365); match prod_local_4367 {
        false => prod_local_4357,
        true => { let prod_local_4369 = 1; { let prod_local_4370 = (prod_local_4358).checked_add(prod_local_4369); prod_local_4370 } },
    } } } },
        true => { let prod_local_4372 = 1; { let prod_local_4373 = (prod_local_4358).checked_add(prod_local_4372); prod_local_4373 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_4374 = prod_local_4142; { let prod_local_4378 = 64; { let prod_local_4379 = (val_2857 & prod_local_4378); { let prod_local_4380 = 0; { let prod_local_4381 = (prod_local_4379 == prod_local_4380); { let prod_local_4385 = match prod_local_4381 {
        false => { let prod_local_4383 = false; prod_local_4383 },
        true => { let prod_local_4384 = true; prod_local_4384 },
    }; match prod_local_4385 {
        false => { let prod_local_4387 = Some(prod_local_4374); { let prod_local_4388 = round64(prod_local_4387); match prod_local_4388 {
        None => { let prod_local_4389 = prod_local_4388; match prod_local_4389 {
        None => None,
        Some(prod_local_4391) => { let prod_local_4392 = prod_local_4391; { let prod_local_4393 = (prod_local_4392).value; { let prod_local_4394 = low64(prod_local_4393); match prod_local_4394 {
        None => prod_local_4394,
        Some(prod_local_4395) => { let prod_local_4396 = (prod_local_4392).guard; match prod_local_4396 {
        false => prod_local_4394,
        true => { let prod_local_4398 = (prod_local_4392).sticky; match prod_local_4398 {
        false => { let prod_local_4402 = 1; { let prod_local_4403 = (prod_local_4395 & prod_local_4402); { let prod_local_4404 = (prod_local_4403 == prod_local_4402); match prod_local_4404 {
        false => prod_local_4394,
        true => { let prod_local_4406 = 1; { let prod_local_4407 = (prod_local_4395).checked_add(prod_local_4406); prod_local_4407 } },
    } } } },
        true => { let prod_local_4409 = 1; { let prod_local_4410 = (prod_local_4395).checked_add(prod_local_4409); prod_local_4410 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_4411) => { let prod_local_4412 = prod_local_4411; { let prod_local_4416 = 128; { let prod_local_4417 = (val_2857 & prod_local_4416); { let prod_local_4418 = 0; { let prod_local_4419 = (prod_local_4417 == prod_local_4418); { let prod_local_4423 = match prod_local_4419 {
        false => { let prod_local_4421 = false; prod_local_4421 },
        true => { let prod_local_4422 = true; prod_local_4422 },
    }; match prod_local_4423 {
        false => { let prod_local_4425 = Some(prod_local_4412); { let prod_local_4426 = round128(prod_local_4425); match prod_local_4426 {
        None => { let prod_local_4427 = prod_local_4426; match prod_local_4427 {
        None => None,
        Some(prod_local_4429) => { let prod_local_4430 = prod_local_4429; { let prod_local_4431 = (prod_local_4430).value; { let prod_local_4432 = low64(prod_local_4431); match prod_local_4432 {
        None => prod_local_4432,
        Some(prod_local_4433) => { let prod_local_4434 = (prod_local_4430).guard; match prod_local_4434 {
        false => prod_local_4432,
        true => { let prod_local_4436 = (prod_local_4430).sticky; match prod_local_4436 {
        false => { let prod_local_4440 = 1; { let prod_local_4441 = (prod_local_4433 & prod_local_4440); { let prod_local_4442 = (prod_local_4441 == prod_local_4440); match prod_local_4442 {
        false => prod_local_4432,
        true => { let prod_local_4444 = 1; { let prod_local_4445 = (prod_local_4433).checked_add(prod_local_4444); prod_local_4445 } },
    } } } },
        true => { let prod_local_4447 = 1; { let prod_local_4448 = (prod_local_4433).checked_add(prod_local_4447); prod_local_4448 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_4449) => { let prod_local_4450 = prod_local_4449; { let prod_local_4451 = prod_local_4450; { let prod_local_4452 = (prod_local_4451).value; { let prod_local_4453 = low64(prod_local_4452); match prod_local_4453 {
        None => prod_local_4453,
        Some(prod_local_4454) => { let prod_local_4455 = (prod_local_4451).guard; match prod_local_4455 {
        false => prod_local_4453,
        true => { let prod_local_4457 = (prod_local_4451).sticky; match prod_local_4457 {
        false => { let prod_local_4461 = 1; { let prod_local_4462 = (prod_local_4454 & prod_local_4461); { let prod_local_4463 = (prod_local_4462 == prod_local_4461); match prod_local_4463 {
        false => prod_local_4453,
        true => { let prod_local_4465 = 1; { let prod_local_4466 = (prod_local_4454).checked_add(prod_local_4465); prod_local_4466 } },
    } } } },
        true => { let prod_local_4468 = 1; { let prod_local_4469 = (prod_local_4454).checked_add(prod_local_4468); prod_local_4469 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_4470 = prod_local_4412; { let prod_local_4471 = prod_local_4470; { let prod_local_4472 = (prod_local_4471).value; { let prod_local_4473 = low64(prod_local_4472); match prod_local_4473 {
        None => prod_local_4473,
        Some(prod_local_4474) => { let prod_local_4475 = (prod_local_4471).guard; match prod_local_4475 {
        false => prod_local_4473,
        true => { let prod_local_4477 = (prod_local_4471).sticky; match prod_local_4477 {
        false => { let prod_local_4481 = 1; { let prod_local_4482 = (prod_local_4474 & prod_local_4481); { let prod_local_4483 = (prod_local_4482 == prod_local_4481); match prod_local_4483 {
        false => prod_local_4473,
        true => { let prod_local_4485 = 1; { let prod_local_4486 = (prod_local_4474).checked_add(prod_local_4485); prod_local_4486 } },
    } } } },
        true => { let prod_local_4488 = 1; { let prod_local_4489 = (prod_local_4474).checked_add(prod_local_4488); prod_local_4489 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_4490 = prod_local_4374; { let prod_local_4494 = 128; { let prod_local_4495 = (val_2857 & prod_local_4494); { let prod_local_4496 = 0; { let prod_local_4497 = (prod_local_4495 == prod_local_4496); { let prod_local_4501 = match prod_local_4497 {
        false => { let prod_local_4499 = false; prod_local_4499 },
        true => { let prod_local_4500 = true; prod_local_4500 },
    }; match prod_local_4501 {
        false => { let prod_local_4503 = Some(prod_local_4490); { let prod_local_4504 = round128(prod_local_4503); match prod_local_4504 {
        None => { let prod_local_4505 = prod_local_4504; match prod_local_4505 {
        None => None,
        Some(prod_local_4507) => { let prod_local_4508 = prod_local_4507; { let prod_local_4509 = (prod_local_4508).value; { let prod_local_4510 = low64(prod_local_4509); match prod_local_4510 {
        None => prod_local_4510,
        Some(prod_local_4511) => { let prod_local_4512 = (prod_local_4508).guard; match prod_local_4512 {
        false => prod_local_4510,
        true => { let prod_local_4514 = (prod_local_4508).sticky; match prod_local_4514 {
        false => { let prod_local_4518 = 1; { let prod_local_4519 = (prod_local_4511 & prod_local_4518); { let prod_local_4520 = (prod_local_4519 == prod_local_4518); match prod_local_4520 {
        false => prod_local_4510,
        true => { let prod_local_4522 = 1; { let prod_local_4523 = (prod_local_4511).checked_add(prod_local_4522); prod_local_4523 } },
    } } } },
        true => { let prod_local_4525 = 1; { let prod_local_4526 = (prod_local_4511).checked_add(prod_local_4525); prod_local_4526 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_4527) => { let prod_local_4528 = prod_local_4527; { let prod_local_4529 = prod_local_4528; { let prod_local_4530 = (prod_local_4529).value; { let prod_local_4531 = low64(prod_local_4530); match prod_local_4531 {
        None => prod_local_4531,
        Some(prod_local_4532) => { let prod_local_4533 = (prod_local_4529).guard; match prod_local_4533 {
        false => prod_local_4531,
        true => { let prod_local_4535 = (prod_local_4529).sticky; match prod_local_4535 {
        false => { let prod_local_4539 = 1; { let prod_local_4540 = (prod_local_4532 & prod_local_4539); { let prod_local_4541 = (prod_local_4540 == prod_local_4539); match prod_local_4541 {
        false => prod_local_4531,
        true => { let prod_local_4543 = 1; { let prod_local_4544 = (prod_local_4532).checked_add(prod_local_4543); prod_local_4544 } },
    } } } },
        true => { let prod_local_4546 = 1; { let prod_local_4547 = (prod_local_4532).checked_add(prod_local_4546); prod_local_4547 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_4548 = prod_local_4490; { let prod_local_4549 = prod_local_4548; { let prod_local_4550 = (prod_local_4549).value; { let prod_local_4551 = low64(prod_local_4550); match prod_local_4551 {
        None => prod_local_4551,
        Some(prod_local_4552) => { let prod_local_4553 = (prod_local_4549).guard; match prod_local_4553 {
        false => prod_local_4551,
        true => { let prod_local_4555 = (prod_local_4549).sticky; match prod_local_4555 {
        false => { let prod_local_4559 = 1; { let prod_local_4560 = (prod_local_4552 & prod_local_4559); { let prod_local_4561 = (prod_local_4560 == prod_local_4559); match prod_local_4561 {
        false => prod_local_4551,
        true => { let prod_local_4563 = 1; { let prod_local_4564 = (prod_local_4552).checked_add(prod_local_4563); prod_local_4564 } },
    } } } },
        true => { let prod_local_4566 = 1; { let prod_local_4567 = (prod_local_4552).checked_add(prod_local_4566); prod_local_4567 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } } } } } },
    } } } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_4568 = prod_local_3640; { let prod_local_4572 = 16; { let prod_local_4573 = (val_2857 & prod_local_4572); { let prod_local_4574 = 0; { let prod_local_4575 = (prod_local_4573 == prod_local_4574); { let prod_local_4579 = match prod_local_4575 {
        false => { let prod_local_4577 = false; prod_local_4577 },
        true => { let prod_local_4578 = true; prod_local_4578 },
    }; match prod_local_4579 {
        false => { let prod_local_4581 = Some(prod_local_4568); { let prod_local_4582 = round16(prod_local_4581); match prod_local_4582 {
        None => { let prod_local_4583 = prod_local_4582; match prod_local_4583 {
        None => None,
        Some(prod_local_4585) => { let prod_local_4586 = prod_local_4585; { let prod_local_4587 = (prod_local_4586).value; { let prod_local_4588 = low64(prod_local_4587); match prod_local_4588 {
        None => prod_local_4588,
        Some(prod_local_4589) => { let prod_local_4590 = (prod_local_4586).guard; match prod_local_4590 {
        false => prod_local_4588,
        true => { let prod_local_4592 = (prod_local_4586).sticky; match prod_local_4592 {
        false => { let prod_local_4596 = 1; { let prod_local_4597 = (prod_local_4589 & prod_local_4596); { let prod_local_4598 = (prod_local_4597 == prod_local_4596); match prod_local_4598 {
        false => prod_local_4588,
        true => { let prod_local_4600 = 1; { let prod_local_4601 = (prod_local_4589).checked_add(prod_local_4600); prod_local_4601 } },
    } } } },
        true => { let prod_local_4603 = 1; { let prod_local_4604 = (prod_local_4589).checked_add(prod_local_4603); prod_local_4604 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_4605) => { let prod_local_4606 = prod_local_4605; { let prod_local_4610 = 32; { let prod_local_4611 = (val_2857 & prod_local_4610); { let prod_local_4612 = 0; { let prod_local_4613 = (prod_local_4611 == prod_local_4612); { let prod_local_4617 = match prod_local_4613 {
        false => { let prod_local_4615 = false; prod_local_4615 },
        true => { let prod_local_4616 = true; prod_local_4616 },
    }; match prod_local_4617 {
        false => { let prod_local_4619 = Some(prod_local_4606); { let prod_local_4620 = round32(prod_local_4619); match prod_local_4620 {
        None => { let prod_local_4621 = prod_local_4620; match prod_local_4621 {
        None => None,
        Some(prod_local_4623) => { let prod_local_4624 = prod_local_4623; { let prod_local_4625 = (prod_local_4624).value; { let prod_local_4626 = low64(prod_local_4625); match prod_local_4626 {
        None => prod_local_4626,
        Some(prod_local_4627) => { let prod_local_4628 = (prod_local_4624).guard; match prod_local_4628 {
        false => prod_local_4626,
        true => { let prod_local_4630 = (prod_local_4624).sticky; match prod_local_4630 {
        false => { let prod_local_4634 = 1; { let prod_local_4635 = (prod_local_4627 & prod_local_4634); { let prod_local_4636 = (prod_local_4635 == prod_local_4634); match prod_local_4636 {
        false => prod_local_4626,
        true => { let prod_local_4638 = 1; { let prod_local_4639 = (prod_local_4627).checked_add(prod_local_4638); prod_local_4639 } },
    } } } },
        true => { let prod_local_4641 = 1; { let prod_local_4642 = (prod_local_4627).checked_add(prod_local_4641); prod_local_4642 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_4643) => { let prod_local_4644 = prod_local_4643; { let prod_local_4648 = 64; { let prod_local_4649 = (val_2857 & prod_local_4648); { let prod_local_4650 = 0; { let prod_local_4651 = (prod_local_4649 == prod_local_4650); { let prod_local_4655 = match prod_local_4651 {
        false => { let prod_local_4653 = false; prod_local_4653 },
        true => { let prod_local_4654 = true; prod_local_4654 },
    }; match prod_local_4655 {
        false => { let prod_local_4657 = Some(prod_local_4644); { let prod_local_4658 = round64(prod_local_4657); match prod_local_4658 {
        None => { let prod_local_4659 = prod_local_4658; match prod_local_4659 {
        None => None,
        Some(prod_local_4661) => { let prod_local_4662 = prod_local_4661; { let prod_local_4663 = (prod_local_4662).value; { let prod_local_4664 = low64(prod_local_4663); match prod_local_4664 {
        None => prod_local_4664,
        Some(prod_local_4665) => { let prod_local_4666 = (prod_local_4662).guard; match prod_local_4666 {
        false => prod_local_4664,
        true => { let prod_local_4668 = (prod_local_4662).sticky; match prod_local_4668 {
        false => { let prod_local_4672 = 1; { let prod_local_4673 = (prod_local_4665 & prod_local_4672); { let prod_local_4674 = (prod_local_4673 == prod_local_4672); match prod_local_4674 {
        false => prod_local_4664,
        true => { let prod_local_4676 = 1; { let prod_local_4677 = (prod_local_4665).checked_add(prod_local_4676); prod_local_4677 } },
    } } } },
        true => { let prod_local_4679 = 1; { let prod_local_4680 = (prod_local_4665).checked_add(prod_local_4679); prod_local_4680 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_4681) => { let prod_local_4682 = prod_local_4681; { let prod_local_4686 = 128; { let prod_local_4687 = (val_2857 & prod_local_4686); { let prod_local_4688 = 0; { let prod_local_4689 = (prod_local_4687 == prod_local_4688); { let prod_local_4693 = match prod_local_4689 {
        false => { let prod_local_4691 = false; prod_local_4691 },
        true => { let prod_local_4692 = true; prod_local_4692 },
    }; match prod_local_4693 {
        false => { let prod_local_4695 = Some(prod_local_4682); { let prod_local_4696 = round128(prod_local_4695); match prod_local_4696 {
        None => { let prod_local_4697 = prod_local_4696; match prod_local_4697 {
        None => None,
        Some(prod_local_4699) => { let prod_local_4700 = prod_local_4699; { let prod_local_4701 = (prod_local_4700).value; { let prod_local_4702 = low64(prod_local_4701); match prod_local_4702 {
        None => prod_local_4702,
        Some(prod_local_4703) => { let prod_local_4704 = (prod_local_4700).guard; match prod_local_4704 {
        false => prod_local_4702,
        true => { let prod_local_4706 = (prod_local_4700).sticky; match prod_local_4706 {
        false => { let prod_local_4710 = 1; { let prod_local_4711 = (prod_local_4703 & prod_local_4710); { let prod_local_4712 = (prod_local_4711 == prod_local_4710); match prod_local_4712 {
        false => prod_local_4702,
        true => { let prod_local_4714 = 1; { let prod_local_4715 = (prod_local_4703).checked_add(prod_local_4714); prod_local_4715 } },
    } } } },
        true => { let prod_local_4717 = 1; { let prod_local_4718 = (prod_local_4703).checked_add(prod_local_4717); prod_local_4718 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_4719) => { let prod_local_4720 = prod_local_4719; { let prod_local_4721 = prod_local_4720; { let prod_local_4722 = (prod_local_4721).value; { let prod_local_4723 = low64(prod_local_4722); match prod_local_4723 {
        None => prod_local_4723,
        Some(prod_local_4724) => { let prod_local_4725 = (prod_local_4721).guard; match prod_local_4725 {
        false => prod_local_4723,
        true => { let prod_local_4727 = (prod_local_4721).sticky; match prod_local_4727 {
        false => { let prod_local_4731 = 1; { let prod_local_4732 = (prod_local_4724 & prod_local_4731); { let prod_local_4733 = (prod_local_4732 == prod_local_4731); match prod_local_4733 {
        false => prod_local_4723,
        true => { let prod_local_4735 = 1; { let prod_local_4736 = (prod_local_4724).checked_add(prod_local_4735); prod_local_4736 } },
    } } } },
        true => { let prod_local_4738 = 1; { let prod_local_4739 = (prod_local_4724).checked_add(prod_local_4738); prod_local_4739 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_4740 = prod_local_4682; { let prod_local_4741 = prod_local_4740; { let prod_local_4742 = (prod_local_4741).value; { let prod_local_4743 = low64(prod_local_4742); match prod_local_4743 {
        None => prod_local_4743,
        Some(prod_local_4744) => { let prod_local_4745 = (prod_local_4741).guard; match prod_local_4745 {
        false => prod_local_4743,
        true => { let prod_local_4747 = (prod_local_4741).sticky; match prod_local_4747 {
        false => { let prod_local_4751 = 1; { let prod_local_4752 = (prod_local_4744 & prod_local_4751); { let prod_local_4753 = (prod_local_4752 == prod_local_4751); match prod_local_4753 {
        false => prod_local_4743,
        true => { let prod_local_4755 = 1; { let prod_local_4756 = (prod_local_4744).checked_add(prod_local_4755); prod_local_4756 } },
    } } } },
        true => { let prod_local_4758 = 1; { let prod_local_4759 = (prod_local_4744).checked_add(prod_local_4758); prod_local_4759 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_4760 = prod_local_4644; { let prod_local_4764 = 128; { let prod_local_4765 = (val_2857 & prod_local_4764); { let prod_local_4766 = 0; { let prod_local_4767 = (prod_local_4765 == prod_local_4766); { let prod_local_4771 = match prod_local_4767 {
        false => { let prod_local_4769 = false; prod_local_4769 },
        true => { let prod_local_4770 = true; prod_local_4770 },
    }; match prod_local_4771 {
        false => { let prod_local_4773 = Some(prod_local_4760); { let prod_local_4774 = round128(prod_local_4773); match prod_local_4774 {
        None => { let prod_local_4775 = prod_local_4774; match prod_local_4775 {
        None => None,
        Some(prod_local_4777) => { let prod_local_4778 = prod_local_4777; { let prod_local_4779 = (prod_local_4778).value; { let prod_local_4780 = low64(prod_local_4779); match prod_local_4780 {
        None => prod_local_4780,
        Some(prod_local_4781) => { let prod_local_4782 = (prod_local_4778).guard; match prod_local_4782 {
        false => prod_local_4780,
        true => { let prod_local_4784 = (prod_local_4778).sticky; match prod_local_4784 {
        false => { let prod_local_4788 = 1; { let prod_local_4789 = (prod_local_4781 & prod_local_4788); { let prod_local_4790 = (prod_local_4789 == prod_local_4788); match prod_local_4790 {
        false => prod_local_4780,
        true => { let prod_local_4792 = 1; { let prod_local_4793 = (prod_local_4781).checked_add(prod_local_4792); prod_local_4793 } },
    } } } },
        true => { let prod_local_4795 = 1; { let prod_local_4796 = (prod_local_4781).checked_add(prod_local_4795); prod_local_4796 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_4797) => { let prod_local_4798 = prod_local_4797; { let prod_local_4799 = prod_local_4798; { let prod_local_4800 = (prod_local_4799).value; { let prod_local_4801 = low64(prod_local_4800); match prod_local_4801 {
        None => prod_local_4801,
        Some(prod_local_4802) => { let prod_local_4803 = (prod_local_4799).guard; match prod_local_4803 {
        false => prod_local_4801,
        true => { let prod_local_4805 = (prod_local_4799).sticky; match prod_local_4805 {
        false => { let prod_local_4809 = 1; { let prod_local_4810 = (prod_local_4802 & prod_local_4809); { let prod_local_4811 = (prod_local_4810 == prod_local_4809); match prod_local_4811 {
        false => prod_local_4801,
        true => { let prod_local_4813 = 1; { let prod_local_4814 = (prod_local_4802).checked_add(prod_local_4813); prod_local_4814 } },
    } } } },
        true => { let prod_local_4816 = 1; { let prod_local_4817 = (prod_local_4802).checked_add(prod_local_4816); prod_local_4817 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_4818 = prod_local_4760; { let prod_local_4819 = prod_local_4818; { let prod_local_4820 = (prod_local_4819).value; { let prod_local_4821 = low64(prod_local_4820); match prod_local_4821 {
        None => prod_local_4821,
        Some(prod_local_4822) => { let prod_local_4823 = (prod_local_4819).guard; match prod_local_4823 {
        false => prod_local_4821,
        true => { let prod_local_4825 = (prod_local_4819).sticky; match prod_local_4825 {
        false => { let prod_local_4829 = 1; { let prod_local_4830 = (prod_local_4822 & prod_local_4829); { let prod_local_4831 = (prod_local_4830 == prod_local_4829); match prod_local_4831 {
        false => prod_local_4821,
        true => { let prod_local_4833 = 1; { let prod_local_4834 = (prod_local_4822).checked_add(prod_local_4833); prod_local_4834 } },
    } } } },
        true => { let prod_local_4836 = 1; { let prod_local_4837 = (prod_local_4822).checked_add(prod_local_4836); prod_local_4837 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_4838 = prod_local_4606; { let prod_local_4842 = 64; { let prod_local_4843 = (val_2857 & prod_local_4842); { let prod_local_4844 = 0; { let prod_local_4845 = (prod_local_4843 == prod_local_4844); { let prod_local_4849 = match prod_local_4845 {
        false => { let prod_local_4847 = false; prod_local_4847 },
        true => { let prod_local_4848 = true; prod_local_4848 },
    }; match prod_local_4849 {
        false => { let prod_local_4851 = Some(prod_local_4838); { let prod_local_4852 = round64(prod_local_4851); match prod_local_4852 {
        None => { let prod_local_4853 = prod_local_4852; match prod_local_4853 {
        None => None,
        Some(prod_local_4855) => { let prod_local_4856 = prod_local_4855; { let prod_local_4857 = (prod_local_4856).value; { let prod_local_4858 = low64(prod_local_4857); match prod_local_4858 {
        None => prod_local_4858,
        Some(prod_local_4859) => { let prod_local_4860 = (prod_local_4856).guard; match prod_local_4860 {
        false => prod_local_4858,
        true => { let prod_local_4862 = (prod_local_4856).sticky; match prod_local_4862 {
        false => { let prod_local_4866 = 1; { let prod_local_4867 = (prod_local_4859 & prod_local_4866); { let prod_local_4868 = (prod_local_4867 == prod_local_4866); match prod_local_4868 {
        false => prod_local_4858,
        true => { let prod_local_4870 = 1; { let prod_local_4871 = (prod_local_4859).checked_add(prod_local_4870); prod_local_4871 } },
    } } } },
        true => { let prod_local_4873 = 1; { let prod_local_4874 = (prod_local_4859).checked_add(prod_local_4873); prod_local_4874 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_4875) => { let prod_local_4876 = prod_local_4875; { let prod_local_4880 = 128; { let prod_local_4881 = (val_2857 & prod_local_4880); { let prod_local_4882 = 0; { let prod_local_4883 = (prod_local_4881 == prod_local_4882); { let prod_local_4887 = match prod_local_4883 {
        false => { let prod_local_4885 = false; prod_local_4885 },
        true => { let prod_local_4886 = true; prod_local_4886 },
    }; match prod_local_4887 {
        false => { let prod_local_4889 = Some(prod_local_4876); { let prod_local_4890 = round128(prod_local_4889); match prod_local_4890 {
        None => { let prod_local_4891 = prod_local_4890; match prod_local_4891 {
        None => None,
        Some(prod_local_4893) => { let prod_local_4894 = prod_local_4893; { let prod_local_4895 = (prod_local_4894).value; { let prod_local_4896 = low64(prod_local_4895); match prod_local_4896 {
        None => prod_local_4896,
        Some(prod_local_4897) => { let prod_local_4898 = (prod_local_4894).guard; match prod_local_4898 {
        false => prod_local_4896,
        true => { let prod_local_4900 = (prod_local_4894).sticky; match prod_local_4900 {
        false => { let prod_local_4904 = 1; { let prod_local_4905 = (prod_local_4897 & prod_local_4904); { let prod_local_4906 = (prod_local_4905 == prod_local_4904); match prod_local_4906 {
        false => prod_local_4896,
        true => { let prod_local_4908 = 1; { let prod_local_4909 = (prod_local_4897).checked_add(prod_local_4908); prod_local_4909 } },
    } } } },
        true => { let prod_local_4911 = 1; { let prod_local_4912 = (prod_local_4897).checked_add(prod_local_4911); prod_local_4912 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_4913) => { let prod_local_4914 = prod_local_4913; { let prod_local_4915 = prod_local_4914; { let prod_local_4916 = (prod_local_4915).value; { let prod_local_4917 = low64(prod_local_4916); match prod_local_4917 {
        None => prod_local_4917,
        Some(prod_local_4918) => { let prod_local_4919 = (prod_local_4915).guard; match prod_local_4919 {
        false => prod_local_4917,
        true => { let prod_local_4921 = (prod_local_4915).sticky; match prod_local_4921 {
        false => { let prod_local_4925 = 1; { let prod_local_4926 = (prod_local_4918 & prod_local_4925); { let prod_local_4927 = (prod_local_4926 == prod_local_4925); match prod_local_4927 {
        false => prod_local_4917,
        true => { let prod_local_4929 = 1; { let prod_local_4930 = (prod_local_4918).checked_add(prod_local_4929); prod_local_4930 } },
    } } } },
        true => { let prod_local_4932 = 1; { let prod_local_4933 = (prod_local_4918).checked_add(prod_local_4932); prod_local_4933 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_4934 = prod_local_4876; { let prod_local_4935 = prod_local_4934; { let prod_local_4936 = (prod_local_4935).value; { let prod_local_4937 = low64(prod_local_4936); match prod_local_4937 {
        None => prod_local_4937,
        Some(prod_local_4938) => { let prod_local_4939 = (prod_local_4935).guard; match prod_local_4939 {
        false => prod_local_4937,
        true => { let prod_local_4941 = (prod_local_4935).sticky; match prod_local_4941 {
        false => { let prod_local_4945 = 1; { let prod_local_4946 = (prod_local_4938 & prod_local_4945); { let prod_local_4947 = (prod_local_4946 == prod_local_4945); match prod_local_4947 {
        false => prod_local_4937,
        true => { let prod_local_4949 = 1; { let prod_local_4950 = (prod_local_4938).checked_add(prod_local_4949); prod_local_4950 } },
    } } } },
        true => { let prod_local_4952 = 1; { let prod_local_4953 = (prod_local_4938).checked_add(prod_local_4952); prod_local_4953 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_4954 = prod_local_4838; { let prod_local_4958 = 128; { let prod_local_4959 = (val_2857 & prod_local_4958); { let prod_local_4960 = 0; { let prod_local_4961 = (prod_local_4959 == prod_local_4960); { let prod_local_4965 = match prod_local_4961 {
        false => { let prod_local_4963 = false; prod_local_4963 },
        true => { let prod_local_4964 = true; prod_local_4964 },
    }; match prod_local_4965 {
        false => { let prod_local_4967 = Some(prod_local_4954); { let prod_local_4968 = round128(prod_local_4967); match prod_local_4968 {
        None => { let prod_local_4969 = prod_local_4968; match prod_local_4969 {
        None => None,
        Some(prod_local_4971) => { let prod_local_4972 = prod_local_4971; { let prod_local_4973 = (prod_local_4972).value; { let prod_local_4974 = low64(prod_local_4973); match prod_local_4974 {
        None => prod_local_4974,
        Some(prod_local_4975) => { let prod_local_4976 = (prod_local_4972).guard; match prod_local_4976 {
        false => prod_local_4974,
        true => { let prod_local_4978 = (prod_local_4972).sticky; match prod_local_4978 {
        false => { let prod_local_4982 = 1; { let prod_local_4983 = (prod_local_4975 & prod_local_4982); { let prod_local_4984 = (prod_local_4983 == prod_local_4982); match prod_local_4984 {
        false => prod_local_4974,
        true => { let prod_local_4986 = 1; { let prod_local_4987 = (prod_local_4975).checked_add(prod_local_4986); prod_local_4987 } },
    } } } },
        true => { let prod_local_4989 = 1; { let prod_local_4990 = (prod_local_4975).checked_add(prod_local_4989); prod_local_4990 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_4991) => { let prod_local_4992 = prod_local_4991; { let prod_local_4993 = prod_local_4992; { let prod_local_4994 = (prod_local_4993).value; { let prod_local_4995 = low64(prod_local_4994); match prod_local_4995 {
        None => prod_local_4995,
        Some(prod_local_4996) => { let prod_local_4997 = (prod_local_4993).guard; match prod_local_4997 {
        false => prod_local_4995,
        true => { let prod_local_4999 = (prod_local_4993).sticky; match prod_local_4999 {
        false => { let prod_local_5003 = 1; { let prod_local_5004 = (prod_local_4996 & prod_local_5003); { let prod_local_5005 = (prod_local_5004 == prod_local_5003); match prod_local_5005 {
        false => prod_local_4995,
        true => { let prod_local_5007 = 1; { let prod_local_5008 = (prod_local_4996).checked_add(prod_local_5007); prod_local_5008 } },
    } } } },
        true => { let prod_local_5010 = 1; { let prod_local_5011 = (prod_local_4996).checked_add(prod_local_5010); prod_local_5011 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_5012 = prod_local_4954; { let prod_local_5013 = prod_local_5012; { let prod_local_5014 = (prod_local_5013).value; { let prod_local_5015 = low64(prod_local_5014); match prod_local_5015 {
        None => prod_local_5015,
        Some(prod_local_5016) => { let prod_local_5017 = (prod_local_5013).guard; match prod_local_5017 {
        false => prod_local_5015,
        true => { let prod_local_5019 = (prod_local_5013).sticky; match prod_local_5019 {
        false => { let prod_local_5023 = 1; { let prod_local_5024 = (prod_local_5016 & prod_local_5023); { let prod_local_5025 = (prod_local_5024 == prod_local_5023); match prod_local_5025 {
        false => prod_local_5015,
        true => { let prod_local_5027 = 1; { let prod_local_5028 = (prod_local_5016).checked_add(prod_local_5027); prod_local_5028 } },
    } } } },
        true => { let prod_local_5030 = 1; { let prod_local_5031 = (prod_local_5016).checked_add(prod_local_5030); prod_local_5031 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_5032 = prod_local_4568; { let prod_local_5036 = 32; { let prod_local_5037 = (val_2857 & prod_local_5036); { let prod_local_5038 = 0; { let prod_local_5039 = (prod_local_5037 == prod_local_5038); { let prod_local_5043 = match prod_local_5039 {
        false => { let prod_local_5041 = false; prod_local_5041 },
        true => { let prod_local_5042 = true; prod_local_5042 },
    }; match prod_local_5043 {
        false => { let prod_local_5045 = Some(prod_local_5032); { let prod_local_5046 = round32(prod_local_5045); match prod_local_5046 {
        None => { let prod_local_5047 = prod_local_5046; match prod_local_5047 {
        None => None,
        Some(prod_local_5049) => { let prod_local_5050 = prod_local_5049; { let prod_local_5051 = (prod_local_5050).value; { let prod_local_5052 = low64(prod_local_5051); match prod_local_5052 {
        None => prod_local_5052,
        Some(prod_local_5053) => { let prod_local_5054 = (prod_local_5050).guard; match prod_local_5054 {
        false => prod_local_5052,
        true => { let prod_local_5056 = (prod_local_5050).sticky; match prod_local_5056 {
        false => { let prod_local_5060 = 1; { let prod_local_5061 = (prod_local_5053 & prod_local_5060); { let prod_local_5062 = (prod_local_5061 == prod_local_5060); match prod_local_5062 {
        false => prod_local_5052,
        true => { let prod_local_5064 = 1; { let prod_local_5065 = (prod_local_5053).checked_add(prod_local_5064); prod_local_5065 } },
    } } } },
        true => { let prod_local_5067 = 1; { let prod_local_5068 = (prod_local_5053).checked_add(prod_local_5067); prod_local_5068 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_5069) => { let prod_local_5070 = prod_local_5069; { let prod_local_5074 = 64; { let prod_local_5075 = (val_2857 & prod_local_5074); { let prod_local_5076 = 0; { let prod_local_5077 = (prod_local_5075 == prod_local_5076); { let prod_local_5081 = match prod_local_5077 {
        false => { let prod_local_5079 = false; prod_local_5079 },
        true => { let prod_local_5080 = true; prod_local_5080 },
    }; match prod_local_5081 {
        false => { let prod_local_5083 = Some(prod_local_5070); { let prod_local_5084 = round64(prod_local_5083); match prod_local_5084 {
        None => { let prod_local_5085 = prod_local_5084; match prod_local_5085 {
        None => None,
        Some(prod_local_5087) => { let prod_local_5088 = prod_local_5087; { let prod_local_5089 = (prod_local_5088).value; { let prod_local_5090 = low64(prod_local_5089); match prod_local_5090 {
        None => prod_local_5090,
        Some(prod_local_5091) => { let prod_local_5092 = (prod_local_5088).guard; match prod_local_5092 {
        false => prod_local_5090,
        true => { let prod_local_5094 = (prod_local_5088).sticky; match prod_local_5094 {
        false => { let prod_local_5098 = 1; { let prod_local_5099 = (prod_local_5091 & prod_local_5098); { let prod_local_5100 = (prod_local_5099 == prod_local_5098); match prod_local_5100 {
        false => prod_local_5090,
        true => { let prod_local_5102 = 1; { let prod_local_5103 = (prod_local_5091).checked_add(prod_local_5102); prod_local_5103 } },
    } } } },
        true => { let prod_local_5105 = 1; { let prod_local_5106 = (prod_local_5091).checked_add(prod_local_5105); prod_local_5106 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_5107) => { let prod_local_5108 = prod_local_5107; { let prod_local_5112 = 128; { let prod_local_5113 = (val_2857 & prod_local_5112); { let prod_local_5114 = 0; { let prod_local_5115 = (prod_local_5113 == prod_local_5114); { let prod_local_5119 = match prod_local_5115 {
        false => { let prod_local_5117 = false; prod_local_5117 },
        true => { let prod_local_5118 = true; prod_local_5118 },
    }; match prod_local_5119 {
        false => { let prod_local_5121 = Some(prod_local_5108); { let prod_local_5122 = round128(prod_local_5121); match prod_local_5122 {
        None => { let prod_local_5123 = prod_local_5122; match prod_local_5123 {
        None => None,
        Some(prod_local_5125) => { let prod_local_5126 = prod_local_5125; { let prod_local_5127 = (prod_local_5126).value; { let prod_local_5128 = low64(prod_local_5127); match prod_local_5128 {
        None => prod_local_5128,
        Some(prod_local_5129) => { let prod_local_5130 = (prod_local_5126).guard; match prod_local_5130 {
        false => prod_local_5128,
        true => { let prod_local_5132 = (prod_local_5126).sticky; match prod_local_5132 {
        false => { let prod_local_5136 = 1; { let prod_local_5137 = (prod_local_5129 & prod_local_5136); { let prod_local_5138 = (prod_local_5137 == prod_local_5136); match prod_local_5138 {
        false => prod_local_5128,
        true => { let prod_local_5140 = 1; { let prod_local_5141 = (prod_local_5129).checked_add(prod_local_5140); prod_local_5141 } },
    } } } },
        true => { let prod_local_5143 = 1; { let prod_local_5144 = (prod_local_5129).checked_add(prod_local_5143); prod_local_5144 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_5145) => { let prod_local_5146 = prod_local_5145; { let prod_local_5147 = prod_local_5146; { let prod_local_5148 = (prod_local_5147).value; { let prod_local_5149 = low64(prod_local_5148); match prod_local_5149 {
        None => prod_local_5149,
        Some(prod_local_5150) => { let prod_local_5151 = (prod_local_5147).guard; match prod_local_5151 {
        false => prod_local_5149,
        true => { let prod_local_5153 = (prod_local_5147).sticky; match prod_local_5153 {
        false => { let prod_local_5157 = 1; { let prod_local_5158 = (prod_local_5150 & prod_local_5157); { let prod_local_5159 = (prod_local_5158 == prod_local_5157); match prod_local_5159 {
        false => prod_local_5149,
        true => { let prod_local_5161 = 1; { let prod_local_5162 = (prod_local_5150).checked_add(prod_local_5161); prod_local_5162 } },
    } } } },
        true => { let prod_local_5164 = 1; { let prod_local_5165 = (prod_local_5150).checked_add(prod_local_5164); prod_local_5165 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_5166 = prod_local_5108; { let prod_local_5167 = prod_local_5166; { let prod_local_5168 = (prod_local_5167).value; { let prod_local_5169 = low64(prod_local_5168); match prod_local_5169 {
        None => prod_local_5169,
        Some(prod_local_5170) => { let prod_local_5171 = (prod_local_5167).guard; match prod_local_5171 {
        false => prod_local_5169,
        true => { let prod_local_5173 = (prod_local_5167).sticky; match prod_local_5173 {
        false => { let prod_local_5177 = 1; { let prod_local_5178 = (prod_local_5170 & prod_local_5177); { let prod_local_5179 = (prod_local_5178 == prod_local_5177); match prod_local_5179 {
        false => prod_local_5169,
        true => { let prod_local_5181 = 1; { let prod_local_5182 = (prod_local_5170).checked_add(prod_local_5181); prod_local_5182 } },
    } } } },
        true => { let prod_local_5184 = 1; { let prod_local_5185 = (prod_local_5170).checked_add(prod_local_5184); prod_local_5185 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_5186 = prod_local_5070; { let prod_local_5190 = 128; { let prod_local_5191 = (val_2857 & prod_local_5190); { let prod_local_5192 = 0; { let prod_local_5193 = (prod_local_5191 == prod_local_5192); { let prod_local_5197 = match prod_local_5193 {
        false => { let prod_local_5195 = false; prod_local_5195 },
        true => { let prod_local_5196 = true; prod_local_5196 },
    }; match prod_local_5197 {
        false => { let prod_local_5199 = Some(prod_local_5186); { let prod_local_5200 = round128(prod_local_5199); match prod_local_5200 {
        None => { let prod_local_5201 = prod_local_5200; match prod_local_5201 {
        None => None,
        Some(prod_local_5203) => { let prod_local_5204 = prod_local_5203; { let prod_local_5205 = (prod_local_5204).value; { let prod_local_5206 = low64(prod_local_5205); match prod_local_5206 {
        None => prod_local_5206,
        Some(prod_local_5207) => { let prod_local_5208 = (prod_local_5204).guard; match prod_local_5208 {
        false => prod_local_5206,
        true => { let prod_local_5210 = (prod_local_5204).sticky; match prod_local_5210 {
        false => { let prod_local_5214 = 1; { let prod_local_5215 = (prod_local_5207 & prod_local_5214); { let prod_local_5216 = (prod_local_5215 == prod_local_5214); match prod_local_5216 {
        false => prod_local_5206,
        true => { let prod_local_5218 = 1; { let prod_local_5219 = (prod_local_5207).checked_add(prod_local_5218); prod_local_5219 } },
    } } } },
        true => { let prod_local_5221 = 1; { let prod_local_5222 = (prod_local_5207).checked_add(prod_local_5221); prod_local_5222 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_5223) => { let prod_local_5224 = prod_local_5223; { let prod_local_5225 = prod_local_5224; { let prod_local_5226 = (prod_local_5225).value; { let prod_local_5227 = low64(prod_local_5226); match prod_local_5227 {
        None => prod_local_5227,
        Some(prod_local_5228) => { let prod_local_5229 = (prod_local_5225).guard; match prod_local_5229 {
        false => prod_local_5227,
        true => { let prod_local_5231 = (prod_local_5225).sticky; match prod_local_5231 {
        false => { let prod_local_5235 = 1; { let prod_local_5236 = (prod_local_5228 & prod_local_5235); { let prod_local_5237 = (prod_local_5236 == prod_local_5235); match prod_local_5237 {
        false => prod_local_5227,
        true => { let prod_local_5239 = 1; { let prod_local_5240 = (prod_local_5228).checked_add(prod_local_5239); prod_local_5240 } },
    } } } },
        true => { let prod_local_5242 = 1; { let prod_local_5243 = (prod_local_5228).checked_add(prod_local_5242); prod_local_5243 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_5244 = prod_local_5186; { let prod_local_5245 = prod_local_5244; { let prod_local_5246 = (prod_local_5245).value; { let prod_local_5247 = low64(prod_local_5246); match prod_local_5247 {
        None => prod_local_5247,
        Some(prod_local_5248) => { let prod_local_5249 = (prod_local_5245).guard; match prod_local_5249 {
        false => prod_local_5247,
        true => { let prod_local_5251 = (prod_local_5245).sticky; match prod_local_5251 {
        false => { let prod_local_5255 = 1; { let prod_local_5256 = (prod_local_5248 & prod_local_5255); { let prod_local_5257 = (prod_local_5256 == prod_local_5255); match prod_local_5257 {
        false => prod_local_5247,
        true => { let prod_local_5259 = 1; { let prod_local_5260 = (prod_local_5248).checked_add(prod_local_5259); prod_local_5260 } },
    } } } },
        true => { let prod_local_5262 = 1; { let prod_local_5263 = (prod_local_5248).checked_add(prod_local_5262); prod_local_5263 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_5264 = prod_local_5032; { let prod_local_5268 = 64; { let prod_local_5269 = (val_2857 & prod_local_5268); { let prod_local_5270 = 0; { let prod_local_5271 = (prod_local_5269 == prod_local_5270); { let prod_local_5275 = match prod_local_5271 {
        false => { let prod_local_5273 = false; prod_local_5273 },
        true => { let prod_local_5274 = true; prod_local_5274 },
    }; match prod_local_5275 {
        false => { let prod_local_5277 = Some(prod_local_5264); { let prod_local_5278 = round64(prod_local_5277); match prod_local_5278 {
        None => { let prod_local_5279 = prod_local_5278; match prod_local_5279 {
        None => None,
        Some(prod_local_5281) => { let prod_local_5282 = prod_local_5281; { let prod_local_5283 = (prod_local_5282).value; { let prod_local_5284 = low64(prod_local_5283); match prod_local_5284 {
        None => prod_local_5284,
        Some(prod_local_5285) => { let prod_local_5286 = (prod_local_5282).guard; match prod_local_5286 {
        false => prod_local_5284,
        true => { let prod_local_5288 = (prod_local_5282).sticky; match prod_local_5288 {
        false => { let prod_local_5292 = 1; { let prod_local_5293 = (prod_local_5285 & prod_local_5292); { let prod_local_5294 = (prod_local_5293 == prod_local_5292); match prod_local_5294 {
        false => prod_local_5284,
        true => { let prod_local_5296 = 1; { let prod_local_5297 = (prod_local_5285).checked_add(prod_local_5296); prod_local_5297 } },
    } } } },
        true => { let prod_local_5299 = 1; { let prod_local_5300 = (prod_local_5285).checked_add(prod_local_5299); prod_local_5300 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_5301) => { let prod_local_5302 = prod_local_5301; { let prod_local_5306 = 128; { let prod_local_5307 = (val_2857 & prod_local_5306); { let prod_local_5308 = 0; { let prod_local_5309 = (prod_local_5307 == prod_local_5308); { let prod_local_5313 = match prod_local_5309 {
        false => { let prod_local_5311 = false; prod_local_5311 },
        true => { let prod_local_5312 = true; prod_local_5312 },
    }; match prod_local_5313 {
        false => { let prod_local_5315 = Some(prod_local_5302); { let prod_local_5316 = round128(prod_local_5315); match prod_local_5316 {
        None => { let prod_local_5317 = prod_local_5316; match prod_local_5317 {
        None => None,
        Some(prod_local_5319) => { let prod_local_5320 = prod_local_5319; { let prod_local_5321 = (prod_local_5320).value; { let prod_local_5322 = low64(prod_local_5321); match prod_local_5322 {
        None => prod_local_5322,
        Some(prod_local_5323) => { let prod_local_5324 = (prod_local_5320).guard; match prod_local_5324 {
        false => prod_local_5322,
        true => { let prod_local_5326 = (prod_local_5320).sticky; match prod_local_5326 {
        false => { let prod_local_5330 = 1; { let prod_local_5331 = (prod_local_5323 & prod_local_5330); { let prod_local_5332 = (prod_local_5331 == prod_local_5330); match prod_local_5332 {
        false => prod_local_5322,
        true => { let prod_local_5334 = 1; { let prod_local_5335 = (prod_local_5323).checked_add(prod_local_5334); prod_local_5335 } },
    } } } },
        true => { let prod_local_5337 = 1; { let prod_local_5338 = (prod_local_5323).checked_add(prod_local_5337); prod_local_5338 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_5339) => { let prod_local_5340 = prod_local_5339; { let prod_local_5341 = prod_local_5340; { let prod_local_5342 = (prod_local_5341).value; { let prod_local_5343 = low64(prod_local_5342); match prod_local_5343 {
        None => prod_local_5343,
        Some(prod_local_5344) => { let prod_local_5345 = (prod_local_5341).guard; match prod_local_5345 {
        false => prod_local_5343,
        true => { let prod_local_5347 = (prod_local_5341).sticky; match prod_local_5347 {
        false => { let prod_local_5351 = 1; { let prod_local_5352 = (prod_local_5344 & prod_local_5351); { let prod_local_5353 = (prod_local_5352 == prod_local_5351); match prod_local_5353 {
        false => prod_local_5343,
        true => { let prod_local_5355 = 1; { let prod_local_5356 = (prod_local_5344).checked_add(prod_local_5355); prod_local_5356 } },
    } } } },
        true => { let prod_local_5358 = 1; { let prod_local_5359 = (prod_local_5344).checked_add(prod_local_5358); prod_local_5359 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_5360 = prod_local_5302; { let prod_local_5361 = prod_local_5360; { let prod_local_5362 = (prod_local_5361).value; { let prod_local_5363 = low64(prod_local_5362); match prod_local_5363 {
        None => prod_local_5363,
        Some(prod_local_5364) => { let prod_local_5365 = (prod_local_5361).guard; match prod_local_5365 {
        false => prod_local_5363,
        true => { let prod_local_5367 = (prod_local_5361).sticky; match prod_local_5367 {
        false => { let prod_local_5371 = 1; { let prod_local_5372 = (prod_local_5364 & prod_local_5371); { let prod_local_5373 = (prod_local_5372 == prod_local_5371); match prod_local_5373 {
        false => prod_local_5363,
        true => { let prod_local_5375 = 1; { let prod_local_5376 = (prod_local_5364).checked_add(prod_local_5375); prod_local_5376 } },
    } } } },
        true => { let prod_local_5378 = 1; { let prod_local_5379 = (prod_local_5364).checked_add(prod_local_5378); prod_local_5379 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_5380 = prod_local_5264; { let prod_local_5384 = 128; { let prod_local_5385 = (val_2857 & prod_local_5384); { let prod_local_5386 = 0; { let prod_local_5387 = (prod_local_5385 == prod_local_5386); { let prod_local_5391 = match prod_local_5387 {
        false => { let prod_local_5389 = false; prod_local_5389 },
        true => { let prod_local_5390 = true; prod_local_5390 },
    }; match prod_local_5391 {
        false => { let prod_local_5393 = Some(prod_local_5380); { let prod_local_5394 = round128(prod_local_5393); match prod_local_5394 {
        None => { let prod_local_5395 = prod_local_5394; match prod_local_5395 {
        None => None,
        Some(prod_local_5397) => { let prod_local_5398 = prod_local_5397; { let prod_local_5399 = (prod_local_5398).value; { let prod_local_5400 = low64(prod_local_5399); match prod_local_5400 {
        None => prod_local_5400,
        Some(prod_local_5401) => { let prod_local_5402 = (prod_local_5398).guard; match prod_local_5402 {
        false => prod_local_5400,
        true => { let prod_local_5404 = (prod_local_5398).sticky; match prod_local_5404 {
        false => { let prod_local_5408 = 1; { let prod_local_5409 = (prod_local_5401 & prod_local_5408); { let prod_local_5410 = (prod_local_5409 == prod_local_5408); match prod_local_5410 {
        false => prod_local_5400,
        true => { let prod_local_5412 = 1; { let prod_local_5413 = (prod_local_5401).checked_add(prod_local_5412); prod_local_5413 } },
    } } } },
        true => { let prod_local_5415 = 1; { let prod_local_5416 = (prod_local_5401).checked_add(prod_local_5415); prod_local_5416 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_5417) => { let prod_local_5418 = prod_local_5417; { let prod_local_5419 = prod_local_5418; { let prod_local_5420 = (prod_local_5419).value; { let prod_local_5421 = low64(prod_local_5420); match prod_local_5421 {
        None => prod_local_5421,
        Some(prod_local_5422) => { let prod_local_5423 = (prod_local_5419).guard; match prod_local_5423 {
        false => prod_local_5421,
        true => { let prod_local_5425 = (prod_local_5419).sticky; match prod_local_5425 {
        false => { let prod_local_5429 = 1; { let prod_local_5430 = (prod_local_5422 & prod_local_5429); { let prod_local_5431 = (prod_local_5430 == prod_local_5429); match prod_local_5431 {
        false => prod_local_5421,
        true => { let prod_local_5433 = 1; { let prod_local_5434 = (prod_local_5422).checked_add(prod_local_5433); prod_local_5434 } },
    } } } },
        true => { let prod_local_5436 = 1; { let prod_local_5437 = (prod_local_5422).checked_add(prod_local_5436); prod_local_5437 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_5438 = prod_local_5380; { let prod_local_5439 = prod_local_5438; { let prod_local_5440 = (prod_local_5439).value; { let prod_local_5441 = low64(prod_local_5440); match prod_local_5441 {
        None => prod_local_5441,
        Some(prod_local_5442) => { let prod_local_5443 = (prod_local_5439).guard; match prod_local_5443 {
        false => prod_local_5441,
        true => { let prod_local_5445 = (prod_local_5439).sticky; match prod_local_5445 {
        false => { let prod_local_5449 = 1; { let prod_local_5450 = (prod_local_5442 & prod_local_5449); { let prod_local_5451 = (prod_local_5450 == prod_local_5449); match prod_local_5451 {
        false => prod_local_5441,
        true => { let prod_local_5453 = 1; { let prod_local_5454 = (prod_local_5442).checked_add(prod_local_5453); prod_local_5454 } },
    } } } },
        true => { let prod_local_5456 = 1; { let prod_local_5457 = (prod_local_5442).checked_add(prod_local_5456); prod_local_5457 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } } } } } },
    } } } } } } },
    } } } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_5458 = prod_local_3602; { let prod_local_5462 = 8; { let prod_local_5463 = (val_2857 & prod_local_5462); { let prod_local_5464 = 0; { let prod_local_5465 = (prod_local_5463 == prod_local_5464); { let prod_local_5469 = match prod_local_5465 {
        false => { let prod_local_5467 = false; prod_local_5467 },
        true => { let prod_local_5468 = true; prod_local_5468 },
    }; match prod_local_5469 {
        false => { let prod_local_5471 = Some(prod_local_5458); { let prod_local_5472 = round8(prod_local_5471); match prod_local_5472 {
        None => { let prod_local_5473 = prod_local_5472; match prod_local_5473 {
        None => None,
        Some(prod_local_5475) => { let prod_local_5476 = prod_local_5475; { let prod_local_5477 = (prod_local_5476).value; { let prod_local_5478 = low64(prod_local_5477); match prod_local_5478 {
        None => prod_local_5478,
        Some(prod_local_5479) => { let prod_local_5480 = (prod_local_5476).guard; match prod_local_5480 {
        false => prod_local_5478,
        true => { let prod_local_5482 = (prod_local_5476).sticky; match prod_local_5482 {
        false => { let prod_local_5486 = 1; { let prod_local_5487 = (prod_local_5479 & prod_local_5486); { let prod_local_5488 = (prod_local_5487 == prod_local_5486); match prod_local_5488 {
        false => prod_local_5478,
        true => { let prod_local_5490 = 1; { let prod_local_5491 = (prod_local_5479).checked_add(prod_local_5490); prod_local_5491 } },
    } } } },
        true => { let prod_local_5493 = 1; { let prod_local_5494 = (prod_local_5479).checked_add(prod_local_5493); prod_local_5494 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_5495) => { let prod_local_5496 = prod_local_5495; { let prod_local_5500 = 16; { let prod_local_5501 = (val_2857 & prod_local_5500); { let prod_local_5502 = 0; { let prod_local_5503 = (prod_local_5501 == prod_local_5502); { let prod_local_5507 = match prod_local_5503 {
        false => { let prod_local_5505 = false; prod_local_5505 },
        true => { let prod_local_5506 = true; prod_local_5506 },
    }; match prod_local_5507 {
        false => { let prod_local_5509 = Some(prod_local_5496); { let prod_local_5510 = round16(prod_local_5509); match prod_local_5510 {
        None => { let prod_local_5511 = prod_local_5510; match prod_local_5511 {
        None => None,
        Some(prod_local_5513) => { let prod_local_5514 = prod_local_5513; { let prod_local_5515 = (prod_local_5514).value; { let prod_local_5516 = low64(prod_local_5515); match prod_local_5516 {
        None => prod_local_5516,
        Some(prod_local_5517) => { let prod_local_5518 = (prod_local_5514).guard; match prod_local_5518 {
        false => prod_local_5516,
        true => { let prod_local_5520 = (prod_local_5514).sticky; match prod_local_5520 {
        false => { let prod_local_5524 = 1; { let prod_local_5525 = (prod_local_5517 & prod_local_5524); { let prod_local_5526 = (prod_local_5525 == prod_local_5524); match prod_local_5526 {
        false => prod_local_5516,
        true => { let prod_local_5528 = 1; { let prod_local_5529 = (prod_local_5517).checked_add(prod_local_5528); prod_local_5529 } },
    } } } },
        true => { let prod_local_5531 = 1; { let prod_local_5532 = (prod_local_5517).checked_add(prod_local_5531); prod_local_5532 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_5533) => { let prod_local_5534 = prod_local_5533; { let prod_local_5538 = 32; { let prod_local_5539 = (val_2857 & prod_local_5538); { let prod_local_5540 = 0; { let prod_local_5541 = (prod_local_5539 == prod_local_5540); { let prod_local_5545 = match prod_local_5541 {
        false => { let prod_local_5543 = false; prod_local_5543 },
        true => { let prod_local_5544 = true; prod_local_5544 },
    }; match prod_local_5545 {
        false => { let prod_local_5547 = Some(prod_local_5534); { let prod_local_5548 = round32(prod_local_5547); match prod_local_5548 {
        None => { let prod_local_5549 = prod_local_5548; match prod_local_5549 {
        None => None,
        Some(prod_local_5551) => { let prod_local_5552 = prod_local_5551; { let prod_local_5553 = (prod_local_5552).value; { let prod_local_5554 = low64(prod_local_5553); match prod_local_5554 {
        None => prod_local_5554,
        Some(prod_local_5555) => { let prod_local_5556 = (prod_local_5552).guard; match prod_local_5556 {
        false => prod_local_5554,
        true => { let prod_local_5558 = (prod_local_5552).sticky; match prod_local_5558 {
        false => { let prod_local_5562 = 1; { let prod_local_5563 = (prod_local_5555 & prod_local_5562); { let prod_local_5564 = (prod_local_5563 == prod_local_5562); match prod_local_5564 {
        false => prod_local_5554,
        true => { let prod_local_5566 = 1; { let prod_local_5567 = (prod_local_5555).checked_add(prod_local_5566); prod_local_5567 } },
    } } } },
        true => { let prod_local_5569 = 1; { let prod_local_5570 = (prod_local_5555).checked_add(prod_local_5569); prod_local_5570 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_5571) => { let prod_local_5572 = prod_local_5571; { let prod_local_5576 = 64; { let prod_local_5577 = (val_2857 & prod_local_5576); { let prod_local_5578 = 0; { let prod_local_5579 = (prod_local_5577 == prod_local_5578); { let prod_local_5583 = match prod_local_5579 {
        false => { let prod_local_5581 = false; prod_local_5581 },
        true => { let prod_local_5582 = true; prod_local_5582 },
    }; match prod_local_5583 {
        false => { let prod_local_5585 = Some(prod_local_5572); { let prod_local_5586 = round64(prod_local_5585); match prod_local_5586 {
        None => { let prod_local_5587 = prod_local_5586; match prod_local_5587 {
        None => None,
        Some(prod_local_5589) => { let prod_local_5590 = prod_local_5589; { let prod_local_5591 = (prod_local_5590).value; { let prod_local_5592 = low64(prod_local_5591); match prod_local_5592 {
        None => prod_local_5592,
        Some(prod_local_5593) => { let prod_local_5594 = (prod_local_5590).guard; match prod_local_5594 {
        false => prod_local_5592,
        true => { let prod_local_5596 = (prod_local_5590).sticky; match prod_local_5596 {
        false => { let prod_local_5600 = 1; { let prod_local_5601 = (prod_local_5593 & prod_local_5600); { let prod_local_5602 = (prod_local_5601 == prod_local_5600); match prod_local_5602 {
        false => prod_local_5592,
        true => { let prod_local_5604 = 1; { let prod_local_5605 = (prod_local_5593).checked_add(prod_local_5604); prod_local_5605 } },
    } } } },
        true => { let prod_local_5607 = 1; { let prod_local_5608 = (prod_local_5593).checked_add(prod_local_5607); prod_local_5608 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_5609) => { let prod_local_5610 = prod_local_5609; { let prod_local_5614 = 128; { let prod_local_5615 = (val_2857 & prod_local_5614); { let prod_local_5616 = 0; { let prod_local_5617 = (prod_local_5615 == prod_local_5616); { let prod_local_5621 = match prod_local_5617 {
        false => { let prod_local_5619 = false; prod_local_5619 },
        true => { let prod_local_5620 = true; prod_local_5620 },
    }; match prod_local_5621 {
        false => { let prod_local_5623 = Some(prod_local_5610); { let prod_local_5624 = round128(prod_local_5623); match prod_local_5624 {
        None => { let prod_local_5625 = prod_local_5624; match prod_local_5625 {
        None => None,
        Some(prod_local_5627) => { let prod_local_5628 = prod_local_5627; { let prod_local_5629 = (prod_local_5628).value; { let prod_local_5630 = low64(prod_local_5629); match prod_local_5630 {
        None => prod_local_5630,
        Some(prod_local_5631) => { let prod_local_5632 = (prod_local_5628).guard; match prod_local_5632 {
        false => prod_local_5630,
        true => { let prod_local_5634 = (prod_local_5628).sticky; match prod_local_5634 {
        false => { let prod_local_5638 = 1; { let prod_local_5639 = (prod_local_5631 & prod_local_5638); { let prod_local_5640 = (prod_local_5639 == prod_local_5638); match prod_local_5640 {
        false => prod_local_5630,
        true => { let prod_local_5642 = 1; { let prod_local_5643 = (prod_local_5631).checked_add(prod_local_5642); prod_local_5643 } },
    } } } },
        true => { let prod_local_5645 = 1; { let prod_local_5646 = (prod_local_5631).checked_add(prod_local_5645); prod_local_5646 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_5647) => { let prod_local_5648 = prod_local_5647; { let prod_local_5649 = prod_local_5648; { let prod_local_5650 = (prod_local_5649).value; { let prod_local_5651 = low64(prod_local_5650); match prod_local_5651 {
        None => prod_local_5651,
        Some(prod_local_5652) => { let prod_local_5653 = (prod_local_5649).guard; match prod_local_5653 {
        false => prod_local_5651,
        true => { let prod_local_5655 = (prod_local_5649).sticky; match prod_local_5655 {
        false => { let prod_local_5659 = 1; { let prod_local_5660 = (prod_local_5652 & prod_local_5659); { let prod_local_5661 = (prod_local_5660 == prod_local_5659); match prod_local_5661 {
        false => prod_local_5651,
        true => { let prod_local_5663 = 1; { let prod_local_5664 = (prod_local_5652).checked_add(prod_local_5663); prod_local_5664 } },
    } } } },
        true => { let prod_local_5666 = 1; { let prod_local_5667 = (prod_local_5652).checked_add(prod_local_5666); prod_local_5667 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_5668 = prod_local_5610; { let prod_local_5669 = prod_local_5668; { let prod_local_5670 = (prod_local_5669).value; { let prod_local_5671 = low64(prod_local_5670); match prod_local_5671 {
        None => prod_local_5671,
        Some(prod_local_5672) => { let prod_local_5673 = (prod_local_5669).guard; match prod_local_5673 {
        false => prod_local_5671,
        true => { let prod_local_5675 = (prod_local_5669).sticky; match prod_local_5675 {
        false => { let prod_local_5679 = 1; { let prod_local_5680 = (prod_local_5672 & prod_local_5679); { let prod_local_5681 = (prod_local_5680 == prod_local_5679); match prod_local_5681 {
        false => prod_local_5671,
        true => { let prod_local_5683 = 1; { let prod_local_5684 = (prod_local_5672).checked_add(prod_local_5683); prod_local_5684 } },
    } } } },
        true => { let prod_local_5686 = 1; { let prod_local_5687 = (prod_local_5672).checked_add(prod_local_5686); prod_local_5687 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_5688 = prod_local_5572; { let prod_local_5692 = 128; { let prod_local_5693 = (val_2857 & prod_local_5692); { let prod_local_5694 = 0; { let prod_local_5695 = (prod_local_5693 == prod_local_5694); { let prod_local_5699 = match prod_local_5695 {
        false => { let prod_local_5697 = false; prod_local_5697 },
        true => { let prod_local_5698 = true; prod_local_5698 },
    }; match prod_local_5699 {
        false => { let prod_local_5701 = Some(prod_local_5688); { let prod_local_5702 = round128(prod_local_5701); match prod_local_5702 {
        None => { let prod_local_5703 = prod_local_5702; match prod_local_5703 {
        None => None,
        Some(prod_local_5705) => { let prod_local_5706 = prod_local_5705; { let prod_local_5707 = (prod_local_5706).value; { let prod_local_5708 = low64(prod_local_5707); match prod_local_5708 {
        None => prod_local_5708,
        Some(prod_local_5709) => { let prod_local_5710 = (prod_local_5706).guard; match prod_local_5710 {
        false => prod_local_5708,
        true => { let prod_local_5712 = (prod_local_5706).sticky; match prod_local_5712 {
        false => { let prod_local_5716 = 1; { let prod_local_5717 = (prod_local_5709 & prod_local_5716); { let prod_local_5718 = (prod_local_5717 == prod_local_5716); match prod_local_5718 {
        false => prod_local_5708,
        true => { let prod_local_5720 = 1; { let prod_local_5721 = (prod_local_5709).checked_add(prod_local_5720); prod_local_5721 } },
    } } } },
        true => { let prod_local_5723 = 1; { let prod_local_5724 = (prod_local_5709).checked_add(prod_local_5723); prod_local_5724 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_5725) => { let prod_local_5726 = prod_local_5725; { let prod_local_5727 = prod_local_5726; { let prod_local_5728 = (prod_local_5727).value; { let prod_local_5729 = low64(prod_local_5728); match prod_local_5729 {
        None => prod_local_5729,
        Some(prod_local_5730) => { let prod_local_5731 = (prod_local_5727).guard; match prod_local_5731 {
        false => prod_local_5729,
        true => { let prod_local_5733 = (prod_local_5727).sticky; match prod_local_5733 {
        false => { let prod_local_5737 = 1; { let prod_local_5738 = (prod_local_5730 & prod_local_5737); { let prod_local_5739 = (prod_local_5738 == prod_local_5737); match prod_local_5739 {
        false => prod_local_5729,
        true => { let prod_local_5741 = 1; { let prod_local_5742 = (prod_local_5730).checked_add(prod_local_5741); prod_local_5742 } },
    } } } },
        true => { let prod_local_5744 = 1; { let prod_local_5745 = (prod_local_5730).checked_add(prod_local_5744); prod_local_5745 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_5746 = prod_local_5688; { let prod_local_5747 = prod_local_5746; { let prod_local_5748 = (prod_local_5747).value; { let prod_local_5749 = low64(prod_local_5748); match prod_local_5749 {
        None => prod_local_5749,
        Some(prod_local_5750) => { let prod_local_5751 = (prod_local_5747).guard; match prod_local_5751 {
        false => prod_local_5749,
        true => { let prod_local_5753 = (prod_local_5747).sticky; match prod_local_5753 {
        false => { let prod_local_5757 = 1; { let prod_local_5758 = (prod_local_5750 & prod_local_5757); { let prod_local_5759 = (prod_local_5758 == prod_local_5757); match prod_local_5759 {
        false => prod_local_5749,
        true => { let prod_local_5761 = 1; { let prod_local_5762 = (prod_local_5750).checked_add(prod_local_5761); prod_local_5762 } },
    } } } },
        true => { let prod_local_5764 = 1; { let prod_local_5765 = (prod_local_5750).checked_add(prod_local_5764); prod_local_5765 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_5766 = prod_local_5534; { let prod_local_5770 = 64; { let prod_local_5771 = (val_2857 & prod_local_5770); { let prod_local_5772 = 0; { let prod_local_5773 = (prod_local_5771 == prod_local_5772); { let prod_local_5777 = match prod_local_5773 {
        false => { let prod_local_5775 = false; prod_local_5775 },
        true => { let prod_local_5776 = true; prod_local_5776 },
    }; match prod_local_5777 {
        false => { let prod_local_5779 = Some(prod_local_5766); { let prod_local_5780 = round64(prod_local_5779); match prod_local_5780 {
        None => { let prod_local_5781 = prod_local_5780; match prod_local_5781 {
        None => None,
        Some(prod_local_5783) => { let prod_local_5784 = prod_local_5783; { let prod_local_5785 = (prod_local_5784).value; { let prod_local_5786 = low64(prod_local_5785); match prod_local_5786 {
        None => prod_local_5786,
        Some(prod_local_5787) => { let prod_local_5788 = (prod_local_5784).guard; match prod_local_5788 {
        false => prod_local_5786,
        true => { let prod_local_5790 = (prod_local_5784).sticky; match prod_local_5790 {
        false => { let prod_local_5794 = 1; { let prod_local_5795 = (prod_local_5787 & prod_local_5794); { let prod_local_5796 = (prod_local_5795 == prod_local_5794); match prod_local_5796 {
        false => prod_local_5786,
        true => { let prod_local_5798 = 1; { let prod_local_5799 = (prod_local_5787).checked_add(prod_local_5798); prod_local_5799 } },
    } } } },
        true => { let prod_local_5801 = 1; { let prod_local_5802 = (prod_local_5787).checked_add(prod_local_5801); prod_local_5802 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_5803) => { let prod_local_5804 = prod_local_5803; { let prod_local_5808 = 128; { let prod_local_5809 = (val_2857 & prod_local_5808); { let prod_local_5810 = 0; { let prod_local_5811 = (prod_local_5809 == prod_local_5810); { let prod_local_5815 = match prod_local_5811 {
        false => { let prod_local_5813 = false; prod_local_5813 },
        true => { let prod_local_5814 = true; prod_local_5814 },
    }; match prod_local_5815 {
        false => { let prod_local_5817 = Some(prod_local_5804); { let prod_local_5818 = round128(prod_local_5817); match prod_local_5818 {
        None => { let prod_local_5819 = prod_local_5818; match prod_local_5819 {
        None => None,
        Some(prod_local_5821) => { let prod_local_5822 = prod_local_5821; { let prod_local_5823 = (prod_local_5822).value; { let prod_local_5824 = low64(prod_local_5823); match prod_local_5824 {
        None => prod_local_5824,
        Some(prod_local_5825) => { let prod_local_5826 = (prod_local_5822).guard; match prod_local_5826 {
        false => prod_local_5824,
        true => { let prod_local_5828 = (prod_local_5822).sticky; match prod_local_5828 {
        false => { let prod_local_5832 = 1; { let prod_local_5833 = (prod_local_5825 & prod_local_5832); { let prod_local_5834 = (prod_local_5833 == prod_local_5832); match prod_local_5834 {
        false => prod_local_5824,
        true => { let prod_local_5836 = 1; { let prod_local_5837 = (prod_local_5825).checked_add(prod_local_5836); prod_local_5837 } },
    } } } },
        true => { let prod_local_5839 = 1; { let prod_local_5840 = (prod_local_5825).checked_add(prod_local_5839); prod_local_5840 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_5841) => { let prod_local_5842 = prod_local_5841; { let prod_local_5843 = prod_local_5842; { let prod_local_5844 = (prod_local_5843).value; { let prod_local_5845 = low64(prod_local_5844); match prod_local_5845 {
        None => prod_local_5845,
        Some(prod_local_5846) => { let prod_local_5847 = (prod_local_5843).guard; match prod_local_5847 {
        false => prod_local_5845,
        true => { let prod_local_5849 = (prod_local_5843).sticky; match prod_local_5849 {
        false => { let prod_local_5853 = 1; { let prod_local_5854 = (prod_local_5846 & prod_local_5853); { let prod_local_5855 = (prod_local_5854 == prod_local_5853); match prod_local_5855 {
        false => prod_local_5845,
        true => { let prod_local_5857 = 1; { let prod_local_5858 = (prod_local_5846).checked_add(prod_local_5857); prod_local_5858 } },
    } } } },
        true => { let prod_local_5860 = 1; { let prod_local_5861 = (prod_local_5846).checked_add(prod_local_5860); prod_local_5861 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_5862 = prod_local_5804; { let prod_local_5863 = prod_local_5862; { let prod_local_5864 = (prod_local_5863).value; { let prod_local_5865 = low64(prod_local_5864); match prod_local_5865 {
        None => prod_local_5865,
        Some(prod_local_5866) => { let prod_local_5867 = (prod_local_5863).guard; match prod_local_5867 {
        false => prod_local_5865,
        true => { let prod_local_5869 = (prod_local_5863).sticky; match prod_local_5869 {
        false => { let prod_local_5873 = 1; { let prod_local_5874 = (prod_local_5866 & prod_local_5873); { let prod_local_5875 = (prod_local_5874 == prod_local_5873); match prod_local_5875 {
        false => prod_local_5865,
        true => { let prod_local_5877 = 1; { let prod_local_5878 = (prod_local_5866).checked_add(prod_local_5877); prod_local_5878 } },
    } } } },
        true => { let prod_local_5880 = 1; { let prod_local_5881 = (prod_local_5866).checked_add(prod_local_5880); prod_local_5881 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_5882 = prod_local_5766; { let prod_local_5886 = 128; { let prod_local_5887 = (val_2857 & prod_local_5886); { let prod_local_5888 = 0; { let prod_local_5889 = (prod_local_5887 == prod_local_5888); { let prod_local_5893 = match prod_local_5889 {
        false => { let prod_local_5891 = false; prod_local_5891 },
        true => { let prod_local_5892 = true; prod_local_5892 },
    }; match prod_local_5893 {
        false => { let prod_local_5895 = Some(prod_local_5882); { let prod_local_5896 = round128(prod_local_5895); match prod_local_5896 {
        None => { let prod_local_5897 = prod_local_5896; match prod_local_5897 {
        None => None,
        Some(prod_local_5899) => { let prod_local_5900 = prod_local_5899; { let prod_local_5901 = (prod_local_5900).value; { let prod_local_5902 = low64(prod_local_5901); match prod_local_5902 {
        None => prod_local_5902,
        Some(prod_local_5903) => { let prod_local_5904 = (prod_local_5900).guard; match prod_local_5904 {
        false => prod_local_5902,
        true => { let prod_local_5906 = (prod_local_5900).sticky; match prod_local_5906 {
        false => { let prod_local_5910 = 1; { let prod_local_5911 = (prod_local_5903 & prod_local_5910); { let prod_local_5912 = (prod_local_5911 == prod_local_5910); match prod_local_5912 {
        false => prod_local_5902,
        true => { let prod_local_5914 = 1; { let prod_local_5915 = (prod_local_5903).checked_add(prod_local_5914); prod_local_5915 } },
    } } } },
        true => { let prod_local_5917 = 1; { let prod_local_5918 = (prod_local_5903).checked_add(prod_local_5917); prod_local_5918 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_5919) => { let prod_local_5920 = prod_local_5919; { let prod_local_5921 = prod_local_5920; { let prod_local_5922 = (prod_local_5921).value; { let prod_local_5923 = low64(prod_local_5922); match prod_local_5923 {
        None => prod_local_5923,
        Some(prod_local_5924) => { let prod_local_5925 = (prod_local_5921).guard; match prod_local_5925 {
        false => prod_local_5923,
        true => { let prod_local_5927 = (prod_local_5921).sticky; match prod_local_5927 {
        false => { let prod_local_5931 = 1; { let prod_local_5932 = (prod_local_5924 & prod_local_5931); { let prod_local_5933 = (prod_local_5932 == prod_local_5931); match prod_local_5933 {
        false => prod_local_5923,
        true => { let prod_local_5935 = 1; { let prod_local_5936 = (prod_local_5924).checked_add(prod_local_5935); prod_local_5936 } },
    } } } },
        true => { let prod_local_5938 = 1; { let prod_local_5939 = (prod_local_5924).checked_add(prod_local_5938); prod_local_5939 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_5940 = prod_local_5882; { let prod_local_5941 = prod_local_5940; { let prod_local_5942 = (prod_local_5941).value; { let prod_local_5943 = low64(prod_local_5942); match prod_local_5943 {
        None => prod_local_5943,
        Some(prod_local_5944) => { let prod_local_5945 = (prod_local_5941).guard; match prod_local_5945 {
        false => prod_local_5943,
        true => { let prod_local_5947 = (prod_local_5941).sticky; match prod_local_5947 {
        false => { let prod_local_5951 = 1; { let prod_local_5952 = (prod_local_5944 & prod_local_5951); { let prod_local_5953 = (prod_local_5952 == prod_local_5951); match prod_local_5953 {
        false => prod_local_5943,
        true => { let prod_local_5955 = 1; { let prod_local_5956 = (prod_local_5944).checked_add(prod_local_5955); prod_local_5956 } },
    } } } },
        true => { let prod_local_5958 = 1; { let prod_local_5959 = (prod_local_5944).checked_add(prod_local_5958); prod_local_5959 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_5960 = prod_local_5496; { let prod_local_5964 = 32; { let prod_local_5965 = (val_2857 & prod_local_5964); { let prod_local_5966 = 0; { let prod_local_5967 = (prod_local_5965 == prod_local_5966); { let prod_local_5971 = match prod_local_5967 {
        false => { let prod_local_5969 = false; prod_local_5969 },
        true => { let prod_local_5970 = true; prod_local_5970 },
    }; match prod_local_5971 {
        false => { let prod_local_5973 = Some(prod_local_5960); { let prod_local_5974 = round32(prod_local_5973); match prod_local_5974 {
        None => { let prod_local_5975 = prod_local_5974; match prod_local_5975 {
        None => None,
        Some(prod_local_5977) => { let prod_local_5978 = prod_local_5977; { let prod_local_5979 = (prod_local_5978).value; { let prod_local_5980 = low64(prod_local_5979); match prod_local_5980 {
        None => prod_local_5980,
        Some(prod_local_5981) => { let prod_local_5982 = (prod_local_5978).guard; match prod_local_5982 {
        false => prod_local_5980,
        true => { let prod_local_5984 = (prod_local_5978).sticky; match prod_local_5984 {
        false => { let prod_local_5988 = 1; { let prod_local_5989 = (prod_local_5981 & prod_local_5988); { let prod_local_5990 = (prod_local_5989 == prod_local_5988); match prod_local_5990 {
        false => prod_local_5980,
        true => { let prod_local_5992 = 1; { let prod_local_5993 = (prod_local_5981).checked_add(prod_local_5992); prod_local_5993 } },
    } } } },
        true => { let prod_local_5995 = 1; { let prod_local_5996 = (prod_local_5981).checked_add(prod_local_5995); prod_local_5996 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_5997) => { let prod_local_5998 = prod_local_5997; { let prod_local_6002 = 64; { let prod_local_6003 = (val_2857 & prod_local_6002); { let prod_local_6004 = 0; { let prod_local_6005 = (prod_local_6003 == prod_local_6004); { let prod_local_6009 = match prod_local_6005 {
        false => { let prod_local_6007 = false; prod_local_6007 },
        true => { let prod_local_6008 = true; prod_local_6008 },
    }; match prod_local_6009 {
        false => { let prod_local_6011 = Some(prod_local_5998); { let prod_local_6012 = round64(prod_local_6011); match prod_local_6012 {
        None => { let prod_local_6013 = prod_local_6012; match prod_local_6013 {
        None => None,
        Some(prod_local_6015) => { let prod_local_6016 = prod_local_6015; { let prod_local_6017 = (prod_local_6016).value; { let prod_local_6018 = low64(prod_local_6017); match prod_local_6018 {
        None => prod_local_6018,
        Some(prod_local_6019) => { let prod_local_6020 = (prod_local_6016).guard; match prod_local_6020 {
        false => prod_local_6018,
        true => { let prod_local_6022 = (prod_local_6016).sticky; match prod_local_6022 {
        false => { let prod_local_6026 = 1; { let prod_local_6027 = (prod_local_6019 & prod_local_6026); { let prod_local_6028 = (prod_local_6027 == prod_local_6026); match prod_local_6028 {
        false => prod_local_6018,
        true => { let prod_local_6030 = 1; { let prod_local_6031 = (prod_local_6019).checked_add(prod_local_6030); prod_local_6031 } },
    } } } },
        true => { let prod_local_6033 = 1; { let prod_local_6034 = (prod_local_6019).checked_add(prod_local_6033); prod_local_6034 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_6035) => { let prod_local_6036 = prod_local_6035; { let prod_local_6040 = 128; { let prod_local_6041 = (val_2857 & prod_local_6040); { let prod_local_6042 = 0; { let prod_local_6043 = (prod_local_6041 == prod_local_6042); { let prod_local_6047 = match prod_local_6043 {
        false => { let prod_local_6045 = false; prod_local_6045 },
        true => { let prod_local_6046 = true; prod_local_6046 },
    }; match prod_local_6047 {
        false => { let prod_local_6049 = Some(prod_local_6036); { let prod_local_6050 = round128(prod_local_6049); match prod_local_6050 {
        None => { let prod_local_6051 = prod_local_6050; match prod_local_6051 {
        None => None,
        Some(prod_local_6053) => { let prod_local_6054 = prod_local_6053; { let prod_local_6055 = (prod_local_6054).value; { let prod_local_6056 = low64(prod_local_6055); match prod_local_6056 {
        None => prod_local_6056,
        Some(prod_local_6057) => { let prod_local_6058 = (prod_local_6054).guard; match prod_local_6058 {
        false => prod_local_6056,
        true => { let prod_local_6060 = (prod_local_6054).sticky; match prod_local_6060 {
        false => { let prod_local_6064 = 1; { let prod_local_6065 = (prod_local_6057 & prod_local_6064); { let prod_local_6066 = (prod_local_6065 == prod_local_6064); match prod_local_6066 {
        false => prod_local_6056,
        true => { let prod_local_6068 = 1; { let prod_local_6069 = (prod_local_6057).checked_add(prod_local_6068); prod_local_6069 } },
    } } } },
        true => { let prod_local_6071 = 1; { let prod_local_6072 = (prod_local_6057).checked_add(prod_local_6071); prod_local_6072 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_6073) => { let prod_local_6074 = prod_local_6073; { let prod_local_6075 = prod_local_6074; { let prod_local_6076 = (prod_local_6075).value; { let prod_local_6077 = low64(prod_local_6076); match prod_local_6077 {
        None => prod_local_6077,
        Some(prod_local_6078) => { let prod_local_6079 = (prod_local_6075).guard; match prod_local_6079 {
        false => prod_local_6077,
        true => { let prod_local_6081 = (prod_local_6075).sticky; match prod_local_6081 {
        false => { let prod_local_6085 = 1; { let prod_local_6086 = (prod_local_6078 & prod_local_6085); { let prod_local_6087 = (prod_local_6086 == prod_local_6085); match prod_local_6087 {
        false => prod_local_6077,
        true => { let prod_local_6089 = 1; { let prod_local_6090 = (prod_local_6078).checked_add(prod_local_6089); prod_local_6090 } },
    } } } },
        true => { let prod_local_6092 = 1; { let prod_local_6093 = (prod_local_6078).checked_add(prod_local_6092); prod_local_6093 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_6094 = prod_local_6036; { let prod_local_6095 = prod_local_6094; { let prod_local_6096 = (prod_local_6095).value; { let prod_local_6097 = low64(prod_local_6096); match prod_local_6097 {
        None => prod_local_6097,
        Some(prod_local_6098) => { let prod_local_6099 = (prod_local_6095).guard; match prod_local_6099 {
        false => prod_local_6097,
        true => { let prod_local_6101 = (prod_local_6095).sticky; match prod_local_6101 {
        false => { let prod_local_6105 = 1; { let prod_local_6106 = (prod_local_6098 & prod_local_6105); { let prod_local_6107 = (prod_local_6106 == prod_local_6105); match prod_local_6107 {
        false => prod_local_6097,
        true => { let prod_local_6109 = 1; { let prod_local_6110 = (prod_local_6098).checked_add(prod_local_6109); prod_local_6110 } },
    } } } },
        true => { let prod_local_6112 = 1; { let prod_local_6113 = (prod_local_6098).checked_add(prod_local_6112); prod_local_6113 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_6114 = prod_local_5998; { let prod_local_6118 = 128; { let prod_local_6119 = (val_2857 & prod_local_6118); { let prod_local_6120 = 0; { let prod_local_6121 = (prod_local_6119 == prod_local_6120); { let prod_local_6125 = match prod_local_6121 {
        false => { let prod_local_6123 = false; prod_local_6123 },
        true => { let prod_local_6124 = true; prod_local_6124 },
    }; match prod_local_6125 {
        false => { let prod_local_6127 = Some(prod_local_6114); { let prod_local_6128 = round128(prod_local_6127); match prod_local_6128 {
        None => { let prod_local_6129 = prod_local_6128; match prod_local_6129 {
        None => None,
        Some(prod_local_6131) => { let prod_local_6132 = prod_local_6131; { let prod_local_6133 = (prod_local_6132).value; { let prod_local_6134 = low64(prod_local_6133); match prod_local_6134 {
        None => prod_local_6134,
        Some(prod_local_6135) => { let prod_local_6136 = (prod_local_6132).guard; match prod_local_6136 {
        false => prod_local_6134,
        true => { let prod_local_6138 = (prod_local_6132).sticky; match prod_local_6138 {
        false => { let prod_local_6142 = 1; { let prod_local_6143 = (prod_local_6135 & prod_local_6142); { let prod_local_6144 = (prod_local_6143 == prod_local_6142); match prod_local_6144 {
        false => prod_local_6134,
        true => { let prod_local_6146 = 1; { let prod_local_6147 = (prod_local_6135).checked_add(prod_local_6146); prod_local_6147 } },
    } } } },
        true => { let prod_local_6149 = 1; { let prod_local_6150 = (prod_local_6135).checked_add(prod_local_6149); prod_local_6150 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_6151) => { let prod_local_6152 = prod_local_6151; { let prod_local_6153 = prod_local_6152; { let prod_local_6154 = (prod_local_6153).value; { let prod_local_6155 = low64(prod_local_6154); match prod_local_6155 {
        None => prod_local_6155,
        Some(prod_local_6156) => { let prod_local_6157 = (prod_local_6153).guard; match prod_local_6157 {
        false => prod_local_6155,
        true => { let prod_local_6159 = (prod_local_6153).sticky; match prod_local_6159 {
        false => { let prod_local_6163 = 1; { let prod_local_6164 = (prod_local_6156 & prod_local_6163); { let prod_local_6165 = (prod_local_6164 == prod_local_6163); match prod_local_6165 {
        false => prod_local_6155,
        true => { let prod_local_6167 = 1; { let prod_local_6168 = (prod_local_6156).checked_add(prod_local_6167); prod_local_6168 } },
    } } } },
        true => { let prod_local_6170 = 1; { let prod_local_6171 = (prod_local_6156).checked_add(prod_local_6170); prod_local_6171 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_6172 = prod_local_6114; { let prod_local_6173 = prod_local_6172; { let prod_local_6174 = (prod_local_6173).value; { let prod_local_6175 = low64(prod_local_6174); match prod_local_6175 {
        None => prod_local_6175,
        Some(prod_local_6176) => { let prod_local_6177 = (prod_local_6173).guard; match prod_local_6177 {
        false => prod_local_6175,
        true => { let prod_local_6179 = (prod_local_6173).sticky; match prod_local_6179 {
        false => { let prod_local_6183 = 1; { let prod_local_6184 = (prod_local_6176 & prod_local_6183); { let prod_local_6185 = (prod_local_6184 == prod_local_6183); match prod_local_6185 {
        false => prod_local_6175,
        true => { let prod_local_6187 = 1; { let prod_local_6188 = (prod_local_6176).checked_add(prod_local_6187); prod_local_6188 } },
    } } } },
        true => { let prod_local_6190 = 1; { let prod_local_6191 = (prod_local_6176).checked_add(prod_local_6190); prod_local_6191 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_6192 = prod_local_5960; { let prod_local_6196 = 64; { let prod_local_6197 = (val_2857 & prod_local_6196); { let prod_local_6198 = 0; { let prod_local_6199 = (prod_local_6197 == prod_local_6198); { let prod_local_6203 = match prod_local_6199 {
        false => { let prod_local_6201 = false; prod_local_6201 },
        true => { let prod_local_6202 = true; prod_local_6202 },
    }; match prod_local_6203 {
        false => { let prod_local_6205 = Some(prod_local_6192); { let prod_local_6206 = round64(prod_local_6205); match prod_local_6206 {
        None => { let prod_local_6207 = prod_local_6206; match prod_local_6207 {
        None => None,
        Some(prod_local_6209) => { let prod_local_6210 = prod_local_6209; { let prod_local_6211 = (prod_local_6210).value; { let prod_local_6212 = low64(prod_local_6211); match prod_local_6212 {
        None => prod_local_6212,
        Some(prod_local_6213) => { let prod_local_6214 = (prod_local_6210).guard; match prod_local_6214 {
        false => prod_local_6212,
        true => { let prod_local_6216 = (prod_local_6210).sticky; match prod_local_6216 {
        false => { let prod_local_6220 = 1; { let prod_local_6221 = (prod_local_6213 & prod_local_6220); { let prod_local_6222 = (prod_local_6221 == prod_local_6220); match prod_local_6222 {
        false => prod_local_6212,
        true => { let prod_local_6224 = 1; { let prod_local_6225 = (prod_local_6213).checked_add(prod_local_6224); prod_local_6225 } },
    } } } },
        true => { let prod_local_6227 = 1; { let prod_local_6228 = (prod_local_6213).checked_add(prod_local_6227); prod_local_6228 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_6229) => { let prod_local_6230 = prod_local_6229; { let prod_local_6234 = 128; { let prod_local_6235 = (val_2857 & prod_local_6234); { let prod_local_6236 = 0; { let prod_local_6237 = (prod_local_6235 == prod_local_6236); { let prod_local_6241 = match prod_local_6237 {
        false => { let prod_local_6239 = false; prod_local_6239 },
        true => { let prod_local_6240 = true; prod_local_6240 },
    }; match prod_local_6241 {
        false => { let prod_local_6243 = Some(prod_local_6230); { let prod_local_6244 = round128(prod_local_6243); match prod_local_6244 {
        None => { let prod_local_6245 = prod_local_6244; match prod_local_6245 {
        None => None,
        Some(prod_local_6247) => { let prod_local_6248 = prod_local_6247; { let prod_local_6249 = (prod_local_6248).value; { let prod_local_6250 = low64(prod_local_6249); match prod_local_6250 {
        None => prod_local_6250,
        Some(prod_local_6251) => { let prod_local_6252 = (prod_local_6248).guard; match prod_local_6252 {
        false => prod_local_6250,
        true => { let prod_local_6254 = (prod_local_6248).sticky; match prod_local_6254 {
        false => { let prod_local_6258 = 1; { let prod_local_6259 = (prod_local_6251 & prod_local_6258); { let prod_local_6260 = (prod_local_6259 == prod_local_6258); match prod_local_6260 {
        false => prod_local_6250,
        true => { let prod_local_6262 = 1; { let prod_local_6263 = (prod_local_6251).checked_add(prod_local_6262); prod_local_6263 } },
    } } } },
        true => { let prod_local_6265 = 1; { let prod_local_6266 = (prod_local_6251).checked_add(prod_local_6265); prod_local_6266 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_6267) => { let prod_local_6268 = prod_local_6267; { let prod_local_6269 = prod_local_6268; { let prod_local_6270 = (prod_local_6269).value; { let prod_local_6271 = low64(prod_local_6270); match prod_local_6271 {
        None => prod_local_6271,
        Some(prod_local_6272) => { let prod_local_6273 = (prod_local_6269).guard; match prod_local_6273 {
        false => prod_local_6271,
        true => { let prod_local_6275 = (prod_local_6269).sticky; match prod_local_6275 {
        false => { let prod_local_6279 = 1; { let prod_local_6280 = (prod_local_6272 & prod_local_6279); { let prod_local_6281 = (prod_local_6280 == prod_local_6279); match prod_local_6281 {
        false => prod_local_6271,
        true => { let prod_local_6283 = 1; { let prod_local_6284 = (prod_local_6272).checked_add(prod_local_6283); prod_local_6284 } },
    } } } },
        true => { let prod_local_6286 = 1; { let prod_local_6287 = (prod_local_6272).checked_add(prod_local_6286); prod_local_6287 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_6288 = prod_local_6230; { let prod_local_6289 = prod_local_6288; { let prod_local_6290 = (prod_local_6289).value; { let prod_local_6291 = low64(prod_local_6290); match prod_local_6291 {
        None => prod_local_6291,
        Some(prod_local_6292) => { let prod_local_6293 = (prod_local_6289).guard; match prod_local_6293 {
        false => prod_local_6291,
        true => { let prod_local_6295 = (prod_local_6289).sticky; match prod_local_6295 {
        false => { let prod_local_6299 = 1; { let prod_local_6300 = (prod_local_6292 & prod_local_6299); { let prod_local_6301 = (prod_local_6300 == prod_local_6299); match prod_local_6301 {
        false => prod_local_6291,
        true => { let prod_local_6303 = 1; { let prod_local_6304 = (prod_local_6292).checked_add(prod_local_6303); prod_local_6304 } },
    } } } },
        true => { let prod_local_6306 = 1; { let prod_local_6307 = (prod_local_6292).checked_add(prod_local_6306); prod_local_6307 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_6308 = prod_local_6192; { let prod_local_6312 = 128; { let prod_local_6313 = (val_2857 & prod_local_6312); { let prod_local_6314 = 0; { let prod_local_6315 = (prod_local_6313 == prod_local_6314); { let prod_local_6319 = match prod_local_6315 {
        false => { let prod_local_6317 = false; prod_local_6317 },
        true => { let prod_local_6318 = true; prod_local_6318 },
    }; match prod_local_6319 {
        false => { let prod_local_6321 = Some(prod_local_6308); { let prod_local_6322 = round128(prod_local_6321); match prod_local_6322 {
        None => { let prod_local_6323 = prod_local_6322; match prod_local_6323 {
        None => None,
        Some(prod_local_6325) => { let prod_local_6326 = prod_local_6325; { let prod_local_6327 = (prod_local_6326).value; { let prod_local_6328 = low64(prod_local_6327); match prod_local_6328 {
        None => prod_local_6328,
        Some(prod_local_6329) => { let prod_local_6330 = (prod_local_6326).guard; match prod_local_6330 {
        false => prod_local_6328,
        true => { let prod_local_6332 = (prod_local_6326).sticky; match prod_local_6332 {
        false => { let prod_local_6336 = 1; { let prod_local_6337 = (prod_local_6329 & prod_local_6336); { let prod_local_6338 = (prod_local_6337 == prod_local_6336); match prod_local_6338 {
        false => prod_local_6328,
        true => { let prod_local_6340 = 1; { let prod_local_6341 = (prod_local_6329).checked_add(prod_local_6340); prod_local_6341 } },
    } } } },
        true => { let prod_local_6343 = 1; { let prod_local_6344 = (prod_local_6329).checked_add(prod_local_6343); prod_local_6344 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_6345) => { let prod_local_6346 = prod_local_6345; { let prod_local_6347 = prod_local_6346; { let prod_local_6348 = (prod_local_6347).value; { let prod_local_6349 = low64(prod_local_6348); match prod_local_6349 {
        None => prod_local_6349,
        Some(prod_local_6350) => { let prod_local_6351 = (prod_local_6347).guard; match prod_local_6351 {
        false => prod_local_6349,
        true => { let prod_local_6353 = (prod_local_6347).sticky; match prod_local_6353 {
        false => { let prod_local_6357 = 1; { let prod_local_6358 = (prod_local_6350 & prod_local_6357); { let prod_local_6359 = (prod_local_6358 == prod_local_6357); match prod_local_6359 {
        false => prod_local_6349,
        true => { let prod_local_6361 = 1; { let prod_local_6362 = (prod_local_6350).checked_add(prod_local_6361); prod_local_6362 } },
    } } } },
        true => { let prod_local_6364 = 1; { let prod_local_6365 = (prod_local_6350).checked_add(prod_local_6364); prod_local_6365 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_6366 = prod_local_6308; { let prod_local_6367 = prod_local_6366; { let prod_local_6368 = (prod_local_6367).value; { let prod_local_6369 = low64(prod_local_6368); match prod_local_6369 {
        None => prod_local_6369,
        Some(prod_local_6370) => { let prod_local_6371 = (prod_local_6367).guard; match prod_local_6371 {
        false => prod_local_6369,
        true => { let prod_local_6373 = (prod_local_6367).sticky; match prod_local_6373 {
        false => { let prod_local_6377 = 1; { let prod_local_6378 = (prod_local_6370 & prod_local_6377); { let prod_local_6379 = (prod_local_6378 == prod_local_6377); match prod_local_6379 {
        false => prod_local_6369,
        true => { let prod_local_6381 = 1; { let prod_local_6382 = (prod_local_6370).checked_add(prod_local_6381); prod_local_6382 } },
    } } } },
        true => { let prod_local_6384 = 1; { let prod_local_6385 = (prod_local_6370).checked_add(prod_local_6384); prod_local_6385 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } } } } } },
    } } } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_6386 = prod_local_5458; { let prod_local_6390 = 16; { let prod_local_6391 = (val_2857 & prod_local_6390); { let prod_local_6392 = 0; { let prod_local_6393 = (prod_local_6391 == prod_local_6392); { let prod_local_6397 = match prod_local_6393 {
        false => { let prod_local_6395 = false; prod_local_6395 },
        true => { let prod_local_6396 = true; prod_local_6396 },
    }; match prod_local_6397 {
        false => { let prod_local_6399 = Some(prod_local_6386); { let prod_local_6400 = round16(prod_local_6399); match prod_local_6400 {
        None => { let prod_local_6401 = prod_local_6400; match prod_local_6401 {
        None => None,
        Some(prod_local_6403) => { let prod_local_6404 = prod_local_6403; { let prod_local_6405 = (prod_local_6404).value; { let prod_local_6406 = low64(prod_local_6405); match prod_local_6406 {
        None => prod_local_6406,
        Some(prod_local_6407) => { let prod_local_6408 = (prod_local_6404).guard; match prod_local_6408 {
        false => prod_local_6406,
        true => { let prod_local_6410 = (prod_local_6404).sticky; match prod_local_6410 {
        false => { let prod_local_6414 = 1; { let prod_local_6415 = (prod_local_6407 & prod_local_6414); { let prod_local_6416 = (prod_local_6415 == prod_local_6414); match prod_local_6416 {
        false => prod_local_6406,
        true => { let prod_local_6418 = 1; { let prod_local_6419 = (prod_local_6407).checked_add(prod_local_6418); prod_local_6419 } },
    } } } },
        true => { let prod_local_6421 = 1; { let prod_local_6422 = (prod_local_6407).checked_add(prod_local_6421); prod_local_6422 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_6423) => { let prod_local_6424 = prod_local_6423; { let prod_local_6428 = 32; { let prod_local_6429 = (val_2857 & prod_local_6428); { let prod_local_6430 = 0; { let prod_local_6431 = (prod_local_6429 == prod_local_6430); { let prod_local_6435 = match prod_local_6431 {
        false => { let prod_local_6433 = false; prod_local_6433 },
        true => { let prod_local_6434 = true; prod_local_6434 },
    }; match prod_local_6435 {
        false => { let prod_local_6437 = Some(prod_local_6424); { let prod_local_6438 = round32(prod_local_6437); match prod_local_6438 {
        None => { let prod_local_6439 = prod_local_6438; match prod_local_6439 {
        None => None,
        Some(prod_local_6441) => { let prod_local_6442 = prod_local_6441; { let prod_local_6443 = (prod_local_6442).value; { let prod_local_6444 = low64(prod_local_6443); match prod_local_6444 {
        None => prod_local_6444,
        Some(prod_local_6445) => { let prod_local_6446 = (prod_local_6442).guard; match prod_local_6446 {
        false => prod_local_6444,
        true => { let prod_local_6448 = (prod_local_6442).sticky; match prod_local_6448 {
        false => { let prod_local_6452 = 1; { let prod_local_6453 = (prod_local_6445 & prod_local_6452); { let prod_local_6454 = (prod_local_6453 == prod_local_6452); match prod_local_6454 {
        false => prod_local_6444,
        true => { let prod_local_6456 = 1; { let prod_local_6457 = (prod_local_6445).checked_add(prod_local_6456); prod_local_6457 } },
    } } } },
        true => { let prod_local_6459 = 1; { let prod_local_6460 = (prod_local_6445).checked_add(prod_local_6459); prod_local_6460 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_6461) => { let prod_local_6462 = prod_local_6461; { let prod_local_6466 = 64; { let prod_local_6467 = (val_2857 & prod_local_6466); { let prod_local_6468 = 0; { let prod_local_6469 = (prod_local_6467 == prod_local_6468); { let prod_local_6473 = match prod_local_6469 {
        false => { let prod_local_6471 = false; prod_local_6471 },
        true => { let prod_local_6472 = true; prod_local_6472 },
    }; match prod_local_6473 {
        false => { let prod_local_6475 = Some(prod_local_6462); { let prod_local_6476 = round64(prod_local_6475); match prod_local_6476 {
        None => { let prod_local_6477 = prod_local_6476; match prod_local_6477 {
        None => None,
        Some(prod_local_6479) => { let prod_local_6480 = prod_local_6479; { let prod_local_6481 = (prod_local_6480).value; { let prod_local_6482 = low64(prod_local_6481); match prod_local_6482 {
        None => prod_local_6482,
        Some(prod_local_6483) => { let prod_local_6484 = (prod_local_6480).guard; match prod_local_6484 {
        false => prod_local_6482,
        true => { let prod_local_6486 = (prod_local_6480).sticky; match prod_local_6486 {
        false => { let prod_local_6490 = 1; { let prod_local_6491 = (prod_local_6483 & prod_local_6490); { let prod_local_6492 = (prod_local_6491 == prod_local_6490); match prod_local_6492 {
        false => prod_local_6482,
        true => { let prod_local_6494 = 1; { let prod_local_6495 = (prod_local_6483).checked_add(prod_local_6494); prod_local_6495 } },
    } } } },
        true => { let prod_local_6497 = 1; { let prod_local_6498 = (prod_local_6483).checked_add(prod_local_6497); prod_local_6498 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_6499) => { let prod_local_6500 = prod_local_6499; { let prod_local_6504 = 128; { let prod_local_6505 = (val_2857 & prod_local_6504); { let prod_local_6506 = 0; { let prod_local_6507 = (prod_local_6505 == prod_local_6506); { let prod_local_6511 = match prod_local_6507 {
        false => { let prod_local_6509 = false; prod_local_6509 },
        true => { let prod_local_6510 = true; prod_local_6510 },
    }; match prod_local_6511 {
        false => { let prod_local_6513 = Some(prod_local_6500); { let prod_local_6514 = round128(prod_local_6513); match prod_local_6514 {
        None => { let prod_local_6515 = prod_local_6514; match prod_local_6515 {
        None => None,
        Some(prod_local_6517) => { let prod_local_6518 = prod_local_6517; { let prod_local_6519 = (prod_local_6518).value; { let prod_local_6520 = low64(prod_local_6519); match prod_local_6520 {
        None => prod_local_6520,
        Some(prod_local_6521) => { let prod_local_6522 = (prod_local_6518).guard; match prod_local_6522 {
        false => prod_local_6520,
        true => { let prod_local_6524 = (prod_local_6518).sticky; match prod_local_6524 {
        false => { let prod_local_6528 = 1; { let prod_local_6529 = (prod_local_6521 & prod_local_6528); { let prod_local_6530 = (prod_local_6529 == prod_local_6528); match prod_local_6530 {
        false => prod_local_6520,
        true => { let prod_local_6532 = 1; { let prod_local_6533 = (prod_local_6521).checked_add(prod_local_6532); prod_local_6533 } },
    } } } },
        true => { let prod_local_6535 = 1; { let prod_local_6536 = (prod_local_6521).checked_add(prod_local_6535); prod_local_6536 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_6537) => { let prod_local_6538 = prod_local_6537; { let prod_local_6539 = prod_local_6538; { let prod_local_6540 = (prod_local_6539).value; { let prod_local_6541 = low64(prod_local_6540); match prod_local_6541 {
        None => prod_local_6541,
        Some(prod_local_6542) => { let prod_local_6543 = (prod_local_6539).guard; match prod_local_6543 {
        false => prod_local_6541,
        true => { let prod_local_6545 = (prod_local_6539).sticky; match prod_local_6545 {
        false => { let prod_local_6549 = 1; { let prod_local_6550 = (prod_local_6542 & prod_local_6549); { let prod_local_6551 = (prod_local_6550 == prod_local_6549); match prod_local_6551 {
        false => prod_local_6541,
        true => { let prod_local_6553 = 1; { let prod_local_6554 = (prod_local_6542).checked_add(prod_local_6553); prod_local_6554 } },
    } } } },
        true => { let prod_local_6556 = 1; { let prod_local_6557 = (prod_local_6542).checked_add(prod_local_6556); prod_local_6557 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_6558 = prod_local_6500; { let prod_local_6559 = prod_local_6558; { let prod_local_6560 = (prod_local_6559).value; { let prod_local_6561 = low64(prod_local_6560); match prod_local_6561 {
        None => prod_local_6561,
        Some(prod_local_6562) => { let prod_local_6563 = (prod_local_6559).guard; match prod_local_6563 {
        false => prod_local_6561,
        true => { let prod_local_6565 = (prod_local_6559).sticky; match prod_local_6565 {
        false => { let prod_local_6569 = 1; { let prod_local_6570 = (prod_local_6562 & prod_local_6569); { let prod_local_6571 = (prod_local_6570 == prod_local_6569); match prod_local_6571 {
        false => prod_local_6561,
        true => { let prod_local_6573 = 1; { let prod_local_6574 = (prod_local_6562).checked_add(prod_local_6573); prod_local_6574 } },
    } } } },
        true => { let prod_local_6576 = 1; { let prod_local_6577 = (prod_local_6562).checked_add(prod_local_6576); prod_local_6577 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_6578 = prod_local_6462; { let prod_local_6582 = 128; { let prod_local_6583 = (val_2857 & prod_local_6582); { let prod_local_6584 = 0; { let prod_local_6585 = (prod_local_6583 == prod_local_6584); { let prod_local_6589 = match prod_local_6585 {
        false => { let prod_local_6587 = false; prod_local_6587 },
        true => { let prod_local_6588 = true; prod_local_6588 },
    }; match prod_local_6589 {
        false => { let prod_local_6591 = Some(prod_local_6578); { let prod_local_6592 = round128(prod_local_6591); match prod_local_6592 {
        None => { let prod_local_6593 = prod_local_6592; match prod_local_6593 {
        None => None,
        Some(prod_local_6595) => { let prod_local_6596 = prod_local_6595; { let prod_local_6597 = (prod_local_6596).value; { let prod_local_6598 = low64(prod_local_6597); match prod_local_6598 {
        None => prod_local_6598,
        Some(prod_local_6599) => { let prod_local_6600 = (prod_local_6596).guard; match prod_local_6600 {
        false => prod_local_6598,
        true => { let prod_local_6602 = (prod_local_6596).sticky; match prod_local_6602 {
        false => { let prod_local_6606 = 1; { let prod_local_6607 = (prod_local_6599 & prod_local_6606); { let prod_local_6608 = (prod_local_6607 == prod_local_6606); match prod_local_6608 {
        false => prod_local_6598,
        true => { let prod_local_6610 = 1; { let prod_local_6611 = (prod_local_6599).checked_add(prod_local_6610); prod_local_6611 } },
    } } } },
        true => { let prod_local_6613 = 1; { let prod_local_6614 = (prod_local_6599).checked_add(prod_local_6613); prod_local_6614 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_6615) => { let prod_local_6616 = prod_local_6615; { let prod_local_6617 = prod_local_6616; { let prod_local_6618 = (prod_local_6617).value; { let prod_local_6619 = low64(prod_local_6618); match prod_local_6619 {
        None => prod_local_6619,
        Some(prod_local_6620) => { let prod_local_6621 = (prod_local_6617).guard; match prod_local_6621 {
        false => prod_local_6619,
        true => { let prod_local_6623 = (prod_local_6617).sticky; match prod_local_6623 {
        false => { let prod_local_6627 = 1; { let prod_local_6628 = (prod_local_6620 & prod_local_6627); { let prod_local_6629 = (prod_local_6628 == prod_local_6627); match prod_local_6629 {
        false => prod_local_6619,
        true => { let prod_local_6631 = 1; { let prod_local_6632 = (prod_local_6620).checked_add(prod_local_6631); prod_local_6632 } },
    } } } },
        true => { let prod_local_6634 = 1; { let prod_local_6635 = (prod_local_6620).checked_add(prod_local_6634); prod_local_6635 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_6636 = prod_local_6578; { let prod_local_6637 = prod_local_6636; { let prod_local_6638 = (prod_local_6637).value; { let prod_local_6639 = low64(prod_local_6638); match prod_local_6639 {
        None => prod_local_6639,
        Some(prod_local_6640) => { let prod_local_6641 = (prod_local_6637).guard; match prod_local_6641 {
        false => prod_local_6639,
        true => { let prod_local_6643 = (prod_local_6637).sticky; match prod_local_6643 {
        false => { let prod_local_6647 = 1; { let prod_local_6648 = (prod_local_6640 & prod_local_6647); { let prod_local_6649 = (prod_local_6648 == prod_local_6647); match prod_local_6649 {
        false => prod_local_6639,
        true => { let prod_local_6651 = 1; { let prod_local_6652 = (prod_local_6640).checked_add(prod_local_6651); prod_local_6652 } },
    } } } },
        true => { let prod_local_6654 = 1; { let prod_local_6655 = (prod_local_6640).checked_add(prod_local_6654); prod_local_6655 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_6656 = prod_local_6424; { let prod_local_6660 = 64; { let prod_local_6661 = (val_2857 & prod_local_6660); { let prod_local_6662 = 0; { let prod_local_6663 = (prod_local_6661 == prod_local_6662); { let prod_local_6667 = match prod_local_6663 {
        false => { let prod_local_6665 = false; prod_local_6665 },
        true => { let prod_local_6666 = true; prod_local_6666 },
    }; match prod_local_6667 {
        false => { let prod_local_6669 = Some(prod_local_6656); { let prod_local_6670 = round64(prod_local_6669); match prod_local_6670 {
        None => { let prod_local_6671 = prod_local_6670; match prod_local_6671 {
        None => None,
        Some(prod_local_6673) => { let prod_local_6674 = prod_local_6673; { let prod_local_6675 = (prod_local_6674).value; { let prod_local_6676 = low64(prod_local_6675); match prod_local_6676 {
        None => prod_local_6676,
        Some(prod_local_6677) => { let prod_local_6678 = (prod_local_6674).guard; match prod_local_6678 {
        false => prod_local_6676,
        true => { let prod_local_6680 = (prod_local_6674).sticky; match prod_local_6680 {
        false => { let prod_local_6684 = 1; { let prod_local_6685 = (prod_local_6677 & prod_local_6684); { let prod_local_6686 = (prod_local_6685 == prod_local_6684); match prod_local_6686 {
        false => prod_local_6676,
        true => { let prod_local_6688 = 1; { let prod_local_6689 = (prod_local_6677).checked_add(prod_local_6688); prod_local_6689 } },
    } } } },
        true => { let prod_local_6691 = 1; { let prod_local_6692 = (prod_local_6677).checked_add(prod_local_6691); prod_local_6692 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_6693) => { let prod_local_6694 = prod_local_6693; { let prod_local_6698 = 128; { let prod_local_6699 = (val_2857 & prod_local_6698); { let prod_local_6700 = 0; { let prod_local_6701 = (prod_local_6699 == prod_local_6700); { let prod_local_6705 = match prod_local_6701 {
        false => { let prod_local_6703 = false; prod_local_6703 },
        true => { let prod_local_6704 = true; prod_local_6704 },
    }; match prod_local_6705 {
        false => { let prod_local_6707 = Some(prod_local_6694); { let prod_local_6708 = round128(prod_local_6707); match prod_local_6708 {
        None => { let prod_local_6709 = prod_local_6708; match prod_local_6709 {
        None => None,
        Some(prod_local_6711) => { let prod_local_6712 = prod_local_6711; { let prod_local_6713 = (prod_local_6712).value; { let prod_local_6714 = low64(prod_local_6713); match prod_local_6714 {
        None => prod_local_6714,
        Some(prod_local_6715) => { let prod_local_6716 = (prod_local_6712).guard; match prod_local_6716 {
        false => prod_local_6714,
        true => { let prod_local_6718 = (prod_local_6712).sticky; match prod_local_6718 {
        false => { let prod_local_6722 = 1; { let prod_local_6723 = (prod_local_6715 & prod_local_6722); { let prod_local_6724 = (prod_local_6723 == prod_local_6722); match prod_local_6724 {
        false => prod_local_6714,
        true => { let prod_local_6726 = 1; { let prod_local_6727 = (prod_local_6715).checked_add(prod_local_6726); prod_local_6727 } },
    } } } },
        true => { let prod_local_6729 = 1; { let prod_local_6730 = (prod_local_6715).checked_add(prod_local_6729); prod_local_6730 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_6731) => { let prod_local_6732 = prod_local_6731; { let prod_local_6733 = prod_local_6732; { let prod_local_6734 = (prod_local_6733).value; { let prod_local_6735 = low64(prod_local_6734); match prod_local_6735 {
        None => prod_local_6735,
        Some(prod_local_6736) => { let prod_local_6737 = (prod_local_6733).guard; match prod_local_6737 {
        false => prod_local_6735,
        true => { let prod_local_6739 = (prod_local_6733).sticky; match prod_local_6739 {
        false => { let prod_local_6743 = 1; { let prod_local_6744 = (prod_local_6736 & prod_local_6743); { let prod_local_6745 = (prod_local_6744 == prod_local_6743); match prod_local_6745 {
        false => prod_local_6735,
        true => { let prod_local_6747 = 1; { let prod_local_6748 = (prod_local_6736).checked_add(prod_local_6747); prod_local_6748 } },
    } } } },
        true => { let prod_local_6750 = 1; { let prod_local_6751 = (prod_local_6736).checked_add(prod_local_6750); prod_local_6751 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_6752 = prod_local_6694; { let prod_local_6753 = prod_local_6752; { let prod_local_6754 = (prod_local_6753).value; { let prod_local_6755 = low64(prod_local_6754); match prod_local_6755 {
        None => prod_local_6755,
        Some(prod_local_6756) => { let prod_local_6757 = (prod_local_6753).guard; match prod_local_6757 {
        false => prod_local_6755,
        true => { let prod_local_6759 = (prod_local_6753).sticky; match prod_local_6759 {
        false => { let prod_local_6763 = 1; { let prod_local_6764 = (prod_local_6756 & prod_local_6763); { let prod_local_6765 = (prod_local_6764 == prod_local_6763); match prod_local_6765 {
        false => prod_local_6755,
        true => { let prod_local_6767 = 1; { let prod_local_6768 = (prod_local_6756).checked_add(prod_local_6767); prod_local_6768 } },
    } } } },
        true => { let prod_local_6770 = 1; { let prod_local_6771 = (prod_local_6756).checked_add(prod_local_6770); prod_local_6771 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_6772 = prod_local_6656; { let prod_local_6776 = 128; { let prod_local_6777 = (val_2857 & prod_local_6776); { let prod_local_6778 = 0; { let prod_local_6779 = (prod_local_6777 == prod_local_6778); { let prod_local_6783 = match prod_local_6779 {
        false => { let prod_local_6781 = false; prod_local_6781 },
        true => { let prod_local_6782 = true; prod_local_6782 },
    }; match prod_local_6783 {
        false => { let prod_local_6785 = Some(prod_local_6772); { let prod_local_6786 = round128(prod_local_6785); match prod_local_6786 {
        None => { let prod_local_6787 = prod_local_6786; match prod_local_6787 {
        None => None,
        Some(prod_local_6789) => { let prod_local_6790 = prod_local_6789; { let prod_local_6791 = (prod_local_6790).value; { let prod_local_6792 = low64(prod_local_6791); match prod_local_6792 {
        None => prod_local_6792,
        Some(prod_local_6793) => { let prod_local_6794 = (prod_local_6790).guard; match prod_local_6794 {
        false => prod_local_6792,
        true => { let prod_local_6796 = (prod_local_6790).sticky; match prod_local_6796 {
        false => { let prod_local_6800 = 1; { let prod_local_6801 = (prod_local_6793 & prod_local_6800); { let prod_local_6802 = (prod_local_6801 == prod_local_6800); match prod_local_6802 {
        false => prod_local_6792,
        true => { let prod_local_6804 = 1; { let prod_local_6805 = (prod_local_6793).checked_add(prod_local_6804); prod_local_6805 } },
    } } } },
        true => { let prod_local_6807 = 1; { let prod_local_6808 = (prod_local_6793).checked_add(prod_local_6807); prod_local_6808 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_6809) => { let prod_local_6810 = prod_local_6809; { let prod_local_6811 = prod_local_6810; { let prod_local_6812 = (prod_local_6811).value; { let prod_local_6813 = low64(prod_local_6812); match prod_local_6813 {
        None => prod_local_6813,
        Some(prod_local_6814) => { let prod_local_6815 = (prod_local_6811).guard; match prod_local_6815 {
        false => prod_local_6813,
        true => { let prod_local_6817 = (prod_local_6811).sticky; match prod_local_6817 {
        false => { let prod_local_6821 = 1; { let prod_local_6822 = (prod_local_6814 & prod_local_6821); { let prod_local_6823 = (prod_local_6822 == prod_local_6821); match prod_local_6823 {
        false => prod_local_6813,
        true => { let prod_local_6825 = 1; { let prod_local_6826 = (prod_local_6814).checked_add(prod_local_6825); prod_local_6826 } },
    } } } },
        true => { let prod_local_6828 = 1; { let prod_local_6829 = (prod_local_6814).checked_add(prod_local_6828); prod_local_6829 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_6830 = prod_local_6772; { let prod_local_6831 = prod_local_6830; { let prod_local_6832 = (prod_local_6831).value; { let prod_local_6833 = low64(prod_local_6832); match prod_local_6833 {
        None => prod_local_6833,
        Some(prod_local_6834) => { let prod_local_6835 = (prod_local_6831).guard; match prod_local_6835 {
        false => prod_local_6833,
        true => { let prod_local_6837 = (prod_local_6831).sticky; match prod_local_6837 {
        false => { let prod_local_6841 = 1; { let prod_local_6842 = (prod_local_6834 & prod_local_6841); { let prod_local_6843 = (prod_local_6842 == prod_local_6841); match prod_local_6843 {
        false => prod_local_6833,
        true => { let prod_local_6845 = 1; { let prod_local_6846 = (prod_local_6834).checked_add(prod_local_6845); prod_local_6846 } },
    } } } },
        true => { let prod_local_6848 = 1; { let prod_local_6849 = (prod_local_6834).checked_add(prod_local_6848); prod_local_6849 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_6850 = prod_local_6386; { let prod_local_6854 = 32; { let prod_local_6855 = (val_2857 & prod_local_6854); { let prod_local_6856 = 0; { let prod_local_6857 = (prod_local_6855 == prod_local_6856); { let prod_local_6861 = match prod_local_6857 {
        false => { let prod_local_6859 = false; prod_local_6859 },
        true => { let prod_local_6860 = true; prod_local_6860 },
    }; match prod_local_6861 {
        false => { let prod_local_6863 = Some(prod_local_6850); { let prod_local_6864 = round32(prod_local_6863); match prod_local_6864 {
        None => { let prod_local_6865 = prod_local_6864; match prod_local_6865 {
        None => None,
        Some(prod_local_6867) => { let prod_local_6868 = prod_local_6867; { let prod_local_6869 = (prod_local_6868).value; { let prod_local_6870 = low64(prod_local_6869); match prod_local_6870 {
        None => prod_local_6870,
        Some(prod_local_6871) => { let prod_local_6872 = (prod_local_6868).guard; match prod_local_6872 {
        false => prod_local_6870,
        true => { let prod_local_6874 = (prod_local_6868).sticky; match prod_local_6874 {
        false => { let prod_local_6878 = 1; { let prod_local_6879 = (prod_local_6871 & prod_local_6878); { let prod_local_6880 = (prod_local_6879 == prod_local_6878); match prod_local_6880 {
        false => prod_local_6870,
        true => { let prod_local_6882 = 1; { let prod_local_6883 = (prod_local_6871).checked_add(prod_local_6882); prod_local_6883 } },
    } } } },
        true => { let prod_local_6885 = 1; { let prod_local_6886 = (prod_local_6871).checked_add(prod_local_6885); prod_local_6886 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_6887) => { let prod_local_6888 = prod_local_6887; { let prod_local_6892 = 64; { let prod_local_6893 = (val_2857 & prod_local_6892); { let prod_local_6894 = 0; { let prod_local_6895 = (prod_local_6893 == prod_local_6894); { let prod_local_6899 = match prod_local_6895 {
        false => { let prod_local_6897 = false; prod_local_6897 },
        true => { let prod_local_6898 = true; prod_local_6898 },
    }; match prod_local_6899 {
        false => { let prod_local_6901 = Some(prod_local_6888); { let prod_local_6902 = round64(prod_local_6901); match prod_local_6902 {
        None => { let prod_local_6903 = prod_local_6902; match prod_local_6903 {
        None => None,
        Some(prod_local_6905) => { let prod_local_6906 = prod_local_6905; { let prod_local_6907 = (prod_local_6906).value; { let prod_local_6908 = low64(prod_local_6907); match prod_local_6908 {
        None => prod_local_6908,
        Some(prod_local_6909) => { let prod_local_6910 = (prod_local_6906).guard; match prod_local_6910 {
        false => prod_local_6908,
        true => { let prod_local_6912 = (prod_local_6906).sticky; match prod_local_6912 {
        false => { let prod_local_6916 = 1; { let prod_local_6917 = (prod_local_6909 & prod_local_6916); { let prod_local_6918 = (prod_local_6917 == prod_local_6916); match prod_local_6918 {
        false => prod_local_6908,
        true => { let prod_local_6920 = 1; { let prod_local_6921 = (prod_local_6909).checked_add(prod_local_6920); prod_local_6921 } },
    } } } },
        true => { let prod_local_6923 = 1; { let prod_local_6924 = (prod_local_6909).checked_add(prod_local_6923); prod_local_6924 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_6925) => { let prod_local_6926 = prod_local_6925; { let prod_local_6930 = 128; { let prod_local_6931 = (val_2857 & prod_local_6930); { let prod_local_6932 = 0; { let prod_local_6933 = (prod_local_6931 == prod_local_6932); { let prod_local_6937 = match prod_local_6933 {
        false => { let prod_local_6935 = false; prod_local_6935 },
        true => { let prod_local_6936 = true; prod_local_6936 },
    }; match prod_local_6937 {
        false => { let prod_local_6939 = Some(prod_local_6926); { let prod_local_6940 = round128(prod_local_6939); match prod_local_6940 {
        None => { let prod_local_6941 = prod_local_6940; match prod_local_6941 {
        None => None,
        Some(prod_local_6943) => { let prod_local_6944 = prod_local_6943; { let prod_local_6945 = (prod_local_6944).value; { let prod_local_6946 = low64(prod_local_6945); match prod_local_6946 {
        None => prod_local_6946,
        Some(prod_local_6947) => { let prod_local_6948 = (prod_local_6944).guard; match prod_local_6948 {
        false => prod_local_6946,
        true => { let prod_local_6950 = (prod_local_6944).sticky; match prod_local_6950 {
        false => { let prod_local_6954 = 1; { let prod_local_6955 = (prod_local_6947 & prod_local_6954); { let prod_local_6956 = (prod_local_6955 == prod_local_6954); match prod_local_6956 {
        false => prod_local_6946,
        true => { let prod_local_6958 = 1; { let prod_local_6959 = (prod_local_6947).checked_add(prod_local_6958); prod_local_6959 } },
    } } } },
        true => { let prod_local_6961 = 1; { let prod_local_6962 = (prod_local_6947).checked_add(prod_local_6961); prod_local_6962 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_6963) => { let prod_local_6964 = prod_local_6963; { let prod_local_6965 = prod_local_6964; { let prod_local_6966 = (prod_local_6965).value; { let prod_local_6967 = low64(prod_local_6966); match prod_local_6967 {
        None => prod_local_6967,
        Some(prod_local_6968) => { let prod_local_6969 = (prod_local_6965).guard; match prod_local_6969 {
        false => prod_local_6967,
        true => { let prod_local_6971 = (prod_local_6965).sticky; match prod_local_6971 {
        false => { let prod_local_6975 = 1; { let prod_local_6976 = (prod_local_6968 & prod_local_6975); { let prod_local_6977 = (prod_local_6976 == prod_local_6975); match prod_local_6977 {
        false => prod_local_6967,
        true => { let prod_local_6979 = 1; { let prod_local_6980 = (prod_local_6968).checked_add(prod_local_6979); prod_local_6980 } },
    } } } },
        true => { let prod_local_6982 = 1; { let prod_local_6983 = (prod_local_6968).checked_add(prod_local_6982); prod_local_6983 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_6984 = prod_local_6926; { let prod_local_6985 = prod_local_6984; { let prod_local_6986 = (prod_local_6985).value; { let prod_local_6987 = low64(prod_local_6986); match prod_local_6987 {
        None => prod_local_6987,
        Some(prod_local_6988) => { let prod_local_6989 = (prod_local_6985).guard; match prod_local_6989 {
        false => prod_local_6987,
        true => { let prod_local_6991 = (prod_local_6985).sticky; match prod_local_6991 {
        false => { let prod_local_6995 = 1; { let prod_local_6996 = (prod_local_6988 & prod_local_6995); { let prod_local_6997 = (prod_local_6996 == prod_local_6995); match prod_local_6997 {
        false => prod_local_6987,
        true => { let prod_local_6999 = 1; { let prod_local_7000 = (prod_local_6988).checked_add(prod_local_6999); prod_local_7000 } },
    } } } },
        true => { let prod_local_7002 = 1; { let prod_local_7003 = (prod_local_6988).checked_add(prod_local_7002); prod_local_7003 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_7004 = prod_local_6888; { let prod_local_7008 = 128; { let prod_local_7009 = (val_2857 & prod_local_7008); { let prod_local_7010 = 0; { let prod_local_7011 = (prod_local_7009 == prod_local_7010); { let prod_local_7015 = match prod_local_7011 {
        false => { let prod_local_7013 = false; prod_local_7013 },
        true => { let prod_local_7014 = true; prod_local_7014 },
    }; match prod_local_7015 {
        false => { let prod_local_7017 = Some(prod_local_7004); { let prod_local_7018 = round128(prod_local_7017); match prod_local_7018 {
        None => { let prod_local_7019 = prod_local_7018; match prod_local_7019 {
        None => None,
        Some(prod_local_7021) => { let prod_local_7022 = prod_local_7021; { let prod_local_7023 = (prod_local_7022).value; { let prod_local_7024 = low64(prod_local_7023); match prod_local_7024 {
        None => prod_local_7024,
        Some(prod_local_7025) => { let prod_local_7026 = (prod_local_7022).guard; match prod_local_7026 {
        false => prod_local_7024,
        true => { let prod_local_7028 = (prod_local_7022).sticky; match prod_local_7028 {
        false => { let prod_local_7032 = 1; { let prod_local_7033 = (prod_local_7025 & prod_local_7032); { let prod_local_7034 = (prod_local_7033 == prod_local_7032); match prod_local_7034 {
        false => prod_local_7024,
        true => { let prod_local_7036 = 1; { let prod_local_7037 = (prod_local_7025).checked_add(prod_local_7036); prod_local_7037 } },
    } } } },
        true => { let prod_local_7039 = 1; { let prod_local_7040 = (prod_local_7025).checked_add(prod_local_7039); prod_local_7040 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_7041) => { let prod_local_7042 = prod_local_7041; { let prod_local_7043 = prod_local_7042; { let prod_local_7044 = (prod_local_7043).value; { let prod_local_7045 = low64(prod_local_7044); match prod_local_7045 {
        None => prod_local_7045,
        Some(prod_local_7046) => { let prod_local_7047 = (prod_local_7043).guard; match prod_local_7047 {
        false => prod_local_7045,
        true => { let prod_local_7049 = (prod_local_7043).sticky; match prod_local_7049 {
        false => { let prod_local_7053 = 1; { let prod_local_7054 = (prod_local_7046 & prod_local_7053); { let prod_local_7055 = (prod_local_7054 == prod_local_7053); match prod_local_7055 {
        false => prod_local_7045,
        true => { let prod_local_7057 = 1; { let prod_local_7058 = (prod_local_7046).checked_add(prod_local_7057); prod_local_7058 } },
    } } } },
        true => { let prod_local_7060 = 1; { let prod_local_7061 = (prod_local_7046).checked_add(prod_local_7060); prod_local_7061 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_7062 = prod_local_7004; { let prod_local_7063 = prod_local_7062; { let prod_local_7064 = (prod_local_7063).value; { let prod_local_7065 = low64(prod_local_7064); match prod_local_7065 {
        None => prod_local_7065,
        Some(prod_local_7066) => { let prod_local_7067 = (prod_local_7063).guard; match prod_local_7067 {
        false => prod_local_7065,
        true => { let prod_local_7069 = (prod_local_7063).sticky; match prod_local_7069 {
        false => { let prod_local_7073 = 1; { let prod_local_7074 = (prod_local_7066 & prod_local_7073); { let prod_local_7075 = (prod_local_7074 == prod_local_7073); match prod_local_7075 {
        false => prod_local_7065,
        true => { let prod_local_7077 = 1; { let prod_local_7078 = (prod_local_7066).checked_add(prod_local_7077); prod_local_7078 } },
    } } } },
        true => { let prod_local_7080 = 1; { let prod_local_7081 = (prod_local_7066).checked_add(prod_local_7080); prod_local_7081 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_7082 = prod_local_6850; { let prod_local_7086 = 64; { let prod_local_7087 = (val_2857 & prod_local_7086); { let prod_local_7088 = 0; { let prod_local_7089 = (prod_local_7087 == prod_local_7088); { let prod_local_7093 = match prod_local_7089 {
        false => { let prod_local_7091 = false; prod_local_7091 },
        true => { let prod_local_7092 = true; prod_local_7092 },
    }; match prod_local_7093 {
        false => { let prod_local_7095 = Some(prod_local_7082); { let prod_local_7096 = round64(prod_local_7095); match prod_local_7096 {
        None => { let prod_local_7097 = prod_local_7096; match prod_local_7097 {
        None => None,
        Some(prod_local_7099) => { let prod_local_7100 = prod_local_7099; { let prod_local_7101 = (prod_local_7100).value; { let prod_local_7102 = low64(prod_local_7101); match prod_local_7102 {
        None => prod_local_7102,
        Some(prod_local_7103) => { let prod_local_7104 = (prod_local_7100).guard; match prod_local_7104 {
        false => prod_local_7102,
        true => { let prod_local_7106 = (prod_local_7100).sticky; match prod_local_7106 {
        false => { let prod_local_7110 = 1; { let prod_local_7111 = (prod_local_7103 & prod_local_7110); { let prod_local_7112 = (prod_local_7111 == prod_local_7110); match prod_local_7112 {
        false => prod_local_7102,
        true => { let prod_local_7114 = 1; { let prod_local_7115 = (prod_local_7103).checked_add(prod_local_7114); prod_local_7115 } },
    } } } },
        true => { let prod_local_7117 = 1; { let prod_local_7118 = (prod_local_7103).checked_add(prod_local_7117); prod_local_7118 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_7119) => { let prod_local_7120 = prod_local_7119; { let prod_local_7124 = 128; { let prod_local_7125 = (val_2857 & prod_local_7124); { let prod_local_7126 = 0; { let prod_local_7127 = (prod_local_7125 == prod_local_7126); { let prod_local_7131 = match prod_local_7127 {
        false => { let prod_local_7129 = false; prod_local_7129 },
        true => { let prod_local_7130 = true; prod_local_7130 },
    }; match prod_local_7131 {
        false => { let prod_local_7133 = Some(prod_local_7120); { let prod_local_7134 = round128(prod_local_7133); match prod_local_7134 {
        None => { let prod_local_7135 = prod_local_7134; match prod_local_7135 {
        None => None,
        Some(prod_local_7137) => { let prod_local_7138 = prod_local_7137; { let prod_local_7139 = (prod_local_7138).value; { let prod_local_7140 = low64(prod_local_7139); match prod_local_7140 {
        None => prod_local_7140,
        Some(prod_local_7141) => { let prod_local_7142 = (prod_local_7138).guard; match prod_local_7142 {
        false => prod_local_7140,
        true => { let prod_local_7144 = (prod_local_7138).sticky; match prod_local_7144 {
        false => { let prod_local_7148 = 1; { let prod_local_7149 = (prod_local_7141 & prod_local_7148); { let prod_local_7150 = (prod_local_7149 == prod_local_7148); match prod_local_7150 {
        false => prod_local_7140,
        true => { let prod_local_7152 = 1; { let prod_local_7153 = (prod_local_7141).checked_add(prod_local_7152); prod_local_7153 } },
    } } } },
        true => { let prod_local_7155 = 1; { let prod_local_7156 = (prod_local_7141).checked_add(prod_local_7155); prod_local_7156 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_7157) => { let prod_local_7158 = prod_local_7157; { let prod_local_7159 = prod_local_7158; { let prod_local_7160 = (prod_local_7159).value; { let prod_local_7161 = low64(prod_local_7160); match prod_local_7161 {
        None => prod_local_7161,
        Some(prod_local_7162) => { let prod_local_7163 = (prod_local_7159).guard; match prod_local_7163 {
        false => prod_local_7161,
        true => { let prod_local_7165 = (prod_local_7159).sticky; match prod_local_7165 {
        false => { let prod_local_7169 = 1; { let prod_local_7170 = (prod_local_7162 & prod_local_7169); { let prod_local_7171 = (prod_local_7170 == prod_local_7169); match prod_local_7171 {
        false => prod_local_7161,
        true => { let prod_local_7173 = 1; { let prod_local_7174 = (prod_local_7162).checked_add(prod_local_7173); prod_local_7174 } },
    } } } },
        true => { let prod_local_7176 = 1; { let prod_local_7177 = (prod_local_7162).checked_add(prod_local_7176); prod_local_7177 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_7178 = prod_local_7120; { let prod_local_7179 = prod_local_7178; { let prod_local_7180 = (prod_local_7179).value; { let prod_local_7181 = low64(prod_local_7180); match prod_local_7181 {
        None => prod_local_7181,
        Some(prod_local_7182) => { let prod_local_7183 = (prod_local_7179).guard; match prod_local_7183 {
        false => prod_local_7181,
        true => { let prod_local_7185 = (prod_local_7179).sticky; match prod_local_7185 {
        false => { let prod_local_7189 = 1; { let prod_local_7190 = (prod_local_7182 & prod_local_7189); { let prod_local_7191 = (prod_local_7190 == prod_local_7189); match prod_local_7191 {
        false => prod_local_7181,
        true => { let prod_local_7193 = 1; { let prod_local_7194 = (prod_local_7182).checked_add(prod_local_7193); prod_local_7194 } },
    } } } },
        true => { let prod_local_7196 = 1; { let prod_local_7197 = (prod_local_7182).checked_add(prod_local_7196); prod_local_7197 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_7198 = prod_local_7082; { let prod_local_7202 = 128; { let prod_local_7203 = (val_2857 & prod_local_7202); { let prod_local_7204 = 0; { let prod_local_7205 = (prod_local_7203 == prod_local_7204); { let prod_local_7209 = match prod_local_7205 {
        false => { let prod_local_7207 = false; prod_local_7207 },
        true => { let prod_local_7208 = true; prod_local_7208 },
    }; match prod_local_7209 {
        false => { let prod_local_7211 = Some(prod_local_7198); { let prod_local_7212 = round128(prod_local_7211); match prod_local_7212 {
        None => { let prod_local_7213 = prod_local_7212; match prod_local_7213 {
        None => None,
        Some(prod_local_7215) => { let prod_local_7216 = prod_local_7215; { let prod_local_7217 = (prod_local_7216).value; { let prod_local_7218 = low64(prod_local_7217); match prod_local_7218 {
        None => prod_local_7218,
        Some(prod_local_7219) => { let prod_local_7220 = (prod_local_7216).guard; match prod_local_7220 {
        false => prod_local_7218,
        true => { let prod_local_7222 = (prod_local_7216).sticky; match prod_local_7222 {
        false => { let prod_local_7226 = 1; { let prod_local_7227 = (prod_local_7219 & prod_local_7226); { let prod_local_7228 = (prod_local_7227 == prod_local_7226); match prod_local_7228 {
        false => prod_local_7218,
        true => { let prod_local_7230 = 1; { let prod_local_7231 = (prod_local_7219).checked_add(prod_local_7230); prod_local_7231 } },
    } } } },
        true => { let prod_local_7233 = 1; { let prod_local_7234 = (prod_local_7219).checked_add(prod_local_7233); prod_local_7234 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_7235) => { let prod_local_7236 = prod_local_7235; { let prod_local_7237 = prod_local_7236; { let prod_local_7238 = (prod_local_7237).value; { let prod_local_7239 = low64(prod_local_7238); match prod_local_7239 {
        None => prod_local_7239,
        Some(prod_local_7240) => { let prod_local_7241 = (prod_local_7237).guard; match prod_local_7241 {
        false => prod_local_7239,
        true => { let prod_local_7243 = (prod_local_7237).sticky; match prod_local_7243 {
        false => { let prod_local_7247 = 1; { let prod_local_7248 = (prod_local_7240 & prod_local_7247); { let prod_local_7249 = (prod_local_7248 == prod_local_7247); match prod_local_7249 {
        false => prod_local_7239,
        true => { let prod_local_7251 = 1; { let prod_local_7252 = (prod_local_7240).checked_add(prod_local_7251); prod_local_7252 } },
    } } } },
        true => { let prod_local_7254 = 1; { let prod_local_7255 = (prod_local_7240).checked_add(prod_local_7254); prod_local_7255 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_7256 = prod_local_7198; { let prod_local_7257 = prod_local_7256; { let prod_local_7258 = (prod_local_7257).value; { let prod_local_7259 = low64(prod_local_7258); match prod_local_7259 {
        None => prod_local_7259,
        Some(prod_local_7260) => { let prod_local_7261 = (prod_local_7257).guard; match prod_local_7261 {
        false => prod_local_7259,
        true => { let prod_local_7263 = (prod_local_7257).sticky; match prod_local_7263 {
        false => { let prod_local_7267 = 1; { let prod_local_7268 = (prod_local_7260 & prod_local_7267); { let prod_local_7269 = (prod_local_7268 == prod_local_7267); match prod_local_7269 {
        false => prod_local_7259,
        true => { let prod_local_7271 = 1; { let prod_local_7272 = (prod_local_7260).checked_add(prod_local_7271); prod_local_7272 } },
    } } } },
        true => { let prod_local_7274 = 1; { let prod_local_7275 = (prod_local_7260).checked_add(prod_local_7274); prod_local_7275 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } } } } } },
    } } } } } } },
    } } } } } } },
    } } } } } } },
    } } } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_7276 = _x_2909; { let prod_local_7280 = 2; { let prod_local_7281 = (val_2857 & prod_local_7280); { let prod_local_7282 = 0; { let prod_local_7283 = (prod_local_7281 == prod_local_7282); { let prod_local_7287 = match prod_local_7283 {
        false => { let prod_local_7285 = false; prod_local_7285 },
        true => { let prod_local_7286 = true; prod_local_7286 },
    }; match prod_local_7287 {
        false => { let prod_local_7289 = Some(prod_local_7276); { let prod_local_7290 = round2(prod_local_7289); match prod_local_7290 {
        None => { let prod_local_7291 = prod_local_7290; match prod_local_7291 {
        None => None,
        Some(prod_local_7293) => { let prod_local_7294 = prod_local_7293; { let prod_local_7295 = (prod_local_7294).value; { let prod_local_7296 = low64(prod_local_7295); match prod_local_7296 {
        None => prod_local_7296,
        Some(prod_local_7297) => { let prod_local_7298 = (prod_local_7294).guard; match prod_local_7298 {
        false => prod_local_7296,
        true => { let prod_local_7300 = (prod_local_7294).sticky; match prod_local_7300 {
        false => { let prod_local_7304 = 1; { let prod_local_7305 = (prod_local_7297 & prod_local_7304); { let prod_local_7306 = (prod_local_7305 == prod_local_7304); match prod_local_7306 {
        false => prod_local_7296,
        true => { let prod_local_7308 = 1; { let prod_local_7309 = (prod_local_7297).checked_add(prod_local_7308); prod_local_7309 } },
    } } } },
        true => { let prod_local_7311 = 1; { let prod_local_7312 = (prod_local_7297).checked_add(prod_local_7311); prod_local_7312 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_7313) => { let prod_local_7314 = prod_local_7313; { let prod_local_7318 = 4; { let prod_local_7319 = (val_2857 & prod_local_7318); { let prod_local_7320 = 0; { let prod_local_7321 = (prod_local_7319 == prod_local_7320); { let prod_local_7325 = match prod_local_7321 {
        false => { let prod_local_7323 = false; prod_local_7323 },
        true => { let prod_local_7324 = true; prod_local_7324 },
    }; match prod_local_7325 {
        false => { let prod_local_7327 = Some(prod_local_7314); { let prod_local_7328 = round4(prod_local_7327); match prod_local_7328 {
        None => { let prod_local_7329 = prod_local_7328; match prod_local_7329 {
        None => None,
        Some(prod_local_7331) => { let prod_local_7332 = prod_local_7331; { let prod_local_7333 = (prod_local_7332).value; { let prod_local_7334 = low64(prod_local_7333); match prod_local_7334 {
        None => prod_local_7334,
        Some(prod_local_7335) => { let prod_local_7336 = (prod_local_7332).guard; match prod_local_7336 {
        false => prod_local_7334,
        true => { let prod_local_7338 = (prod_local_7332).sticky; match prod_local_7338 {
        false => { let prod_local_7342 = 1; { let prod_local_7343 = (prod_local_7335 & prod_local_7342); { let prod_local_7344 = (prod_local_7343 == prod_local_7342); match prod_local_7344 {
        false => prod_local_7334,
        true => { let prod_local_7346 = 1; { let prod_local_7347 = (prod_local_7335).checked_add(prod_local_7346); prod_local_7347 } },
    } } } },
        true => { let prod_local_7349 = 1; { let prod_local_7350 = (prod_local_7335).checked_add(prod_local_7349); prod_local_7350 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_7351) => { let prod_local_7352 = prod_local_7351; { let prod_local_7356 = 8; { let prod_local_7357 = (val_2857 & prod_local_7356); { let prod_local_7358 = 0; { let prod_local_7359 = (prod_local_7357 == prod_local_7358); { let prod_local_7363 = match prod_local_7359 {
        false => { let prod_local_7361 = false; prod_local_7361 },
        true => { let prod_local_7362 = true; prod_local_7362 },
    }; match prod_local_7363 {
        false => { let prod_local_7365 = Some(prod_local_7352); { let prod_local_7366 = round8(prod_local_7365); match prod_local_7366 {
        None => { let prod_local_7367 = prod_local_7366; match prod_local_7367 {
        None => None,
        Some(prod_local_7369) => { let prod_local_7370 = prod_local_7369; { let prod_local_7371 = (prod_local_7370).value; { let prod_local_7372 = low64(prod_local_7371); match prod_local_7372 {
        None => prod_local_7372,
        Some(prod_local_7373) => { let prod_local_7374 = (prod_local_7370).guard; match prod_local_7374 {
        false => prod_local_7372,
        true => { let prod_local_7376 = (prod_local_7370).sticky; match prod_local_7376 {
        false => { let prod_local_7380 = 1; { let prod_local_7381 = (prod_local_7373 & prod_local_7380); { let prod_local_7382 = (prod_local_7381 == prod_local_7380); match prod_local_7382 {
        false => prod_local_7372,
        true => { let prod_local_7384 = 1; { let prod_local_7385 = (prod_local_7373).checked_add(prod_local_7384); prod_local_7385 } },
    } } } },
        true => { let prod_local_7387 = 1; { let prod_local_7388 = (prod_local_7373).checked_add(prod_local_7387); prod_local_7388 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_7389) => { let prod_local_7390 = prod_local_7389; { let prod_local_7394 = 16; { let prod_local_7395 = (val_2857 & prod_local_7394); { let prod_local_7396 = 0; { let prod_local_7397 = (prod_local_7395 == prod_local_7396); { let prod_local_7401 = match prod_local_7397 {
        false => { let prod_local_7399 = false; prod_local_7399 },
        true => { let prod_local_7400 = true; prod_local_7400 },
    }; match prod_local_7401 {
        false => { let prod_local_7403 = Some(prod_local_7390); { let prod_local_7404 = round16(prod_local_7403); match prod_local_7404 {
        None => { let prod_local_7405 = prod_local_7404; match prod_local_7405 {
        None => None,
        Some(prod_local_7407) => { let prod_local_7408 = prod_local_7407; { let prod_local_7409 = (prod_local_7408).value; { let prod_local_7410 = low64(prod_local_7409); match prod_local_7410 {
        None => prod_local_7410,
        Some(prod_local_7411) => { let prod_local_7412 = (prod_local_7408).guard; match prod_local_7412 {
        false => prod_local_7410,
        true => { let prod_local_7414 = (prod_local_7408).sticky; match prod_local_7414 {
        false => { let prod_local_7418 = 1; { let prod_local_7419 = (prod_local_7411 & prod_local_7418); { let prod_local_7420 = (prod_local_7419 == prod_local_7418); match prod_local_7420 {
        false => prod_local_7410,
        true => { let prod_local_7422 = 1; { let prod_local_7423 = (prod_local_7411).checked_add(prod_local_7422); prod_local_7423 } },
    } } } },
        true => { let prod_local_7425 = 1; { let prod_local_7426 = (prod_local_7411).checked_add(prod_local_7425); prod_local_7426 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_7427) => { let prod_local_7428 = prod_local_7427; { let prod_local_7432 = 32; { let prod_local_7433 = (val_2857 & prod_local_7432); { let prod_local_7434 = 0; { let prod_local_7435 = (prod_local_7433 == prod_local_7434); { let prod_local_7439 = match prod_local_7435 {
        false => { let prod_local_7437 = false; prod_local_7437 },
        true => { let prod_local_7438 = true; prod_local_7438 },
    }; match prod_local_7439 {
        false => { let prod_local_7441 = Some(prod_local_7428); { let prod_local_7442 = round32(prod_local_7441); match prod_local_7442 {
        None => { let prod_local_7443 = prod_local_7442; match prod_local_7443 {
        None => None,
        Some(prod_local_7445) => { let prod_local_7446 = prod_local_7445; { let prod_local_7447 = (prod_local_7446).value; { let prod_local_7448 = low64(prod_local_7447); match prod_local_7448 {
        None => prod_local_7448,
        Some(prod_local_7449) => { let prod_local_7450 = (prod_local_7446).guard; match prod_local_7450 {
        false => prod_local_7448,
        true => { let prod_local_7452 = (prod_local_7446).sticky; match prod_local_7452 {
        false => { let prod_local_7456 = 1; { let prod_local_7457 = (prod_local_7449 & prod_local_7456); { let prod_local_7458 = (prod_local_7457 == prod_local_7456); match prod_local_7458 {
        false => prod_local_7448,
        true => { let prod_local_7460 = 1; { let prod_local_7461 = (prod_local_7449).checked_add(prod_local_7460); prod_local_7461 } },
    } } } },
        true => { let prod_local_7463 = 1; { let prod_local_7464 = (prod_local_7449).checked_add(prod_local_7463); prod_local_7464 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_7465) => { let prod_local_7466 = prod_local_7465; { let prod_local_7470 = 64; { let prod_local_7471 = (val_2857 & prod_local_7470); { let prod_local_7472 = 0; { let prod_local_7473 = (prod_local_7471 == prod_local_7472); { let prod_local_7477 = match prod_local_7473 {
        false => { let prod_local_7475 = false; prod_local_7475 },
        true => { let prod_local_7476 = true; prod_local_7476 },
    }; match prod_local_7477 {
        false => { let prod_local_7479 = Some(prod_local_7466); { let prod_local_7480 = round64(prod_local_7479); match prod_local_7480 {
        None => { let prod_local_7481 = prod_local_7480; match prod_local_7481 {
        None => None,
        Some(prod_local_7483) => { let prod_local_7484 = prod_local_7483; { let prod_local_7485 = (prod_local_7484).value; { let prod_local_7486 = low64(prod_local_7485); match prod_local_7486 {
        None => prod_local_7486,
        Some(prod_local_7487) => { let prod_local_7488 = (prod_local_7484).guard; match prod_local_7488 {
        false => prod_local_7486,
        true => { let prod_local_7490 = (prod_local_7484).sticky; match prod_local_7490 {
        false => { let prod_local_7494 = 1; { let prod_local_7495 = (prod_local_7487 & prod_local_7494); { let prod_local_7496 = (prod_local_7495 == prod_local_7494); match prod_local_7496 {
        false => prod_local_7486,
        true => { let prod_local_7498 = 1; { let prod_local_7499 = (prod_local_7487).checked_add(prod_local_7498); prod_local_7499 } },
    } } } },
        true => { let prod_local_7501 = 1; { let prod_local_7502 = (prod_local_7487).checked_add(prod_local_7501); prod_local_7502 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_7503) => { let prod_local_7504 = prod_local_7503; { let prod_local_7508 = 128; { let prod_local_7509 = (val_2857 & prod_local_7508); { let prod_local_7510 = 0; { let prod_local_7511 = (prod_local_7509 == prod_local_7510); { let prod_local_7515 = match prod_local_7511 {
        false => { let prod_local_7513 = false; prod_local_7513 },
        true => { let prod_local_7514 = true; prod_local_7514 },
    }; match prod_local_7515 {
        false => { let prod_local_7517 = Some(prod_local_7504); { let prod_local_7518 = round128(prod_local_7517); match prod_local_7518 {
        None => { let prod_local_7519 = prod_local_7518; match prod_local_7519 {
        None => None,
        Some(prod_local_7521) => { let prod_local_7522 = prod_local_7521; { let prod_local_7523 = (prod_local_7522).value; { let prod_local_7524 = low64(prod_local_7523); match prod_local_7524 {
        None => prod_local_7524,
        Some(prod_local_7525) => { let prod_local_7526 = (prod_local_7522).guard; match prod_local_7526 {
        false => prod_local_7524,
        true => { let prod_local_7528 = (prod_local_7522).sticky; match prod_local_7528 {
        false => { let prod_local_7532 = 1; { let prod_local_7533 = (prod_local_7525 & prod_local_7532); { let prod_local_7534 = (prod_local_7533 == prod_local_7532); match prod_local_7534 {
        false => prod_local_7524,
        true => { let prod_local_7536 = 1; { let prod_local_7537 = (prod_local_7525).checked_add(prod_local_7536); prod_local_7537 } },
    } } } },
        true => { let prod_local_7539 = 1; { let prod_local_7540 = (prod_local_7525).checked_add(prod_local_7539); prod_local_7540 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_7541) => { let prod_local_7542 = prod_local_7541; { let prod_local_7543 = prod_local_7542; { let prod_local_7544 = (prod_local_7543).value; { let prod_local_7545 = low64(prod_local_7544); match prod_local_7545 {
        None => prod_local_7545,
        Some(prod_local_7546) => { let prod_local_7547 = (prod_local_7543).guard; match prod_local_7547 {
        false => prod_local_7545,
        true => { let prod_local_7549 = (prod_local_7543).sticky; match prod_local_7549 {
        false => { let prod_local_7553 = 1; { let prod_local_7554 = (prod_local_7546 & prod_local_7553); { let prod_local_7555 = (prod_local_7554 == prod_local_7553); match prod_local_7555 {
        false => prod_local_7545,
        true => { let prod_local_7557 = 1; { let prod_local_7558 = (prod_local_7546).checked_add(prod_local_7557); prod_local_7558 } },
    } } } },
        true => { let prod_local_7560 = 1; { let prod_local_7561 = (prod_local_7546).checked_add(prod_local_7560); prod_local_7561 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_7562 = prod_local_7504; { let prod_local_7563 = prod_local_7562; { let prod_local_7564 = (prod_local_7563).value; { let prod_local_7565 = low64(prod_local_7564); match prod_local_7565 {
        None => prod_local_7565,
        Some(prod_local_7566) => { let prod_local_7567 = (prod_local_7563).guard; match prod_local_7567 {
        false => prod_local_7565,
        true => { let prod_local_7569 = (prod_local_7563).sticky; match prod_local_7569 {
        false => { let prod_local_7573 = 1; { let prod_local_7574 = (prod_local_7566 & prod_local_7573); { let prod_local_7575 = (prod_local_7574 == prod_local_7573); match prod_local_7575 {
        false => prod_local_7565,
        true => { let prod_local_7577 = 1; { let prod_local_7578 = (prod_local_7566).checked_add(prod_local_7577); prod_local_7578 } },
    } } } },
        true => { let prod_local_7580 = 1; { let prod_local_7581 = (prod_local_7566).checked_add(prod_local_7580); prod_local_7581 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_7582 = prod_local_7466; { let prod_local_7586 = 128; { let prod_local_7587 = (val_2857 & prod_local_7586); { let prod_local_7588 = 0; { let prod_local_7589 = (prod_local_7587 == prod_local_7588); { let prod_local_7593 = match prod_local_7589 {
        false => { let prod_local_7591 = false; prod_local_7591 },
        true => { let prod_local_7592 = true; prod_local_7592 },
    }; match prod_local_7593 {
        false => { let prod_local_7595 = Some(prod_local_7582); { let prod_local_7596 = round128(prod_local_7595); match prod_local_7596 {
        None => { let prod_local_7597 = prod_local_7596; match prod_local_7597 {
        None => None,
        Some(prod_local_7599) => { let prod_local_7600 = prod_local_7599; { let prod_local_7601 = (prod_local_7600).value; { let prod_local_7602 = low64(prod_local_7601); match prod_local_7602 {
        None => prod_local_7602,
        Some(prod_local_7603) => { let prod_local_7604 = (prod_local_7600).guard; match prod_local_7604 {
        false => prod_local_7602,
        true => { let prod_local_7606 = (prod_local_7600).sticky; match prod_local_7606 {
        false => { let prod_local_7610 = 1; { let prod_local_7611 = (prod_local_7603 & prod_local_7610); { let prod_local_7612 = (prod_local_7611 == prod_local_7610); match prod_local_7612 {
        false => prod_local_7602,
        true => { let prod_local_7614 = 1; { let prod_local_7615 = (prod_local_7603).checked_add(prod_local_7614); prod_local_7615 } },
    } } } },
        true => { let prod_local_7617 = 1; { let prod_local_7618 = (prod_local_7603).checked_add(prod_local_7617); prod_local_7618 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_7619) => { let prod_local_7620 = prod_local_7619; { let prod_local_7621 = prod_local_7620; { let prod_local_7622 = (prod_local_7621).value; { let prod_local_7623 = low64(prod_local_7622); match prod_local_7623 {
        None => prod_local_7623,
        Some(prod_local_7624) => { let prod_local_7625 = (prod_local_7621).guard; match prod_local_7625 {
        false => prod_local_7623,
        true => { let prod_local_7627 = (prod_local_7621).sticky; match prod_local_7627 {
        false => { let prod_local_7631 = 1; { let prod_local_7632 = (prod_local_7624 & prod_local_7631); { let prod_local_7633 = (prod_local_7632 == prod_local_7631); match prod_local_7633 {
        false => prod_local_7623,
        true => { let prod_local_7635 = 1; { let prod_local_7636 = (prod_local_7624).checked_add(prod_local_7635); prod_local_7636 } },
    } } } },
        true => { let prod_local_7638 = 1; { let prod_local_7639 = (prod_local_7624).checked_add(prod_local_7638); prod_local_7639 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_7640 = prod_local_7582; { let prod_local_7641 = prod_local_7640; { let prod_local_7642 = (prod_local_7641).value; { let prod_local_7643 = low64(prod_local_7642); match prod_local_7643 {
        None => prod_local_7643,
        Some(prod_local_7644) => { let prod_local_7645 = (prod_local_7641).guard; match prod_local_7645 {
        false => prod_local_7643,
        true => { let prod_local_7647 = (prod_local_7641).sticky; match prod_local_7647 {
        false => { let prod_local_7651 = 1; { let prod_local_7652 = (prod_local_7644 & prod_local_7651); { let prod_local_7653 = (prod_local_7652 == prod_local_7651); match prod_local_7653 {
        false => prod_local_7643,
        true => { let prod_local_7655 = 1; { let prod_local_7656 = (prod_local_7644).checked_add(prod_local_7655); prod_local_7656 } },
    } } } },
        true => { let prod_local_7658 = 1; { let prod_local_7659 = (prod_local_7644).checked_add(prod_local_7658); prod_local_7659 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_7660 = prod_local_7428; { let prod_local_7664 = 64; { let prod_local_7665 = (val_2857 & prod_local_7664); { let prod_local_7666 = 0; { let prod_local_7667 = (prod_local_7665 == prod_local_7666); { let prod_local_7671 = match prod_local_7667 {
        false => { let prod_local_7669 = false; prod_local_7669 },
        true => { let prod_local_7670 = true; prod_local_7670 },
    }; match prod_local_7671 {
        false => { let prod_local_7673 = Some(prod_local_7660); { let prod_local_7674 = round64(prod_local_7673); match prod_local_7674 {
        None => { let prod_local_7675 = prod_local_7674; match prod_local_7675 {
        None => None,
        Some(prod_local_7677) => { let prod_local_7678 = prod_local_7677; { let prod_local_7679 = (prod_local_7678).value; { let prod_local_7680 = low64(prod_local_7679); match prod_local_7680 {
        None => prod_local_7680,
        Some(prod_local_7681) => { let prod_local_7682 = (prod_local_7678).guard; match prod_local_7682 {
        false => prod_local_7680,
        true => { let prod_local_7684 = (prod_local_7678).sticky; match prod_local_7684 {
        false => { let prod_local_7688 = 1; { let prod_local_7689 = (prod_local_7681 & prod_local_7688); { let prod_local_7690 = (prod_local_7689 == prod_local_7688); match prod_local_7690 {
        false => prod_local_7680,
        true => { let prod_local_7692 = 1; { let prod_local_7693 = (prod_local_7681).checked_add(prod_local_7692); prod_local_7693 } },
    } } } },
        true => { let prod_local_7695 = 1; { let prod_local_7696 = (prod_local_7681).checked_add(prod_local_7695); prod_local_7696 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_7697) => { let prod_local_7698 = prod_local_7697; { let prod_local_7702 = 128; { let prod_local_7703 = (val_2857 & prod_local_7702); { let prod_local_7704 = 0; { let prod_local_7705 = (prod_local_7703 == prod_local_7704); { let prod_local_7709 = match prod_local_7705 {
        false => { let prod_local_7707 = false; prod_local_7707 },
        true => { let prod_local_7708 = true; prod_local_7708 },
    }; match prod_local_7709 {
        false => { let prod_local_7711 = Some(prod_local_7698); { let prod_local_7712 = round128(prod_local_7711); match prod_local_7712 {
        None => { let prod_local_7713 = prod_local_7712; match prod_local_7713 {
        None => None,
        Some(prod_local_7715) => { let prod_local_7716 = prod_local_7715; { let prod_local_7717 = (prod_local_7716).value; { let prod_local_7718 = low64(prod_local_7717); match prod_local_7718 {
        None => prod_local_7718,
        Some(prod_local_7719) => { let prod_local_7720 = (prod_local_7716).guard; match prod_local_7720 {
        false => prod_local_7718,
        true => { let prod_local_7722 = (prod_local_7716).sticky; match prod_local_7722 {
        false => { let prod_local_7726 = 1; { let prod_local_7727 = (prod_local_7719 & prod_local_7726); { let prod_local_7728 = (prod_local_7727 == prod_local_7726); match prod_local_7728 {
        false => prod_local_7718,
        true => { let prod_local_7730 = 1; { let prod_local_7731 = (prod_local_7719).checked_add(prod_local_7730); prod_local_7731 } },
    } } } },
        true => { let prod_local_7733 = 1; { let prod_local_7734 = (prod_local_7719).checked_add(prod_local_7733); prod_local_7734 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_7735) => { let prod_local_7736 = prod_local_7735; { let prod_local_7737 = prod_local_7736; { let prod_local_7738 = (prod_local_7737).value; { let prod_local_7739 = low64(prod_local_7738); match prod_local_7739 {
        None => prod_local_7739,
        Some(prod_local_7740) => { let prod_local_7741 = (prod_local_7737).guard; match prod_local_7741 {
        false => prod_local_7739,
        true => { let prod_local_7743 = (prod_local_7737).sticky; match prod_local_7743 {
        false => { let prod_local_7747 = 1; { let prod_local_7748 = (prod_local_7740 & prod_local_7747); { let prod_local_7749 = (prod_local_7748 == prod_local_7747); match prod_local_7749 {
        false => prod_local_7739,
        true => { let prod_local_7751 = 1; { let prod_local_7752 = (prod_local_7740).checked_add(prod_local_7751); prod_local_7752 } },
    } } } },
        true => { let prod_local_7754 = 1; { let prod_local_7755 = (prod_local_7740).checked_add(prod_local_7754); prod_local_7755 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_7756 = prod_local_7698; { let prod_local_7757 = prod_local_7756; { let prod_local_7758 = (prod_local_7757).value; { let prod_local_7759 = low64(prod_local_7758); match prod_local_7759 {
        None => prod_local_7759,
        Some(prod_local_7760) => { let prod_local_7761 = (prod_local_7757).guard; match prod_local_7761 {
        false => prod_local_7759,
        true => { let prod_local_7763 = (prod_local_7757).sticky; match prod_local_7763 {
        false => { let prod_local_7767 = 1; { let prod_local_7768 = (prod_local_7760 & prod_local_7767); { let prod_local_7769 = (prod_local_7768 == prod_local_7767); match prod_local_7769 {
        false => prod_local_7759,
        true => { let prod_local_7771 = 1; { let prod_local_7772 = (prod_local_7760).checked_add(prod_local_7771); prod_local_7772 } },
    } } } },
        true => { let prod_local_7774 = 1; { let prod_local_7775 = (prod_local_7760).checked_add(prod_local_7774); prod_local_7775 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_7776 = prod_local_7660; { let prod_local_7780 = 128; { let prod_local_7781 = (val_2857 & prod_local_7780); { let prod_local_7782 = 0; { let prod_local_7783 = (prod_local_7781 == prod_local_7782); { let prod_local_7787 = match prod_local_7783 {
        false => { let prod_local_7785 = false; prod_local_7785 },
        true => { let prod_local_7786 = true; prod_local_7786 },
    }; match prod_local_7787 {
        false => { let prod_local_7789 = Some(prod_local_7776); { let prod_local_7790 = round128(prod_local_7789); match prod_local_7790 {
        None => { let prod_local_7791 = prod_local_7790; match prod_local_7791 {
        None => None,
        Some(prod_local_7793) => { let prod_local_7794 = prod_local_7793; { let prod_local_7795 = (prod_local_7794).value; { let prod_local_7796 = low64(prod_local_7795); match prod_local_7796 {
        None => prod_local_7796,
        Some(prod_local_7797) => { let prod_local_7798 = (prod_local_7794).guard; match prod_local_7798 {
        false => prod_local_7796,
        true => { let prod_local_7800 = (prod_local_7794).sticky; match prod_local_7800 {
        false => { let prod_local_7804 = 1; { let prod_local_7805 = (prod_local_7797 & prod_local_7804); { let prod_local_7806 = (prod_local_7805 == prod_local_7804); match prod_local_7806 {
        false => prod_local_7796,
        true => { let prod_local_7808 = 1; { let prod_local_7809 = (prod_local_7797).checked_add(prod_local_7808); prod_local_7809 } },
    } } } },
        true => { let prod_local_7811 = 1; { let prod_local_7812 = (prod_local_7797).checked_add(prod_local_7811); prod_local_7812 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_7813) => { let prod_local_7814 = prod_local_7813; { let prod_local_7815 = prod_local_7814; { let prod_local_7816 = (prod_local_7815).value; { let prod_local_7817 = low64(prod_local_7816); match prod_local_7817 {
        None => prod_local_7817,
        Some(prod_local_7818) => { let prod_local_7819 = (prod_local_7815).guard; match prod_local_7819 {
        false => prod_local_7817,
        true => { let prod_local_7821 = (prod_local_7815).sticky; match prod_local_7821 {
        false => { let prod_local_7825 = 1; { let prod_local_7826 = (prod_local_7818 & prod_local_7825); { let prod_local_7827 = (prod_local_7826 == prod_local_7825); match prod_local_7827 {
        false => prod_local_7817,
        true => { let prod_local_7829 = 1; { let prod_local_7830 = (prod_local_7818).checked_add(prod_local_7829); prod_local_7830 } },
    } } } },
        true => { let prod_local_7832 = 1; { let prod_local_7833 = (prod_local_7818).checked_add(prod_local_7832); prod_local_7833 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_7834 = prod_local_7776; { let prod_local_7835 = prod_local_7834; { let prod_local_7836 = (prod_local_7835).value; { let prod_local_7837 = low64(prod_local_7836); match prod_local_7837 {
        None => prod_local_7837,
        Some(prod_local_7838) => { let prod_local_7839 = (prod_local_7835).guard; match prod_local_7839 {
        false => prod_local_7837,
        true => { let prod_local_7841 = (prod_local_7835).sticky; match prod_local_7841 {
        false => { let prod_local_7845 = 1; { let prod_local_7846 = (prod_local_7838 & prod_local_7845); { let prod_local_7847 = (prod_local_7846 == prod_local_7845); match prod_local_7847 {
        false => prod_local_7837,
        true => { let prod_local_7849 = 1; { let prod_local_7850 = (prod_local_7838).checked_add(prod_local_7849); prod_local_7850 } },
    } } } },
        true => { let prod_local_7852 = 1; { let prod_local_7853 = (prod_local_7838).checked_add(prod_local_7852); prod_local_7853 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_7854 = prod_local_7390; { let prod_local_7858 = 32; { let prod_local_7859 = (val_2857 & prod_local_7858); { let prod_local_7860 = 0; { let prod_local_7861 = (prod_local_7859 == prod_local_7860); { let prod_local_7865 = match prod_local_7861 {
        false => { let prod_local_7863 = false; prod_local_7863 },
        true => { let prod_local_7864 = true; prod_local_7864 },
    }; match prod_local_7865 {
        false => { let prod_local_7867 = Some(prod_local_7854); { let prod_local_7868 = round32(prod_local_7867); match prod_local_7868 {
        None => { let prod_local_7869 = prod_local_7868; match prod_local_7869 {
        None => None,
        Some(prod_local_7871) => { let prod_local_7872 = prod_local_7871; { let prod_local_7873 = (prod_local_7872).value; { let prod_local_7874 = low64(prod_local_7873); match prod_local_7874 {
        None => prod_local_7874,
        Some(prod_local_7875) => { let prod_local_7876 = (prod_local_7872).guard; match prod_local_7876 {
        false => prod_local_7874,
        true => { let prod_local_7878 = (prod_local_7872).sticky; match prod_local_7878 {
        false => { let prod_local_7882 = 1; { let prod_local_7883 = (prod_local_7875 & prod_local_7882); { let prod_local_7884 = (prod_local_7883 == prod_local_7882); match prod_local_7884 {
        false => prod_local_7874,
        true => { let prod_local_7886 = 1; { let prod_local_7887 = (prod_local_7875).checked_add(prod_local_7886); prod_local_7887 } },
    } } } },
        true => { let prod_local_7889 = 1; { let prod_local_7890 = (prod_local_7875).checked_add(prod_local_7889); prod_local_7890 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_7891) => { let prod_local_7892 = prod_local_7891; { let prod_local_7896 = 64; { let prod_local_7897 = (val_2857 & prod_local_7896); { let prod_local_7898 = 0; { let prod_local_7899 = (prod_local_7897 == prod_local_7898); { let prod_local_7903 = match prod_local_7899 {
        false => { let prod_local_7901 = false; prod_local_7901 },
        true => { let prod_local_7902 = true; prod_local_7902 },
    }; match prod_local_7903 {
        false => { let prod_local_7905 = Some(prod_local_7892); { let prod_local_7906 = round64(prod_local_7905); match prod_local_7906 {
        None => { let prod_local_7907 = prod_local_7906; match prod_local_7907 {
        None => None,
        Some(prod_local_7909) => { let prod_local_7910 = prod_local_7909; { let prod_local_7911 = (prod_local_7910).value; { let prod_local_7912 = low64(prod_local_7911); match prod_local_7912 {
        None => prod_local_7912,
        Some(prod_local_7913) => { let prod_local_7914 = (prod_local_7910).guard; match prod_local_7914 {
        false => prod_local_7912,
        true => { let prod_local_7916 = (prod_local_7910).sticky; match prod_local_7916 {
        false => { let prod_local_7920 = 1; { let prod_local_7921 = (prod_local_7913 & prod_local_7920); { let prod_local_7922 = (prod_local_7921 == prod_local_7920); match prod_local_7922 {
        false => prod_local_7912,
        true => { let prod_local_7924 = 1; { let prod_local_7925 = (prod_local_7913).checked_add(prod_local_7924); prod_local_7925 } },
    } } } },
        true => { let prod_local_7927 = 1; { let prod_local_7928 = (prod_local_7913).checked_add(prod_local_7927); prod_local_7928 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_7929) => { let prod_local_7930 = prod_local_7929; { let prod_local_7934 = 128; { let prod_local_7935 = (val_2857 & prod_local_7934); { let prod_local_7936 = 0; { let prod_local_7937 = (prod_local_7935 == prod_local_7936); { let prod_local_7941 = match prod_local_7937 {
        false => { let prod_local_7939 = false; prod_local_7939 },
        true => { let prod_local_7940 = true; prod_local_7940 },
    }; match prod_local_7941 {
        false => { let prod_local_7943 = Some(prod_local_7930); { let prod_local_7944 = round128(prod_local_7943); match prod_local_7944 {
        None => { let prod_local_7945 = prod_local_7944; match prod_local_7945 {
        None => None,
        Some(prod_local_7947) => { let prod_local_7948 = prod_local_7947; { let prod_local_7949 = (prod_local_7948).value; { let prod_local_7950 = low64(prod_local_7949); match prod_local_7950 {
        None => prod_local_7950,
        Some(prod_local_7951) => { let prod_local_7952 = (prod_local_7948).guard; match prod_local_7952 {
        false => prod_local_7950,
        true => { let prod_local_7954 = (prod_local_7948).sticky; match prod_local_7954 {
        false => { let prod_local_7958 = 1; { let prod_local_7959 = (prod_local_7951 & prod_local_7958); { let prod_local_7960 = (prod_local_7959 == prod_local_7958); match prod_local_7960 {
        false => prod_local_7950,
        true => { let prod_local_7962 = 1; { let prod_local_7963 = (prod_local_7951).checked_add(prod_local_7962); prod_local_7963 } },
    } } } },
        true => { let prod_local_7965 = 1; { let prod_local_7966 = (prod_local_7951).checked_add(prod_local_7965); prod_local_7966 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_7967) => { let prod_local_7968 = prod_local_7967; { let prod_local_7969 = prod_local_7968; { let prod_local_7970 = (prod_local_7969).value; { let prod_local_7971 = low64(prod_local_7970); match prod_local_7971 {
        None => prod_local_7971,
        Some(prod_local_7972) => { let prod_local_7973 = (prod_local_7969).guard; match prod_local_7973 {
        false => prod_local_7971,
        true => { let prod_local_7975 = (prod_local_7969).sticky; match prod_local_7975 {
        false => { let prod_local_7979 = 1; { let prod_local_7980 = (prod_local_7972 & prod_local_7979); { let prod_local_7981 = (prod_local_7980 == prod_local_7979); match prod_local_7981 {
        false => prod_local_7971,
        true => { let prod_local_7983 = 1; { let prod_local_7984 = (prod_local_7972).checked_add(prod_local_7983); prod_local_7984 } },
    } } } },
        true => { let prod_local_7986 = 1; { let prod_local_7987 = (prod_local_7972).checked_add(prod_local_7986); prod_local_7987 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_7988 = prod_local_7930; { let prod_local_7989 = prod_local_7988; { let prod_local_7990 = (prod_local_7989).value; { let prod_local_7991 = low64(prod_local_7990); match prod_local_7991 {
        None => prod_local_7991,
        Some(prod_local_7992) => { let prod_local_7993 = (prod_local_7989).guard; match prod_local_7993 {
        false => prod_local_7991,
        true => { let prod_local_7995 = (prod_local_7989).sticky; match prod_local_7995 {
        false => { let prod_local_7999 = 1; { let prod_local_8000 = (prod_local_7992 & prod_local_7999); { let prod_local_8001 = (prod_local_8000 == prod_local_7999); match prod_local_8001 {
        false => prod_local_7991,
        true => { let prod_local_8003 = 1; { let prod_local_8004 = (prod_local_7992).checked_add(prod_local_8003); prod_local_8004 } },
    } } } },
        true => { let prod_local_8006 = 1; { let prod_local_8007 = (prod_local_7992).checked_add(prod_local_8006); prod_local_8007 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_8008 = prod_local_7892; { let prod_local_8012 = 128; { let prod_local_8013 = (val_2857 & prod_local_8012); { let prod_local_8014 = 0; { let prod_local_8015 = (prod_local_8013 == prod_local_8014); { let prod_local_8019 = match prod_local_8015 {
        false => { let prod_local_8017 = false; prod_local_8017 },
        true => { let prod_local_8018 = true; prod_local_8018 },
    }; match prod_local_8019 {
        false => { let prod_local_8021 = Some(prod_local_8008); { let prod_local_8022 = round128(prod_local_8021); match prod_local_8022 {
        None => { let prod_local_8023 = prod_local_8022; match prod_local_8023 {
        None => None,
        Some(prod_local_8025) => { let prod_local_8026 = prod_local_8025; { let prod_local_8027 = (prod_local_8026).value; { let prod_local_8028 = low64(prod_local_8027); match prod_local_8028 {
        None => prod_local_8028,
        Some(prod_local_8029) => { let prod_local_8030 = (prod_local_8026).guard; match prod_local_8030 {
        false => prod_local_8028,
        true => { let prod_local_8032 = (prod_local_8026).sticky; match prod_local_8032 {
        false => { let prod_local_8036 = 1; { let prod_local_8037 = (prod_local_8029 & prod_local_8036); { let prod_local_8038 = (prod_local_8037 == prod_local_8036); match prod_local_8038 {
        false => prod_local_8028,
        true => { let prod_local_8040 = 1; { let prod_local_8041 = (prod_local_8029).checked_add(prod_local_8040); prod_local_8041 } },
    } } } },
        true => { let prod_local_8043 = 1; { let prod_local_8044 = (prod_local_8029).checked_add(prod_local_8043); prod_local_8044 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_8045) => { let prod_local_8046 = prod_local_8045; { let prod_local_8047 = prod_local_8046; { let prod_local_8048 = (prod_local_8047).value; { let prod_local_8049 = low64(prod_local_8048); match prod_local_8049 {
        None => prod_local_8049,
        Some(prod_local_8050) => { let prod_local_8051 = (prod_local_8047).guard; match prod_local_8051 {
        false => prod_local_8049,
        true => { let prod_local_8053 = (prod_local_8047).sticky; match prod_local_8053 {
        false => { let prod_local_8057 = 1; { let prod_local_8058 = (prod_local_8050 & prod_local_8057); { let prod_local_8059 = (prod_local_8058 == prod_local_8057); match prod_local_8059 {
        false => prod_local_8049,
        true => { let prod_local_8061 = 1; { let prod_local_8062 = (prod_local_8050).checked_add(prod_local_8061); prod_local_8062 } },
    } } } },
        true => { let prod_local_8064 = 1; { let prod_local_8065 = (prod_local_8050).checked_add(prod_local_8064); prod_local_8065 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_8066 = prod_local_8008; { let prod_local_8067 = prod_local_8066; { let prod_local_8068 = (prod_local_8067).value; { let prod_local_8069 = low64(prod_local_8068); match prod_local_8069 {
        None => prod_local_8069,
        Some(prod_local_8070) => { let prod_local_8071 = (prod_local_8067).guard; match prod_local_8071 {
        false => prod_local_8069,
        true => { let prod_local_8073 = (prod_local_8067).sticky; match prod_local_8073 {
        false => { let prod_local_8077 = 1; { let prod_local_8078 = (prod_local_8070 & prod_local_8077); { let prod_local_8079 = (prod_local_8078 == prod_local_8077); match prod_local_8079 {
        false => prod_local_8069,
        true => { let prod_local_8081 = 1; { let prod_local_8082 = (prod_local_8070).checked_add(prod_local_8081); prod_local_8082 } },
    } } } },
        true => { let prod_local_8084 = 1; { let prod_local_8085 = (prod_local_8070).checked_add(prod_local_8084); prod_local_8085 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_8086 = prod_local_7854; { let prod_local_8090 = 64; { let prod_local_8091 = (val_2857 & prod_local_8090); { let prod_local_8092 = 0; { let prod_local_8093 = (prod_local_8091 == prod_local_8092); { let prod_local_8097 = match prod_local_8093 {
        false => { let prod_local_8095 = false; prod_local_8095 },
        true => { let prod_local_8096 = true; prod_local_8096 },
    }; match prod_local_8097 {
        false => { let prod_local_8099 = Some(prod_local_8086); { let prod_local_8100 = round64(prod_local_8099); match prod_local_8100 {
        None => { let prod_local_8101 = prod_local_8100; match prod_local_8101 {
        None => None,
        Some(prod_local_8103) => { let prod_local_8104 = prod_local_8103; { let prod_local_8105 = (prod_local_8104).value; { let prod_local_8106 = low64(prod_local_8105); match prod_local_8106 {
        None => prod_local_8106,
        Some(prod_local_8107) => { let prod_local_8108 = (prod_local_8104).guard; match prod_local_8108 {
        false => prod_local_8106,
        true => { let prod_local_8110 = (prod_local_8104).sticky; match prod_local_8110 {
        false => { let prod_local_8114 = 1; { let prod_local_8115 = (prod_local_8107 & prod_local_8114); { let prod_local_8116 = (prod_local_8115 == prod_local_8114); match prod_local_8116 {
        false => prod_local_8106,
        true => { let prod_local_8118 = 1; { let prod_local_8119 = (prod_local_8107).checked_add(prod_local_8118); prod_local_8119 } },
    } } } },
        true => { let prod_local_8121 = 1; { let prod_local_8122 = (prod_local_8107).checked_add(prod_local_8121); prod_local_8122 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_8123) => { let prod_local_8124 = prod_local_8123; { let prod_local_8128 = 128; { let prod_local_8129 = (val_2857 & prod_local_8128); { let prod_local_8130 = 0; { let prod_local_8131 = (prod_local_8129 == prod_local_8130); { let prod_local_8135 = match prod_local_8131 {
        false => { let prod_local_8133 = false; prod_local_8133 },
        true => { let prod_local_8134 = true; prod_local_8134 },
    }; match prod_local_8135 {
        false => { let prod_local_8137 = Some(prod_local_8124); { let prod_local_8138 = round128(prod_local_8137); match prod_local_8138 {
        None => { let prod_local_8139 = prod_local_8138; match prod_local_8139 {
        None => None,
        Some(prod_local_8141) => { let prod_local_8142 = prod_local_8141; { let prod_local_8143 = (prod_local_8142).value; { let prod_local_8144 = low64(prod_local_8143); match prod_local_8144 {
        None => prod_local_8144,
        Some(prod_local_8145) => { let prod_local_8146 = (prod_local_8142).guard; match prod_local_8146 {
        false => prod_local_8144,
        true => { let prod_local_8148 = (prod_local_8142).sticky; match prod_local_8148 {
        false => { let prod_local_8152 = 1; { let prod_local_8153 = (prod_local_8145 & prod_local_8152); { let prod_local_8154 = (prod_local_8153 == prod_local_8152); match prod_local_8154 {
        false => prod_local_8144,
        true => { let prod_local_8156 = 1; { let prod_local_8157 = (prod_local_8145).checked_add(prod_local_8156); prod_local_8157 } },
    } } } },
        true => { let prod_local_8159 = 1; { let prod_local_8160 = (prod_local_8145).checked_add(prod_local_8159); prod_local_8160 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_8161) => { let prod_local_8162 = prod_local_8161; { let prod_local_8163 = prod_local_8162; { let prod_local_8164 = (prod_local_8163).value; { let prod_local_8165 = low64(prod_local_8164); match prod_local_8165 {
        None => prod_local_8165,
        Some(prod_local_8166) => { let prod_local_8167 = (prod_local_8163).guard; match prod_local_8167 {
        false => prod_local_8165,
        true => { let prod_local_8169 = (prod_local_8163).sticky; match prod_local_8169 {
        false => { let prod_local_8173 = 1; { let prod_local_8174 = (prod_local_8166 & prod_local_8173); { let prod_local_8175 = (prod_local_8174 == prod_local_8173); match prod_local_8175 {
        false => prod_local_8165,
        true => { let prod_local_8177 = 1; { let prod_local_8178 = (prod_local_8166).checked_add(prod_local_8177); prod_local_8178 } },
    } } } },
        true => { let prod_local_8180 = 1; { let prod_local_8181 = (prod_local_8166).checked_add(prod_local_8180); prod_local_8181 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_8182 = prod_local_8124; { let prod_local_8183 = prod_local_8182; { let prod_local_8184 = (prod_local_8183).value; { let prod_local_8185 = low64(prod_local_8184); match prod_local_8185 {
        None => prod_local_8185,
        Some(prod_local_8186) => { let prod_local_8187 = (prod_local_8183).guard; match prod_local_8187 {
        false => prod_local_8185,
        true => { let prod_local_8189 = (prod_local_8183).sticky; match prod_local_8189 {
        false => { let prod_local_8193 = 1; { let prod_local_8194 = (prod_local_8186 & prod_local_8193); { let prod_local_8195 = (prod_local_8194 == prod_local_8193); match prod_local_8195 {
        false => prod_local_8185,
        true => { let prod_local_8197 = 1; { let prod_local_8198 = (prod_local_8186).checked_add(prod_local_8197); prod_local_8198 } },
    } } } },
        true => { let prod_local_8200 = 1; { let prod_local_8201 = (prod_local_8186).checked_add(prod_local_8200); prod_local_8201 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_8202 = prod_local_8086; { let prod_local_8206 = 128; { let prod_local_8207 = (val_2857 & prod_local_8206); { let prod_local_8208 = 0; { let prod_local_8209 = (prod_local_8207 == prod_local_8208); { let prod_local_8213 = match prod_local_8209 {
        false => { let prod_local_8211 = false; prod_local_8211 },
        true => { let prod_local_8212 = true; prod_local_8212 },
    }; match prod_local_8213 {
        false => { let prod_local_8215 = Some(prod_local_8202); { let prod_local_8216 = round128(prod_local_8215); match prod_local_8216 {
        None => { let prod_local_8217 = prod_local_8216; match prod_local_8217 {
        None => None,
        Some(prod_local_8219) => { let prod_local_8220 = prod_local_8219; { let prod_local_8221 = (prod_local_8220).value; { let prod_local_8222 = low64(prod_local_8221); match prod_local_8222 {
        None => prod_local_8222,
        Some(prod_local_8223) => { let prod_local_8224 = (prod_local_8220).guard; match prod_local_8224 {
        false => prod_local_8222,
        true => { let prod_local_8226 = (prod_local_8220).sticky; match prod_local_8226 {
        false => { let prod_local_8230 = 1; { let prod_local_8231 = (prod_local_8223 & prod_local_8230); { let prod_local_8232 = (prod_local_8231 == prod_local_8230); match prod_local_8232 {
        false => prod_local_8222,
        true => { let prod_local_8234 = 1; { let prod_local_8235 = (prod_local_8223).checked_add(prod_local_8234); prod_local_8235 } },
    } } } },
        true => { let prod_local_8237 = 1; { let prod_local_8238 = (prod_local_8223).checked_add(prod_local_8237); prod_local_8238 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_8239) => { let prod_local_8240 = prod_local_8239; { let prod_local_8241 = prod_local_8240; { let prod_local_8242 = (prod_local_8241).value; { let prod_local_8243 = low64(prod_local_8242); match prod_local_8243 {
        None => prod_local_8243,
        Some(prod_local_8244) => { let prod_local_8245 = (prod_local_8241).guard; match prod_local_8245 {
        false => prod_local_8243,
        true => { let prod_local_8247 = (prod_local_8241).sticky; match prod_local_8247 {
        false => { let prod_local_8251 = 1; { let prod_local_8252 = (prod_local_8244 & prod_local_8251); { let prod_local_8253 = (prod_local_8252 == prod_local_8251); match prod_local_8253 {
        false => prod_local_8243,
        true => { let prod_local_8255 = 1; { let prod_local_8256 = (prod_local_8244).checked_add(prod_local_8255); prod_local_8256 } },
    } } } },
        true => { let prod_local_8258 = 1; { let prod_local_8259 = (prod_local_8244).checked_add(prod_local_8258); prod_local_8259 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_8260 = prod_local_8202; { let prod_local_8261 = prod_local_8260; { let prod_local_8262 = (prod_local_8261).value; { let prod_local_8263 = low64(prod_local_8262); match prod_local_8263 {
        None => prod_local_8263,
        Some(prod_local_8264) => { let prod_local_8265 = (prod_local_8261).guard; match prod_local_8265 {
        false => prod_local_8263,
        true => { let prod_local_8267 = (prod_local_8261).sticky; match prod_local_8267 {
        false => { let prod_local_8271 = 1; { let prod_local_8272 = (prod_local_8264 & prod_local_8271); { let prod_local_8273 = (prod_local_8272 == prod_local_8271); match prod_local_8273 {
        false => prod_local_8263,
        true => { let prod_local_8275 = 1; { let prod_local_8276 = (prod_local_8264).checked_add(prod_local_8275); prod_local_8276 } },
    } } } },
        true => { let prod_local_8278 = 1; { let prod_local_8279 = (prod_local_8264).checked_add(prod_local_8278); prod_local_8279 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } } } } } },
    } } } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_8280 = prod_local_7352; { let prod_local_8284 = 16; { let prod_local_8285 = (val_2857 & prod_local_8284); { let prod_local_8286 = 0; { let prod_local_8287 = (prod_local_8285 == prod_local_8286); { let prod_local_8291 = match prod_local_8287 {
        false => { let prod_local_8289 = false; prod_local_8289 },
        true => { let prod_local_8290 = true; prod_local_8290 },
    }; match prod_local_8291 {
        false => { let prod_local_8293 = Some(prod_local_8280); { let prod_local_8294 = round16(prod_local_8293); match prod_local_8294 {
        None => { let prod_local_8295 = prod_local_8294; match prod_local_8295 {
        None => None,
        Some(prod_local_8297) => { let prod_local_8298 = prod_local_8297; { let prod_local_8299 = (prod_local_8298).value; { let prod_local_8300 = low64(prod_local_8299); match prod_local_8300 {
        None => prod_local_8300,
        Some(prod_local_8301) => { let prod_local_8302 = (prod_local_8298).guard; match prod_local_8302 {
        false => prod_local_8300,
        true => { let prod_local_8304 = (prod_local_8298).sticky; match prod_local_8304 {
        false => { let prod_local_8308 = 1; { let prod_local_8309 = (prod_local_8301 & prod_local_8308); { let prod_local_8310 = (prod_local_8309 == prod_local_8308); match prod_local_8310 {
        false => prod_local_8300,
        true => { let prod_local_8312 = 1; { let prod_local_8313 = (prod_local_8301).checked_add(prod_local_8312); prod_local_8313 } },
    } } } },
        true => { let prod_local_8315 = 1; { let prod_local_8316 = (prod_local_8301).checked_add(prod_local_8315); prod_local_8316 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_8317) => { let prod_local_8318 = prod_local_8317; { let prod_local_8322 = 32; { let prod_local_8323 = (val_2857 & prod_local_8322); { let prod_local_8324 = 0; { let prod_local_8325 = (prod_local_8323 == prod_local_8324); { let prod_local_8329 = match prod_local_8325 {
        false => { let prod_local_8327 = false; prod_local_8327 },
        true => { let prod_local_8328 = true; prod_local_8328 },
    }; match prod_local_8329 {
        false => { let prod_local_8331 = Some(prod_local_8318); { let prod_local_8332 = round32(prod_local_8331); match prod_local_8332 {
        None => { let prod_local_8333 = prod_local_8332; match prod_local_8333 {
        None => None,
        Some(prod_local_8335) => { let prod_local_8336 = prod_local_8335; { let prod_local_8337 = (prod_local_8336).value; { let prod_local_8338 = low64(prod_local_8337); match prod_local_8338 {
        None => prod_local_8338,
        Some(prod_local_8339) => { let prod_local_8340 = (prod_local_8336).guard; match prod_local_8340 {
        false => prod_local_8338,
        true => { let prod_local_8342 = (prod_local_8336).sticky; match prod_local_8342 {
        false => { let prod_local_8346 = 1; { let prod_local_8347 = (prod_local_8339 & prod_local_8346); { let prod_local_8348 = (prod_local_8347 == prod_local_8346); match prod_local_8348 {
        false => prod_local_8338,
        true => { let prod_local_8350 = 1; { let prod_local_8351 = (prod_local_8339).checked_add(prod_local_8350); prod_local_8351 } },
    } } } },
        true => { let prod_local_8353 = 1; { let prod_local_8354 = (prod_local_8339).checked_add(prod_local_8353); prod_local_8354 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_8355) => { let prod_local_8356 = prod_local_8355; { let prod_local_8360 = 64; { let prod_local_8361 = (val_2857 & prod_local_8360); { let prod_local_8362 = 0; { let prod_local_8363 = (prod_local_8361 == prod_local_8362); { let prod_local_8367 = match prod_local_8363 {
        false => { let prod_local_8365 = false; prod_local_8365 },
        true => { let prod_local_8366 = true; prod_local_8366 },
    }; match prod_local_8367 {
        false => { let prod_local_8369 = Some(prod_local_8356); { let prod_local_8370 = round64(prod_local_8369); match prod_local_8370 {
        None => { let prod_local_8371 = prod_local_8370; match prod_local_8371 {
        None => None,
        Some(prod_local_8373) => { let prod_local_8374 = prod_local_8373; { let prod_local_8375 = (prod_local_8374).value; { let prod_local_8376 = low64(prod_local_8375); match prod_local_8376 {
        None => prod_local_8376,
        Some(prod_local_8377) => { let prod_local_8378 = (prod_local_8374).guard; match prod_local_8378 {
        false => prod_local_8376,
        true => { let prod_local_8380 = (prod_local_8374).sticky; match prod_local_8380 {
        false => { let prod_local_8384 = 1; { let prod_local_8385 = (prod_local_8377 & prod_local_8384); { let prod_local_8386 = (prod_local_8385 == prod_local_8384); match prod_local_8386 {
        false => prod_local_8376,
        true => { let prod_local_8388 = 1; { let prod_local_8389 = (prod_local_8377).checked_add(prod_local_8388); prod_local_8389 } },
    } } } },
        true => { let prod_local_8391 = 1; { let prod_local_8392 = (prod_local_8377).checked_add(prod_local_8391); prod_local_8392 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_8393) => { let prod_local_8394 = prod_local_8393; { let prod_local_8398 = 128; { let prod_local_8399 = (val_2857 & prod_local_8398); { let prod_local_8400 = 0; { let prod_local_8401 = (prod_local_8399 == prod_local_8400); { let prod_local_8405 = match prod_local_8401 {
        false => { let prod_local_8403 = false; prod_local_8403 },
        true => { let prod_local_8404 = true; prod_local_8404 },
    }; match prod_local_8405 {
        false => { let prod_local_8407 = Some(prod_local_8394); { let prod_local_8408 = round128(prod_local_8407); match prod_local_8408 {
        None => { let prod_local_8409 = prod_local_8408; match prod_local_8409 {
        None => None,
        Some(prod_local_8411) => { let prod_local_8412 = prod_local_8411; { let prod_local_8413 = (prod_local_8412).value; { let prod_local_8414 = low64(prod_local_8413); match prod_local_8414 {
        None => prod_local_8414,
        Some(prod_local_8415) => { let prod_local_8416 = (prod_local_8412).guard; match prod_local_8416 {
        false => prod_local_8414,
        true => { let prod_local_8418 = (prod_local_8412).sticky; match prod_local_8418 {
        false => { let prod_local_8422 = 1; { let prod_local_8423 = (prod_local_8415 & prod_local_8422); { let prod_local_8424 = (prod_local_8423 == prod_local_8422); match prod_local_8424 {
        false => prod_local_8414,
        true => { let prod_local_8426 = 1; { let prod_local_8427 = (prod_local_8415).checked_add(prod_local_8426); prod_local_8427 } },
    } } } },
        true => { let prod_local_8429 = 1; { let prod_local_8430 = (prod_local_8415).checked_add(prod_local_8429); prod_local_8430 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_8431) => { let prod_local_8432 = prod_local_8431; { let prod_local_8433 = prod_local_8432; { let prod_local_8434 = (prod_local_8433).value; { let prod_local_8435 = low64(prod_local_8434); match prod_local_8435 {
        None => prod_local_8435,
        Some(prod_local_8436) => { let prod_local_8437 = (prod_local_8433).guard; match prod_local_8437 {
        false => prod_local_8435,
        true => { let prod_local_8439 = (prod_local_8433).sticky; match prod_local_8439 {
        false => { let prod_local_8443 = 1; { let prod_local_8444 = (prod_local_8436 & prod_local_8443); { let prod_local_8445 = (prod_local_8444 == prod_local_8443); match prod_local_8445 {
        false => prod_local_8435,
        true => { let prod_local_8447 = 1; { let prod_local_8448 = (prod_local_8436).checked_add(prod_local_8447); prod_local_8448 } },
    } } } },
        true => { let prod_local_8450 = 1; { let prod_local_8451 = (prod_local_8436).checked_add(prod_local_8450); prod_local_8451 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_8452 = prod_local_8394; { let prod_local_8453 = prod_local_8452; { let prod_local_8454 = (prod_local_8453).value; { let prod_local_8455 = low64(prod_local_8454); match prod_local_8455 {
        None => prod_local_8455,
        Some(prod_local_8456) => { let prod_local_8457 = (prod_local_8453).guard; match prod_local_8457 {
        false => prod_local_8455,
        true => { let prod_local_8459 = (prod_local_8453).sticky; match prod_local_8459 {
        false => { let prod_local_8463 = 1; { let prod_local_8464 = (prod_local_8456 & prod_local_8463); { let prod_local_8465 = (prod_local_8464 == prod_local_8463); match prod_local_8465 {
        false => prod_local_8455,
        true => { let prod_local_8467 = 1; { let prod_local_8468 = (prod_local_8456).checked_add(prod_local_8467); prod_local_8468 } },
    } } } },
        true => { let prod_local_8470 = 1; { let prod_local_8471 = (prod_local_8456).checked_add(prod_local_8470); prod_local_8471 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_8472 = prod_local_8356; { let prod_local_8476 = 128; { let prod_local_8477 = (val_2857 & prod_local_8476); { let prod_local_8478 = 0; { let prod_local_8479 = (prod_local_8477 == prod_local_8478); { let prod_local_8483 = match prod_local_8479 {
        false => { let prod_local_8481 = false; prod_local_8481 },
        true => { let prod_local_8482 = true; prod_local_8482 },
    }; match prod_local_8483 {
        false => { let prod_local_8485 = Some(prod_local_8472); { let prod_local_8486 = round128(prod_local_8485); match prod_local_8486 {
        None => { let prod_local_8487 = prod_local_8486; match prod_local_8487 {
        None => None,
        Some(prod_local_8489) => { let prod_local_8490 = prod_local_8489; { let prod_local_8491 = (prod_local_8490).value; { let prod_local_8492 = low64(prod_local_8491); match prod_local_8492 {
        None => prod_local_8492,
        Some(prod_local_8493) => { let prod_local_8494 = (prod_local_8490).guard; match prod_local_8494 {
        false => prod_local_8492,
        true => { let prod_local_8496 = (prod_local_8490).sticky; match prod_local_8496 {
        false => { let prod_local_8500 = 1; { let prod_local_8501 = (prod_local_8493 & prod_local_8500); { let prod_local_8502 = (prod_local_8501 == prod_local_8500); match prod_local_8502 {
        false => prod_local_8492,
        true => { let prod_local_8504 = 1; { let prod_local_8505 = (prod_local_8493).checked_add(prod_local_8504); prod_local_8505 } },
    } } } },
        true => { let prod_local_8507 = 1; { let prod_local_8508 = (prod_local_8493).checked_add(prod_local_8507); prod_local_8508 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_8509) => { let prod_local_8510 = prod_local_8509; { let prod_local_8511 = prod_local_8510; { let prod_local_8512 = (prod_local_8511).value; { let prod_local_8513 = low64(prod_local_8512); match prod_local_8513 {
        None => prod_local_8513,
        Some(prod_local_8514) => { let prod_local_8515 = (prod_local_8511).guard; match prod_local_8515 {
        false => prod_local_8513,
        true => { let prod_local_8517 = (prod_local_8511).sticky; match prod_local_8517 {
        false => { let prod_local_8521 = 1; { let prod_local_8522 = (prod_local_8514 & prod_local_8521); { let prod_local_8523 = (prod_local_8522 == prod_local_8521); match prod_local_8523 {
        false => prod_local_8513,
        true => { let prod_local_8525 = 1; { let prod_local_8526 = (prod_local_8514).checked_add(prod_local_8525); prod_local_8526 } },
    } } } },
        true => { let prod_local_8528 = 1; { let prod_local_8529 = (prod_local_8514).checked_add(prod_local_8528); prod_local_8529 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_8530 = prod_local_8472; { let prod_local_8531 = prod_local_8530; { let prod_local_8532 = (prod_local_8531).value; { let prod_local_8533 = low64(prod_local_8532); match prod_local_8533 {
        None => prod_local_8533,
        Some(prod_local_8534) => { let prod_local_8535 = (prod_local_8531).guard; match prod_local_8535 {
        false => prod_local_8533,
        true => { let prod_local_8537 = (prod_local_8531).sticky; match prod_local_8537 {
        false => { let prod_local_8541 = 1; { let prod_local_8542 = (prod_local_8534 & prod_local_8541); { let prod_local_8543 = (prod_local_8542 == prod_local_8541); match prod_local_8543 {
        false => prod_local_8533,
        true => { let prod_local_8545 = 1; { let prod_local_8546 = (prod_local_8534).checked_add(prod_local_8545); prod_local_8546 } },
    } } } },
        true => { let prod_local_8548 = 1; { let prod_local_8549 = (prod_local_8534).checked_add(prod_local_8548); prod_local_8549 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_8550 = prod_local_8318; { let prod_local_8554 = 64; { let prod_local_8555 = (val_2857 & prod_local_8554); { let prod_local_8556 = 0; { let prod_local_8557 = (prod_local_8555 == prod_local_8556); { let prod_local_8561 = match prod_local_8557 {
        false => { let prod_local_8559 = false; prod_local_8559 },
        true => { let prod_local_8560 = true; prod_local_8560 },
    }; match prod_local_8561 {
        false => { let prod_local_8563 = Some(prod_local_8550); { let prod_local_8564 = round64(prod_local_8563); match prod_local_8564 {
        None => { let prod_local_8565 = prod_local_8564; match prod_local_8565 {
        None => None,
        Some(prod_local_8567) => { let prod_local_8568 = prod_local_8567; { let prod_local_8569 = (prod_local_8568).value; { let prod_local_8570 = low64(prod_local_8569); match prod_local_8570 {
        None => prod_local_8570,
        Some(prod_local_8571) => { let prod_local_8572 = (prod_local_8568).guard; match prod_local_8572 {
        false => prod_local_8570,
        true => { let prod_local_8574 = (prod_local_8568).sticky; match prod_local_8574 {
        false => { let prod_local_8578 = 1; { let prod_local_8579 = (prod_local_8571 & prod_local_8578); { let prod_local_8580 = (prod_local_8579 == prod_local_8578); match prod_local_8580 {
        false => prod_local_8570,
        true => { let prod_local_8582 = 1; { let prod_local_8583 = (prod_local_8571).checked_add(prod_local_8582); prod_local_8583 } },
    } } } },
        true => { let prod_local_8585 = 1; { let prod_local_8586 = (prod_local_8571).checked_add(prod_local_8585); prod_local_8586 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_8587) => { let prod_local_8588 = prod_local_8587; { let prod_local_8592 = 128; { let prod_local_8593 = (val_2857 & prod_local_8592); { let prod_local_8594 = 0; { let prod_local_8595 = (prod_local_8593 == prod_local_8594); { let prod_local_8599 = match prod_local_8595 {
        false => { let prod_local_8597 = false; prod_local_8597 },
        true => { let prod_local_8598 = true; prod_local_8598 },
    }; match prod_local_8599 {
        false => { let prod_local_8601 = Some(prod_local_8588); { let prod_local_8602 = round128(prod_local_8601); match prod_local_8602 {
        None => { let prod_local_8603 = prod_local_8602; match prod_local_8603 {
        None => None,
        Some(prod_local_8605) => { let prod_local_8606 = prod_local_8605; { let prod_local_8607 = (prod_local_8606).value; { let prod_local_8608 = low64(prod_local_8607); match prod_local_8608 {
        None => prod_local_8608,
        Some(prod_local_8609) => { let prod_local_8610 = (prod_local_8606).guard; match prod_local_8610 {
        false => prod_local_8608,
        true => { let prod_local_8612 = (prod_local_8606).sticky; match prod_local_8612 {
        false => { let prod_local_8616 = 1; { let prod_local_8617 = (prod_local_8609 & prod_local_8616); { let prod_local_8618 = (prod_local_8617 == prod_local_8616); match prod_local_8618 {
        false => prod_local_8608,
        true => { let prod_local_8620 = 1; { let prod_local_8621 = (prod_local_8609).checked_add(prod_local_8620); prod_local_8621 } },
    } } } },
        true => { let prod_local_8623 = 1; { let prod_local_8624 = (prod_local_8609).checked_add(prod_local_8623); prod_local_8624 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_8625) => { let prod_local_8626 = prod_local_8625; { let prod_local_8627 = prod_local_8626; { let prod_local_8628 = (prod_local_8627).value; { let prod_local_8629 = low64(prod_local_8628); match prod_local_8629 {
        None => prod_local_8629,
        Some(prod_local_8630) => { let prod_local_8631 = (prod_local_8627).guard; match prod_local_8631 {
        false => prod_local_8629,
        true => { let prod_local_8633 = (prod_local_8627).sticky; match prod_local_8633 {
        false => { let prod_local_8637 = 1; { let prod_local_8638 = (prod_local_8630 & prod_local_8637); { let prod_local_8639 = (prod_local_8638 == prod_local_8637); match prod_local_8639 {
        false => prod_local_8629,
        true => { let prod_local_8641 = 1; { let prod_local_8642 = (prod_local_8630).checked_add(prod_local_8641); prod_local_8642 } },
    } } } },
        true => { let prod_local_8644 = 1; { let prod_local_8645 = (prod_local_8630).checked_add(prod_local_8644); prod_local_8645 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_8646 = prod_local_8588; { let prod_local_8647 = prod_local_8646; { let prod_local_8648 = (prod_local_8647).value; { let prod_local_8649 = low64(prod_local_8648); match prod_local_8649 {
        None => prod_local_8649,
        Some(prod_local_8650) => { let prod_local_8651 = (prod_local_8647).guard; match prod_local_8651 {
        false => prod_local_8649,
        true => { let prod_local_8653 = (prod_local_8647).sticky; match prod_local_8653 {
        false => { let prod_local_8657 = 1; { let prod_local_8658 = (prod_local_8650 & prod_local_8657); { let prod_local_8659 = (prod_local_8658 == prod_local_8657); match prod_local_8659 {
        false => prod_local_8649,
        true => { let prod_local_8661 = 1; { let prod_local_8662 = (prod_local_8650).checked_add(prod_local_8661); prod_local_8662 } },
    } } } },
        true => { let prod_local_8664 = 1; { let prod_local_8665 = (prod_local_8650).checked_add(prod_local_8664); prod_local_8665 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_8666 = prod_local_8550; { let prod_local_8670 = 128; { let prod_local_8671 = (val_2857 & prod_local_8670); { let prod_local_8672 = 0; { let prod_local_8673 = (prod_local_8671 == prod_local_8672); { let prod_local_8677 = match prod_local_8673 {
        false => { let prod_local_8675 = false; prod_local_8675 },
        true => { let prod_local_8676 = true; prod_local_8676 },
    }; match prod_local_8677 {
        false => { let prod_local_8679 = Some(prod_local_8666); { let prod_local_8680 = round128(prod_local_8679); match prod_local_8680 {
        None => { let prod_local_8681 = prod_local_8680; match prod_local_8681 {
        None => None,
        Some(prod_local_8683) => { let prod_local_8684 = prod_local_8683; { let prod_local_8685 = (prod_local_8684).value; { let prod_local_8686 = low64(prod_local_8685); match prod_local_8686 {
        None => prod_local_8686,
        Some(prod_local_8687) => { let prod_local_8688 = (prod_local_8684).guard; match prod_local_8688 {
        false => prod_local_8686,
        true => { let prod_local_8690 = (prod_local_8684).sticky; match prod_local_8690 {
        false => { let prod_local_8694 = 1; { let prod_local_8695 = (prod_local_8687 & prod_local_8694); { let prod_local_8696 = (prod_local_8695 == prod_local_8694); match prod_local_8696 {
        false => prod_local_8686,
        true => { let prod_local_8698 = 1; { let prod_local_8699 = (prod_local_8687).checked_add(prod_local_8698); prod_local_8699 } },
    } } } },
        true => { let prod_local_8701 = 1; { let prod_local_8702 = (prod_local_8687).checked_add(prod_local_8701); prod_local_8702 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_8703) => { let prod_local_8704 = prod_local_8703; { let prod_local_8705 = prod_local_8704; { let prod_local_8706 = (prod_local_8705).value; { let prod_local_8707 = low64(prod_local_8706); match prod_local_8707 {
        None => prod_local_8707,
        Some(prod_local_8708) => { let prod_local_8709 = (prod_local_8705).guard; match prod_local_8709 {
        false => prod_local_8707,
        true => { let prod_local_8711 = (prod_local_8705).sticky; match prod_local_8711 {
        false => { let prod_local_8715 = 1; { let prod_local_8716 = (prod_local_8708 & prod_local_8715); { let prod_local_8717 = (prod_local_8716 == prod_local_8715); match prod_local_8717 {
        false => prod_local_8707,
        true => { let prod_local_8719 = 1; { let prod_local_8720 = (prod_local_8708).checked_add(prod_local_8719); prod_local_8720 } },
    } } } },
        true => { let prod_local_8722 = 1; { let prod_local_8723 = (prod_local_8708).checked_add(prod_local_8722); prod_local_8723 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_8724 = prod_local_8666; { let prod_local_8725 = prod_local_8724; { let prod_local_8726 = (prod_local_8725).value; { let prod_local_8727 = low64(prod_local_8726); match prod_local_8727 {
        None => prod_local_8727,
        Some(prod_local_8728) => { let prod_local_8729 = (prod_local_8725).guard; match prod_local_8729 {
        false => prod_local_8727,
        true => { let prod_local_8731 = (prod_local_8725).sticky; match prod_local_8731 {
        false => { let prod_local_8735 = 1; { let prod_local_8736 = (prod_local_8728 & prod_local_8735); { let prod_local_8737 = (prod_local_8736 == prod_local_8735); match prod_local_8737 {
        false => prod_local_8727,
        true => { let prod_local_8739 = 1; { let prod_local_8740 = (prod_local_8728).checked_add(prod_local_8739); prod_local_8740 } },
    } } } },
        true => { let prod_local_8742 = 1; { let prod_local_8743 = (prod_local_8728).checked_add(prod_local_8742); prod_local_8743 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_8744 = prod_local_8280; { let prod_local_8748 = 32; { let prod_local_8749 = (val_2857 & prod_local_8748); { let prod_local_8750 = 0; { let prod_local_8751 = (prod_local_8749 == prod_local_8750); { let prod_local_8755 = match prod_local_8751 {
        false => { let prod_local_8753 = false; prod_local_8753 },
        true => { let prod_local_8754 = true; prod_local_8754 },
    }; match prod_local_8755 {
        false => { let prod_local_8757 = Some(prod_local_8744); { let prod_local_8758 = round32(prod_local_8757); match prod_local_8758 {
        None => { let prod_local_8759 = prod_local_8758; match prod_local_8759 {
        None => None,
        Some(prod_local_8761) => { let prod_local_8762 = prod_local_8761; { let prod_local_8763 = (prod_local_8762).value; { let prod_local_8764 = low64(prod_local_8763); match prod_local_8764 {
        None => prod_local_8764,
        Some(prod_local_8765) => { let prod_local_8766 = (prod_local_8762).guard; match prod_local_8766 {
        false => prod_local_8764,
        true => { let prod_local_8768 = (prod_local_8762).sticky; match prod_local_8768 {
        false => { let prod_local_8772 = 1; { let prod_local_8773 = (prod_local_8765 & prod_local_8772); { let prod_local_8774 = (prod_local_8773 == prod_local_8772); match prod_local_8774 {
        false => prod_local_8764,
        true => { let prod_local_8776 = 1; { let prod_local_8777 = (prod_local_8765).checked_add(prod_local_8776); prod_local_8777 } },
    } } } },
        true => { let prod_local_8779 = 1; { let prod_local_8780 = (prod_local_8765).checked_add(prod_local_8779); prod_local_8780 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_8781) => { let prod_local_8782 = prod_local_8781; { let prod_local_8786 = 64; { let prod_local_8787 = (val_2857 & prod_local_8786); { let prod_local_8788 = 0; { let prod_local_8789 = (prod_local_8787 == prod_local_8788); { let prod_local_8793 = match prod_local_8789 {
        false => { let prod_local_8791 = false; prod_local_8791 },
        true => { let prod_local_8792 = true; prod_local_8792 },
    }; match prod_local_8793 {
        false => { let prod_local_8795 = Some(prod_local_8782); { let prod_local_8796 = round64(prod_local_8795); match prod_local_8796 {
        None => { let prod_local_8797 = prod_local_8796; match prod_local_8797 {
        None => None,
        Some(prod_local_8799) => { let prod_local_8800 = prod_local_8799; { let prod_local_8801 = (prod_local_8800).value; { let prod_local_8802 = low64(prod_local_8801); match prod_local_8802 {
        None => prod_local_8802,
        Some(prod_local_8803) => { let prod_local_8804 = (prod_local_8800).guard; match prod_local_8804 {
        false => prod_local_8802,
        true => { let prod_local_8806 = (prod_local_8800).sticky; match prod_local_8806 {
        false => { let prod_local_8810 = 1; { let prod_local_8811 = (prod_local_8803 & prod_local_8810); { let prod_local_8812 = (prod_local_8811 == prod_local_8810); match prod_local_8812 {
        false => prod_local_8802,
        true => { let prod_local_8814 = 1; { let prod_local_8815 = (prod_local_8803).checked_add(prod_local_8814); prod_local_8815 } },
    } } } },
        true => { let prod_local_8817 = 1; { let prod_local_8818 = (prod_local_8803).checked_add(prod_local_8817); prod_local_8818 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_8819) => { let prod_local_8820 = prod_local_8819; { let prod_local_8824 = 128; { let prod_local_8825 = (val_2857 & prod_local_8824); { let prod_local_8826 = 0; { let prod_local_8827 = (prod_local_8825 == prod_local_8826); { let prod_local_8831 = match prod_local_8827 {
        false => { let prod_local_8829 = false; prod_local_8829 },
        true => { let prod_local_8830 = true; prod_local_8830 },
    }; match prod_local_8831 {
        false => { let prod_local_8833 = Some(prod_local_8820); { let prod_local_8834 = round128(prod_local_8833); match prod_local_8834 {
        None => { let prod_local_8835 = prod_local_8834; match prod_local_8835 {
        None => None,
        Some(prod_local_8837) => { let prod_local_8838 = prod_local_8837; { let prod_local_8839 = (prod_local_8838).value; { let prod_local_8840 = low64(prod_local_8839); match prod_local_8840 {
        None => prod_local_8840,
        Some(prod_local_8841) => { let prod_local_8842 = (prod_local_8838).guard; match prod_local_8842 {
        false => prod_local_8840,
        true => { let prod_local_8844 = (prod_local_8838).sticky; match prod_local_8844 {
        false => { let prod_local_8848 = 1; { let prod_local_8849 = (prod_local_8841 & prod_local_8848); { let prod_local_8850 = (prod_local_8849 == prod_local_8848); match prod_local_8850 {
        false => prod_local_8840,
        true => { let prod_local_8852 = 1; { let prod_local_8853 = (prod_local_8841).checked_add(prod_local_8852); prod_local_8853 } },
    } } } },
        true => { let prod_local_8855 = 1; { let prod_local_8856 = (prod_local_8841).checked_add(prod_local_8855); prod_local_8856 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_8857) => { let prod_local_8858 = prod_local_8857; { let prod_local_8859 = prod_local_8858; { let prod_local_8860 = (prod_local_8859).value; { let prod_local_8861 = low64(prod_local_8860); match prod_local_8861 {
        None => prod_local_8861,
        Some(prod_local_8862) => { let prod_local_8863 = (prod_local_8859).guard; match prod_local_8863 {
        false => prod_local_8861,
        true => { let prod_local_8865 = (prod_local_8859).sticky; match prod_local_8865 {
        false => { let prod_local_8869 = 1; { let prod_local_8870 = (prod_local_8862 & prod_local_8869); { let prod_local_8871 = (prod_local_8870 == prod_local_8869); match prod_local_8871 {
        false => prod_local_8861,
        true => { let prod_local_8873 = 1; { let prod_local_8874 = (prod_local_8862).checked_add(prod_local_8873); prod_local_8874 } },
    } } } },
        true => { let prod_local_8876 = 1; { let prod_local_8877 = (prod_local_8862).checked_add(prod_local_8876); prod_local_8877 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_8878 = prod_local_8820; { let prod_local_8879 = prod_local_8878; { let prod_local_8880 = (prod_local_8879).value; { let prod_local_8881 = low64(prod_local_8880); match prod_local_8881 {
        None => prod_local_8881,
        Some(prod_local_8882) => { let prod_local_8883 = (prod_local_8879).guard; match prod_local_8883 {
        false => prod_local_8881,
        true => { let prod_local_8885 = (prod_local_8879).sticky; match prod_local_8885 {
        false => { let prod_local_8889 = 1; { let prod_local_8890 = (prod_local_8882 & prod_local_8889); { let prod_local_8891 = (prod_local_8890 == prod_local_8889); match prod_local_8891 {
        false => prod_local_8881,
        true => { let prod_local_8893 = 1; { let prod_local_8894 = (prod_local_8882).checked_add(prod_local_8893); prod_local_8894 } },
    } } } },
        true => { let prod_local_8896 = 1; { let prod_local_8897 = (prod_local_8882).checked_add(prod_local_8896); prod_local_8897 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_8898 = prod_local_8782; { let prod_local_8902 = 128; { let prod_local_8903 = (val_2857 & prod_local_8902); { let prod_local_8904 = 0; { let prod_local_8905 = (prod_local_8903 == prod_local_8904); { let prod_local_8909 = match prod_local_8905 {
        false => { let prod_local_8907 = false; prod_local_8907 },
        true => { let prod_local_8908 = true; prod_local_8908 },
    }; match prod_local_8909 {
        false => { let prod_local_8911 = Some(prod_local_8898); { let prod_local_8912 = round128(prod_local_8911); match prod_local_8912 {
        None => { let prod_local_8913 = prod_local_8912; match prod_local_8913 {
        None => None,
        Some(prod_local_8915) => { let prod_local_8916 = prod_local_8915; { let prod_local_8917 = (prod_local_8916).value; { let prod_local_8918 = low64(prod_local_8917); match prod_local_8918 {
        None => prod_local_8918,
        Some(prod_local_8919) => { let prod_local_8920 = (prod_local_8916).guard; match prod_local_8920 {
        false => prod_local_8918,
        true => { let prod_local_8922 = (prod_local_8916).sticky; match prod_local_8922 {
        false => { let prod_local_8926 = 1; { let prod_local_8927 = (prod_local_8919 & prod_local_8926); { let prod_local_8928 = (prod_local_8927 == prod_local_8926); match prod_local_8928 {
        false => prod_local_8918,
        true => { let prod_local_8930 = 1; { let prod_local_8931 = (prod_local_8919).checked_add(prod_local_8930); prod_local_8931 } },
    } } } },
        true => { let prod_local_8933 = 1; { let prod_local_8934 = (prod_local_8919).checked_add(prod_local_8933); prod_local_8934 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_8935) => { let prod_local_8936 = prod_local_8935; { let prod_local_8937 = prod_local_8936; { let prod_local_8938 = (prod_local_8937).value; { let prod_local_8939 = low64(prod_local_8938); match prod_local_8939 {
        None => prod_local_8939,
        Some(prod_local_8940) => { let prod_local_8941 = (prod_local_8937).guard; match prod_local_8941 {
        false => prod_local_8939,
        true => { let prod_local_8943 = (prod_local_8937).sticky; match prod_local_8943 {
        false => { let prod_local_8947 = 1; { let prod_local_8948 = (prod_local_8940 & prod_local_8947); { let prod_local_8949 = (prod_local_8948 == prod_local_8947); match prod_local_8949 {
        false => prod_local_8939,
        true => { let prod_local_8951 = 1; { let prod_local_8952 = (prod_local_8940).checked_add(prod_local_8951); prod_local_8952 } },
    } } } },
        true => { let prod_local_8954 = 1; { let prod_local_8955 = (prod_local_8940).checked_add(prod_local_8954); prod_local_8955 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_8956 = prod_local_8898; { let prod_local_8957 = prod_local_8956; { let prod_local_8958 = (prod_local_8957).value; { let prod_local_8959 = low64(prod_local_8958); match prod_local_8959 {
        None => prod_local_8959,
        Some(prod_local_8960) => { let prod_local_8961 = (prod_local_8957).guard; match prod_local_8961 {
        false => prod_local_8959,
        true => { let prod_local_8963 = (prod_local_8957).sticky; match prod_local_8963 {
        false => { let prod_local_8967 = 1; { let prod_local_8968 = (prod_local_8960 & prod_local_8967); { let prod_local_8969 = (prod_local_8968 == prod_local_8967); match prod_local_8969 {
        false => prod_local_8959,
        true => { let prod_local_8971 = 1; { let prod_local_8972 = (prod_local_8960).checked_add(prod_local_8971); prod_local_8972 } },
    } } } },
        true => { let prod_local_8974 = 1; { let prod_local_8975 = (prod_local_8960).checked_add(prod_local_8974); prod_local_8975 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_8976 = prod_local_8744; { let prod_local_8980 = 64; { let prod_local_8981 = (val_2857 & prod_local_8980); { let prod_local_8982 = 0; { let prod_local_8983 = (prod_local_8981 == prod_local_8982); { let prod_local_8987 = match prod_local_8983 {
        false => { let prod_local_8985 = false; prod_local_8985 },
        true => { let prod_local_8986 = true; prod_local_8986 },
    }; match prod_local_8987 {
        false => { let prod_local_8989 = Some(prod_local_8976); { let prod_local_8990 = round64(prod_local_8989); match prod_local_8990 {
        None => { let prod_local_8991 = prod_local_8990; match prod_local_8991 {
        None => None,
        Some(prod_local_8993) => { let prod_local_8994 = prod_local_8993; { let prod_local_8995 = (prod_local_8994).value; { let prod_local_8996 = low64(prod_local_8995); match prod_local_8996 {
        None => prod_local_8996,
        Some(prod_local_8997) => { let prod_local_8998 = (prod_local_8994).guard; match prod_local_8998 {
        false => prod_local_8996,
        true => { let prod_local_9000 = (prod_local_8994).sticky; match prod_local_9000 {
        false => { let prod_local_9004 = 1; { let prod_local_9005 = (prod_local_8997 & prod_local_9004); { let prod_local_9006 = (prod_local_9005 == prod_local_9004); match prod_local_9006 {
        false => prod_local_8996,
        true => { let prod_local_9008 = 1; { let prod_local_9009 = (prod_local_8997).checked_add(prod_local_9008); prod_local_9009 } },
    } } } },
        true => { let prod_local_9011 = 1; { let prod_local_9012 = (prod_local_8997).checked_add(prod_local_9011); prod_local_9012 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_9013) => { let prod_local_9014 = prod_local_9013; { let prod_local_9018 = 128; { let prod_local_9019 = (val_2857 & prod_local_9018); { let prod_local_9020 = 0; { let prod_local_9021 = (prod_local_9019 == prod_local_9020); { let prod_local_9025 = match prod_local_9021 {
        false => { let prod_local_9023 = false; prod_local_9023 },
        true => { let prod_local_9024 = true; prod_local_9024 },
    }; match prod_local_9025 {
        false => { let prod_local_9027 = Some(prod_local_9014); { let prod_local_9028 = round128(prod_local_9027); match prod_local_9028 {
        None => { let prod_local_9029 = prod_local_9028; match prod_local_9029 {
        None => None,
        Some(prod_local_9031) => { let prod_local_9032 = prod_local_9031; { let prod_local_9033 = (prod_local_9032).value; { let prod_local_9034 = low64(prod_local_9033); match prod_local_9034 {
        None => prod_local_9034,
        Some(prod_local_9035) => { let prod_local_9036 = (prod_local_9032).guard; match prod_local_9036 {
        false => prod_local_9034,
        true => { let prod_local_9038 = (prod_local_9032).sticky; match prod_local_9038 {
        false => { let prod_local_9042 = 1; { let prod_local_9043 = (prod_local_9035 & prod_local_9042); { let prod_local_9044 = (prod_local_9043 == prod_local_9042); match prod_local_9044 {
        false => prod_local_9034,
        true => { let prod_local_9046 = 1; { let prod_local_9047 = (prod_local_9035).checked_add(prod_local_9046); prod_local_9047 } },
    } } } },
        true => { let prod_local_9049 = 1; { let prod_local_9050 = (prod_local_9035).checked_add(prod_local_9049); prod_local_9050 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_9051) => { let prod_local_9052 = prod_local_9051; { let prod_local_9053 = prod_local_9052; { let prod_local_9054 = (prod_local_9053).value; { let prod_local_9055 = low64(prod_local_9054); match prod_local_9055 {
        None => prod_local_9055,
        Some(prod_local_9056) => { let prod_local_9057 = (prod_local_9053).guard; match prod_local_9057 {
        false => prod_local_9055,
        true => { let prod_local_9059 = (prod_local_9053).sticky; match prod_local_9059 {
        false => { let prod_local_9063 = 1; { let prod_local_9064 = (prod_local_9056 & prod_local_9063); { let prod_local_9065 = (prod_local_9064 == prod_local_9063); match prod_local_9065 {
        false => prod_local_9055,
        true => { let prod_local_9067 = 1; { let prod_local_9068 = (prod_local_9056).checked_add(prod_local_9067); prod_local_9068 } },
    } } } },
        true => { let prod_local_9070 = 1; { let prod_local_9071 = (prod_local_9056).checked_add(prod_local_9070); prod_local_9071 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_9072 = prod_local_9014; { let prod_local_9073 = prod_local_9072; { let prod_local_9074 = (prod_local_9073).value; { let prod_local_9075 = low64(prod_local_9074); match prod_local_9075 {
        None => prod_local_9075,
        Some(prod_local_9076) => { let prod_local_9077 = (prod_local_9073).guard; match prod_local_9077 {
        false => prod_local_9075,
        true => { let prod_local_9079 = (prod_local_9073).sticky; match prod_local_9079 {
        false => { let prod_local_9083 = 1; { let prod_local_9084 = (prod_local_9076 & prod_local_9083); { let prod_local_9085 = (prod_local_9084 == prod_local_9083); match prod_local_9085 {
        false => prod_local_9075,
        true => { let prod_local_9087 = 1; { let prod_local_9088 = (prod_local_9076).checked_add(prod_local_9087); prod_local_9088 } },
    } } } },
        true => { let prod_local_9090 = 1; { let prod_local_9091 = (prod_local_9076).checked_add(prod_local_9090); prod_local_9091 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_9092 = prod_local_8976; { let prod_local_9096 = 128; { let prod_local_9097 = (val_2857 & prod_local_9096); { let prod_local_9098 = 0; { let prod_local_9099 = (prod_local_9097 == prod_local_9098); { let prod_local_9103 = match prod_local_9099 {
        false => { let prod_local_9101 = false; prod_local_9101 },
        true => { let prod_local_9102 = true; prod_local_9102 },
    }; match prod_local_9103 {
        false => { let prod_local_9105 = Some(prod_local_9092); { let prod_local_9106 = round128(prod_local_9105); match prod_local_9106 {
        None => { let prod_local_9107 = prod_local_9106; match prod_local_9107 {
        None => None,
        Some(prod_local_9109) => { let prod_local_9110 = prod_local_9109; { let prod_local_9111 = (prod_local_9110).value; { let prod_local_9112 = low64(prod_local_9111); match prod_local_9112 {
        None => prod_local_9112,
        Some(prod_local_9113) => { let prod_local_9114 = (prod_local_9110).guard; match prod_local_9114 {
        false => prod_local_9112,
        true => { let prod_local_9116 = (prod_local_9110).sticky; match prod_local_9116 {
        false => { let prod_local_9120 = 1; { let prod_local_9121 = (prod_local_9113 & prod_local_9120); { let prod_local_9122 = (prod_local_9121 == prod_local_9120); match prod_local_9122 {
        false => prod_local_9112,
        true => { let prod_local_9124 = 1; { let prod_local_9125 = (prod_local_9113).checked_add(prod_local_9124); prod_local_9125 } },
    } } } },
        true => { let prod_local_9127 = 1; { let prod_local_9128 = (prod_local_9113).checked_add(prod_local_9127); prod_local_9128 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_9129) => { let prod_local_9130 = prod_local_9129; { let prod_local_9131 = prod_local_9130; { let prod_local_9132 = (prod_local_9131).value; { let prod_local_9133 = low64(prod_local_9132); match prod_local_9133 {
        None => prod_local_9133,
        Some(prod_local_9134) => { let prod_local_9135 = (prod_local_9131).guard; match prod_local_9135 {
        false => prod_local_9133,
        true => { let prod_local_9137 = (prod_local_9131).sticky; match prod_local_9137 {
        false => { let prod_local_9141 = 1; { let prod_local_9142 = (prod_local_9134 & prod_local_9141); { let prod_local_9143 = (prod_local_9142 == prod_local_9141); match prod_local_9143 {
        false => prod_local_9133,
        true => { let prod_local_9145 = 1; { let prod_local_9146 = (prod_local_9134).checked_add(prod_local_9145); prod_local_9146 } },
    } } } },
        true => { let prod_local_9148 = 1; { let prod_local_9149 = (prod_local_9134).checked_add(prod_local_9148); prod_local_9149 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_9150 = prod_local_9092; { let prod_local_9151 = prod_local_9150; { let prod_local_9152 = (prod_local_9151).value; { let prod_local_9153 = low64(prod_local_9152); match prod_local_9153 {
        None => prod_local_9153,
        Some(prod_local_9154) => { let prod_local_9155 = (prod_local_9151).guard; match prod_local_9155 {
        false => prod_local_9153,
        true => { let prod_local_9157 = (prod_local_9151).sticky; match prod_local_9157 {
        false => { let prod_local_9161 = 1; { let prod_local_9162 = (prod_local_9154 & prod_local_9161); { let prod_local_9163 = (prod_local_9162 == prod_local_9161); match prod_local_9163 {
        false => prod_local_9153,
        true => { let prod_local_9165 = 1; { let prod_local_9166 = (prod_local_9154).checked_add(prod_local_9165); prod_local_9166 } },
    } } } },
        true => { let prod_local_9168 = 1; { let prod_local_9169 = (prod_local_9154).checked_add(prod_local_9168); prod_local_9169 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } } } } } },
    } } } } } } },
    } } } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_9170 = prod_local_7314; { let prod_local_9174 = 8; { let prod_local_9175 = (val_2857 & prod_local_9174); { let prod_local_9176 = 0; { let prod_local_9177 = (prod_local_9175 == prod_local_9176); { let prod_local_9181 = match prod_local_9177 {
        false => { let prod_local_9179 = false; prod_local_9179 },
        true => { let prod_local_9180 = true; prod_local_9180 },
    }; match prod_local_9181 {
        false => { let prod_local_9183 = Some(prod_local_9170); { let prod_local_9184 = round8(prod_local_9183); match prod_local_9184 {
        None => { let prod_local_9185 = prod_local_9184; match prod_local_9185 {
        None => None,
        Some(prod_local_9187) => { let prod_local_9188 = prod_local_9187; { let prod_local_9189 = (prod_local_9188).value; { let prod_local_9190 = low64(prod_local_9189); match prod_local_9190 {
        None => prod_local_9190,
        Some(prod_local_9191) => { let prod_local_9192 = (prod_local_9188).guard; match prod_local_9192 {
        false => prod_local_9190,
        true => { let prod_local_9194 = (prod_local_9188).sticky; match prod_local_9194 {
        false => { let prod_local_9198 = 1; { let prod_local_9199 = (prod_local_9191 & prod_local_9198); { let prod_local_9200 = (prod_local_9199 == prod_local_9198); match prod_local_9200 {
        false => prod_local_9190,
        true => { let prod_local_9202 = 1; { let prod_local_9203 = (prod_local_9191).checked_add(prod_local_9202); prod_local_9203 } },
    } } } },
        true => { let prod_local_9205 = 1; { let prod_local_9206 = (prod_local_9191).checked_add(prod_local_9205); prod_local_9206 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_9207) => { let prod_local_9208 = prod_local_9207; { let prod_local_9212 = 16; { let prod_local_9213 = (val_2857 & prod_local_9212); { let prod_local_9214 = 0; { let prod_local_9215 = (prod_local_9213 == prod_local_9214); { let prod_local_9219 = match prod_local_9215 {
        false => { let prod_local_9217 = false; prod_local_9217 },
        true => { let prod_local_9218 = true; prod_local_9218 },
    }; match prod_local_9219 {
        false => { let prod_local_9221 = Some(prod_local_9208); { let prod_local_9222 = round16(prod_local_9221); match prod_local_9222 {
        None => { let prod_local_9223 = prod_local_9222; match prod_local_9223 {
        None => None,
        Some(prod_local_9225) => { let prod_local_9226 = prod_local_9225; { let prod_local_9227 = (prod_local_9226).value; { let prod_local_9228 = low64(prod_local_9227); match prod_local_9228 {
        None => prod_local_9228,
        Some(prod_local_9229) => { let prod_local_9230 = (prod_local_9226).guard; match prod_local_9230 {
        false => prod_local_9228,
        true => { let prod_local_9232 = (prod_local_9226).sticky; match prod_local_9232 {
        false => { let prod_local_9236 = 1; { let prod_local_9237 = (prod_local_9229 & prod_local_9236); { let prod_local_9238 = (prod_local_9237 == prod_local_9236); match prod_local_9238 {
        false => prod_local_9228,
        true => { let prod_local_9240 = 1; { let prod_local_9241 = (prod_local_9229).checked_add(prod_local_9240); prod_local_9241 } },
    } } } },
        true => { let prod_local_9243 = 1; { let prod_local_9244 = (prod_local_9229).checked_add(prod_local_9243); prod_local_9244 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_9245) => { let prod_local_9246 = prod_local_9245; { let prod_local_9250 = 32; { let prod_local_9251 = (val_2857 & prod_local_9250); { let prod_local_9252 = 0; { let prod_local_9253 = (prod_local_9251 == prod_local_9252); { let prod_local_9257 = match prod_local_9253 {
        false => { let prod_local_9255 = false; prod_local_9255 },
        true => { let prod_local_9256 = true; prod_local_9256 },
    }; match prod_local_9257 {
        false => { let prod_local_9259 = Some(prod_local_9246); { let prod_local_9260 = round32(prod_local_9259); match prod_local_9260 {
        None => { let prod_local_9261 = prod_local_9260; match prod_local_9261 {
        None => None,
        Some(prod_local_9263) => { let prod_local_9264 = prod_local_9263; { let prod_local_9265 = (prod_local_9264).value; { let prod_local_9266 = low64(prod_local_9265); match prod_local_9266 {
        None => prod_local_9266,
        Some(prod_local_9267) => { let prod_local_9268 = (prod_local_9264).guard; match prod_local_9268 {
        false => prod_local_9266,
        true => { let prod_local_9270 = (prod_local_9264).sticky; match prod_local_9270 {
        false => { let prod_local_9274 = 1; { let prod_local_9275 = (prod_local_9267 & prod_local_9274); { let prod_local_9276 = (prod_local_9275 == prod_local_9274); match prod_local_9276 {
        false => prod_local_9266,
        true => { let prod_local_9278 = 1; { let prod_local_9279 = (prod_local_9267).checked_add(prod_local_9278); prod_local_9279 } },
    } } } },
        true => { let prod_local_9281 = 1; { let prod_local_9282 = (prod_local_9267).checked_add(prod_local_9281); prod_local_9282 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_9283) => { let prod_local_9284 = prod_local_9283; { let prod_local_9288 = 64; { let prod_local_9289 = (val_2857 & prod_local_9288); { let prod_local_9290 = 0; { let prod_local_9291 = (prod_local_9289 == prod_local_9290); { let prod_local_9295 = match prod_local_9291 {
        false => { let prod_local_9293 = false; prod_local_9293 },
        true => { let prod_local_9294 = true; prod_local_9294 },
    }; match prod_local_9295 {
        false => { let prod_local_9297 = Some(prod_local_9284); { let prod_local_9298 = round64(prod_local_9297); match prod_local_9298 {
        None => { let prod_local_9299 = prod_local_9298; match prod_local_9299 {
        None => None,
        Some(prod_local_9301) => { let prod_local_9302 = prod_local_9301; { let prod_local_9303 = (prod_local_9302).value; { let prod_local_9304 = low64(prod_local_9303); match prod_local_9304 {
        None => prod_local_9304,
        Some(prod_local_9305) => { let prod_local_9306 = (prod_local_9302).guard; match prod_local_9306 {
        false => prod_local_9304,
        true => { let prod_local_9308 = (prod_local_9302).sticky; match prod_local_9308 {
        false => { let prod_local_9312 = 1; { let prod_local_9313 = (prod_local_9305 & prod_local_9312); { let prod_local_9314 = (prod_local_9313 == prod_local_9312); match prod_local_9314 {
        false => prod_local_9304,
        true => { let prod_local_9316 = 1; { let prod_local_9317 = (prod_local_9305).checked_add(prod_local_9316); prod_local_9317 } },
    } } } },
        true => { let prod_local_9319 = 1; { let prod_local_9320 = (prod_local_9305).checked_add(prod_local_9319); prod_local_9320 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_9321) => { let prod_local_9322 = prod_local_9321; { let prod_local_9326 = 128; { let prod_local_9327 = (val_2857 & prod_local_9326); { let prod_local_9328 = 0; { let prod_local_9329 = (prod_local_9327 == prod_local_9328); { let prod_local_9333 = match prod_local_9329 {
        false => { let prod_local_9331 = false; prod_local_9331 },
        true => { let prod_local_9332 = true; prod_local_9332 },
    }; match prod_local_9333 {
        false => { let prod_local_9335 = Some(prod_local_9322); { let prod_local_9336 = round128(prod_local_9335); match prod_local_9336 {
        None => { let prod_local_9337 = prod_local_9336; match prod_local_9337 {
        None => None,
        Some(prod_local_9339) => { let prod_local_9340 = prod_local_9339; { let prod_local_9341 = (prod_local_9340).value; { let prod_local_9342 = low64(prod_local_9341); match prod_local_9342 {
        None => prod_local_9342,
        Some(prod_local_9343) => { let prod_local_9344 = (prod_local_9340).guard; match prod_local_9344 {
        false => prod_local_9342,
        true => { let prod_local_9346 = (prod_local_9340).sticky; match prod_local_9346 {
        false => { let prod_local_9350 = 1; { let prod_local_9351 = (prod_local_9343 & prod_local_9350); { let prod_local_9352 = (prod_local_9351 == prod_local_9350); match prod_local_9352 {
        false => prod_local_9342,
        true => { let prod_local_9354 = 1; { let prod_local_9355 = (prod_local_9343).checked_add(prod_local_9354); prod_local_9355 } },
    } } } },
        true => { let prod_local_9357 = 1; { let prod_local_9358 = (prod_local_9343).checked_add(prod_local_9357); prod_local_9358 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_9359) => { let prod_local_9360 = prod_local_9359; { let prod_local_9361 = prod_local_9360; { let prod_local_9362 = (prod_local_9361).value; { let prod_local_9363 = low64(prod_local_9362); match prod_local_9363 {
        None => prod_local_9363,
        Some(prod_local_9364) => { let prod_local_9365 = (prod_local_9361).guard; match prod_local_9365 {
        false => prod_local_9363,
        true => { let prod_local_9367 = (prod_local_9361).sticky; match prod_local_9367 {
        false => { let prod_local_9371 = 1; { let prod_local_9372 = (prod_local_9364 & prod_local_9371); { let prod_local_9373 = (prod_local_9372 == prod_local_9371); match prod_local_9373 {
        false => prod_local_9363,
        true => { let prod_local_9375 = 1; { let prod_local_9376 = (prod_local_9364).checked_add(prod_local_9375); prod_local_9376 } },
    } } } },
        true => { let prod_local_9378 = 1; { let prod_local_9379 = (prod_local_9364).checked_add(prod_local_9378); prod_local_9379 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_9380 = prod_local_9322; { let prod_local_9381 = prod_local_9380; { let prod_local_9382 = (prod_local_9381).value; { let prod_local_9383 = low64(prod_local_9382); match prod_local_9383 {
        None => prod_local_9383,
        Some(prod_local_9384) => { let prod_local_9385 = (prod_local_9381).guard; match prod_local_9385 {
        false => prod_local_9383,
        true => { let prod_local_9387 = (prod_local_9381).sticky; match prod_local_9387 {
        false => { let prod_local_9391 = 1; { let prod_local_9392 = (prod_local_9384 & prod_local_9391); { let prod_local_9393 = (prod_local_9392 == prod_local_9391); match prod_local_9393 {
        false => prod_local_9383,
        true => { let prod_local_9395 = 1; { let prod_local_9396 = (prod_local_9384).checked_add(prod_local_9395); prod_local_9396 } },
    } } } },
        true => { let prod_local_9398 = 1; { let prod_local_9399 = (prod_local_9384).checked_add(prod_local_9398); prod_local_9399 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_9400 = prod_local_9284; { let prod_local_9404 = 128; { let prod_local_9405 = (val_2857 & prod_local_9404); { let prod_local_9406 = 0; { let prod_local_9407 = (prod_local_9405 == prod_local_9406); { let prod_local_9411 = match prod_local_9407 {
        false => { let prod_local_9409 = false; prod_local_9409 },
        true => { let prod_local_9410 = true; prod_local_9410 },
    }; match prod_local_9411 {
        false => { let prod_local_9413 = Some(prod_local_9400); { let prod_local_9414 = round128(prod_local_9413); match prod_local_9414 {
        None => { let prod_local_9415 = prod_local_9414; match prod_local_9415 {
        None => None,
        Some(prod_local_9417) => { let prod_local_9418 = prod_local_9417; { let prod_local_9419 = (prod_local_9418).value; { let prod_local_9420 = low64(prod_local_9419); match prod_local_9420 {
        None => prod_local_9420,
        Some(prod_local_9421) => { let prod_local_9422 = (prod_local_9418).guard; match prod_local_9422 {
        false => prod_local_9420,
        true => { let prod_local_9424 = (prod_local_9418).sticky; match prod_local_9424 {
        false => { let prod_local_9428 = 1; { let prod_local_9429 = (prod_local_9421 & prod_local_9428); { let prod_local_9430 = (prod_local_9429 == prod_local_9428); match prod_local_9430 {
        false => prod_local_9420,
        true => { let prod_local_9432 = 1; { let prod_local_9433 = (prod_local_9421).checked_add(prod_local_9432); prod_local_9433 } },
    } } } },
        true => { let prod_local_9435 = 1; { let prod_local_9436 = (prod_local_9421).checked_add(prod_local_9435); prod_local_9436 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_9437) => { let prod_local_9438 = prod_local_9437; { let prod_local_9439 = prod_local_9438; { let prod_local_9440 = (prod_local_9439).value; { let prod_local_9441 = low64(prod_local_9440); match prod_local_9441 {
        None => prod_local_9441,
        Some(prod_local_9442) => { let prod_local_9443 = (prod_local_9439).guard; match prod_local_9443 {
        false => prod_local_9441,
        true => { let prod_local_9445 = (prod_local_9439).sticky; match prod_local_9445 {
        false => { let prod_local_9449 = 1; { let prod_local_9450 = (prod_local_9442 & prod_local_9449); { let prod_local_9451 = (prod_local_9450 == prod_local_9449); match prod_local_9451 {
        false => prod_local_9441,
        true => { let prod_local_9453 = 1; { let prod_local_9454 = (prod_local_9442).checked_add(prod_local_9453); prod_local_9454 } },
    } } } },
        true => { let prod_local_9456 = 1; { let prod_local_9457 = (prod_local_9442).checked_add(prod_local_9456); prod_local_9457 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_9458 = prod_local_9400; { let prod_local_9459 = prod_local_9458; { let prod_local_9460 = (prod_local_9459).value; { let prod_local_9461 = low64(prod_local_9460); match prod_local_9461 {
        None => prod_local_9461,
        Some(prod_local_9462) => { let prod_local_9463 = (prod_local_9459).guard; match prod_local_9463 {
        false => prod_local_9461,
        true => { let prod_local_9465 = (prod_local_9459).sticky; match prod_local_9465 {
        false => { let prod_local_9469 = 1; { let prod_local_9470 = (prod_local_9462 & prod_local_9469); { let prod_local_9471 = (prod_local_9470 == prod_local_9469); match prod_local_9471 {
        false => prod_local_9461,
        true => { let prod_local_9473 = 1; { let prod_local_9474 = (prod_local_9462).checked_add(prod_local_9473); prod_local_9474 } },
    } } } },
        true => { let prod_local_9476 = 1; { let prod_local_9477 = (prod_local_9462).checked_add(prod_local_9476); prod_local_9477 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_9478 = prod_local_9246; { let prod_local_9482 = 64; { let prod_local_9483 = (val_2857 & prod_local_9482); { let prod_local_9484 = 0; { let prod_local_9485 = (prod_local_9483 == prod_local_9484); { let prod_local_9489 = match prod_local_9485 {
        false => { let prod_local_9487 = false; prod_local_9487 },
        true => { let prod_local_9488 = true; prod_local_9488 },
    }; match prod_local_9489 {
        false => { let prod_local_9491 = Some(prod_local_9478); { let prod_local_9492 = round64(prod_local_9491); match prod_local_9492 {
        None => { let prod_local_9493 = prod_local_9492; match prod_local_9493 {
        None => None,
        Some(prod_local_9495) => { let prod_local_9496 = prod_local_9495; { let prod_local_9497 = (prod_local_9496).value; { let prod_local_9498 = low64(prod_local_9497); match prod_local_9498 {
        None => prod_local_9498,
        Some(prod_local_9499) => { let prod_local_9500 = (prod_local_9496).guard; match prod_local_9500 {
        false => prod_local_9498,
        true => { let prod_local_9502 = (prod_local_9496).sticky; match prod_local_9502 {
        false => { let prod_local_9506 = 1; { let prod_local_9507 = (prod_local_9499 & prod_local_9506); { let prod_local_9508 = (prod_local_9507 == prod_local_9506); match prod_local_9508 {
        false => prod_local_9498,
        true => { let prod_local_9510 = 1; { let prod_local_9511 = (prod_local_9499).checked_add(prod_local_9510); prod_local_9511 } },
    } } } },
        true => { let prod_local_9513 = 1; { let prod_local_9514 = (prod_local_9499).checked_add(prod_local_9513); prod_local_9514 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_9515) => { let prod_local_9516 = prod_local_9515; { let prod_local_9520 = 128; { let prod_local_9521 = (val_2857 & prod_local_9520); { let prod_local_9522 = 0; { let prod_local_9523 = (prod_local_9521 == prod_local_9522); { let prod_local_9527 = match prod_local_9523 {
        false => { let prod_local_9525 = false; prod_local_9525 },
        true => { let prod_local_9526 = true; prod_local_9526 },
    }; match prod_local_9527 {
        false => { let prod_local_9529 = Some(prod_local_9516); { let prod_local_9530 = round128(prod_local_9529); match prod_local_9530 {
        None => { let prod_local_9531 = prod_local_9530; match prod_local_9531 {
        None => None,
        Some(prod_local_9533) => { let prod_local_9534 = prod_local_9533; { let prod_local_9535 = (prod_local_9534).value; { let prod_local_9536 = low64(prod_local_9535); match prod_local_9536 {
        None => prod_local_9536,
        Some(prod_local_9537) => { let prod_local_9538 = (prod_local_9534).guard; match prod_local_9538 {
        false => prod_local_9536,
        true => { let prod_local_9540 = (prod_local_9534).sticky; match prod_local_9540 {
        false => { let prod_local_9544 = 1; { let prod_local_9545 = (prod_local_9537 & prod_local_9544); { let prod_local_9546 = (prod_local_9545 == prod_local_9544); match prod_local_9546 {
        false => prod_local_9536,
        true => { let prod_local_9548 = 1; { let prod_local_9549 = (prod_local_9537).checked_add(prod_local_9548); prod_local_9549 } },
    } } } },
        true => { let prod_local_9551 = 1; { let prod_local_9552 = (prod_local_9537).checked_add(prod_local_9551); prod_local_9552 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_9553) => { let prod_local_9554 = prod_local_9553; { let prod_local_9555 = prod_local_9554; { let prod_local_9556 = (prod_local_9555).value; { let prod_local_9557 = low64(prod_local_9556); match prod_local_9557 {
        None => prod_local_9557,
        Some(prod_local_9558) => { let prod_local_9559 = (prod_local_9555).guard; match prod_local_9559 {
        false => prod_local_9557,
        true => { let prod_local_9561 = (prod_local_9555).sticky; match prod_local_9561 {
        false => { let prod_local_9565 = 1; { let prod_local_9566 = (prod_local_9558 & prod_local_9565); { let prod_local_9567 = (prod_local_9566 == prod_local_9565); match prod_local_9567 {
        false => prod_local_9557,
        true => { let prod_local_9569 = 1; { let prod_local_9570 = (prod_local_9558).checked_add(prod_local_9569); prod_local_9570 } },
    } } } },
        true => { let prod_local_9572 = 1; { let prod_local_9573 = (prod_local_9558).checked_add(prod_local_9572); prod_local_9573 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_9574 = prod_local_9516; { let prod_local_9575 = prod_local_9574; { let prod_local_9576 = (prod_local_9575).value; { let prod_local_9577 = low64(prod_local_9576); match prod_local_9577 {
        None => prod_local_9577,
        Some(prod_local_9578) => { let prod_local_9579 = (prod_local_9575).guard; match prod_local_9579 {
        false => prod_local_9577,
        true => { let prod_local_9581 = (prod_local_9575).sticky; match prod_local_9581 {
        false => { let prod_local_9585 = 1; { let prod_local_9586 = (prod_local_9578 & prod_local_9585); { let prod_local_9587 = (prod_local_9586 == prod_local_9585); match prod_local_9587 {
        false => prod_local_9577,
        true => { let prod_local_9589 = 1; { let prod_local_9590 = (prod_local_9578).checked_add(prod_local_9589); prod_local_9590 } },
    } } } },
        true => { let prod_local_9592 = 1; { let prod_local_9593 = (prod_local_9578).checked_add(prod_local_9592); prod_local_9593 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_9594 = prod_local_9478; { let prod_local_9598 = 128; { let prod_local_9599 = (val_2857 & prod_local_9598); { let prod_local_9600 = 0; { let prod_local_9601 = (prod_local_9599 == prod_local_9600); { let prod_local_9605 = match prod_local_9601 {
        false => { let prod_local_9603 = false; prod_local_9603 },
        true => { let prod_local_9604 = true; prod_local_9604 },
    }; match prod_local_9605 {
        false => { let prod_local_9607 = Some(prod_local_9594); { let prod_local_9608 = round128(prod_local_9607); match prod_local_9608 {
        None => { let prod_local_9609 = prod_local_9608; match prod_local_9609 {
        None => None,
        Some(prod_local_9611) => { let prod_local_9612 = prod_local_9611; { let prod_local_9613 = (prod_local_9612).value; { let prod_local_9614 = low64(prod_local_9613); match prod_local_9614 {
        None => prod_local_9614,
        Some(prod_local_9615) => { let prod_local_9616 = (prod_local_9612).guard; match prod_local_9616 {
        false => prod_local_9614,
        true => { let prod_local_9618 = (prod_local_9612).sticky; match prod_local_9618 {
        false => { let prod_local_9622 = 1; { let prod_local_9623 = (prod_local_9615 & prod_local_9622); { let prod_local_9624 = (prod_local_9623 == prod_local_9622); match prod_local_9624 {
        false => prod_local_9614,
        true => { let prod_local_9626 = 1; { let prod_local_9627 = (prod_local_9615).checked_add(prod_local_9626); prod_local_9627 } },
    } } } },
        true => { let prod_local_9629 = 1; { let prod_local_9630 = (prod_local_9615).checked_add(prod_local_9629); prod_local_9630 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_9631) => { let prod_local_9632 = prod_local_9631; { let prod_local_9633 = prod_local_9632; { let prod_local_9634 = (prod_local_9633).value; { let prod_local_9635 = low64(prod_local_9634); match prod_local_9635 {
        None => prod_local_9635,
        Some(prod_local_9636) => { let prod_local_9637 = (prod_local_9633).guard; match prod_local_9637 {
        false => prod_local_9635,
        true => { let prod_local_9639 = (prod_local_9633).sticky; match prod_local_9639 {
        false => { let prod_local_9643 = 1; { let prod_local_9644 = (prod_local_9636 & prod_local_9643); { let prod_local_9645 = (prod_local_9644 == prod_local_9643); match prod_local_9645 {
        false => prod_local_9635,
        true => { let prod_local_9647 = 1; { let prod_local_9648 = (prod_local_9636).checked_add(prod_local_9647); prod_local_9648 } },
    } } } },
        true => { let prod_local_9650 = 1; { let prod_local_9651 = (prod_local_9636).checked_add(prod_local_9650); prod_local_9651 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_9652 = prod_local_9594; { let prod_local_9653 = prod_local_9652; { let prod_local_9654 = (prod_local_9653).value; { let prod_local_9655 = low64(prod_local_9654); match prod_local_9655 {
        None => prod_local_9655,
        Some(prod_local_9656) => { let prod_local_9657 = (prod_local_9653).guard; match prod_local_9657 {
        false => prod_local_9655,
        true => { let prod_local_9659 = (prod_local_9653).sticky; match prod_local_9659 {
        false => { let prod_local_9663 = 1; { let prod_local_9664 = (prod_local_9656 & prod_local_9663); { let prod_local_9665 = (prod_local_9664 == prod_local_9663); match prod_local_9665 {
        false => prod_local_9655,
        true => { let prod_local_9667 = 1; { let prod_local_9668 = (prod_local_9656).checked_add(prod_local_9667); prod_local_9668 } },
    } } } },
        true => { let prod_local_9670 = 1; { let prod_local_9671 = (prod_local_9656).checked_add(prod_local_9670); prod_local_9671 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_9672 = prod_local_9208; { let prod_local_9676 = 32; { let prod_local_9677 = (val_2857 & prod_local_9676); { let prod_local_9678 = 0; { let prod_local_9679 = (prod_local_9677 == prod_local_9678); { let prod_local_9683 = match prod_local_9679 {
        false => { let prod_local_9681 = false; prod_local_9681 },
        true => { let prod_local_9682 = true; prod_local_9682 },
    }; match prod_local_9683 {
        false => { let prod_local_9685 = Some(prod_local_9672); { let prod_local_9686 = round32(prod_local_9685); match prod_local_9686 {
        None => { let prod_local_9687 = prod_local_9686; match prod_local_9687 {
        None => None,
        Some(prod_local_9689) => { let prod_local_9690 = prod_local_9689; { let prod_local_9691 = (prod_local_9690).value; { let prod_local_9692 = low64(prod_local_9691); match prod_local_9692 {
        None => prod_local_9692,
        Some(prod_local_9693) => { let prod_local_9694 = (prod_local_9690).guard; match prod_local_9694 {
        false => prod_local_9692,
        true => { let prod_local_9696 = (prod_local_9690).sticky; match prod_local_9696 {
        false => { let prod_local_9700 = 1; { let prod_local_9701 = (prod_local_9693 & prod_local_9700); { let prod_local_9702 = (prod_local_9701 == prod_local_9700); match prod_local_9702 {
        false => prod_local_9692,
        true => { let prod_local_9704 = 1; { let prod_local_9705 = (prod_local_9693).checked_add(prod_local_9704); prod_local_9705 } },
    } } } },
        true => { let prod_local_9707 = 1; { let prod_local_9708 = (prod_local_9693).checked_add(prod_local_9707); prod_local_9708 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_9709) => { let prod_local_9710 = prod_local_9709; { let prod_local_9714 = 64; { let prod_local_9715 = (val_2857 & prod_local_9714); { let prod_local_9716 = 0; { let prod_local_9717 = (prod_local_9715 == prod_local_9716); { let prod_local_9721 = match prod_local_9717 {
        false => { let prod_local_9719 = false; prod_local_9719 },
        true => { let prod_local_9720 = true; prod_local_9720 },
    }; match prod_local_9721 {
        false => { let prod_local_9723 = Some(prod_local_9710); { let prod_local_9724 = round64(prod_local_9723); match prod_local_9724 {
        None => { let prod_local_9725 = prod_local_9724; match prod_local_9725 {
        None => None,
        Some(prod_local_9727) => { let prod_local_9728 = prod_local_9727; { let prod_local_9729 = (prod_local_9728).value; { let prod_local_9730 = low64(prod_local_9729); match prod_local_9730 {
        None => prod_local_9730,
        Some(prod_local_9731) => { let prod_local_9732 = (prod_local_9728).guard; match prod_local_9732 {
        false => prod_local_9730,
        true => { let prod_local_9734 = (prod_local_9728).sticky; match prod_local_9734 {
        false => { let prod_local_9738 = 1; { let prod_local_9739 = (prod_local_9731 & prod_local_9738); { let prod_local_9740 = (prod_local_9739 == prod_local_9738); match prod_local_9740 {
        false => prod_local_9730,
        true => { let prod_local_9742 = 1; { let prod_local_9743 = (prod_local_9731).checked_add(prod_local_9742); prod_local_9743 } },
    } } } },
        true => { let prod_local_9745 = 1; { let prod_local_9746 = (prod_local_9731).checked_add(prod_local_9745); prod_local_9746 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_9747) => { let prod_local_9748 = prod_local_9747; { let prod_local_9752 = 128; { let prod_local_9753 = (val_2857 & prod_local_9752); { let prod_local_9754 = 0; { let prod_local_9755 = (prod_local_9753 == prod_local_9754); { let prod_local_9759 = match prod_local_9755 {
        false => { let prod_local_9757 = false; prod_local_9757 },
        true => { let prod_local_9758 = true; prod_local_9758 },
    }; match prod_local_9759 {
        false => { let prod_local_9761 = Some(prod_local_9748); { let prod_local_9762 = round128(prod_local_9761); match prod_local_9762 {
        None => { let prod_local_9763 = prod_local_9762; match prod_local_9763 {
        None => None,
        Some(prod_local_9765) => { let prod_local_9766 = prod_local_9765; { let prod_local_9767 = (prod_local_9766).value; { let prod_local_9768 = low64(prod_local_9767); match prod_local_9768 {
        None => prod_local_9768,
        Some(prod_local_9769) => { let prod_local_9770 = (prod_local_9766).guard; match prod_local_9770 {
        false => prod_local_9768,
        true => { let prod_local_9772 = (prod_local_9766).sticky; match prod_local_9772 {
        false => { let prod_local_9776 = 1; { let prod_local_9777 = (prod_local_9769 & prod_local_9776); { let prod_local_9778 = (prod_local_9777 == prod_local_9776); match prod_local_9778 {
        false => prod_local_9768,
        true => { let prod_local_9780 = 1; { let prod_local_9781 = (prod_local_9769).checked_add(prod_local_9780); prod_local_9781 } },
    } } } },
        true => { let prod_local_9783 = 1; { let prod_local_9784 = (prod_local_9769).checked_add(prod_local_9783); prod_local_9784 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_9785) => { let prod_local_9786 = prod_local_9785; { let prod_local_9787 = prod_local_9786; { let prod_local_9788 = (prod_local_9787).value; { let prod_local_9789 = low64(prod_local_9788); match prod_local_9789 {
        None => prod_local_9789,
        Some(prod_local_9790) => { let prod_local_9791 = (prod_local_9787).guard; match prod_local_9791 {
        false => prod_local_9789,
        true => { let prod_local_9793 = (prod_local_9787).sticky; match prod_local_9793 {
        false => { let prod_local_9797 = 1; { let prod_local_9798 = (prod_local_9790 & prod_local_9797); { let prod_local_9799 = (prod_local_9798 == prod_local_9797); match prod_local_9799 {
        false => prod_local_9789,
        true => { let prod_local_9801 = 1; { let prod_local_9802 = (prod_local_9790).checked_add(prod_local_9801); prod_local_9802 } },
    } } } },
        true => { let prod_local_9804 = 1; { let prod_local_9805 = (prod_local_9790).checked_add(prod_local_9804); prod_local_9805 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_9806 = prod_local_9748; { let prod_local_9807 = prod_local_9806; { let prod_local_9808 = (prod_local_9807).value; { let prod_local_9809 = low64(prod_local_9808); match prod_local_9809 {
        None => prod_local_9809,
        Some(prod_local_9810) => { let prod_local_9811 = (prod_local_9807).guard; match prod_local_9811 {
        false => prod_local_9809,
        true => { let prod_local_9813 = (prod_local_9807).sticky; match prod_local_9813 {
        false => { let prod_local_9817 = 1; { let prod_local_9818 = (prod_local_9810 & prod_local_9817); { let prod_local_9819 = (prod_local_9818 == prod_local_9817); match prod_local_9819 {
        false => prod_local_9809,
        true => { let prod_local_9821 = 1; { let prod_local_9822 = (prod_local_9810).checked_add(prod_local_9821); prod_local_9822 } },
    } } } },
        true => { let prod_local_9824 = 1; { let prod_local_9825 = (prod_local_9810).checked_add(prod_local_9824); prod_local_9825 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_9826 = prod_local_9710; { let prod_local_9830 = 128; { let prod_local_9831 = (val_2857 & prod_local_9830); { let prod_local_9832 = 0; { let prod_local_9833 = (prod_local_9831 == prod_local_9832); { let prod_local_9837 = match prod_local_9833 {
        false => { let prod_local_9835 = false; prod_local_9835 },
        true => { let prod_local_9836 = true; prod_local_9836 },
    }; match prod_local_9837 {
        false => { let prod_local_9839 = Some(prod_local_9826); { let prod_local_9840 = round128(prod_local_9839); match prod_local_9840 {
        None => { let prod_local_9841 = prod_local_9840; match prod_local_9841 {
        None => None,
        Some(prod_local_9843) => { let prod_local_9844 = prod_local_9843; { let prod_local_9845 = (prod_local_9844).value; { let prod_local_9846 = low64(prod_local_9845); match prod_local_9846 {
        None => prod_local_9846,
        Some(prod_local_9847) => { let prod_local_9848 = (prod_local_9844).guard; match prod_local_9848 {
        false => prod_local_9846,
        true => { let prod_local_9850 = (prod_local_9844).sticky; match prod_local_9850 {
        false => { let prod_local_9854 = 1; { let prod_local_9855 = (prod_local_9847 & prod_local_9854); { let prod_local_9856 = (prod_local_9855 == prod_local_9854); match prod_local_9856 {
        false => prod_local_9846,
        true => { let prod_local_9858 = 1; { let prod_local_9859 = (prod_local_9847).checked_add(prod_local_9858); prod_local_9859 } },
    } } } },
        true => { let prod_local_9861 = 1; { let prod_local_9862 = (prod_local_9847).checked_add(prod_local_9861); prod_local_9862 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_9863) => { let prod_local_9864 = prod_local_9863; { let prod_local_9865 = prod_local_9864; { let prod_local_9866 = (prod_local_9865).value; { let prod_local_9867 = low64(prod_local_9866); match prod_local_9867 {
        None => prod_local_9867,
        Some(prod_local_9868) => { let prod_local_9869 = (prod_local_9865).guard; match prod_local_9869 {
        false => prod_local_9867,
        true => { let prod_local_9871 = (prod_local_9865).sticky; match prod_local_9871 {
        false => { let prod_local_9875 = 1; { let prod_local_9876 = (prod_local_9868 & prod_local_9875); { let prod_local_9877 = (prod_local_9876 == prod_local_9875); match prod_local_9877 {
        false => prod_local_9867,
        true => { let prod_local_9879 = 1; { let prod_local_9880 = (prod_local_9868).checked_add(prod_local_9879); prod_local_9880 } },
    } } } },
        true => { let prod_local_9882 = 1; { let prod_local_9883 = (prod_local_9868).checked_add(prod_local_9882); prod_local_9883 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_9884 = prod_local_9826; { let prod_local_9885 = prod_local_9884; { let prod_local_9886 = (prod_local_9885).value; { let prod_local_9887 = low64(prod_local_9886); match prod_local_9887 {
        None => prod_local_9887,
        Some(prod_local_9888) => { let prod_local_9889 = (prod_local_9885).guard; match prod_local_9889 {
        false => prod_local_9887,
        true => { let prod_local_9891 = (prod_local_9885).sticky; match prod_local_9891 {
        false => { let prod_local_9895 = 1; { let prod_local_9896 = (prod_local_9888 & prod_local_9895); { let prod_local_9897 = (prod_local_9896 == prod_local_9895); match prod_local_9897 {
        false => prod_local_9887,
        true => { let prod_local_9899 = 1; { let prod_local_9900 = (prod_local_9888).checked_add(prod_local_9899); prod_local_9900 } },
    } } } },
        true => { let prod_local_9902 = 1; { let prod_local_9903 = (prod_local_9888).checked_add(prod_local_9902); prod_local_9903 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_9904 = prod_local_9672; { let prod_local_9908 = 64; { let prod_local_9909 = (val_2857 & prod_local_9908); { let prod_local_9910 = 0; { let prod_local_9911 = (prod_local_9909 == prod_local_9910); { let prod_local_9915 = match prod_local_9911 {
        false => { let prod_local_9913 = false; prod_local_9913 },
        true => { let prod_local_9914 = true; prod_local_9914 },
    }; match prod_local_9915 {
        false => { let prod_local_9917 = Some(prod_local_9904); { let prod_local_9918 = round64(prod_local_9917); match prod_local_9918 {
        None => { let prod_local_9919 = prod_local_9918; match prod_local_9919 {
        None => None,
        Some(prod_local_9921) => { let prod_local_9922 = prod_local_9921; { let prod_local_9923 = (prod_local_9922).value; { let prod_local_9924 = low64(prod_local_9923); match prod_local_9924 {
        None => prod_local_9924,
        Some(prod_local_9925) => { let prod_local_9926 = (prod_local_9922).guard; match prod_local_9926 {
        false => prod_local_9924,
        true => { let prod_local_9928 = (prod_local_9922).sticky; match prod_local_9928 {
        false => { let prod_local_9932 = 1; { let prod_local_9933 = (prod_local_9925 & prod_local_9932); { let prod_local_9934 = (prod_local_9933 == prod_local_9932); match prod_local_9934 {
        false => prod_local_9924,
        true => { let prod_local_9936 = 1; { let prod_local_9937 = (prod_local_9925).checked_add(prod_local_9936); prod_local_9937 } },
    } } } },
        true => { let prod_local_9939 = 1; { let prod_local_9940 = (prod_local_9925).checked_add(prod_local_9939); prod_local_9940 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_9941) => { let prod_local_9942 = prod_local_9941; { let prod_local_9946 = 128; { let prod_local_9947 = (val_2857 & prod_local_9946); { let prod_local_9948 = 0; { let prod_local_9949 = (prod_local_9947 == prod_local_9948); { let prod_local_9953 = match prod_local_9949 {
        false => { let prod_local_9951 = false; prod_local_9951 },
        true => { let prod_local_9952 = true; prod_local_9952 },
    }; match prod_local_9953 {
        false => { let prod_local_9955 = Some(prod_local_9942); { let prod_local_9956 = round128(prod_local_9955); match prod_local_9956 {
        None => { let prod_local_9957 = prod_local_9956; match prod_local_9957 {
        None => None,
        Some(prod_local_9959) => { let prod_local_9960 = prod_local_9959; { let prod_local_9961 = (prod_local_9960).value; { let prod_local_9962 = low64(prod_local_9961); match prod_local_9962 {
        None => prod_local_9962,
        Some(prod_local_9963) => { let prod_local_9964 = (prod_local_9960).guard; match prod_local_9964 {
        false => prod_local_9962,
        true => { let prod_local_9966 = (prod_local_9960).sticky; match prod_local_9966 {
        false => { let prod_local_9970 = 1; { let prod_local_9971 = (prod_local_9963 & prod_local_9970); { let prod_local_9972 = (prod_local_9971 == prod_local_9970); match prod_local_9972 {
        false => prod_local_9962,
        true => { let prod_local_9974 = 1; { let prod_local_9975 = (prod_local_9963).checked_add(prod_local_9974); prod_local_9975 } },
    } } } },
        true => { let prod_local_9977 = 1; { let prod_local_9978 = (prod_local_9963).checked_add(prod_local_9977); prod_local_9978 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_9979) => { let prod_local_9980 = prod_local_9979; { let prod_local_9981 = prod_local_9980; { let prod_local_9982 = (prod_local_9981).value; { let prod_local_9983 = low64(prod_local_9982); match prod_local_9983 {
        None => prod_local_9983,
        Some(prod_local_9984) => { let prod_local_9985 = (prod_local_9981).guard; match prod_local_9985 {
        false => prod_local_9983,
        true => { let prod_local_9987 = (prod_local_9981).sticky; match prod_local_9987 {
        false => { let prod_local_9991 = 1; { let prod_local_9992 = (prod_local_9984 & prod_local_9991); { let prod_local_9993 = (prod_local_9992 == prod_local_9991); match prod_local_9993 {
        false => prod_local_9983,
        true => { let prod_local_9995 = 1; { let prod_local_9996 = (prod_local_9984).checked_add(prod_local_9995); prod_local_9996 } },
    } } } },
        true => { let prod_local_9998 = 1; { let prod_local_9999 = (prod_local_9984).checked_add(prod_local_9998); prod_local_9999 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_10000 = prod_local_9942; { let prod_local_10001 = prod_local_10000; { let prod_local_10002 = (prod_local_10001).value; { let prod_local_10003 = low64(prod_local_10002); match prod_local_10003 {
        None => prod_local_10003,
        Some(prod_local_10004) => { let prod_local_10005 = (prod_local_10001).guard; match prod_local_10005 {
        false => prod_local_10003,
        true => { let prod_local_10007 = (prod_local_10001).sticky; match prod_local_10007 {
        false => { let prod_local_10011 = 1; { let prod_local_10012 = (prod_local_10004 & prod_local_10011); { let prod_local_10013 = (prod_local_10012 == prod_local_10011); match prod_local_10013 {
        false => prod_local_10003,
        true => { let prod_local_10015 = 1; { let prod_local_10016 = (prod_local_10004).checked_add(prod_local_10015); prod_local_10016 } },
    } } } },
        true => { let prod_local_10018 = 1; { let prod_local_10019 = (prod_local_10004).checked_add(prod_local_10018); prod_local_10019 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_10020 = prod_local_9904; { let prod_local_10024 = 128; { let prod_local_10025 = (val_2857 & prod_local_10024); { let prod_local_10026 = 0; { let prod_local_10027 = (prod_local_10025 == prod_local_10026); { let prod_local_10031 = match prod_local_10027 {
        false => { let prod_local_10029 = false; prod_local_10029 },
        true => { let prod_local_10030 = true; prod_local_10030 },
    }; match prod_local_10031 {
        false => { let prod_local_10033 = Some(prod_local_10020); { let prod_local_10034 = round128(prod_local_10033); match prod_local_10034 {
        None => { let prod_local_10035 = prod_local_10034; match prod_local_10035 {
        None => None,
        Some(prod_local_10037) => { let prod_local_10038 = prod_local_10037; { let prod_local_10039 = (prod_local_10038).value; { let prod_local_10040 = low64(prod_local_10039); match prod_local_10040 {
        None => prod_local_10040,
        Some(prod_local_10041) => { let prod_local_10042 = (prod_local_10038).guard; match prod_local_10042 {
        false => prod_local_10040,
        true => { let prod_local_10044 = (prod_local_10038).sticky; match prod_local_10044 {
        false => { let prod_local_10048 = 1; { let prod_local_10049 = (prod_local_10041 & prod_local_10048); { let prod_local_10050 = (prod_local_10049 == prod_local_10048); match prod_local_10050 {
        false => prod_local_10040,
        true => { let prod_local_10052 = 1; { let prod_local_10053 = (prod_local_10041).checked_add(prod_local_10052); prod_local_10053 } },
    } } } },
        true => { let prod_local_10055 = 1; { let prod_local_10056 = (prod_local_10041).checked_add(prod_local_10055); prod_local_10056 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_10057) => { let prod_local_10058 = prod_local_10057; { let prod_local_10059 = prod_local_10058; { let prod_local_10060 = (prod_local_10059).value; { let prod_local_10061 = low64(prod_local_10060); match prod_local_10061 {
        None => prod_local_10061,
        Some(prod_local_10062) => { let prod_local_10063 = (prod_local_10059).guard; match prod_local_10063 {
        false => prod_local_10061,
        true => { let prod_local_10065 = (prod_local_10059).sticky; match prod_local_10065 {
        false => { let prod_local_10069 = 1; { let prod_local_10070 = (prod_local_10062 & prod_local_10069); { let prod_local_10071 = (prod_local_10070 == prod_local_10069); match prod_local_10071 {
        false => prod_local_10061,
        true => { let prod_local_10073 = 1; { let prod_local_10074 = (prod_local_10062).checked_add(prod_local_10073); prod_local_10074 } },
    } } } },
        true => { let prod_local_10076 = 1; { let prod_local_10077 = (prod_local_10062).checked_add(prod_local_10076); prod_local_10077 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_10078 = prod_local_10020; { let prod_local_10079 = prod_local_10078; { let prod_local_10080 = (prod_local_10079).value; { let prod_local_10081 = low64(prod_local_10080); match prod_local_10081 {
        None => prod_local_10081,
        Some(prod_local_10082) => { let prod_local_10083 = (prod_local_10079).guard; match prod_local_10083 {
        false => prod_local_10081,
        true => { let prod_local_10085 = (prod_local_10079).sticky; match prod_local_10085 {
        false => { let prod_local_10089 = 1; { let prod_local_10090 = (prod_local_10082 & prod_local_10089); { let prod_local_10091 = (prod_local_10090 == prod_local_10089); match prod_local_10091 {
        false => prod_local_10081,
        true => { let prod_local_10093 = 1; { let prod_local_10094 = (prod_local_10082).checked_add(prod_local_10093); prod_local_10094 } },
    } } } },
        true => { let prod_local_10096 = 1; { let prod_local_10097 = (prod_local_10082).checked_add(prod_local_10096); prod_local_10097 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } } } } } },
    } } } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_10098 = prod_local_9170; { let prod_local_10102 = 16; { let prod_local_10103 = (val_2857 & prod_local_10102); { let prod_local_10104 = 0; { let prod_local_10105 = (prod_local_10103 == prod_local_10104); { let prod_local_10109 = match prod_local_10105 {
        false => { let prod_local_10107 = false; prod_local_10107 },
        true => { let prod_local_10108 = true; prod_local_10108 },
    }; match prod_local_10109 {
        false => { let prod_local_10111 = Some(prod_local_10098); { let prod_local_10112 = round16(prod_local_10111); match prod_local_10112 {
        None => { let prod_local_10113 = prod_local_10112; match prod_local_10113 {
        None => None,
        Some(prod_local_10115) => { let prod_local_10116 = prod_local_10115; { let prod_local_10117 = (prod_local_10116).value; { let prod_local_10118 = low64(prod_local_10117); match prod_local_10118 {
        None => prod_local_10118,
        Some(prod_local_10119) => { let prod_local_10120 = (prod_local_10116).guard; match prod_local_10120 {
        false => prod_local_10118,
        true => { let prod_local_10122 = (prod_local_10116).sticky; match prod_local_10122 {
        false => { let prod_local_10126 = 1; { let prod_local_10127 = (prod_local_10119 & prod_local_10126); { let prod_local_10128 = (prod_local_10127 == prod_local_10126); match prod_local_10128 {
        false => prod_local_10118,
        true => { let prod_local_10130 = 1; { let prod_local_10131 = (prod_local_10119).checked_add(prod_local_10130); prod_local_10131 } },
    } } } },
        true => { let prod_local_10133 = 1; { let prod_local_10134 = (prod_local_10119).checked_add(prod_local_10133); prod_local_10134 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_10135) => { let prod_local_10136 = prod_local_10135; { let prod_local_10140 = 32; { let prod_local_10141 = (val_2857 & prod_local_10140); { let prod_local_10142 = 0; { let prod_local_10143 = (prod_local_10141 == prod_local_10142); { let prod_local_10147 = match prod_local_10143 {
        false => { let prod_local_10145 = false; prod_local_10145 },
        true => { let prod_local_10146 = true; prod_local_10146 },
    }; match prod_local_10147 {
        false => { let prod_local_10149 = Some(prod_local_10136); { let prod_local_10150 = round32(prod_local_10149); match prod_local_10150 {
        None => { let prod_local_10151 = prod_local_10150; match prod_local_10151 {
        None => None,
        Some(prod_local_10153) => { let prod_local_10154 = prod_local_10153; { let prod_local_10155 = (prod_local_10154).value; { let prod_local_10156 = low64(prod_local_10155); match prod_local_10156 {
        None => prod_local_10156,
        Some(prod_local_10157) => { let prod_local_10158 = (prod_local_10154).guard; match prod_local_10158 {
        false => prod_local_10156,
        true => { let prod_local_10160 = (prod_local_10154).sticky; match prod_local_10160 {
        false => { let prod_local_10164 = 1; { let prod_local_10165 = (prod_local_10157 & prod_local_10164); { let prod_local_10166 = (prod_local_10165 == prod_local_10164); match prod_local_10166 {
        false => prod_local_10156,
        true => { let prod_local_10168 = 1; { let prod_local_10169 = (prod_local_10157).checked_add(prod_local_10168); prod_local_10169 } },
    } } } },
        true => { let prod_local_10171 = 1; { let prod_local_10172 = (prod_local_10157).checked_add(prod_local_10171); prod_local_10172 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_10173) => { let prod_local_10174 = prod_local_10173; { let prod_local_10178 = 64; { let prod_local_10179 = (val_2857 & prod_local_10178); { let prod_local_10180 = 0; { let prod_local_10181 = (prod_local_10179 == prod_local_10180); { let prod_local_10185 = match prod_local_10181 {
        false => { let prod_local_10183 = false; prod_local_10183 },
        true => { let prod_local_10184 = true; prod_local_10184 },
    }; match prod_local_10185 {
        false => { let prod_local_10187 = Some(prod_local_10174); { let prod_local_10188 = round64(prod_local_10187); match prod_local_10188 {
        None => { let prod_local_10189 = prod_local_10188; match prod_local_10189 {
        None => None,
        Some(prod_local_10191) => { let prod_local_10192 = prod_local_10191; { let prod_local_10193 = (prod_local_10192).value; { let prod_local_10194 = low64(prod_local_10193); match prod_local_10194 {
        None => prod_local_10194,
        Some(prod_local_10195) => { let prod_local_10196 = (prod_local_10192).guard; match prod_local_10196 {
        false => prod_local_10194,
        true => { let prod_local_10198 = (prod_local_10192).sticky; match prod_local_10198 {
        false => { let prod_local_10202 = 1; { let prod_local_10203 = (prod_local_10195 & prod_local_10202); { let prod_local_10204 = (prod_local_10203 == prod_local_10202); match prod_local_10204 {
        false => prod_local_10194,
        true => { let prod_local_10206 = 1; { let prod_local_10207 = (prod_local_10195).checked_add(prod_local_10206); prod_local_10207 } },
    } } } },
        true => { let prod_local_10209 = 1; { let prod_local_10210 = (prod_local_10195).checked_add(prod_local_10209); prod_local_10210 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_10211) => { let prod_local_10212 = prod_local_10211; { let prod_local_10216 = 128; { let prod_local_10217 = (val_2857 & prod_local_10216); { let prod_local_10218 = 0; { let prod_local_10219 = (prod_local_10217 == prod_local_10218); { let prod_local_10223 = match prod_local_10219 {
        false => { let prod_local_10221 = false; prod_local_10221 },
        true => { let prod_local_10222 = true; prod_local_10222 },
    }; match prod_local_10223 {
        false => { let prod_local_10225 = Some(prod_local_10212); { let prod_local_10226 = round128(prod_local_10225); match prod_local_10226 {
        None => { let prod_local_10227 = prod_local_10226; match prod_local_10227 {
        None => None,
        Some(prod_local_10229) => { let prod_local_10230 = prod_local_10229; { let prod_local_10231 = (prod_local_10230).value; { let prod_local_10232 = low64(prod_local_10231); match prod_local_10232 {
        None => prod_local_10232,
        Some(prod_local_10233) => { let prod_local_10234 = (prod_local_10230).guard; match prod_local_10234 {
        false => prod_local_10232,
        true => { let prod_local_10236 = (prod_local_10230).sticky; match prod_local_10236 {
        false => { let prod_local_10240 = 1; { let prod_local_10241 = (prod_local_10233 & prod_local_10240); { let prod_local_10242 = (prod_local_10241 == prod_local_10240); match prod_local_10242 {
        false => prod_local_10232,
        true => { let prod_local_10244 = 1; { let prod_local_10245 = (prod_local_10233).checked_add(prod_local_10244); prod_local_10245 } },
    } } } },
        true => { let prod_local_10247 = 1; { let prod_local_10248 = (prod_local_10233).checked_add(prod_local_10247); prod_local_10248 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_10249) => { let prod_local_10250 = prod_local_10249; { let prod_local_10251 = prod_local_10250; { let prod_local_10252 = (prod_local_10251).value; { let prod_local_10253 = low64(prod_local_10252); match prod_local_10253 {
        None => prod_local_10253,
        Some(prod_local_10254) => { let prod_local_10255 = (prod_local_10251).guard; match prod_local_10255 {
        false => prod_local_10253,
        true => { let prod_local_10257 = (prod_local_10251).sticky; match prod_local_10257 {
        false => { let prod_local_10261 = 1; { let prod_local_10262 = (prod_local_10254 & prod_local_10261); { let prod_local_10263 = (prod_local_10262 == prod_local_10261); match prod_local_10263 {
        false => prod_local_10253,
        true => { let prod_local_10265 = 1; { let prod_local_10266 = (prod_local_10254).checked_add(prod_local_10265); prod_local_10266 } },
    } } } },
        true => { let prod_local_10268 = 1; { let prod_local_10269 = (prod_local_10254).checked_add(prod_local_10268); prod_local_10269 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_10270 = prod_local_10212; { let prod_local_10271 = prod_local_10270; { let prod_local_10272 = (prod_local_10271).value; { let prod_local_10273 = low64(prod_local_10272); match prod_local_10273 {
        None => prod_local_10273,
        Some(prod_local_10274) => { let prod_local_10275 = (prod_local_10271).guard; match prod_local_10275 {
        false => prod_local_10273,
        true => { let prod_local_10277 = (prod_local_10271).sticky; match prod_local_10277 {
        false => { let prod_local_10281 = 1; { let prod_local_10282 = (prod_local_10274 & prod_local_10281); { let prod_local_10283 = (prod_local_10282 == prod_local_10281); match prod_local_10283 {
        false => prod_local_10273,
        true => { let prod_local_10285 = 1; { let prod_local_10286 = (prod_local_10274).checked_add(prod_local_10285); prod_local_10286 } },
    } } } },
        true => { let prod_local_10288 = 1; { let prod_local_10289 = (prod_local_10274).checked_add(prod_local_10288); prod_local_10289 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_10290 = prod_local_10174; { let prod_local_10294 = 128; { let prod_local_10295 = (val_2857 & prod_local_10294); { let prod_local_10296 = 0; { let prod_local_10297 = (prod_local_10295 == prod_local_10296); { let prod_local_10301 = match prod_local_10297 {
        false => { let prod_local_10299 = false; prod_local_10299 },
        true => { let prod_local_10300 = true; prod_local_10300 },
    }; match prod_local_10301 {
        false => { let prod_local_10303 = Some(prod_local_10290); { let prod_local_10304 = round128(prod_local_10303); match prod_local_10304 {
        None => { let prod_local_10305 = prod_local_10304; match prod_local_10305 {
        None => None,
        Some(prod_local_10307) => { let prod_local_10308 = prod_local_10307; { let prod_local_10309 = (prod_local_10308).value; { let prod_local_10310 = low64(prod_local_10309); match prod_local_10310 {
        None => prod_local_10310,
        Some(prod_local_10311) => { let prod_local_10312 = (prod_local_10308).guard; match prod_local_10312 {
        false => prod_local_10310,
        true => { let prod_local_10314 = (prod_local_10308).sticky; match prod_local_10314 {
        false => { let prod_local_10318 = 1; { let prod_local_10319 = (prod_local_10311 & prod_local_10318); { let prod_local_10320 = (prod_local_10319 == prod_local_10318); match prod_local_10320 {
        false => prod_local_10310,
        true => { let prod_local_10322 = 1; { let prod_local_10323 = (prod_local_10311).checked_add(prod_local_10322); prod_local_10323 } },
    } } } },
        true => { let prod_local_10325 = 1; { let prod_local_10326 = (prod_local_10311).checked_add(prod_local_10325); prod_local_10326 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_10327) => { let prod_local_10328 = prod_local_10327; { let prod_local_10329 = prod_local_10328; { let prod_local_10330 = (prod_local_10329).value; { let prod_local_10331 = low64(prod_local_10330); match prod_local_10331 {
        None => prod_local_10331,
        Some(prod_local_10332) => { let prod_local_10333 = (prod_local_10329).guard; match prod_local_10333 {
        false => prod_local_10331,
        true => { let prod_local_10335 = (prod_local_10329).sticky; match prod_local_10335 {
        false => { let prod_local_10339 = 1; { let prod_local_10340 = (prod_local_10332 & prod_local_10339); { let prod_local_10341 = (prod_local_10340 == prod_local_10339); match prod_local_10341 {
        false => prod_local_10331,
        true => { let prod_local_10343 = 1; { let prod_local_10344 = (prod_local_10332).checked_add(prod_local_10343); prod_local_10344 } },
    } } } },
        true => { let prod_local_10346 = 1; { let prod_local_10347 = (prod_local_10332).checked_add(prod_local_10346); prod_local_10347 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_10348 = prod_local_10290; { let prod_local_10349 = prod_local_10348; { let prod_local_10350 = (prod_local_10349).value; { let prod_local_10351 = low64(prod_local_10350); match prod_local_10351 {
        None => prod_local_10351,
        Some(prod_local_10352) => { let prod_local_10353 = (prod_local_10349).guard; match prod_local_10353 {
        false => prod_local_10351,
        true => { let prod_local_10355 = (prod_local_10349).sticky; match prod_local_10355 {
        false => { let prod_local_10359 = 1; { let prod_local_10360 = (prod_local_10352 & prod_local_10359); { let prod_local_10361 = (prod_local_10360 == prod_local_10359); match prod_local_10361 {
        false => prod_local_10351,
        true => { let prod_local_10363 = 1; { let prod_local_10364 = (prod_local_10352).checked_add(prod_local_10363); prod_local_10364 } },
    } } } },
        true => { let prod_local_10366 = 1; { let prod_local_10367 = (prod_local_10352).checked_add(prod_local_10366); prod_local_10367 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_10368 = prod_local_10136; { let prod_local_10372 = 64; { let prod_local_10373 = (val_2857 & prod_local_10372); { let prod_local_10374 = 0; { let prod_local_10375 = (prod_local_10373 == prod_local_10374); { let prod_local_10379 = match prod_local_10375 {
        false => { let prod_local_10377 = false; prod_local_10377 },
        true => { let prod_local_10378 = true; prod_local_10378 },
    }; match prod_local_10379 {
        false => { let prod_local_10381 = Some(prod_local_10368); { let prod_local_10382 = round64(prod_local_10381); match prod_local_10382 {
        None => { let prod_local_10383 = prod_local_10382; match prod_local_10383 {
        None => None,
        Some(prod_local_10385) => { let prod_local_10386 = prod_local_10385; { let prod_local_10387 = (prod_local_10386).value; { let prod_local_10388 = low64(prod_local_10387); match prod_local_10388 {
        None => prod_local_10388,
        Some(prod_local_10389) => { let prod_local_10390 = (prod_local_10386).guard; match prod_local_10390 {
        false => prod_local_10388,
        true => { let prod_local_10392 = (prod_local_10386).sticky; match prod_local_10392 {
        false => { let prod_local_10396 = 1; { let prod_local_10397 = (prod_local_10389 & prod_local_10396); { let prod_local_10398 = (prod_local_10397 == prod_local_10396); match prod_local_10398 {
        false => prod_local_10388,
        true => { let prod_local_10400 = 1; { let prod_local_10401 = (prod_local_10389).checked_add(prod_local_10400); prod_local_10401 } },
    } } } },
        true => { let prod_local_10403 = 1; { let prod_local_10404 = (prod_local_10389).checked_add(prod_local_10403); prod_local_10404 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_10405) => { let prod_local_10406 = prod_local_10405; { let prod_local_10410 = 128; { let prod_local_10411 = (val_2857 & prod_local_10410); { let prod_local_10412 = 0; { let prod_local_10413 = (prod_local_10411 == prod_local_10412); { let prod_local_10417 = match prod_local_10413 {
        false => { let prod_local_10415 = false; prod_local_10415 },
        true => { let prod_local_10416 = true; prod_local_10416 },
    }; match prod_local_10417 {
        false => { let prod_local_10419 = Some(prod_local_10406); { let prod_local_10420 = round128(prod_local_10419); match prod_local_10420 {
        None => { let prod_local_10421 = prod_local_10420; match prod_local_10421 {
        None => None,
        Some(prod_local_10423) => { let prod_local_10424 = prod_local_10423; { let prod_local_10425 = (prod_local_10424).value; { let prod_local_10426 = low64(prod_local_10425); match prod_local_10426 {
        None => prod_local_10426,
        Some(prod_local_10427) => { let prod_local_10428 = (prod_local_10424).guard; match prod_local_10428 {
        false => prod_local_10426,
        true => { let prod_local_10430 = (prod_local_10424).sticky; match prod_local_10430 {
        false => { let prod_local_10434 = 1; { let prod_local_10435 = (prod_local_10427 & prod_local_10434); { let prod_local_10436 = (prod_local_10435 == prod_local_10434); match prod_local_10436 {
        false => prod_local_10426,
        true => { let prod_local_10438 = 1; { let prod_local_10439 = (prod_local_10427).checked_add(prod_local_10438); prod_local_10439 } },
    } } } },
        true => { let prod_local_10441 = 1; { let prod_local_10442 = (prod_local_10427).checked_add(prod_local_10441); prod_local_10442 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_10443) => { let prod_local_10444 = prod_local_10443; { let prod_local_10445 = prod_local_10444; { let prod_local_10446 = (prod_local_10445).value; { let prod_local_10447 = low64(prod_local_10446); match prod_local_10447 {
        None => prod_local_10447,
        Some(prod_local_10448) => { let prod_local_10449 = (prod_local_10445).guard; match prod_local_10449 {
        false => prod_local_10447,
        true => { let prod_local_10451 = (prod_local_10445).sticky; match prod_local_10451 {
        false => { let prod_local_10455 = 1; { let prod_local_10456 = (prod_local_10448 & prod_local_10455); { let prod_local_10457 = (prod_local_10456 == prod_local_10455); match prod_local_10457 {
        false => prod_local_10447,
        true => { let prod_local_10459 = 1; { let prod_local_10460 = (prod_local_10448).checked_add(prod_local_10459); prod_local_10460 } },
    } } } },
        true => { let prod_local_10462 = 1; { let prod_local_10463 = (prod_local_10448).checked_add(prod_local_10462); prod_local_10463 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_10464 = prod_local_10406; { let prod_local_10465 = prod_local_10464; { let prod_local_10466 = (prod_local_10465).value; { let prod_local_10467 = low64(prod_local_10466); match prod_local_10467 {
        None => prod_local_10467,
        Some(prod_local_10468) => { let prod_local_10469 = (prod_local_10465).guard; match prod_local_10469 {
        false => prod_local_10467,
        true => { let prod_local_10471 = (prod_local_10465).sticky; match prod_local_10471 {
        false => { let prod_local_10475 = 1; { let prod_local_10476 = (prod_local_10468 & prod_local_10475); { let prod_local_10477 = (prod_local_10476 == prod_local_10475); match prod_local_10477 {
        false => prod_local_10467,
        true => { let prod_local_10479 = 1; { let prod_local_10480 = (prod_local_10468).checked_add(prod_local_10479); prod_local_10480 } },
    } } } },
        true => { let prod_local_10482 = 1; { let prod_local_10483 = (prod_local_10468).checked_add(prod_local_10482); prod_local_10483 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_10484 = prod_local_10368; { let prod_local_10488 = 128; { let prod_local_10489 = (val_2857 & prod_local_10488); { let prod_local_10490 = 0; { let prod_local_10491 = (prod_local_10489 == prod_local_10490); { let prod_local_10495 = match prod_local_10491 {
        false => { let prod_local_10493 = false; prod_local_10493 },
        true => { let prod_local_10494 = true; prod_local_10494 },
    }; match prod_local_10495 {
        false => { let prod_local_10497 = Some(prod_local_10484); { let prod_local_10498 = round128(prod_local_10497); match prod_local_10498 {
        None => { let prod_local_10499 = prod_local_10498; match prod_local_10499 {
        None => None,
        Some(prod_local_10501) => { let prod_local_10502 = prod_local_10501; { let prod_local_10503 = (prod_local_10502).value; { let prod_local_10504 = low64(prod_local_10503); match prod_local_10504 {
        None => prod_local_10504,
        Some(prod_local_10505) => { let prod_local_10506 = (prod_local_10502).guard; match prod_local_10506 {
        false => prod_local_10504,
        true => { let prod_local_10508 = (prod_local_10502).sticky; match prod_local_10508 {
        false => { let prod_local_10512 = 1; { let prod_local_10513 = (prod_local_10505 & prod_local_10512); { let prod_local_10514 = (prod_local_10513 == prod_local_10512); match prod_local_10514 {
        false => prod_local_10504,
        true => { let prod_local_10516 = 1; { let prod_local_10517 = (prod_local_10505).checked_add(prod_local_10516); prod_local_10517 } },
    } } } },
        true => { let prod_local_10519 = 1; { let prod_local_10520 = (prod_local_10505).checked_add(prod_local_10519); prod_local_10520 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_10521) => { let prod_local_10522 = prod_local_10521; { let prod_local_10523 = prod_local_10522; { let prod_local_10524 = (prod_local_10523).value; { let prod_local_10525 = low64(prod_local_10524); match prod_local_10525 {
        None => prod_local_10525,
        Some(prod_local_10526) => { let prod_local_10527 = (prod_local_10523).guard; match prod_local_10527 {
        false => prod_local_10525,
        true => { let prod_local_10529 = (prod_local_10523).sticky; match prod_local_10529 {
        false => { let prod_local_10533 = 1; { let prod_local_10534 = (prod_local_10526 & prod_local_10533); { let prod_local_10535 = (prod_local_10534 == prod_local_10533); match prod_local_10535 {
        false => prod_local_10525,
        true => { let prod_local_10537 = 1; { let prod_local_10538 = (prod_local_10526).checked_add(prod_local_10537); prod_local_10538 } },
    } } } },
        true => { let prod_local_10540 = 1; { let prod_local_10541 = (prod_local_10526).checked_add(prod_local_10540); prod_local_10541 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_10542 = prod_local_10484; { let prod_local_10543 = prod_local_10542; { let prod_local_10544 = (prod_local_10543).value; { let prod_local_10545 = low64(prod_local_10544); match prod_local_10545 {
        None => prod_local_10545,
        Some(prod_local_10546) => { let prod_local_10547 = (prod_local_10543).guard; match prod_local_10547 {
        false => prod_local_10545,
        true => { let prod_local_10549 = (prod_local_10543).sticky; match prod_local_10549 {
        false => { let prod_local_10553 = 1; { let prod_local_10554 = (prod_local_10546 & prod_local_10553); { let prod_local_10555 = (prod_local_10554 == prod_local_10553); match prod_local_10555 {
        false => prod_local_10545,
        true => { let prod_local_10557 = 1; { let prod_local_10558 = (prod_local_10546).checked_add(prod_local_10557); prod_local_10558 } },
    } } } },
        true => { let prod_local_10560 = 1; { let prod_local_10561 = (prod_local_10546).checked_add(prod_local_10560); prod_local_10561 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_10562 = prod_local_10098; { let prod_local_10566 = 32; { let prod_local_10567 = (val_2857 & prod_local_10566); { let prod_local_10568 = 0; { let prod_local_10569 = (prod_local_10567 == prod_local_10568); { let prod_local_10573 = match prod_local_10569 {
        false => { let prod_local_10571 = false; prod_local_10571 },
        true => { let prod_local_10572 = true; prod_local_10572 },
    }; match prod_local_10573 {
        false => { let prod_local_10575 = Some(prod_local_10562); { let prod_local_10576 = round32(prod_local_10575); match prod_local_10576 {
        None => { let prod_local_10577 = prod_local_10576; match prod_local_10577 {
        None => None,
        Some(prod_local_10579) => { let prod_local_10580 = prod_local_10579; { let prod_local_10581 = (prod_local_10580).value; { let prod_local_10582 = low64(prod_local_10581); match prod_local_10582 {
        None => prod_local_10582,
        Some(prod_local_10583) => { let prod_local_10584 = (prod_local_10580).guard; match prod_local_10584 {
        false => prod_local_10582,
        true => { let prod_local_10586 = (prod_local_10580).sticky; match prod_local_10586 {
        false => { let prod_local_10590 = 1; { let prod_local_10591 = (prod_local_10583 & prod_local_10590); { let prod_local_10592 = (prod_local_10591 == prod_local_10590); match prod_local_10592 {
        false => prod_local_10582,
        true => { let prod_local_10594 = 1; { let prod_local_10595 = (prod_local_10583).checked_add(prod_local_10594); prod_local_10595 } },
    } } } },
        true => { let prod_local_10597 = 1; { let prod_local_10598 = (prod_local_10583).checked_add(prod_local_10597); prod_local_10598 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_10599) => { let prod_local_10600 = prod_local_10599; { let prod_local_10604 = 64; { let prod_local_10605 = (val_2857 & prod_local_10604); { let prod_local_10606 = 0; { let prod_local_10607 = (prod_local_10605 == prod_local_10606); { let prod_local_10611 = match prod_local_10607 {
        false => { let prod_local_10609 = false; prod_local_10609 },
        true => { let prod_local_10610 = true; prod_local_10610 },
    }; match prod_local_10611 {
        false => { let prod_local_10613 = Some(prod_local_10600); { let prod_local_10614 = round64(prod_local_10613); match prod_local_10614 {
        None => { let prod_local_10615 = prod_local_10614; match prod_local_10615 {
        None => None,
        Some(prod_local_10617) => { let prod_local_10618 = prod_local_10617; { let prod_local_10619 = (prod_local_10618).value; { let prod_local_10620 = low64(prod_local_10619); match prod_local_10620 {
        None => prod_local_10620,
        Some(prod_local_10621) => { let prod_local_10622 = (prod_local_10618).guard; match prod_local_10622 {
        false => prod_local_10620,
        true => { let prod_local_10624 = (prod_local_10618).sticky; match prod_local_10624 {
        false => { let prod_local_10628 = 1; { let prod_local_10629 = (prod_local_10621 & prod_local_10628); { let prod_local_10630 = (prod_local_10629 == prod_local_10628); match prod_local_10630 {
        false => prod_local_10620,
        true => { let prod_local_10632 = 1; { let prod_local_10633 = (prod_local_10621).checked_add(prod_local_10632); prod_local_10633 } },
    } } } },
        true => { let prod_local_10635 = 1; { let prod_local_10636 = (prod_local_10621).checked_add(prod_local_10635); prod_local_10636 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_10637) => { let prod_local_10638 = prod_local_10637; { let prod_local_10642 = 128; { let prod_local_10643 = (val_2857 & prod_local_10642); { let prod_local_10644 = 0; { let prod_local_10645 = (prod_local_10643 == prod_local_10644); { let prod_local_10649 = match prod_local_10645 {
        false => { let prod_local_10647 = false; prod_local_10647 },
        true => { let prod_local_10648 = true; prod_local_10648 },
    }; match prod_local_10649 {
        false => { let prod_local_10651 = Some(prod_local_10638); { let prod_local_10652 = round128(prod_local_10651); match prod_local_10652 {
        None => { let prod_local_10653 = prod_local_10652; match prod_local_10653 {
        None => None,
        Some(prod_local_10655) => { let prod_local_10656 = prod_local_10655; { let prod_local_10657 = (prod_local_10656).value; { let prod_local_10658 = low64(prod_local_10657); match prod_local_10658 {
        None => prod_local_10658,
        Some(prod_local_10659) => { let prod_local_10660 = (prod_local_10656).guard; match prod_local_10660 {
        false => prod_local_10658,
        true => { let prod_local_10662 = (prod_local_10656).sticky; match prod_local_10662 {
        false => { let prod_local_10666 = 1; { let prod_local_10667 = (prod_local_10659 & prod_local_10666); { let prod_local_10668 = (prod_local_10667 == prod_local_10666); match prod_local_10668 {
        false => prod_local_10658,
        true => { let prod_local_10670 = 1; { let prod_local_10671 = (prod_local_10659).checked_add(prod_local_10670); prod_local_10671 } },
    } } } },
        true => { let prod_local_10673 = 1; { let prod_local_10674 = (prod_local_10659).checked_add(prod_local_10673); prod_local_10674 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_10675) => { let prod_local_10676 = prod_local_10675; { let prod_local_10677 = prod_local_10676; { let prod_local_10678 = (prod_local_10677).value; { let prod_local_10679 = low64(prod_local_10678); match prod_local_10679 {
        None => prod_local_10679,
        Some(prod_local_10680) => { let prod_local_10681 = (prod_local_10677).guard; match prod_local_10681 {
        false => prod_local_10679,
        true => { let prod_local_10683 = (prod_local_10677).sticky; match prod_local_10683 {
        false => { let prod_local_10687 = 1; { let prod_local_10688 = (prod_local_10680 & prod_local_10687); { let prod_local_10689 = (prod_local_10688 == prod_local_10687); match prod_local_10689 {
        false => prod_local_10679,
        true => { let prod_local_10691 = 1; { let prod_local_10692 = (prod_local_10680).checked_add(prod_local_10691); prod_local_10692 } },
    } } } },
        true => { let prod_local_10694 = 1; { let prod_local_10695 = (prod_local_10680).checked_add(prod_local_10694); prod_local_10695 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_10696 = prod_local_10638; { let prod_local_10697 = prod_local_10696; { let prod_local_10698 = (prod_local_10697).value; { let prod_local_10699 = low64(prod_local_10698); match prod_local_10699 {
        None => prod_local_10699,
        Some(prod_local_10700) => { let prod_local_10701 = (prod_local_10697).guard; match prod_local_10701 {
        false => prod_local_10699,
        true => { let prod_local_10703 = (prod_local_10697).sticky; match prod_local_10703 {
        false => { let prod_local_10707 = 1; { let prod_local_10708 = (prod_local_10700 & prod_local_10707); { let prod_local_10709 = (prod_local_10708 == prod_local_10707); match prod_local_10709 {
        false => prod_local_10699,
        true => { let prod_local_10711 = 1; { let prod_local_10712 = (prod_local_10700).checked_add(prod_local_10711); prod_local_10712 } },
    } } } },
        true => { let prod_local_10714 = 1; { let prod_local_10715 = (prod_local_10700).checked_add(prod_local_10714); prod_local_10715 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_10716 = prod_local_10600; { let prod_local_10720 = 128; { let prod_local_10721 = (val_2857 & prod_local_10720); { let prod_local_10722 = 0; { let prod_local_10723 = (prod_local_10721 == prod_local_10722); { let prod_local_10727 = match prod_local_10723 {
        false => { let prod_local_10725 = false; prod_local_10725 },
        true => { let prod_local_10726 = true; prod_local_10726 },
    }; match prod_local_10727 {
        false => { let prod_local_10729 = Some(prod_local_10716); { let prod_local_10730 = round128(prod_local_10729); match prod_local_10730 {
        None => { let prod_local_10731 = prod_local_10730; match prod_local_10731 {
        None => None,
        Some(prod_local_10733) => { let prod_local_10734 = prod_local_10733; { let prod_local_10735 = (prod_local_10734).value; { let prod_local_10736 = low64(prod_local_10735); match prod_local_10736 {
        None => prod_local_10736,
        Some(prod_local_10737) => { let prod_local_10738 = (prod_local_10734).guard; match prod_local_10738 {
        false => prod_local_10736,
        true => { let prod_local_10740 = (prod_local_10734).sticky; match prod_local_10740 {
        false => { let prod_local_10744 = 1; { let prod_local_10745 = (prod_local_10737 & prod_local_10744); { let prod_local_10746 = (prod_local_10745 == prod_local_10744); match prod_local_10746 {
        false => prod_local_10736,
        true => { let prod_local_10748 = 1; { let prod_local_10749 = (prod_local_10737).checked_add(prod_local_10748); prod_local_10749 } },
    } } } },
        true => { let prod_local_10751 = 1; { let prod_local_10752 = (prod_local_10737).checked_add(prod_local_10751); prod_local_10752 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_10753) => { let prod_local_10754 = prod_local_10753; { let prod_local_10755 = prod_local_10754; { let prod_local_10756 = (prod_local_10755).value; { let prod_local_10757 = low64(prod_local_10756); match prod_local_10757 {
        None => prod_local_10757,
        Some(prod_local_10758) => { let prod_local_10759 = (prod_local_10755).guard; match prod_local_10759 {
        false => prod_local_10757,
        true => { let prod_local_10761 = (prod_local_10755).sticky; match prod_local_10761 {
        false => { let prod_local_10765 = 1; { let prod_local_10766 = (prod_local_10758 & prod_local_10765); { let prod_local_10767 = (prod_local_10766 == prod_local_10765); match prod_local_10767 {
        false => prod_local_10757,
        true => { let prod_local_10769 = 1; { let prod_local_10770 = (prod_local_10758).checked_add(prod_local_10769); prod_local_10770 } },
    } } } },
        true => { let prod_local_10772 = 1; { let prod_local_10773 = (prod_local_10758).checked_add(prod_local_10772); prod_local_10773 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_10774 = prod_local_10716; { let prod_local_10775 = prod_local_10774; { let prod_local_10776 = (prod_local_10775).value; { let prod_local_10777 = low64(prod_local_10776); match prod_local_10777 {
        None => prod_local_10777,
        Some(prod_local_10778) => { let prod_local_10779 = (prod_local_10775).guard; match prod_local_10779 {
        false => prod_local_10777,
        true => { let prod_local_10781 = (prod_local_10775).sticky; match prod_local_10781 {
        false => { let prod_local_10785 = 1; { let prod_local_10786 = (prod_local_10778 & prod_local_10785); { let prod_local_10787 = (prod_local_10786 == prod_local_10785); match prod_local_10787 {
        false => prod_local_10777,
        true => { let prod_local_10789 = 1; { let prod_local_10790 = (prod_local_10778).checked_add(prod_local_10789); prod_local_10790 } },
    } } } },
        true => { let prod_local_10792 = 1; { let prod_local_10793 = (prod_local_10778).checked_add(prod_local_10792); prod_local_10793 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_10794 = prod_local_10562; { let prod_local_10798 = 64; { let prod_local_10799 = (val_2857 & prod_local_10798); { let prod_local_10800 = 0; { let prod_local_10801 = (prod_local_10799 == prod_local_10800); { let prod_local_10805 = match prod_local_10801 {
        false => { let prod_local_10803 = false; prod_local_10803 },
        true => { let prod_local_10804 = true; prod_local_10804 },
    }; match prod_local_10805 {
        false => { let prod_local_10807 = Some(prod_local_10794); { let prod_local_10808 = round64(prod_local_10807); match prod_local_10808 {
        None => { let prod_local_10809 = prod_local_10808; match prod_local_10809 {
        None => None,
        Some(prod_local_10811) => { let prod_local_10812 = prod_local_10811; { let prod_local_10813 = (prod_local_10812).value; { let prod_local_10814 = low64(prod_local_10813); match prod_local_10814 {
        None => prod_local_10814,
        Some(prod_local_10815) => { let prod_local_10816 = (prod_local_10812).guard; match prod_local_10816 {
        false => prod_local_10814,
        true => { let prod_local_10818 = (prod_local_10812).sticky; match prod_local_10818 {
        false => { let prod_local_10822 = 1; { let prod_local_10823 = (prod_local_10815 & prod_local_10822); { let prod_local_10824 = (prod_local_10823 == prod_local_10822); match prod_local_10824 {
        false => prod_local_10814,
        true => { let prod_local_10826 = 1; { let prod_local_10827 = (prod_local_10815).checked_add(prod_local_10826); prod_local_10827 } },
    } } } },
        true => { let prod_local_10829 = 1; { let prod_local_10830 = (prod_local_10815).checked_add(prod_local_10829); prod_local_10830 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_10831) => { let prod_local_10832 = prod_local_10831; { let prod_local_10836 = 128; { let prod_local_10837 = (val_2857 & prod_local_10836); { let prod_local_10838 = 0; { let prod_local_10839 = (prod_local_10837 == prod_local_10838); { let prod_local_10843 = match prod_local_10839 {
        false => { let prod_local_10841 = false; prod_local_10841 },
        true => { let prod_local_10842 = true; prod_local_10842 },
    }; match prod_local_10843 {
        false => { let prod_local_10845 = Some(prod_local_10832); { let prod_local_10846 = round128(prod_local_10845); match prod_local_10846 {
        None => { let prod_local_10847 = prod_local_10846; match prod_local_10847 {
        None => None,
        Some(prod_local_10849) => { let prod_local_10850 = prod_local_10849; { let prod_local_10851 = (prod_local_10850).value; { let prod_local_10852 = low64(prod_local_10851); match prod_local_10852 {
        None => prod_local_10852,
        Some(prod_local_10853) => { let prod_local_10854 = (prod_local_10850).guard; match prod_local_10854 {
        false => prod_local_10852,
        true => { let prod_local_10856 = (prod_local_10850).sticky; match prod_local_10856 {
        false => { let prod_local_10860 = 1; { let prod_local_10861 = (prod_local_10853 & prod_local_10860); { let prod_local_10862 = (prod_local_10861 == prod_local_10860); match prod_local_10862 {
        false => prod_local_10852,
        true => { let prod_local_10864 = 1; { let prod_local_10865 = (prod_local_10853).checked_add(prod_local_10864); prod_local_10865 } },
    } } } },
        true => { let prod_local_10867 = 1; { let prod_local_10868 = (prod_local_10853).checked_add(prod_local_10867); prod_local_10868 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_10869) => { let prod_local_10870 = prod_local_10869; { let prod_local_10871 = prod_local_10870; { let prod_local_10872 = (prod_local_10871).value; { let prod_local_10873 = low64(prod_local_10872); match prod_local_10873 {
        None => prod_local_10873,
        Some(prod_local_10874) => { let prod_local_10875 = (prod_local_10871).guard; match prod_local_10875 {
        false => prod_local_10873,
        true => { let prod_local_10877 = (prod_local_10871).sticky; match prod_local_10877 {
        false => { let prod_local_10881 = 1; { let prod_local_10882 = (prod_local_10874 & prod_local_10881); { let prod_local_10883 = (prod_local_10882 == prod_local_10881); match prod_local_10883 {
        false => prod_local_10873,
        true => { let prod_local_10885 = 1; { let prod_local_10886 = (prod_local_10874).checked_add(prod_local_10885); prod_local_10886 } },
    } } } },
        true => { let prod_local_10888 = 1; { let prod_local_10889 = (prod_local_10874).checked_add(prod_local_10888); prod_local_10889 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_10890 = prod_local_10832; { let prod_local_10891 = prod_local_10890; { let prod_local_10892 = (prod_local_10891).value; { let prod_local_10893 = low64(prod_local_10892); match prod_local_10893 {
        None => prod_local_10893,
        Some(prod_local_10894) => { let prod_local_10895 = (prod_local_10891).guard; match prod_local_10895 {
        false => prod_local_10893,
        true => { let prod_local_10897 = (prod_local_10891).sticky; match prod_local_10897 {
        false => { let prod_local_10901 = 1; { let prod_local_10902 = (prod_local_10894 & prod_local_10901); { let prod_local_10903 = (prod_local_10902 == prod_local_10901); match prod_local_10903 {
        false => prod_local_10893,
        true => { let prod_local_10905 = 1; { let prod_local_10906 = (prod_local_10894).checked_add(prod_local_10905); prod_local_10906 } },
    } } } },
        true => { let prod_local_10908 = 1; { let prod_local_10909 = (prod_local_10894).checked_add(prod_local_10908); prod_local_10909 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_10910 = prod_local_10794; { let prod_local_10914 = 128; { let prod_local_10915 = (val_2857 & prod_local_10914); { let prod_local_10916 = 0; { let prod_local_10917 = (prod_local_10915 == prod_local_10916); { let prod_local_10921 = match prod_local_10917 {
        false => { let prod_local_10919 = false; prod_local_10919 },
        true => { let prod_local_10920 = true; prod_local_10920 },
    }; match prod_local_10921 {
        false => { let prod_local_10923 = Some(prod_local_10910); { let prod_local_10924 = round128(prod_local_10923); match prod_local_10924 {
        None => { let prod_local_10925 = prod_local_10924; match prod_local_10925 {
        None => None,
        Some(prod_local_10927) => { let prod_local_10928 = prod_local_10927; { let prod_local_10929 = (prod_local_10928).value; { let prod_local_10930 = low64(prod_local_10929); match prod_local_10930 {
        None => prod_local_10930,
        Some(prod_local_10931) => { let prod_local_10932 = (prod_local_10928).guard; match prod_local_10932 {
        false => prod_local_10930,
        true => { let prod_local_10934 = (prod_local_10928).sticky; match prod_local_10934 {
        false => { let prod_local_10938 = 1; { let prod_local_10939 = (prod_local_10931 & prod_local_10938); { let prod_local_10940 = (prod_local_10939 == prod_local_10938); match prod_local_10940 {
        false => prod_local_10930,
        true => { let prod_local_10942 = 1; { let prod_local_10943 = (prod_local_10931).checked_add(prod_local_10942); prod_local_10943 } },
    } } } },
        true => { let prod_local_10945 = 1; { let prod_local_10946 = (prod_local_10931).checked_add(prod_local_10945); prod_local_10946 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_10947) => { let prod_local_10948 = prod_local_10947; { let prod_local_10949 = prod_local_10948; { let prod_local_10950 = (prod_local_10949).value; { let prod_local_10951 = low64(prod_local_10950); match prod_local_10951 {
        None => prod_local_10951,
        Some(prod_local_10952) => { let prod_local_10953 = (prod_local_10949).guard; match prod_local_10953 {
        false => prod_local_10951,
        true => { let prod_local_10955 = (prod_local_10949).sticky; match prod_local_10955 {
        false => { let prod_local_10959 = 1; { let prod_local_10960 = (prod_local_10952 & prod_local_10959); { let prod_local_10961 = (prod_local_10960 == prod_local_10959); match prod_local_10961 {
        false => prod_local_10951,
        true => { let prod_local_10963 = 1; { let prod_local_10964 = (prod_local_10952).checked_add(prod_local_10963); prod_local_10964 } },
    } } } },
        true => { let prod_local_10966 = 1; { let prod_local_10967 = (prod_local_10952).checked_add(prod_local_10966); prod_local_10967 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_10968 = prod_local_10910; { let prod_local_10969 = prod_local_10968; { let prod_local_10970 = (prod_local_10969).value; { let prod_local_10971 = low64(prod_local_10970); match prod_local_10971 {
        None => prod_local_10971,
        Some(prod_local_10972) => { let prod_local_10973 = (prod_local_10969).guard; match prod_local_10973 {
        false => prod_local_10971,
        true => { let prod_local_10975 = (prod_local_10969).sticky; match prod_local_10975 {
        false => { let prod_local_10979 = 1; { let prod_local_10980 = (prod_local_10972 & prod_local_10979); { let prod_local_10981 = (prod_local_10980 == prod_local_10979); match prod_local_10981 {
        false => prod_local_10971,
        true => { let prod_local_10983 = 1; { let prod_local_10984 = (prod_local_10972).checked_add(prod_local_10983); prod_local_10984 } },
    } } } },
        true => { let prod_local_10986 = 1; { let prod_local_10987 = (prod_local_10972).checked_add(prod_local_10986); prod_local_10987 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } } } } } },
    } } } } } } },
    } } } } } } },
    } } } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_10988 = prod_local_7276; { let prod_local_10992 = 4; { let prod_local_10993 = (val_2857 & prod_local_10992); { let prod_local_10994 = 0; { let prod_local_10995 = (prod_local_10993 == prod_local_10994); { let prod_local_10999 = match prod_local_10995 {
        false => { let prod_local_10997 = false; prod_local_10997 },
        true => { let prod_local_10998 = true; prod_local_10998 },
    }; match prod_local_10999 {
        false => { let prod_local_11001 = Some(prod_local_10988); { let prod_local_11002 = round4(prod_local_11001); match prod_local_11002 {
        None => { let prod_local_11003 = prod_local_11002; match prod_local_11003 {
        None => None,
        Some(prod_local_11005) => { let prod_local_11006 = prod_local_11005; { let prod_local_11007 = (prod_local_11006).value; { let prod_local_11008 = low64(prod_local_11007); match prod_local_11008 {
        None => prod_local_11008,
        Some(prod_local_11009) => { let prod_local_11010 = (prod_local_11006).guard; match prod_local_11010 {
        false => prod_local_11008,
        true => { let prod_local_11012 = (prod_local_11006).sticky; match prod_local_11012 {
        false => { let prod_local_11016 = 1; { let prod_local_11017 = (prod_local_11009 & prod_local_11016); { let prod_local_11018 = (prod_local_11017 == prod_local_11016); match prod_local_11018 {
        false => prod_local_11008,
        true => { let prod_local_11020 = 1; { let prod_local_11021 = (prod_local_11009).checked_add(prod_local_11020); prod_local_11021 } },
    } } } },
        true => { let prod_local_11023 = 1; { let prod_local_11024 = (prod_local_11009).checked_add(prod_local_11023); prod_local_11024 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_11025) => { let prod_local_11026 = prod_local_11025; { let prod_local_11030 = 8; { let prod_local_11031 = (val_2857 & prod_local_11030); { let prod_local_11032 = 0; { let prod_local_11033 = (prod_local_11031 == prod_local_11032); { let prod_local_11037 = match prod_local_11033 {
        false => { let prod_local_11035 = false; prod_local_11035 },
        true => { let prod_local_11036 = true; prod_local_11036 },
    }; match prod_local_11037 {
        false => { let prod_local_11039 = Some(prod_local_11026); { let prod_local_11040 = round8(prod_local_11039); match prod_local_11040 {
        None => { let prod_local_11041 = prod_local_11040; match prod_local_11041 {
        None => None,
        Some(prod_local_11043) => { let prod_local_11044 = prod_local_11043; { let prod_local_11045 = (prod_local_11044).value; { let prod_local_11046 = low64(prod_local_11045); match prod_local_11046 {
        None => prod_local_11046,
        Some(prod_local_11047) => { let prod_local_11048 = (prod_local_11044).guard; match prod_local_11048 {
        false => prod_local_11046,
        true => { let prod_local_11050 = (prod_local_11044).sticky; match prod_local_11050 {
        false => { let prod_local_11054 = 1; { let prod_local_11055 = (prod_local_11047 & prod_local_11054); { let prod_local_11056 = (prod_local_11055 == prod_local_11054); match prod_local_11056 {
        false => prod_local_11046,
        true => { let prod_local_11058 = 1; { let prod_local_11059 = (prod_local_11047).checked_add(prod_local_11058); prod_local_11059 } },
    } } } },
        true => { let prod_local_11061 = 1; { let prod_local_11062 = (prod_local_11047).checked_add(prod_local_11061); prod_local_11062 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_11063) => { let prod_local_11064 = prod_local_11063; { let prod_local_11068 = 16; { let prod_local_11069 = (val_2857 & prod_local_11068); { let prod_local_11070 = 0; { let prod_local_11071 = (prod_local_11069 == prod_local_11070); { let prod_local_11075 = match prod_local_11071 {
        false => { let prod_local_11073 = false; prod_local_11073 },
        true => { let prod_local_11074 = true; prod_local_11074 },
    }; match prod_local_11075 {
        false => { let prod_local_11077 = Some(prod_local_11064); { let prod_local_11078 = round16(prod_local_11077); match prod_local_11078 {
        None => { let prod_local_11079 = prod_local_11078; match prod_local_11079 {
        None => None,
        Some(prod_local_11081) => { let prod_local_11082 = prod_local_11081; { let prod_local_11083 = (prod_local_11082).value; { let prod_local_11084 = low64(prod_local_11083); match prod_local_11084 {
        None => prod_local_11084,
        Some(prod_local_11085) => { let prod_local_11086 = (prod_local_11082).guard; match prod_local_11086 {
        false => prod_local_11084,
        true => { let prod_local_11088 = (prod_local_11082).sticky; match prod_local_11088 {
        false => { let prod_local_11092 = 1; { let prod_local_11093 = (prod_local_11085 & prod_local_11092); { let prod_local_11094 = (prod_local_11093 == prod_local_11092); match prod_local_11094 {
        false => prod_local_11084,
        true => { let prod_local_11096 = 1; { let prod_local_11097 = (prod_local_11085).checked_add(prod_local_11096); prod_local_11097 } },
    } } } },
        true => { let prod_local_11099 = 1; { let prod_local_11100 = (prod_local_11085).checked_add(prod_local_11099); prod_local_11100 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_11101) => { let prod_local_11102 = prod_local_11101; { let prod_local_11106 = 32; { let prod_local_11107 = (val_2857 & prod_local_11106); { let prod_local_11108 = 0; { let prod_local_11109 = (prod_local_11107 == prod_local_11108); { let prod_local_11113 = match prod_local_11109 {
        false => { let prod_local_11111 = false; prod_local_11111 },
        true => { let prod_local_11112 = true; prod_local_11112 },
    }; match prod_local_11113 {
        false => { let prod_local_11115 = Some(prod_local_11102); { let prod_local_11116 = round32(prod_local_11115); match prod_local_11116 {
        None => { let prod_local_11117 = prod_local_11116; match prod_local_11117 {
        None => None,
        Some(prod_local_11119) => { let prod_local_11120 = prod_local_11119; { let prod_local_11121 = (prod_local_11120).value; { let prod_local_11122 = low64(prod_local_11121); match prod_local_11122 {
        None => prod_local_11122,
        Some(prod_local_11123) => { let prod_local_11124 = (prod_local_11120).guard; match prod_local_11124 {
        false => prod_local_11122,
        true => { let prod_local_11126 = (prod_local_11120).sticky; match prod_local_11126 {
        false => { let prod_local_11130 = 1; { let prod_local_11131 = (prod_local_11123 & prod_local_11130); { let prod_local_11132 = (prod_local_11131 == prod_local_11130); match prod_local_11132 {
        false => prod_local_11122,
        true => { let prod_local_11134 = 1; { let prod_local_11135 = (prod_local_11123).checked_add(prod_local_11134); prod_local_11135 } },
    } } } },
        true => { let prod_local_11137 = 1; { let prod_local_11138 = (prod_local_11123).checked_add(prod_local_11137); prod_local_11138 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_11139) => { let prod_local_11140 = prod_local_11139; { let prod_local_11144 = 64; { let prod_local_11145 = (val_2857 & prod_local_11144); { let prod_local_11146 = 0; { let prod_local_11147 = (prod_local_11145 == prod_local_11146); { let prod_local_11151 = match prod_local_11147 {
        false => { let prod_local_11149 = false; prod_local_11149 },
        true => { let prod_local_11150 = true; prod_local_11150 },
    }; match prod_local_11151 {
        false => { let prod_local_11153 = Some(prod_local_11140); { let prod_local_11154 = round64(prod_local_11153); match prod_local_11154 {
        None => { let prod_local_11155 = prod_local_11154; match prod_local_11155 {
        None => None,
        Some(prod_local_11157) => { let prod_local_11158 = prod_local_11157; { let prod_local_11159 = (prod_local_11158).value; { let prod_local_11160 = low64(prod_local_11159); match prod_local_11160 {
        None => prod_local_11160,
        Some(prod_local_11161) => { let prod_local_11162 = (prod_local_11158).guard; match prod_local_11162 {
        false => prod_local_11160,
        true => { let prod_local_11164 = (prod_local_11158).sticky; match prod_local_11164 {
        false => { let prod_local_11168 = 1; { let prod_local_11169 = (prod_local_11161 & prod_local_11168); { let prod_local_11170 = (prod_local_11169 == prod_local_11168); match prod_local_11170 {
        false => prod_local_11160,
        true => { let prod_local_11172 = 1; { let prod_local_11173 = (prod_local_11161).checked_add(prod_local_11172); prod_local_11173 } },
    } } } },
        true => { let prod_local_11175 = 1; { let prod_local_11176 = (prod_local_11161).checked_add(prod_local_11175); prod_local_11176 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_11177) => { let prod_local_11178 = prod_local_11177; { let prod_local_11182 = 128; { let prod_local_11183 = (val_2857 & prod_local_11182); { let prod_local_11184 = 0; { let prod_local_11185 = (prod_local_11183 == prod_local_11184); { let prod_local_11189 = match prod_local_11185 {
        false => { let prod_local_11187 = false; prod_local_11187 },
        true => { let prod_local_11188 = true; prod_local_11188 },
    }; match prod_local_11189 {
        false => { let prod_local_11191 = Some(prod_local_11178); { let prod_local_11192 = round128(prod_local_11191); match prod_local_11192 {
        None => { let prod_local_11193 = prod_local_11192; match prod_local_11193 {
        None => None,
        Some(prod_local_11195) => { let prod_local_11196 = prod_local_11195; { let prod_local_11197 = (prod_local_11196).value; { let prod_local_11198 = low64(prod_local_11197); match prod_local_11198 {
        None => prod_local_11198,
        Some(prod_local_11199) => { let prod_local_11200 = (prod_local_11196).guard; match prod_local_11200 {
        false => prod_local_11198,
        true => { let prod_local_11202 = (prod_local_11196).sticky; match prod_local_11202 {
        false => { let prod_local_11206 = 1; { let prod_local_11207 = (prod_local_11199 & prod_local_11206); { let prod_local_11208 = (prod_local_11207 == prod_local_11206); match prod_local_11208 {
        false => prod_local_11198,
        true => { let prod_local_11210 = 1; { let prod_local_11211 = (prod_local_11199).checked_add(prod_local_11210); prod_local_11211 } },
    } } } },
        true => { let prod_local_11213 = 1; { let prod_local_11214 = (prod_local_11199).checked_add(prod_local_11213); prod_local_11214 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_11215) => { let prod_local_11216 = prod_local_11215; { let prod_local_11217 = prod_local_11216; { let prod_local_11218 = (prod_local_11217).value; { let prod_local_11219 = low64(prod_local_11218); match prod_local_11219 {
        None => prod_local_11219,
        Some(prod_local_11220) => { let prod_local_11221 = (prod_local_11217).guard; match prod_local_11221 {
        false => prod_local_11219,
        true => { let prod_local_11223 = (prod_local_11217).sticky; match prod_local_11223 {
        false => { let prod_local_11227 = 1; { let prod_local_11228 = (prod_local_11220 & prod_local_11227); { let prod_local_11229 = (prod_local_11228 == prod_local_11227); match prod_local_11229 {
        false => prod_local_11219,
        true => { let prod_local_11231 = 1; { let prod_local_11232 = (prod_local_11220).checked_add(prod_local_11231); prod_local_11232 } },
    } } } },
        true => { let prod_local_11234 = 1; { let prod_local_11235 = (prod_local_11220).checked_add(prod_local_11234); prod_local_11235 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_11236 = prod_local_11178; { let prod_local_11237 = prod_local_11236; { let prod_local_11238 = (prod_local_11237).value; { let prod_local_11239 = low64(prod_local_11238); match prod_local_11239 {
        None => prod_local_11239,
        Some(prod_local_11240) => { let prod_local_11241 = (prod_local_11237).guard; match prod_local_11241 {
        false => prod_local_11239,
        true => { let prod_local_11243 = (prod_local_11237).sticky; match prod_local_11243 {
        false => { let prod_local_11247 = 1; { let prod_local_11248 = (prod_local_11240 & prod_local_11247); { let prod_local_11249 = (prod_local_11248 == prod_local_11247); match prod_local_11249 {
        false => prod_local_11239,
        true => { let prod_local_11251 = 1; { let prod_local_11252 = (prod_local_11240).checked_add(prod_local_11251); prod_local_11252 } },
    } } } },
        true => { let prod_local_11254 = 1; { let prod_local_11255 = (prod_local_11240).checked_add(prod_local_11254); prod_local_11255 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_11256 = prod_local_11140; { let prod_local_11260 = 128; { let prod_local_11261 = (val_2857 & prod_local_11260); { let prod_local_11262 = 0; { let prod_local_11263 = (prod_local_11261 == prod_local_11262); { let prod_local_11267 = match prod_local_11263 {
        false => { let prod_local_11265 = false; prod_local_11265 },
        true => { let prod_local_11266 = true; prod_local_11266 },
    }; match prod_local_11267 {
        false => { let prod_local_11269 = Some(prod_local_11256); { let prod_local_11270 = round128(prod_local_11269); match prod_local_11270 {
        None => { let prod_local_11271 = prod_local_11270; match prod_local_11271 {
        None => None,
        Some(prod_local_11273) => { let prod_local_11274 = prod_local_11273; { let prod_local_11275 = (prod_local_11274).value; { let prod_local_11276 = low64(prod_local_11275); match prod_local_11276 {
        None => prod_local_11276,
        Some(prod_local_11277) => { let prod_local_11278 = (prod_local_11274).guard; match prod_local_11278 {
        false => prod_local_11276,
        true => { let prod_local_11280 = (prod_local_11274).sticky; match prod_local_11280 {
        false => { let prod_local_11284 = 1; { let prod_local_11285 = (prod_local_11277 & prod_local_11284); { let prod_local_11286 = (prod_local_11285 == prod_local_11284); match prod_local_11286 {
        false => prod_local_11276,
        true => { let prod_local_11288 = 1; { let prod_local_11289 = (prod_local_11277).checked_add(prod_local_11288); prod_local_11289 } },
    } } } },
        true => { let prod_local_11291 = 1; { let prod_local_11292 = (prod_local_11277).checked_add(prod_local_11291); prod_local_11292 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_11293) => { let prod_local_11294 = prod_local_11293; { let prod_local_11295 = prod_local_11294; { let prod_local_11296 = (prod_local_11295).value; { let prod_local_11297 = low64(prod_local_11296); match prod_local_11297 {
        None => prod_local_11297,
        Some(prod_local_11298) => { let prod_local_11299 = (prod_local_11295).guard; match prod_local_11299 {
        false => prod_local_11297,
        true => { let prod_local_11301 = (prod_local_11295).sticky; match prod_local_11301 {
        false => { let prod_local_11305 = 1; { let prod_local_11306 = (prod_local_11298 & prod_local_11305); { let prod_local_11307 = (prod_local_11306 == prod_local_11305); match prod_local_11307 {
        false => prod_local_11297,
        true => { let prod_local_11309 = 1; { let prod_local_11310 = (prod_local_11298).checked_add(prod_local_11309); prod_local_11310 } },
    } } } },
        true => { let prod_local_11312 = 1; { let prod_local_11313 = (prod_local_11298).checked_add(prod_local_11312); prod_local_11313 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_11314 = prod_local_11256; { let prod_local_11315 = prod_local_11314; { let prod_local_11316 = (prod_local_11315).value; { let prod_local_11317 = low64(prod_local_11316); match prod_local_11317 {
        None => prod_local_11317,
        Some(prod_local_11318) => { let prod_local_11319 = (prod_local_11315).guard; match prod_local_11319 {
        false => prod_local_11317,
        true => { let prod_local_11321 = (prod_local_11315).sticky; match prod_local_11321 {
        false => { let prod_local_11325 = 1; { let prod_local_11326 = (prod_local_11318 & prod_local_11325); { let prod_local_11327 = (prod_local_11326 == prod_local_11325); match prod_local_11327 {
        false => prod_local_11317,
        true => { let prod_local_11329 = 1; { let prod_local_11330 = (prod_local_11318).checked_add(prod_local_11329); prod_local_11330 } },
    } } } },
        true => { let prod_local_11332 = 1; { let prod_local_11333 = (prod_local_11318).checked_add(prod_local_11332); prod_local_11333 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_11334 = prod_local_11102; { let prod_local_11338 = 64; { let prod_local_11339 = (val_2857 & prod_local_11338); { let prod_local_11340 = 0; { let prod_local_11341 = (prod_local_11339 == prod_local_11340); { let prod_local_11345 = match prod_local_11341 {
        false => { let prod_local_11343 = false; prod_local_11343 },
        true => { let prod_local_11344 = true; prod_local_11344 },
    }; match prod_local_11345 {
        false => { let prod_local_11347 = Some(prod_local_11334); { let prod_local_11348 = round64(prod_local_11347); match prod_local_11348 {
        None => { let prod_local_11349 = prod_local_11348; match prod_local_11349 {
        None => None,
        Some(prod_local_11351) => { let prod_local_11352 = prod_local_11351; { let prod_local_11353 = (prod_local_11352).value; { let prod_local_11354 = low64(prod_local_11353); match prod_local_11354 {
        None => prod_local_11354,
        Some(prod_local_11355) => { let prod_local_11356 = (prod_local_11352).guard; match prod_local_11356 {
        false => prod_local_11354,
        true => { let prod_local_11358 = (prod_local_11352).sticky; match prod_local_11358 {
        false => { let prod_local_11362 = 1; { let prod_local_11363 = (prod_local_11355 & prod_local_11362); { let prod_local_11364 = (prod_local_11363 == prod_local_11362); match prod_local_11364 {
        false => prod_local_11354,
        true => { let prod_local_11366 = 1; { let prod_local_11367 = (prod_local_11355).checked_add(prod_local_11366); prod_local_11367 } },
    } } } },
        true => { let prod_local_11369 = 1; { let prod_local_11370 = (prod_local_11355).checked_add(prod_local_11369); prod_local_11370 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_11371) => { let prod_local_11372 = prod_local_11371; { let prod_local_11376 = 128; { let prod_local_11377 = (val_2857 & prod_local_11376); { let prod_local_11378 = 0; { let prod_local_11379 = (prod_local_11377 == prod_local_11378); { let prod_local_11383 = match prod_local_11379 {
        false => { let prod_local_11381 = false; prod_local_11381 },
        true => { let prod_local_11382 = true; prod_local_11382 },
    }; match prod_local_11383 {
        false => { let prod_local_11385 = Some(prod_local_11372); { let prod_local_11386 = round128(prod_local_11385); match prod_local_11386 {
        None => { let prod_local_11387 = prod_local_11386; match prod_local_11387 {
        None => None,
        Some(prod_local_11389) => { let prod_local_11390 = prod_local_11389; { let prod_local_11391 = (prod_local_11390).value; { let prod_local_11392 = low64(prod_local_11391); match prod_local_11392 {
        None => prod_local_11392,
        Some(prod_local_11393) => { let prod_local_11394 = (prod_local_11390).guard; match prod_local_11394 {
        false => prod_local_11392,
        true => { let prod_local_11396 = (prod_local_11390).sticky; match prod_local_11396 {
        false => { let prod_local_11400 = 1; { let prod_local_11401 = (prod_local_11393 & prod_local_11400); { let prod_local_11402 = (prod_local_11401 == prod_local_11400); match prod_local_11402 {
        false => prod_local_11392,
        true => { let prod_local_11404 = 1; { let prod_local_11405 = (prod_local_11393).checked_add(prod_local_11404); prod_local_11405 } },
    } } } },
        true => { let prod_local_11407 = 1; { let prod_local_11408 = (prod_local_11393).checked_add(prod_local_11407); prod_local_11408 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_11409) => { let prod_local_11410 = prod_local_11409; { let prod_local_11411 = prod_local_11410; { let prod_local_11412 = (prod_local_11411).value; { let prod_local_11413 = low64(prod_local_11412); match prod_local_11413 {
        None => prod_local_11413,
        Some(prod_local_11414) => { let prod_local_11415 = (prod_local_11411).guard; match prod_local_11415 {
        false => prod_local_11413,
        true => { let prod_local_11417 = (prod_local_11411).sticky; match prod_local_11417 {
        false => { let prod_local_11421 = 1; { let prod_local_11422 = (prod_local_11414 & prod_local_11421); { let prod_local_11423 = (prod_local_11422 == prod_local_11421); match prod_local_11423 {
        false => prod_local_11413,
        true => { let prod_local_11425 = 1; { let prod_local_11426 = (prod_local_11414).checked_add(prod_local_11425); prod_local_11426 } },
    } } } },
        true => { let prod_local_11428 = 1; { let prod_local_11429 = (prod_local_11414).checked_add(prod_local_11428); prod_local_11429 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_11430 = prod_local_11372; { let prod_local_11431 = prod_local_11430; { let prod_local_11432 = (prod_local_11431).value; { let prod_local_11433 = low64(prod_local_11432); match prod_local_11433 {
        None => prod_local_11433,
        Some(prod_local_11434) => { let prod_local_11435 = (prod_local_11431).guard; match prod_local_11435 {
        false => prod_local_11433,
        true => { let prod_local_11437 = (prod_local_11431).sticky; match prod_local_11437 {
        false => { let prod_local_11441 = 1; { let prod_local_11442 = (prod_local_11434 & prod_local_11441); { let prod_local_11443 = (prod_local_11442 == prod_local_11441); match prod_local_11443 {
        false => prod_local_11433,
        true => { let prod_local_11445 = 1; { let prod_local_11446 = (prod_local_11434).checked_add(prod_local_11445); prod_local_11446 } },
    } } } },
        true => { let prod_local_11448 = 1; { let prod_local_11449 = (prod_local_11434).checked_add(prod_local_11448); prod_local_11449 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_11450 = prod_local_11334; { let prod_local_11454 = 128; { let prod_local_11455 = (val_2857 & prod_local_11454); { let prod_local_11456 = 0; { let prod_local_11457 = (prod_local_11455 == prod_local_11456); { let prod_local_11461 = match prod_local_11457 {
        false => { let prod_local_11459 = false; prod_local_11459 },
        true => { let prod_local_11460 = true; prod_local_11460 },
    }; match prod_local_11461 {
        false => { let prod_local_11463 = Some(prod_local_11450); { let prod_local_11464 = round128(prod_local_11463); match prod_local_11464 {
        None => { let prod_local_11465 = prod_local_11464; match prod_local_11465 {
        None => None,
        Some(prod_local_11467) => { let prod_local_11468 = prod_local_11467; { let prod_local_11469 = (prod_local_11468).value; { let prod_local_11470 = low64(prod_local_11469); match prod_local_11470 {
        None => prod_local_11470,
        Some(prod_local_11471) => { let prod_local_11472 = (prod_local_11468).guard; match prod_local_11472 {
        false => prod_local_11470,
        true => { let prod_local_11474 = (prod_local_11468).sticky; match prod_local_11474 {
        false => { let prod_local_11478 = 1; { let prod_local_11479 = (prod_local_11471 & prod_local_11478); { let prod_local_11480 = (prod_local_11479 == prod_local_11478); match prod_local_11480 {
        false => prod_local_11470,
        true => { let prod_local_11482 = 1; { let prod_local_11483 = (prod_local_11471).checked_add(prod_local_11482); prod_local_11483 } },
    } } } },
        true => { let prod_local_11485 = 1; { let prod_local_11486 = (prod_local_11471).checked_add(prod_local_11485); prod_local_11486 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_11487) => { let prod_local_11488 = prod_local_11487; { let prod_local_11489 = prod_local_11488; { let prod_local_11490 = (prod_local_11489).value; { let prod_local_11491 = low64(prod_local_11490); match prod_local_11491 {
        None => prod_local_11491,
        Some(prod_local_11492) => { let prod_local_11493 = (prod_local_11489).guard; match prod_local_11493 {
        false => prod_local_11491,
        true => { let prod_local_11495 = (prod_local_11489).sticky; match prod_local_11495 {
        false => { let prod_local_11499 = 1; { let prod_local_11500 = (prod_local_11492 & prod_local_11499); { let prod_local_11501 = (prod_local_11500 == prod_local_11499); match prod_local_11501 {
        false => prod_local_11491,
        true => { let prod_local_11503 = 1; { let prod_local_11504 = (prod_local_11492).checked_add(prod_local_11503); prod_local_11504 } },
    } } } },
        true => { let prod_local_11506 = 1; { let prod_local_11507 = (prod_local_11492).checked_add(prod_local_11506); prod_local_11507 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_11508 = prod_local_11450; { let prod_local_11509 = prod_local_11508; { let prod_local_11510 = (prod_local_11509).value; { let prod_local_11511 = low64(prod_local_11510); match prod_local_11511 {
        None => prod_local_11511,
        Some(prod_local_11512) => { let prod_local_11513 = (prod_local_11509).guard; match prod_local_11513 {
        false => prod_local_11511,
        true => { let prod_local_11515 = (prod_local_11509).sticky; match prod_local_11515 {
        false => { let prod_local_11519 = 1; { let prod_local_11520 = (prod_local_11512 & prod_local_11519); { let prod_local_11521 = (prod_local_11520 == prod_local_11519); match prod_local_11521 {
        false => prod_local_11511,
        true => { let prod_local_11523 = 1; { let prod_local_11524 = (prod_local_11512).checked_add(prod_local_11523); prod_local_11524 } },
    } } } },
        true => { let prod_local_11526 = 1; { let prod_local_11527 = (prod_local_11512).checked_add(prod_local_11526); prod_local_11527 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_11528 = prod_local_11064; { let prod_local_11532 = 32; { let prod_local_11533 = (val_2857 & prod_local_11532); { let prod_local_11534 = 0; { let prod_local_11535 = (prod_local_11533 == prod_local_11534); { let prod_local_11539 = match prod_local_11535 {
        false => { let prod_local_11537 = false; prod_local_11537 },
        true => { let prod_local_11538 = true; prod_local_11538 },
    }; match prod_local_11539 {
        false => { let prod_local_11541 = Some(prod_local_11528); { let prod_local_11542 = round32(prod_local_11541); match prod_local_11542 {
        None => { let prod_local_11543 = prod_local_11542; match prod_local_11543 {
        None => None,
        Some(prod_local_11545) => { let prod_local_11546 = prod_local_11545; { let prod_local_11547 = (prod_local_11546).value; { let prod_local_11548 = low64(prod_local_11547); match prod_local_11548 {
        None => prod_local_11548,
        Some(prod_local_11549) => { let prod_local_11550 = (prod_local_11546).guard; match prod_local_11550 {
        false => prod_local_11548,
        true => { let prod_local_11552 = (prod_local_11546).sticky; match prod_local_11552 {
        false => { let prod_local_11556 = 1; { let prod_local_11557 = (prod_local_11549 & prod_local_11556); { let prod_local_11558 = (prod_local_11557 == prod_local_11556); match prod_local_11558 {
        false => prod_local_11548,
        true => { let prod_local_11560 = 1; { let prod_local_11561 = (prod_local_11549).checked_add(prod_local_11560); prod_local_11561 } },
    } } } },
        true => { let prod_local_11563 = 1; { let prod_local_11564 = (prod_local_11549).checked_add(prod_local_11563); prod_local_11564 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_11565) => { let prod_local_11566 = prod_local_11565; { let prod_local_11570 = 64; { let prod_local_11571 = (val_2857 & prod_local_11570); { let prod_local_11572 = 0; { let prod_local_11573 = (prod_local_11571 == prod_local_11572); { let prod_local_11577 = match prod_local_11573 {
        false => { let prod_local_11575 = false; prod_local_11575 },
        true => { let prod_local_11576 = true; prod_local_11576 },
    }; match prod_local_11577 {
        false => { let prod_local_11579 = Some(prod_local_11566); { let prod_local_11580 = round64(prod_local_11579); match prod_local_11580 {
        None => { let prod_local_11581 = prod_local_11580; match prod_local_11581 {
        None => None,
        Some(prod_local_11583) => { let prod_local_11584 = prod_local_11583; { let prod_local_11585 = (prod_local_11584).value; { let prod_local_11586 = low64(prod_local_11585); match prod_local_11586 {
        None => prod_local_11586,
        Some(prod_local_11587) => { let prod_local_11588 = (prod_local_11584).guard; match prod_local_11588 {
        false => prod_local_11586,
        true => { let prod_local_11590 = (prod_local_11584).sticky; match prod_local_11590 {
        false => { let prod_local_11594 = 1; { let prod_local_11595 = (prod_local_11587 & prod_local_11594); { let prod_local_11596 = (prod_local_11595 == prod_local_11594); match prod_local_11596 {
        false => prod_local_11586,
        true => { let prod_local_11598 = 1; { let prod_local_11599 = (prod_local_11587).checked_add(prod_local_11598); prod_local_11599 } },
    } } } },
        true => { let prod_local_11601 = 1; { let prod_local_11602 = (prod_local_11587).checked_add(prod_local_11601); prod_local_11602 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_11603) => { let prod_local_11604 = prod_local_11603; { let prod_local_11608 = 128; { let prod_local_11609 = (val_2857 & prod_local_11608); { let prod_local_11610 = 0; { let prod_local_11611 = (prod_local_11609 == prod_local_11610); { let prod_local_11615 = match prod_local_11611 {
        false => { let prod_local_11613 = false; prod_local_11613 },
        true => { let prod_local_11614 = true; prod_local_11614 },
    }; match prod_local_11615 {
        false => { let prod_local_11617 = Some(prod_local_11604); { let prod_local_11618 = round128(prod_local_11617); match prod_local_11618 {
        None => { let prod_local_11619 = prod_local_11618; match prod_local_11619 {
        None => None,
        Some(prod_local_11621) => { let prod_local_11622 = prod_local_11621; { let prod_local_11623 = (prod_local_11622).value; { let prod_local_11624 = low64(prod_local_11623); match prod_local_11624 {
        None => prod_local_11624,
        Some(prod_local_11625) => { let prod_local_11626 = (prod_local_11622).guard; match prod_local_11626 {
        false => prod_local_11624,
        true => { let prod_local_11628 = (prod_local_11622).sticky; match prod_local_11628 {
        false => { let prod_local_11632 = 1; { let prod_local_11633 = (prod_local_11625 & prod_local_11632); { let prod_local_11634 = (prod_local_11633 == prod_local_11632); match prod_local_11634 {
        false => prod_local_11624,
        true => { let prod_local_11636 = 1; { let prod_local_11637 = (prod_local_11625).checked_add(prod_local_11636); prod_local_11637 } },
    } } } },
        true => { let prod_local_11639 = 1; { let prod_local_11640 = (prod_local_11625).checked_add(prod_local_11639); prod_local_11640 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_11641) => { let prod_local_11642 = prod_local_11641; { let prod_local_11643 = prod_local_11642; { let prod_local_11644 = (prod_local_11643).value; { let prod_local_11645 = low64(prod_local_11644); match prod_local_11645 {
        None => prod_local_11645,
        Some(prod_local_11646) => { let prod_local_11647 = (prod_local_11643).guard; match prod_local_11647 {
        false => prod_local_11645,
        true => { let prod_local_11649 = (prod_local_11643).sticky; match prod_local_11649 {
        false => { let prod_local_11653 = 1; { let prod_local_11654 = (prod_local_11646 & prod_local_11653); { let prod_local_11655 = (prod_local_11654 == prod_local_11653); match prod_local_11655 {
        false => prod_local_11645,
        true => { let prod_local_11657 = 1; { let prod_local_11658 = (prod_local_11646).checked_add(prod_local_11657); prod_local_11658 } },
    } } } },
        true => { let prod_local_11660 = 1; { let prod_local_11661 = (prod_local_11646).checked_add(prod_local_11660); prod_local_11661 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_11662 = prod_local_11604; { let prod_local_11663 = prod_local_11662; { let prod_local_11664 = (prod_local_11663).value; { let prod_local_11665 = low64(prod_local_11664); match prod_local_11665 {
        None => prod_local_11665,
        Some(prod_local_11666) => { let prod_local_11667 = (prod_local_11663).guard; match prod_local_11667 {
        false => prod_local_11665,
        true => { let prod_local_11669 = (prod_local_11663).sticky; match prod_local_11669 {
        false => { let prod_local_11673 = 1; { let prod_local_11674 = (prod_local_11666 & prod_local_11673); { let prod_local_11675 = (prod_local_11674 == prod_local_11673); match prod_local_11675 {
        false => prod_local_11665,
        true => { let prod_local_11677 = 1; { let prod_local_11678 = (prod_local_11666).checked_add(prod_local_11677); prod_local_11678 } },
    } } } },
        true => { let prod_local_11680 = 1; { let prod_local_11681 = (prod_local_11666).checked_add(prod_local_11680); prod_local_11681 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_11682 = prod_local_11566; { let prod_local_11686 = 128; { let prod_local_11687 = (val_2857 & prod_local_11686); { let prod_local_11688 = 0; { let prod_local_11689 = (prod_local_11687 == prod_local_11688); { let prod_local_11693 = match prod_local_11689 {
        false => { let prod_local_11691 = false; prod_local_11691 },
        true => { let prod_local_11692 = true; prod_local_11692 },
    }; match prod_local_11693 {
        false => { let prod_local_11695 = Some(prod_local_11682); { let prod_local_11696 = round128(prod_local_11695); match prod_local_11696 {
        None => { let prod_local_11697 = prod_local_11696; match prod_local_11697 {
        None => None,
        Some(prod_local_11699) => { let prod_local_11700 = prod_local_11699; { let prod_local_11701 = (prod_local_11700).value; { let prod_local_11702 = low64(prod_local_11701); match prod_local_11702 {
        None => prod_local_11702,
        Some(prod_local_11703) => { let prod_local_11704 = (prod_local_11700).guard; match prod_local_11704 {
        false => prod_local_11702,
        true => { let prod_local_11706 = (prod_local_11700).sticky; match prod_local_11706 {
        false => { let prod_local_11710 = 1; { let prod_local_11711 = (prod_local_11703 & prod_local_11710); { let prod_local_11712 = (prod_local_11711 == prod_local_11710); match prod_local_11712 {
        false => prod_local_11702,
        true => { let prod_local_11714 = 1; { let prod_local_11715 = (prod_local_11703).checked_add(prod_local_11714); prod_local_11715 } },
    } } } },
        true => { let prod_local_11717 = 1; { let prod_local_11718 = (prod_local_11703).checked_add(prod_local_11717); prod_local_11718 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_11719) => { let prod_local_11720 = prod_local_11719; { let prod_local_11721 = prod_local_11720; { let prod_local_11722 = (prod_local_11721).value; { let prod_local_11723 = low64(prod_local_11722); match prod_local_11723 {
        None => prod_local_11723,
        Some(prod_local_11724) => { let prod_local_11725 = (prod_local_11721).guard; match prod_local_11725 {
        false => prod_local_11723,
        true => { let prod_local_11727 = (prod_local_11721).sticky; match prod_local_11727 {
        false => { let prod_local_11731 = 1; { let prod_local_11732 = (prod_local_11724 & prod_local_11731); { let prod_local_11733 = (prod_local_11732 == prod_local_11731); match prod_local_11733 {
        false => prod_local_11723,
        true => { let prod_local_11735 = 1; { let prod_local_11736 = (prod_local_11724).checked_add(prod_local_11735); prod_local_11736 } },
    } } } },
        true => { let prod_local_11738 = 1; { let prod_local_11739 = (prod_local_11724).checked_add(prod_local_11738); prod_local_11739 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_11740 = prod_local_11682; { let prod_local_11741 = prod_local_11740; { let prod_local_11742 = (prod_local_11741).value; { let prod_local_11743 = low64(prod_local_11742); match prod_local_11743 {
        None => prod_local_11743,
        Some(prod_local_11744) => { let prod_local_11745 = (prod_local_11741).guard; match prod_local_11745 {
        false => prod_local_11743,
        true => { let prod_local_11747 = (prod_local_11741).sticky; match prod_local_11747 {
        false => { let prod_local_11751 = 1; { let prod_local_11752 = (prod_local_11744 & prod_local_11751); { let prod_local_11753 = (prod_local_11752 == prod_local_11751); match prod_local_11753 {
        false => prod_local_11743,
        true => { let prod_local_11755 = 1; { let prod_local_11756 = (prod_local_11744).checked_add(prod_local_11755); prod_local_11756 } },
    } } } },
        true => { let prod_local_11758 = 1; { let prod_local_11759 = (prod_local_11744).checked_add(prod_local_11758); prod_local_11759 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_11760 = prod_local_11528; { let prod_local_11764 = 64; { let prod_local_11765 = (val_2857 & prod_local_11764); { let prod_local_11766 = 0; { let prod_local_11767 = (prod_local_11765 == prod_local_11766); { let prod_local_11771 = match prod_local_11767 {
        false => { let prod_local_11769 = false; prod_local_11769 },
        true => { let prod_local_11770 = true; prod_local_11770 },
    }; match prod_local_11771 {
        false => { let prod_local_11773 = Some(prod_local_11760); { let prod_local_11774 = round64(prod_local_11773); match prod_local_11774 {
        None => { let prod_local_11775 = prod_local_11774; match prod_local_11775 {
        None => None,
        Some(prod_local_11777) => { let prod_local_11778 = prod_local_11777; { let prod_local_11779 = (prod_local_11778).value; { let prod_local_11780 = low64(prod_local_11779); match prod_local_11780 {
        None => prod_local_11780,
        Some(prod_local_11781) => { let prod_local_11782 = (prod_local_11778).guard; match prod_local_11782 {
        false => prod_local_11780,
        true => { let prod_local_11784 = (prod_local_11778).sticky; match prod_local_11784 {
        false => { let prod_local_11788 = 1; { let prod_local_11789 = (prod_local_11781 & prod_local_11788); { let prod_local_11790 = (prod_local_11789 == prod_local_11788); match prod_local_11790 {
        false => prod_local_11780,
        true => { let prod_local_11792 = 1; { let prod_local_11793 = (prod_local_11781).checked_add(prod_local_11792); prod_local_11793 } },
    } } } },
        true => { let prod_local_11795 = 1; { let prod_local_11796 = (prod_local_11781).checked_add(prod_local_11795); prod_local_11796 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_11797) => { let prod_local_11798 = prod_local_11797; { let prod_local_11802 = 128; { let prod_local_11803 = (val_2857 & prod_local_11802); { let prod_local_11804 = 0; { let prod_local_11805 = (prod_local_11803 == prod_local_11804); { let prod_local_11809 = match prod_local_11805 {
        false => { let prod_local_11807 = false; prod_local_11807 },
        true => { let prod_local_11808 = true; prod_local_11808 },
    }; match prod_local_11809 {
        false => { let prod_local_11811 = Some(prod_local_11798); { let prod_local_11812 = round128(prod_local_11811); match prod_local_11812 {
        None => { let prod_local_11813 = prod_local_11812; match prod_local_11813 {
        None => None,
        Some(prod_local_11815) => { let prod_local_11816 = prod_local_11815; { let prod_local_11817 = (prod_local_11816).value; { let prod_local_11818 = low64(prod_local_11817); match prod_local_11818 {
        None => prod_local_11818,
        Some(prod_local_11819) => { let prod_local_11820 = (prod_local_11816).guard; match prod_local_11820 {
        false => prod_local_11818,
        true => { let prod_local_11822 = (prod_local_11816).sticky; match prod_local_11822 {
        false => { let prod_local_11826 = 1; { let prod_local_11827 = (prod_local_11819 & prod_local_11826); { let prod_local_11828 = (prod_local_11827 == prod_local_11826); match prod_local_11828 {
        false => prod_local_11818,
        true => { let prod_local_11830 = 1; { let prod_local_11831 = (prod_local_11819).checked_add(prod_local_11830); prod_local_11831 } },
    } } } },
        true => { let prod_local_11833 = 1; { let prod_local_11834 = (prod_local_11819).checked_add(prod_local_11833); prod_local_11834 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_11835) => { let prod_local_11836 = prod_local_11835; { let prod_local_11837 = prod_local_11836; { let prod_local_11838 = (prod_local_11837).value; { let prod_local_11839 = low64(prod_local_11838); match prod_local_11839 {
        None => prod_local_11839,
        Some(prod_local_11840) => { let prod_local_11841 = (prod_local_11837).guard; match prod_local_11841 {
        false => prod_local_11839,
        true => { let prod_local_11843 = (prod_local_11837).sticky; match prod_local_11843 {
        false => { let prod_local_11847 = 1; { let prod_local_11848 = (prod_local_11840 & prod_local_11847); { let prod_local_11849 = (prod_local_11848 == prod_local_11847); match prod_local_11849 {
        false => prod_local_11839,
        true => { let prod_local_11851 = 1; { let prod_local_11852 = (prod_local_11840).checked_add(prod_local_11851); prod_local_11852 } },
    } } } },
        true => { let prod_local_11854 = 1; { let prod_local_11855 = (prod_local_11840).checked_add(prod_local_11854); prod_local_11855 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_11856 = prod_local_11798; { let prod_local_11857 = prod_local_11856; { let prod_local_11858 = (prod_local_11857).value; { let prod_local_11859 = low64(prod_local_11858); match prod_local_11859 {
        None => prod_local_11859,
        Some(prod_local_11860) => { let prod_local_11861 = (prod_local_11857).guard; match prod_local_11861 {
        false => prod_local_11859,
        true => { let prod_local_11863 = (prod_local_11857).sticky; match prod_local_11863 {
        false => { let prod_local_11867 = 1; { let prod_local_11868 = (prod_local_11860 & prod_local_11867); { let prod_local_11869 = (prod_local_11868 == prod_local_11867); match prod_local_11869 {
        false => prod_local_11859,
        true => { let prod_local_11871 = 1; { let prod_local_11872 = (prod_local_11860).checked_add(prod_local_11871); prod_local_11872 } },
    } } } },
        true => { let prod_local_11874 = 1; { let prod_local_11875 = (prod_local_11860).checked_add(prod_local_11874); prod_local_11875 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_11876 = prod_local_11760; { let prod_local_11880 = 128; { let prod_local_11881 = (val_2857 & prod_local_11880); { let prod_local_11882 = 0; { let prod_local_11883 = (prod_local_11881 == prod_local_11882); { let prod_local_11887 = match prod_local_11883 {
        false => { let prod_local_11885 = false; prod_local_11885 },
        true => { let prod_local_11886 = true; prod_local_11886 },
    }; match prod_local_11887 {
        false => { let prod_local_11889 = Some(prod_local_11876); { let prod_local_11890 = round128(prod_local_11889); match prod_local_11890 {
        None => { let prod_local_11891 = prod_local_11890; match prod_local_11891 {
        None => None,
        Some(prod_local_11893) => { let prod_local_11894 = prod_local_11893; { let prod_local_11895 = (prod_local_11894).value; { let prod_local_11896 = low64(prod_local_11895); match prod_local_11896 {
        None => prod_local_11896,
        Some(prod_local_11897) => { let prod_local_11898 = (prod_local_11894).guard; match prod_local_11898 {
        false => prod_local_11896,
        true => { let prod_local_11900 = (prod_local_11894).sticky; match prod_local_11900 {
        false => { let prod_local_11904 = 1; { let prod_local_11905 = (prod_local_11897 & prod_local_11904); { let prod_local_11906 = (prod_local_11905 == prod_local_11904); match prod_local_11906 {
        false => prod_local_11896,
        true => { let prod_local_11908 = 1; { let prod_local_11909 = (prod_local_11897).checked_add(prod_local_11908); prod_local_11909 } },
    } } } },
        true => { let prod_local_11911 = 1; { let prod_local_11912 = (prod_local_11897).checked_add(prod_local_11911); prod_local_11912 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_11913) => { let prod_local_11914 = prod_local_11913; { let prod_local_11915 = prod_local_11914; { let prod_local_11916 = (prod_local_11915).value; { let prod_local_11917 = low64(prod_local_11916); match prod_local_11917 {
        None => prod_local_11917,
        Some(prod_local_11918) => { let prod_local_11919 = (prod_local_11915).guard; match prod_local_11919 {
        false => prod_local_11917,
        true => { let prod_local_11921 = (prod_local_11915).sticky; match prod_local_11921 {
        false => { let prod_local_11925 = 1; { let prod_local_11926 = (prod_local_11918 & prod_local_11925); { let prod_local_11927 = (prod_local_11926 == prod_local_11925); match prod_local_11927 {
        false => prod_local_11917,
        true => { let prod_local_11929 = 1; { let prod_local_11930 = (prod_local_11918).checked_add(prod_local_11929); prod_local_11930 } },
    } } } },
        true => { let prod_local_11932 = 1; { let prod_local_11933 = (prod_local_11918).checked_add(prod_local_11932); prod_local_11933 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_11934 = prod_local_11876; { let prod_local_11935 = prod_local_11934; { let prod_local_11936 = (prod_local_11935).value; { let prod_local_11937 = low64(prod_local_11936); match prod_local_11937 {
        None => prod_local_11937,
        Some(prod_local_11938) => { let prod_local_11939 = (prod_local_11935).guard; match prod_local_11939 {
        false => prod_local_11937,
        true => { let prod_local_11941 = (prod_local_11935).sticky; match prod_local_11941 {
        false => { let prod_local_11945 = 1; { let prod_local_11946 = (prod_local_11938 & prod_local_11945); { let prod_local_11947 = (prod_local_11946 == prod_local_11945); match prod_local_11947 {
        false => prod_local_11937,
        true => { let prod_local_11949 = 1; { let prod_local_11950 = (prod_local_11938).checked_add(prod_local_11949); prod_local_11950 } },
    } } } },
        true => { let prod_local_11952 = 1; { let prod_local_11953 = (prod_local_11938).checked_add(prod_local_11952); prod_local_11953 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } } } } } },
    } } } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_11954 = prod_local_11026; { let prod_local_11958 = 16; { let prod_local_11959 = (val_2857 & prod_local_11958); { let prod_local_11960 = 0; { let prod_local_11961 = (prod_local_11959 == prod_local_11960); { let prod_local_11965 = match prod_local_11961 {
        false => { let prod_local_11963 = false; prod_local_11963 },
        true => { let prod_local_11964 = true; prod_local_11964 },
    }; match prod_local_11965 {
        false => { let prod_local_11967 = Some(prod_local_11954); { let prod_local_11968 = round16(prod_local_11967); match prod_local_11968 {
        None => { let prod_local_11969 = prod_local_11968; match prod_local_11969 {
        None => None,
        Some(prod_local_11971) => { let prod_local_11972 = prod_local_11971; { let prod_local_11973 = (prod_local_11972).value; { let prod_local_11974 = low64(prod_local_11973); match prod_local_11974 {
        None => prod_local_11974,
        Some(prod_local_11975) => { let prod_local_11976 = (prod_local_11972).guard; match prod_local_11976 {
        false => prod_local_11974,
        true => { let prod_local_11978 = (prod_local_11972).sticky; match prod_local_11978 {
        false => { let prod_local_11982 = 1; { let prod_local_11983 = (prod_local_11975 & prod_local_11982); { let prod_local_11984 = (prod_local_11983 == prod_local_11982); match prod_local_11984 {
        false => prod_local_11974,
        true => { let prod_local_11986 = 1; { let prod_local_11987 = (prod_local_11975).checked_add(prod_local_11986); prod_local_11987 } },
    } } } },
        true => { let prod_local_11989 = 1; { let prod_local_11990 = (prod_local_11975).checked_add(prod_local_11989); prod_local_11990 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_11991) => { let prod_local_11992 = prod_local_11991; { let prod_local_11996 = 32; { let prod_local_11997 = (val_2857 & prod_local_11996); { let prod_local_11998 = 0; { let prod_local_11999 = (prod_local_11997 == prod_local_11998); { let prod_local_12003 = match prod_local_11999 {
        false => { let prod_local_12001 = false; prod_local_12001 },
        true => { let prod_local_12002 = true; prod_local_12002 },
    }; match prod_local_12003 {
        false => { let prod_local_12005 = Some(prod_local_11992); { let prod_local_12006 = round32(prod_local_12005); match prod_local_12006 {
        None => { let prod_local_12007 = prod_local_12006; match prod_local_12007 {
        None => None,
        Some(prod_local_12009) => { let prod_local_12010 = prod_local_12009; { let prod_local_12011 = (prod_local_12010).value; { let prod_local_12012 = low64(prod_local_12011); match prod_local_12012 {
        None => prod_local_12012,
        Some(prod_local_12013) => { let prod_local_12014 = (prod_local_12010).guard; match prod_local_12014 {
        false => prod_local_12012,
        true => { let prod_local_12016 = (prod_local_12010).sticky; match prod_local_12016 {
        false => { let prod_local_12020 = 1; { let prod_local_12021 = (prod_local_12013 & prod_local_12020); { let prod_local_12022 = (prod_local_12021 == prod_local_12020); match prod_local_12022 {
        false => prod_local_12012,
        true => { let prod_local_12024 = 1; { let prod_local_12025 = (prod_local_12013).checked_add(prod_local_12024); prod_local_12025 } },
    } } } },
        true => { let prod_local_12027 = 1; { let prod_local_12028 = (prod_local_12013).checked_add(prod_local_12027); prod_local_12028 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_12029) => { let prod_local_12030 = prod_local_12029; { let prod_local_12034 = 64; { let prod_local_12035 = (val_2857 & prod_local_12034); { let prod_local_12036 = 0; { let prod_local_12037 = (prod_local_12035 == prod_local_12036); { let prod_local_12041 = match prod_local_12037 {
        false => { let prod_local_12039 = false; prod_local_12039 },
        true => { let prod_local_12040 = true; prod_local_12040 },
    }; match prod_local_12041 {
        false => { let prod_local_12043 = Some(prod_local_12030); { let prod_local_12044 = round64(prod_local_12043); match prod_local_12044 {
        None => { let prod_local_12045 = prod_local_12044; match prod_local_12045 {
        None => None,
        Some(prod_local_12047) => { let prod_local_12048 = prod_local_12047; { let prod_local_12049 = (prod_local_12048).value; { let prod_local_12050 = low64(prod_local_12049); match prod_local_12050 {
        None => prod_local_12050,
        Some(prod_local_12051) => { let prod_local_12052 = (prod_local_12048).guard; match prod_local_12052 {
        false => prod_local_12050,
        true => { let prod_local_12054 = (prod_local_12048).sticky; match prod_local_12054 {
        false => { let prod_local_12058 = 1; { let prod_local_12059 = (prod_local_12051 & prod_local_12058); { let prod_local_12060 = (prod_local_12059 == prod_local_12058); match prod_local_12060 {
        false => prod_local_12050,
        true => { let prod_local_12062 = 1; { let prod_local_12063 = (prod_local_12051).checked_add(prod_local_12062); prod_local_12063 } },
    } } } },
        true => { let prod_local_12065 = 1; { let prod_local_12066 = (prod_local_12051).checked_add(prod_local_12065); prod_local_12066 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_12067) => { let prod_local_12068 = prod_local_12067; { let prod_local_12072 = 128; { let prod_local_12073 = (val_2857 & prod_local_12072); { let prod_local_12074 = 0; { let prod_local_12075 = (prod_local_12073 == prod_local_12074); { let prod_local_12079 = match prod_local_12075 {
        false => { let prod_local_12077 = false; prod_local_12077 },
        true => { let prod_local_12078 = true; prod_local_12078 },
    }; match prod_local_12079 {
        false => { let prod_local_12081 = Some(prod_local_12068); { let prod_local_12082 = round128(prod_local_12081); match prod_local_12082 {
        None => { let prod_local_12083 = prod_local_12082; match prod_local_12083 {
        None => None,
        Some(prod_local_12085) => { let prod_local_12086 = prod_local_12085; { let prod_local_12087 = (prod_local_12086).value; { let prod_local_12088 = low64(prod_local_12087); match prod_local_12088 {
        None => prod_local_12088,
        Some(prod_local_12089) => { let prod_local_12090 = (prod_local_12086).guard; match prod_local_12090 {
        false => prod_local_12088,
        true => { let prod_local_12092 = (prod_local_12086).sticky; match prod_local_12092 {
        false => { let prod_local_12096 = 1; { let prod_local_12097 = (prod_local_12089 & prod_local_12096); { let prod_local_12098 = (prod_local_12097 == prod_local_12096); match prod_local_12098 {
        false => prod_local_12088,
        true => { let prod_local_12100 = 1; { let prod_local_12101 = (prod_local_12089).checked_add(prod_local_12100); prod_local_12101 } },
    } } } },
        true => { let prod_local_12103 = 1; { let prod_local_12104 = (prod_local_12089).checked_add(prod_local_12103); prod_local_12104 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_12105) => { let prod_local_12106 = prod_local_12105; { let prod_local_12107 = prod_local_12106; { let prod_local_12108 = (prod_local_12107).value; { let prod_local_12109 = low64(prod_local_12108); match prod_local_12109 {
        None => prod_local_12109,
        Some(prod_local_12110) => { let prod_local_12111 = (prod_local_12107).guard; match prod_local_12111 {
        false => prod_local_12109,
        true => { let prod_local_12113 = (prod_local_12107).sticky; match prod_local_12113 {
        false => { let prod_local_12117 = 1; { let prod_local_12118 = (prod_local_12110 & prod_local_12117); { let prod_local_12119 = (prod_local_12118 == prod_local_12117); match prod_local_12119 {
        false => prod_local_12109,
        true => { let prod_local_12121 = 1; { let prod_local_12122 = (prod_local_12110).checked_add(prod_local_12121); prod_local_12122 } },
    } } } },
        true => { let prod_local_12124 = 1; { let prod_local_12125 = (prod_local_12110).checked_add(prod_local_12124); prod_local_12125 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_12126 = prod_local_12068; { let prod_local_12127 = prod_local_12126; { let prod_local_12128 = (prod_local_12127).value; { let prod_local_12129 = low64(prod_local_12128); match prod_local_12129 {
        None => prod_local_12129,
        Some(prod_local_12130) => { let prod_local_12131 = (prod_local_12127).guard; match prod_local_12131 {
        false => prod_local_12129,
        true => { let prod_local_12133 = (prod_local_12127).sticky; match prod_local_12133 {
        false => { let prod_local_12137 = 1; { let prod_local_12138 = (prod_local_12130 & prod_local_12137); { let prod_local_12139 = (prod_local_12138 == prod_local_12137); match prod_local_12139 {
        false => prod_local_12129,
        true => { let prod_local_12141 = 1; { let prod_local_12142 = (prod_local_12130).checked_add(prod_local_12141); prod_local_12142 } },
    } } } },
        true => { let prod_local_12144 = 1; { let prod_local_12145 = (prod_local_12130).checked_add(prod_local_12144); prod_local_12145 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_12146 = prod_local_12030; { let prod_local_12150 = 128; { let prod_local_12151 = (val_2857 & prod_local_12150); { let prod_local_12152 = 0; { let prod_local_12153 = (prod_local_12151 == prod_local_12152); { let prod_local_12157 = match prod_local_12153 {
        false => { let prod_local_12155 = false; prod_local_12155 },
        true => { let prod_local_12156 = true; prod_local_12156 },
    }; match prod_local_12157 {
        false => { let prod_local_12159 = Some(prod_local_12146); { let prod_local_12160 = round128(prod_local_12159); match prod_local_12160 {
        None => { let prod_local_12161 = prod_local_12160; match prod_local_12161 {
        None => None,
        Some(prod_local_12163) => { let prod_local_12164 = prod_local_12163; { let prod_local_12165 = (prod_local_12164).value; { let prod_local_12166 = low64(prod_local_12165); match prod_local_12166 {
        None => prod_local_12166,
        Some(prod_local_12167) => { let prod_local_12168 = (prod_local_12164).guard; match prod_local_12168 {
        false => prod_local_12166,
        true => { let prod_local_12170 = (prod_local_12164).sticky; match prod_local_12170 {
        false => { let prod_local_12174 = 1; { let prod_local_12175 = (prod_local_12167 & prod_local_12174); { let prod_local_12176 = (prod_local_12175 == prod_local_12174); match prod_local_12176 {
        false => prod_local_12166,
        true => { let prod_local_12178 = 1; { let prod_local_12179 = (prod_local_12167).checked_add(prod_local_12178); prod_local_12179 } },
    } } } },
        true => { let prod_local_12181 = 1; { let prod_local_12182 = (prod_local_12167).checked_add(prod_local_12181); prod_local_12182 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_12183) => { let prod_local_12184 = prod_local_12183; { let prod_local_12185 = prod_local_12184; { let prod_local_12186 = (prod_local_12185).value; { let prod_local_12187 = low64(prod_local_12186); match prod_local_12187 {
        None => prod_local_12187,
        Some(prod_local_12188) => { let prod_local_12189 = (prod_local_12185).guard; match prod_local_12189 {
        false => prod_local_12187,
        true => { let prod_local_12191 = (prod_local_12185).sticky; match prod_local_12191 {
        false => { let prod_local_12195 = 1; { let prod_local_12196 = (prod_local_12188 & prod_local_12195); { let prod_local_12197 = (prod_local_12196 == prod_local_12195); match prod_local_12197 {
        false => prod_local_12187,
        true => { let prod_local_12199 = 1; { let prod_local_12200 = (prod_local_12188).checked_add(prod_local_12199); prod_local_12200 } },
    } } } },
        true => { let prod_local_12202 = 1; { let prod_local_12203 = (prod_local_12188).checked_add(prod_local_12202); prod_local_12203 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_12204 = prod_local_12146; { let prod_local_12205 = prod_local_12204; { let prod_local_12206 = (prod_local_12205).value; { let prod_local_12207 = low64(prod_local_12206); match prod_local_12207 {
        None => prod_local_12207,
        Some(prod_local_12208) => { let prod_local_12209 = (prod_local_12205).guard; match prod_local_12209 {
        false => prod_local_12207,
        true => { let prod_local_12211 = (prod_local_12205).sticky; match prod_local_12211 {
        false => { let prod_local_12215 = 1; { let prod_local_12216 = (prod_local_12208 & prod_local_12215); { let prod_local_12217 = (prod_local_12216 == prod_local_12215); match prod_local_12217 {
        false => prod_local_12207,
        true => { let prod_local_12219 = 1; { let prod_local_12220 = (prod_local_12208).checked_add(prod_local_12219); prod_local_12220 } },
    } } } },
        true => { let prod_local_12222 = 1; { let prod_local_12223 = (prod_local_12208).checked_add(prod_local_12222); prod_local_12223 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_12224 = prod_local_11992; { let prod_local_12228 = 64; { let prod_local_12229 = (val_2857 & prod_local_12228); { let prod_local_12230 = 0; { let prod_local_12231 = (prod_local_12229 == prod_local_12230); { let prod_local_12235 = match prod_local_12231 {
        false => { let prod_local_12233 = false; prod_local_12233 },
        true => { let prod_local_12234 = true; prod_local_12234 },
    }; match prod_local_12235 {
        false => { let prod_local_12237 = Some(prod_local_12224); { let prod_local_12238 = round64(prod_local_12237); match prod_local_12238 {
        None => { let prod_local_12239 = prod_local_12238; match prod_local_12239 {
        None => None,
        Some(prod_local_12241) => { let prod_local_12242 = prod_local_12241; { let prod_local_12243 = (prod_local_12242).value; { let prod_local_12244 = low64(prod_local_12243); match prod_local_12244 {
        None => prod_local_12244,
        Some(prod_local_12245) => { let prod_local_12246 = (prod_local_12242).guard; match prod_local_12246 {
        false => prod_local_12244,
        true => { let prod_local_12248 = (prod_local_12242).sticky; match prod_local_12248 {
        false => { let prod_local_12252 = 1; { let prod_local_12253 = (prod_local_12245 & prod_local_12252); { let prod_local_12254 = (prod_local_12253 == prod_local_12252); match prod_local_12254 {
        false => prod_local_12244,
        true => { let prod_local_12256 = 1; { let prod_local_12257 = (prod_local_12245).checked_add(prod_local_12256); prod_local_12257 } },
    } } } },
        true => { let prod_local_12259 = 1; { let prod_local_12260 = (prod_local_12245).checked_add(prod_local_12259); prod_local_12260 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_12261) => { let prod_local_12262 = prod_local_12261; { let prod_local_12266 = 128; { let prod_local_12267 = (val_2857 & prod_local_12266); { let prod_local_12268 = 0; { let prod_local_12269 = (prod_local_12267 == prod_local_12268); { let prod_local_12273 = match prod_local_12269 {
        false => { let prod_local_12271 = false; prod_local_12271 },
        true => { let prod_local_12272 = true; prod_local_12272 },
    }; match prod_local_12273 {
        false => { let prod_local_12275 = Some(prod_local_12262); { let prod_local_12276 = round128(prod_local_12275); match prod_local_12276 {
        None => { let prod_local_12277 = prod_local_12276; match prod_local_12277 {
        None => None,
        Some(prod_local_12279) => { let prod_local_12280 = prod_local_12279; { let prod_local_12281 = (prod_local_12280).value; { let prod_local_12282 = low64(prod_local_12281); match prod_local_12282 {
        None => prod_local_12282,
        Some(prod_local_12283) => { let prod_local_12284 = (prod_local_12280).guard; match prod_local_12284 {
        false => prod_local_12282,
        true => { let prod_local_12286 = (prod_local_12280).sticky; match prod_local_12286 {
        false => { let prod_local_12290 = 1; { let prod_local_12291 = (prod_local_12283 & prod_local_12290); { let prod_local_12292 = (prod_local_12291 == prod_local_12290); match prod_local_12292 {
        false => prod_local_12282,
        true => { let prod_local_12294 = 1; { let prod_local_12295 = (prod_local_12283).checked_add(prod_local_12294); prod_local_12295 } },
    } } } },
        true => { let prod_local_12297 = 1; { let prod_local_12298 = (prod_local_12283).checked_add(prod_local_12297); prod_local_12298 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_12299) => { let prod_local_12300 = prod_local_12299; { let prod_local_12301 = prod_local_12300; { let prod_local_12302 = (prod_local_12301).value; { let prod_local_12303 = low64(prod_local_12302); match prod_local_12303 {
        None => prod_local_12303,
        Some(prod_local_12304) => { let prod_local_12305 = (prod_local_12301).guard; match prod_local_12305 {
        false => prod_local_12303,
        true => { let prod_local_12307 = (prod_local_12301).sticky; match prod_local_12307 {
        false => { let prod_local_12311 = 1; { let prod_local_12312 = (prod_local_12304 & prod_local_12311); { let prod_local_12313 = (prod_local_12312 == prod_local_12311); match prod_local_12313 {
        false => prod_local_12303,
        true => { let prod_local_12315 = 1; { let prod_local_12316 = (prod_local_12304).checked_add(prod_local_12315); prod_local_12316 } },
    } } } },
        true => { let prod_local_12318 = 1; { let prod_local_12319 = (prod_local_12304).checked_add(prod_local_12318); prod_local_12319 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_12320 = prod_local_12262; { let prod_local_12321 = prod_local_12320; { let prod_local_12322 = (prod_local_12321).value; { let prod_local_12323 = low64(prod_local_12322); match prod_local_12323 {
        None => prod_local_12323,
        Some(prod_local_12324) => { let prod_local_12325 = (prod_local_12321).guard; match prod_local_12325 {
        false => prod_local_12323,
        true => { let prod_local_12327 = (prod_local_12321).sticky; match prod_local_12327 {
        false => { let prod_local_12331 = 1; { let prod_local_12332 = (prod_local_12324 & prod_local_12331); { let prod_local_12333 = (prod_local_12332 == prod_local_12331); match prod_local_12333 {
        false => prod_local_12323,
        true => { let prod_local_12335 = 1; { let prod_local_12336 = (prod_local_12324).checked_add(prod_local_12335); prod_local_12336 } },
    } } } },
        true => { let prod_local_12338 = 1; { let prod_local_12339 = (prod_local_12324).checked_add(prod_local_12338); prod_local_12339 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_12340 = prod_local_12224; { let prod_local_12344 = 128; { let prod_local_12345 = (val_2857 & prod_local_12344); { let prod_local_12346 = 0; { let prod_local_12347 = (prod_local_12345 == prod_local_12346); { let prod_local_12351 = match prod_local_12347 {
        false => { let prod_local_12349 = false; prod_local_12349 },
        true => { let prod_local_12350 = true; prod_local_12350 },
    }; match prod_local_12351 {
        false => { let prod_local_12353 = Some(prod_local_12340); { let prod_local_12354 = round128(prod_local_12353); match prod_local_12354 {
        None => { let prod_local_12355 = prod_local_12354; match prod_local_12355 {
        None => None,
        Some(prod_local_12357) => { let prod_local_12358 = prod_local_12357; { let prod_local_12359 = (prod_local_12358).value; { let prod_local_12360 = low64(prod_local_12359); match prod_local_12360 {
        None => prod_local_12360,
        Some(prod_local_12361) => { let prod_local_12362 = (prod_local_12358).guard; match prod_local_12362 {
        false => prod_local_12360,
        true => { let prod_local_12364 = (prod_local_12358).sticky; match prod_local_12364 {
        false => { let prod_local_12368 = 1; { let prod_local_12369 = (prod_local_12361 & prod_local_12368); { let prod_local_12370 = (prod_local_12369 == prod_local_12368); match prod_local_12370 {
        false => prod_local_12360,
        true => { let prod_local_12372 = 1; { let prod_local_12373 = (prod_local_12361).checked_add(prod_local_12372); prod_local_12373 } },
    } } } },
        true => { let prod_local_12375 = 1; { let prod_local_12376 = (prod_local_12361).checked_add(prod_local_12375); prod_local_12376 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_12377) => { let prod_local_12378 = prod_local_12377; { let prod_local_12379 = prod_local_12378; { let prod_local_12380 = (prod_local_12379).value; { let prod_local_12381 = low64(prod_local_12380); match prod_local_12381 {
        None => prod_local_12381,
        Some(prod_local_12382) => { let prod_local_12383 = (prod_local_12379).guard; match prod_local_12383 {
        false => prod_local_12381,
        true => { let prod_local_12385 = (prod_local_12379).sticky; match prod_local_12385 {
        false => { let prod_local_12389 = 1; { let prod_local_12390 = (prod_local_12382 & prod_local_12389); { let prod_local_12391 = (prod_local_12390 == prod_local_12389); match prod_local_12391 {
        false => prod_local_12381,
        true => { let prod_local_12393 = 1; { let prod_local_12394 = (prod_local_12382).checked_add(prod_local_12393); prod_local_12394 } },
    } } } },
        true => { let prod_local_12396 = 1; { let prod_local_12397 = (prod_local_12382).checked_add(prod_local_12396); prod_local_12397 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_12398 = prod_local_12340; { let prod_local_12399 = prod_local_12398; { let prod_local_12400 = (prod_local_12399).value; { let prod_local_12401 = low64(prod_local_12400); match prod_local_12401 {
        None => prod_local_12401,
        Some(prod_local_12402) => { let prod_local_12403 = (prod_local_12399).guard; match prod_local_12403 {
        false => prod_local_12401,
        true => { let prod_local_12405 = (prod_local_12399).sticky; match prod_local_12405 {
        false => { let prod_local_12409 = 1; { let prod_local_12410 = (prod_local_12402 & prod_local_12409); { let prod_local_12411 = (prod_local_12410 == prod_local_12409); match prod_local_12411 {
        false => prod_local_12401,
        true => { let prod_local_12413 = 1; { let prod_local_12414 = (prod_local_12402).checked_add(prod_local_12413); prod_local_12414 } },
    } } } },
        true => { let prod_local_12416 = 1; { let prod_local_12417 = (prod_local_12402).checked_add(prod_local_12416); prod_local_12417 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_12418 = prod_local_11954; { let prod_local_12422 = 32; { let prod_local_12423 = (val_2857 & prod_local_12422); { let prod_local_12424 = 0; { let prod_local_12425 = (prod_local_12423 == prod_local_12424); { let prod_local_12429 = match prod_local_12425 {
        false => { let prod_local_12427 = false; prod_local_12427 },
        true => { let prod_local_12428 = true; prod_local_12428 },
    }; match prod_local_12429 {
        false => { let prod_local_12431 = Some(prod_local_12418); { let prod_local_12432 = round32(prod_local_12431); match prod_local_12432 {
        None => { let prod_local_12433 = prod_local_12432; match prod_local_12433 {
        None => None,
        Some(prod_local_12435) => { let prod_local_12436 = prod_local_12435; { let prod_local_12437 = (prod_local_12436).value; { let prod_local_12438 = low64(prod_local_12437); match prod_local_12438 {
        None => prod_local_12438,
        Some(prod_local_12439) => { let prod_local_12440 = (prod_local_12436).guard; match prod_local_12440 {
        false => prod_local_12438,
        true => { let prod_local_12442 = (prod_local_12436).sticky; match prod_local_12442 {
        false => { let prod_local_12446 = 1; { let prod_local_12447 = (prod_local_12439 & prod_local_12446); { let prod_local_12448 = (prod_local_12447 == prod_local_12446); match prod_local_12448 {
        false => prod_local_12438,
        true => { let prod_local_12450 = 1; { let prod_local_12451 = (prod_local_12439).checked_add(prod_local_12450); prod_local_12451 } },
    } } } },
        true => { let prod_local_12453 = 1; { let prod_local_12454 = (prod_local_12439).checked_add(prod_local_12453); prod_local_12454 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_12455) => { let prod_local_12456 = prod_local_12455; { let prod_local_12460 = 64; { let prod_local_12461 = (val_2857 & prod_local_12460); { let prod_local_12462 = 0; { let prod_local_12463 = (prod_local_12461 == prod_local_12462); { let prod_local_12467 = match prod_local_12463 {
        false => { let prod_local_12465 = false; prod_local_12465 },
        true => { let prod_local_12466 = true; prod_local_12466 },
    }; match prod_local_12467 {
        false => { let prod_local_12469 = Some(prod_local_12456); { let prod_local_12470 = round64(prod_local_12469); match prod_local_12470 {
        None => { let prod_local_12471 = prod_local_12470; match prod_local_12471 {
        None => None,
        Some(prod_local_12473) => { let prod_local_12474 = prod_local_12473; { let prod_local_12475 = (prod_local_12474).value; { let prod_local_12476 = low64(prod_local_12475); match prod_local_12476 {
        None => prod_local_12476,
        Some(prod_local_12477) => { let prod_local_12478 = (prod_local_12474).guard; match prod_local_12478 {
        false => prod_local_12476,
        true => { let prod_local_12480 = (prod_local_12474).sticky; match prod_local_12480 {
        false => { let prod_local_12484 = 1; { let prod_local_12485 = (prod_local_12477 & prod_local_12484); { let prod_local_12486 = (prod_local_12485 == prod_local_12484); match prod_local_12486 {
        false => prod_local_12476,
        true => { let prod_local_12488 = 1; { let prod_local_12489 = (prod_local_12477).checked_add(prod_local_12488); prod_local_12489 } },
    } } } },
        true => { let prod_local_12491 = 1; { let prod_local_12492 = (prod_local_12477).checked_add(prod_local_12491); prod_local_12492 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_12493) => { let prod_local_12494 = prod_local_12493; { let prod_local_12498 = 128; { let prod_local_12499 = (val_2857 & prod_local_12498); { let prod_local_12500 = 0; { let prod_local_12501 = (prod_local_12499 == prod_local_12500); { let prod_local_12505 = match prod_local_12501 {
        false => { let prod_local_12503 = false; prod_local_12503 },
        true => { let prod_local_12504 = true; prod_local_12504 },
    }; match prod_local_12505 {
        false => { let prod_local_12507 = Some(prod_local_12494); { let prod_local_12508 = round128(prod_local_12507); match prod_local_12508 {
        None => { let prod_local_12509 = prod_local_12508; match prod_local_12509 {
        None => None,
        Some(prod_local_12511) => { let prod_local_12512 = prod_local_12511; { let prod_local_12513 = (prod_local_12512).value; { let prod_local_12514 = low64(prod_local_12513); match prod_local_12514 {
        None => prod_local_12514,
        Some(prod_local_12515) => { let prod_local_12516 = (prod_local_12512).guard; match prod_local_12516 {
        false => prod_local_12514,
        true => { let prod_local_12518 = (prod_local_12512).sticky; match prod_local_12518 {
        false => { let prod_local_12522 = 1; { let prod_local_12523 = (prod_local_12515 & prod_local_12522); { let prod_local_12524 = (prod_local_12523 == prod_local_12522); match prod_local_12524 {
        false => prod_local_12514,
        true => { let prod_local_12526 = 1; { let prod_local_12527 = (prod_local_12515).checked_add(prod_local_12526); prod_local_12527 } },
    } } } },
        true => { let prod_local_12529 = 1; { let prod_local_12530 = (prod_local_12515).checked_add(prod_local_12529); prod_local_12530 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_12531) => { let prod_local_12532 = prod_local_12531; { let prod_local_12533 = prod_local_12532; { let prod_local_12534 = (prod_local_12533).value; { let prod_local_12535 = low64(prod_local_12534); match prod_local_12535 {
        None => prod_local_12535,
        Some(prod_local_12536) => { let prod_local_12537 = (prod_local_12533).guard; match prod_local_12537 {
        false => prod_local_12535,
        true => { let prod_local_12539 = (prod_local_12533).sticky; match prod_local_12539 {
        false => { let prod_local_12543 = 1; { let prod_local_12544 = (prod_local_12536 & prod_local_12543); { let prod_local_12545 = (prod_local_12544 == prod_local_12543); match prod_local_12545 {
        false => prod_local_12535,
        true => { let prod_local_12547 = 1; { let prod_local_12548 = (prod_local_12536).checked_add(prod_local_12547); prod_local_12548 } },
    } } } },
        true => { let prod_local_12550 = 1; { let prod_local_12551 = (prod_local_12536).checked_add(prod_local_12550); prod_local_12551 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_12552 = prod_local_12494; { let prod_local_12553 = prod_local_12552; { let prod_local_12554 = (prod_local_12553).value; { let prod_local_12555 = low64(prod_local_12554); match prod_local_12555 {
        None => prod_local_12555,
        Some(prod_local_12556) => { let prod_local_12557 = (prod_local_12553).guard; match prod_local_12557 {
        false => prod_local_12555,
        true => { let prod_local_12559 = (prod_local_12553).sticky; match prod_local_12559 {
        false => { let prod_local_12563 = 1; { let prod_local_12564 = (prod_local_12556 & prod_local_12563); { let prod_local_12565 = (prod_local_12564 == prod_local_12563); match prod_local_12565 {
        false => prod_local_12555,
        true => { let prod_local_12567 = 1; { let prod_local_12568 = (prod_local_12556).checked_add(prod_local_12567); prod_local_12568 } },
    } } } },
        true => { let prod_local_12570 = 1; { let prod_local_12571 = (prod_local_12556).checked_add(prod_local_12570); prod_local_12571 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_12572 = prod_local_12456; { let prod_local_12576 = 128; { let prod_local_12577 = (val_2857 & prod_local_12576); { let prod_local_12578 = 0; { let prod_local_12579 = (prod_local_12577 == prod_local_12578); { let prod_local_12583 = match prod_local_12579 {
        false => { let prod_local_12581 = false; prod_local_12581 },
        true => { let prod_local_12582 = true; prod_local_12582 },
    }; match prod_local_12583 {
        false => { let prod_local_12585 = Some(prod_local_12572); { let prod_local_12586 = round128(prod_local_12585); match prod_local_12586 {
        None => { let prod_local_12587 = prod_local_12586; match prod_local_12587 {
        None => None,
        Some(prod_local_12589) => { let prod_local_12590 = prod_local_12589; { let prod_local_12591 = (prod_local_12590).value; { let prod_local_12592 = low64(prod_local_12591); match prod_local_12592 {
        None => prod_local_12592,
        Some(prod_local_12593) => { let prod_local_12594 = (prod_local_12590).guard; match prod_local_12594 {
        false => prod_local_12592,
        true => { let prod_local_12596 = (prod_local_12590).sticky; match prod_local_12596 {
        false => { let prod_local_12600 = 1; { let prod_local_12601 = (prod_local_12593 & prod_local_12600); { let prod_local_12602 = (prod_local_12601 == prod_local_12600); match prod_local_12602 {
        false => prod_local_12592,
        true => { let prod_local_12604 = 1; { let prod_local_12605 = (prod_local_12593).checked_add(prod_local_12604); prod_local_12605 } },
    } } } },
        true => { let prod_local_12607 = 1; { let prod_local_12608 = (prod_local_12593).checked_add(prod_local_12607); prod_local_12608 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_12609) => { let prod_local_12610 = prod_local_12609; { let prod_local_12611 = prod_local_12610; { let prod_local_12612 = (prod_local_12611).value; { let prod_local_12613 = low64(prod_local_12612); match prod_local_12613 {
        None => prod_local_12613,
        Some(prod_local_12614) => { let prod_local_12615 = (prod_local_12611).guard; match prod_local_12615 {
        false => prod_local_12613,
        true => { let prod_local_12617 = (prod_local_12611).sticky; match prod_local_12617 {
        false => { let prod_local_12621 = 1; { let prod_local_12622 = (prod_local_12614 & prod_local_12621); { let prod_local_12623 = (prod_local_12622 == prod_local_12621); match prod_local_12623 {
        false => prod_local_12613,
        true => { let prod_local_12625 = 1; { let prod_local_12626 = (prod_local_12614).checked_add(prod_local_12625); prod_local_12626 } },
    } } } },
        true => { let prod_local_12628 = 1; { let prod_local_12629 = (prod_local_12614).checked_add(prod_local_12628); prod_local_12629 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_12630 = prod_local_12572; { let prod_local_12631 = prod_local_12630; { let prod_local_12632 = (prod_local_12631).value; { let prod_local_12633 = low64(prod_local_12632); match prod_local_12633 {
        None => prod_local_12633,
        Some(prod_local_12634) => { let prod_local_12635 = (prod_local_12631).guard; match prod_local_12635 {
        false => prod_local_12633,
        true => { let prod_local_12637 = (prod_local_12631).sticky; match prod_local_12637 {
        false => { let prod_local_12641 = 1; { let prod_local_12642 = (prod_local_12634 & prod_local_12641); { let prod_local_12643 = (prod_local_12642 == prod_local_12641); match prod_local_12643 {
        false => prod_local_12633,
        true => { let prod_local_12645 = 1; { let prod_local_12646 = (prod_local_12634).checked_add(prod_local_12645); prod_local_12646 } },
    } } } },
        true => { let prod_local_12648 = 1; { let prod_local_12649 = (prod_local_12634).checked_add(prod_local_12648); prod_local_12649 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_12650 = prod_local_12418; { let prod_local_12654 = 64; { let prod_local_12655 = (val_2857 & prod_local_12654); { let prod_local_12656 = 0; { let prod_local_12657 = (prod_local_12655 == prod_local_12656); { let prod_local_12661 = match prod_local_12657 {
        false => { let prod_local_12659 = false; prod_local_12659 },
        true => { let prod_local_12660 = true; prod_local_12660 },
    }; match prod_local_12661 {
        false => { let prod_local_12663 = Some(prod_local_12650); { let prod_local_12664 = round64(prod_local_12663); match prod_local_12664 {
        None => { let prod_local_12665 = prod_local_12664; match prod_local_12665 {
        None => None,
        Some(prod_local_12667) => { let prod_local_12668 = prod_local_12667; { let prod_local_12669 = (prod_local_12668).value; { let prod_local_12670 = low64(prod_local_12669); match prod_local_12670 {
        None => prod_local_12670,
        Some(prod_local_12671) => { let prod_local_12672 = (prod_local_12668).guard; match prod_local_12672 {
        false => prod_local_12670,
        true => { let prod_local_12674 = (prod_local_12668).sticky; match prod_local_12674 {
        false => { let prod_local_12678 = 1; { let prod_local_12679 = (prod_local_12671 & prod_local_12678); { let prod_local_12680 = (prod_local_12679 == prod_local_12678); match prod_local_12680 {
        false => prod_local_12670,
        true => { let prod_local_12682 = 1; { let prod_local_12683 = (prod_local_12671).checked_add(prod_local_12682); prod_local_12683 } },
    } } } },
        true => { let prod_local_12685 = 1; { let prod_local_12686 = (prod_local_12671).checked_add(prod_local_12685); prod_local_12686 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_12687) => { let prod_local_12688 = prod_local_12687; { let prod_local_12692 = 128; { let prod_local_12693 = (val_2857 & prod_local_12692); { let prod_local_12694 = 0; { let prod_local_12695 = (prod_local_12693 == prod_local_12694); { let prod_local_12699 = match prod_local_12695 {
        false => { let prod_local_12697 = false; prod_local_12697 },
        true => { let prod_local_12698 = true; prod_local_12698 },
    }; match prod_local_12699 {
        false => { let prod_local_12701 = Some(prod_local_12688); { let prod_local_12702 = round128(prod_local_12701); match prod_local_12702 {
        None => { let prod_local_12703 = prod_local_12702; match prod_local_12703 {
        None => None,
        Some(prod_local_12705) => { let prod_local_12706 = prod_local_12705; { let prod_local_12707 = (prod_local_12706).value; { let prod_local_12708 = low64(prod_local_12707); match prod_local_12708 {
        None => prod_local_12708,
        Some(prod_local_12709) => { let prod_local_12710 = (prod_local_12706).guard; match prod_local_12710 {
        false => prod_local_12708,
        true => { let prod_local_12712 = (prod_local_12706).sticky; match prod_local_12712 {
        false => { let prod_local_12716 = 1; { let prod_local_12717 = (prod_local_12709 & prod_local_12716); { let prod_local_12718 = (prod_local_12717 == prod_local_12716); match prod_local_12718 {
        false => prod_local_12708,
        true => { let prod_local_12720 = 1; { let prod_local_12721 = (prod_local_12709).checked_add(prod_local_12720); prod_local_12721 } },
    } } } },
        true => { let prod_local_12723 = 1; { let prod_local_12724 = (prod_local_12709).checked_add(prod_local_12723); prod_local_12724 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_12725) => { let prod_local_12726 = prod_local_12725; { let prod_local_12727 = prod_local_12726; { let prod_local_12728 = (prod_local_12727).value; { let prod_local_12729 = low64(prod_local_12728); match prod_local_12729 {
        None => prod_local_12729,
        Some(prod_local_12730) => { let prod_local_12731 = (prod_local_12727).guard; match prod_local_12731 {
        false => prod_local_12729,
        true => { let prod_local_12733 = (prod_local_12727).sticky; match prod_local_12733 {
        false => { let prod_local_12737 = 1; { let prod_local_12738 = (prod_local_12730 & prod_local_12737); { let prod_local_12739 = (prod_local_12738 == prod_local_12737); match prod_local_12739 {
        false => prod_local_12729,
        true => { let prod_local_12741 = 1; { let prod_local_12742 = (prod_local_12730).checked_add(prod_local_12741); prod_local_12742 } },
    } } } },
        true => { let prod_local_12744 = 1; { let prod_local_12745 = (prod_local_12730).checked_add(prod_local_12744); prod_local_12745 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_12746 = prod_local_12688; { let prod_local_12747 = prod_local_12746; { let prod_local_12748 = (prod_local_12747).value; { let prod_local_12749 = low64(prod_local_12748); match prod_local_12749 {
        None => prod_local_12749,
        Some(prod_local_12750) => { let prod_local_12751 = (prod_local_12747).guard; match prod_local_12751 {
        false => prod_local_12749,
        true => { let prod_local_12753 = (prod_local_12747).sticky; match prod_local_12753 {
        false => { let prod_local_12757 = 1; { let prod_local_12758 = (prod_local_12750 & prod_local_12757); { let prod_local_12759 = (prod_local_12758 == prod_local_12757); match prod_local_12759 {
        false => prod_local_12749,
        true => { let prod_local_12761 = 1; { let prod_local_12762 = (prod_local_12750).checked_add(prod_local_12761); prod_local_12762 } },
    } } } },
        true => { let prod_local_12764 = 1; { let prod_local_12765 = (prod_local_12750).checked_add(prod_local_12764); prod_local_12765 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_12766 = prod_local_12650; { let prod_local_12770 = 128; { let prod_local_12771 = (val_2857 & prod_local_12770); { let prod_local_12772 = 0; { let prod_local_12773 = (prod_local_12771 == prod_local_12772); { let prod_local_12777 = match prod_local_12773 {
        false => { let prod_local_12775 = false; prod_local_12775 },
        true => { let prod_local_12776 = true; prod_local_12776 },
    }; match prod_local_12777 {
        false => { let prod_local_12779 = Some(prod_local_12766); { let prod_local_12780 = round128(prod_local_12779); match prod_local_12780 {
        None => { let prod_local_12781 = prod_local_12780; match prod_local_12781 {
        None => None,
        Some(prod_local_12783) => { let prod_local_12784 = prod_local_12783; { let prod_local_12785 = (prod_local_12784).value; { let prod_local_12786 = low64(prod_local_12785); match prod_local_12786 {
        None => prod_local_12786,
        Some(prod_local_12787) => { let prod_local_12788 = (prod_local_12784).guard; match prod_local_12788 {
        false => prod_local_12786,
        true => { let prod_local_12790 = (prod_local_12784).sticky; match prod_local_12790 {
        false => { let prod_local_12794 = 1; { let prod_local_12795 = (prod_local_12787 & prod_local_12794); { let prod_local_12796 = (prod_local_12795 == prod_local_12794); match prod_local_12796 {
        false => prod_local_12786,
        true => { let prod_local_12798 = 1; { let prod_local_12799 = (prod_local_12787).checked_add(prod_local_12798); prod_local_12799 } },
    } } } },
        true => { let prod_local_12801 = 1; { let prod_local_12802 = (prod_local_12787).checked_add(prod_local_12801); prod_local_12802 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_12803) => { let prod_local_12804 = prod_local_12803; { let prod_local_12805 = prod_local_12804; { let prod_local_12806 = (prod_local_12805).value; { let prod_local_12807 = low64(prod_local_12806); match prod_local_12807 {
        None => prod_local_12807,
        Some(prod_local_12808) => { let prod_local_12809 = (prod_local_12805).guard; match prod_local_12809 {
        false => prod_local_12807,
        true => { let prod_local_12811 = (prod_local_12805).sticky; match prod_local_12811 {
        false => { let prod_local_12815 = 1; { let prod_local_12816 = (prod_local_12808 & prod_local_12815); { let prod_local_12817 = (prod_local_12816 == prod_local_12815); match prod_local_12817 {
        false => prod_local_12807,
        true => { let prod_local_12819 = 1; { let prod_local_12820 = (prod_local_12808).checked_add(prod_local_12819); prod_local_12820 } },
    } } } },
        true => { let prod_local_12822 = 1; { let prod_local_12823 = (prod_local_12808).checked_add(prod_local_12822); prod_local_12823 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_12824 = prod_local_12766; { let prod_local_12825 = prod_local_12824; { let prod_local_12826 = (prod_local_12825).value; { let prod_local_12827 = low64(prod_local_12826); match prod_local_12827 {
        None => prod_local_12827,
        Some(prod_local_12828) => { let prod_local_12829 = (prod_local_12825).guard; match prod_local_12829 {
        false => prod_local_12827,
        true => { let prod_local_12831 = (prod_local_12825).sticky; match prod_local_12831 {
        false => { let prod_local_12835 = 1; { let prod_local_12836 = (prod_local_12828 & prod_local_12835); { let prod_local_12837 = (prod_local_12836 == prod_local_12835); match prod_local_12837 {
        false => prod_local_12827,
        true => { let prod_local_12839 = 1; { let prod_local_12840 = (prod_local_12828).checked_add(prod_local_12839); prod_local_12840 } },
    } } } },
        true => { let prod_local_12842 = 1; { let prod_local_12843 = (prod_local_12828).checked_add(prod_local_12842); prod_local_12843 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } } } } } },
    } } } } } } },
    } } } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_12844 = prod_local_10988; { let prod_local_12848 = 8; { let prod_local_12849 = (val_2857 & prod_local_12848); { let prod_local_12850 = 0; { let prod_local_12851 = (prod_local_12849 == prod_local_12850); { let prod_local_12855 = match prod_local_12851 {
        false => { let prod_local_12853 = false; prod_local_12853 },
        true => { let prod_local_12854 = true; prod_local_12854 },
    }; match prod_local_12855 {
        false => { let prod_local_12857 = Some(prod_local_12844); { let prod_local_12858 = round8(prod_local_12857); match prod_local_12858 {
        None => { let prod_local_12859 = prod_local_12858; match prod_local_12859 {
        None => None,
        Some(prod_local_12861) => { let prod_local_12862 = prod_local_12861; { let prod_local_12863 = (prod_local_12862).value; { let prod_local_12864 = low64(prod_local_12863); match prod_local_12864 {
        None => prod_local_12864,
        Some(prod_local_12865) => { let prod_local_12866 = (prod_local_12862).guard; match prod_local_12866 {
        false => prod_local_12864,
        true => { let prod_local_12868 = (prod_local_12862).sticky; match prod_local_12868 {
        false => { let prod_local_12872 = 1; { let prod_local_12873 = (prod_local_12865 & prod_local_12872); { let prod_local_12874 = (prod_local_12873 == prod_local_12872); match prod_local_12874 {
        false => prod_local_12864,
        true => { let prod_local_12876 = 1; { let prod_local_12877 = (prod_local_12865).checked_add(prod_local_12876); prod_local_12877 } },
    } } } },
        true => { let prod_local_12879 = 1; { let prod_local_12880 = (prod_local_12865).checked_add(prod_local_12879); prod_local_12880 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_12881) => { let prod_local_12882 = prod_local_12881; { let prod_local_12886 = 16; { let prod_local_12887 = (val_2857 & prod_local_12886); { let prod_local_12888 = 0; { let prod_local_12889 = (prod_local_12887 == prod_local_12888); { let prod_local_12893 = match prod_local_12889 {
        false => { let prod_local_12891 = false; prod_local_12891 },
        true => { let prod_local_12892 = true; prod_local_12892 },
    }; match prod_local_12893 {
        false => { let prod_local_12895 = Some(prod_local_12882); { let prod_local_12896 = round16(prod_local_12895); match prod_local_12896 {
        None => { let prod_local_12897 = prod_local_12896; match prod_local_12897 {
        None => None,
        Some(prod_local_12899) => { let prod_local_12900 = prod_local_12899; { let prod_local_12901 = (prod_local_12900).value; { let prod_local_12902 = low64(prod_local_12901); match prod_local_12902 {
        None => prod_local_12902,
        Some(prod_local_12903) => { let prod_local_12904 = (prod_local_12900).guard; match prod_local_12904 {
        false => prod_local_12902,
        true => { let prod_local_12906 = (prod_local_12900).sticky; match prod_local_12906 {
        false => { let prod_local_12910 = 1; { let prod_local_12911 = (prod_local_12903 & prod_local_12910); { let prod_local_12912 = (prod_local_12911 == prod_local_12910); match prod_local_12912 {
        false => prod_local_12902,
        true => { let prod_local_12914 = 1; { let prod_local_12915 = (prod_local_12903).checked_add(prod_local_12914); prod_local_12915 } },
    } } } },
        true => { let prod_local_12917 = 1; { let prod_local_12918 = (prod_local_12903).checked_add(prod_local_12917); prod_local_12918 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_12919) => { let prod_local_12920 = prod_local_12919; { let prod_local_12924 = 32; { let prod_local_12925 = (val_2857 & prod_local_12924); { let prod_local_12926 = 0; { let prod_local_12927 = (prod_local_12925 == prod_local_12926); { let prod_local_12931 = match prod_local_12927 {
        false => { let prod_local_12929 = false; prod_local_12929 },
        true => { let prod_local_12930 = true; prod_local_12930 },
    }; match prod_local_12931 {
        false => { let prod_local_12933 = Some(prod_local_12920); { let prod_local_12934 = round32(prod_local_12933); match prod_local_12934 {
        None => { let prod_local_12935 = prod_local_12934; match prod_local_12935 {
        None => None,
        Some(prod_local_12937) => { let prod_local_12938 = prod_local_12937; { let prod_local_12939 = (prod_local_12938).value; { let prod_local_12940 = low64(prod_local_12939); match prod_local_12940 {
        None => prod_local_12940,
        Some(prod_local_12941) => { let prod_local_12942 = (prod_local_12938).guard; match prod_local_12942 {
        false => prod_local_12940,
        true => { let prod_local_12944 = (prod_local_12938).sticky; match prod_local_12944 {
        false => { let prod_local_12948 = 1; { let prod_local_12949 = (prod_local_12941 & prod_local_12948); { let prod_local_12950 = (prod_local_12949 == prod_local_12948); match prod_local_12950 {
        false => prod_local_12940,
        true => { let prod_local_12952 = 1; { let prod_local_12953 = (prod_local_12941).checked_add(prod_local_12952); prod_local_12953 } },
    } } } },
        true => { let prod_local_12955 = 1; { let prod_local_12956 = (prod_local_12941).checked_add(prod_local_12955); prod_local_12956 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_12957) => { let prod_local_12958 = prod_local_12957; { let prod_local_12962 = 64; { let prod_local_12963 = (val_2857 & prod_local_12962); { let prod_local_12964 = 0; { let prod_local_12965 = (prod_local_12963 == prod_local_12964); { let prod_local_12969 = match prod_local_12965 {
        false => { let prod_local_12967 = false; prod_local_12967 },
        true => { let prod_local_12968 = true; prod_local_12968 },
    }; match prod_local_12969 {
        false => { let prod_local_12971 = Some(prod_local_12958); { let prod_local_12972 = round64(prod_local_12971); match prod_local_12972 {
        None => { let prod_local_12973 = prod_local_12972; match prod_local_12973 {
        None => None,
        Some(prod_local_12975) => { let prod_local_12976 = prod_local_12975; { let prod_local_12977 = (prod_local_12976).value; { let prod_local_12978 = low64(prod_local_12977); match prod_local_12978 {
        None => prod_local_12978,
        Some(prod_local_12979) => { let prod_local_12980 = (prod_local_12976).guard; match prod_local_12980 {
        false => prod_local_12978,
        true => { let prod_local_12982 = (prod_local_12976).sticky; match prod_local_12982 {
        false => { let prod_local_12986 = 1; { let prod_local_12987 = (prod_local_12979 & prod_local_12986); { let prod_local_12988 = (prod_local_12987 == prod_local_12986); match prod_local_12988 {
        false => prod_local_12978,
        true => { let prod_local_12990 = 1; { let prod_local_12991 = (prod_local_12979).checked_add(prod_local_12990); prod_local_12991 } },
    } } } },
        true => { let prod_local_12993 = 1; { let prod_local_12994 = (prod_local_12979).checked_add(prod_local_12993); prod_local_12994 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_12995) => { let prod_local_12996 = prod_local_12995; { let prod_local_13000 = 128; { let prod_local_13001 = (val_2857 & prod_local_13000); { let prod_local_13002 = 0; { let prod_local_13003 = (prod_local_13001 == prod_local_13002); { let prod_local_13007 = match prod_local_13003 {
        false => { let prod_local_13005 = false; prod_local_13005 },
        true => { let prod_local_13006 = true; prod_local_13006 },
    }; match prod_local_13007 {
        false => { let prod_local_13009 = Some(prod_local_12996); { let prod_local_13010 = round128(prod_local_13009); match prod_local_13010 {
        None => { let prod_local_13011 = prod_local_13010; match prod_local_13011 {
        None => None,
        Some(prod_local_13013) => { let prod_local_13014 = prod_local_13013; { let prod_local_13015 = (prod_local_13014).value; { let prod_local_13016 = low64(prod_local_13015); match prod_local_13016 {
        None => prod_local_13016,
        Some(prod_local_13017) => { let prod_local_13018 = (prod_local_13014).guard; match prod_local_13018 {
        false => prod_local_13016,
        true => { let prod_local_13020 = (prod_local_13014).sticky; match prod_local_13020 {
        false => { let prod_local_13024 = 1; { let prod_local_13025 = (prod_local_13017 & prod_local_13024); { let prod_local_13026 = (prod_local_13025 == prod_local_13024); match prod_local_13026 {
        false => prod_local_13016,
        true => { let prod_local_13028 = 1; { let prod_local_13029 = (prod_local_13017).checked_add(prod_local_13028); prod_local_13029 } },
    } } } },
        true => { let prod_local_13031 = 1; { let prod_local_13032 = (prod_local_13017).checked_add(prod_local_13031); prod_local_13032 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_13033) => { let prod_local_13034 = prod_local_13033; { let prod_local_13035 = prod_local_13034; { let prod_local_13036 = (prod_local_13035).value; { let prod_local_13037 = low64(prod_local_13036); match prod_local_13037 {
        None => prod_local_13037,
        Some(prod_local_13038) => { let prod_local_13039 = (prod_local_13035).guard; match prod_local_13039 {
        false => prod_local_13037,
        true => { let prod_local_13041 = (prod_local_13035).sticky; match prod_local_13041 {
        false => { let prod_local_13045 = 1; { let prod_local_13046 = (prod_local_13038 & prod_local_13045); { let prod_local_13047 = (prod_local_13046 == prod_local_13045); match prod_local_13047 {
        false => prod_local_13037,
        true => { let prod_local_13049 = 1; { let prod_local_13050 = (prod_local_13038).checked_add(prod_local_13049); prod_local_13050 } },
    } } } },
        true => { let prod_local_13052 = 1; { let prod_local_13053 = (prod_local_13038).checked_add(prod_local_13052); prod_local_13053 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_13054 = prod_local_12996; { let prod_local_13055 = prod_local_13054; { let prod_local_13056 = (prod_local_13055).value; { let prod_local_13057 = low64(prod_local_13056); match prod_local_13057 {
        None => prod_local_13057,
        Some(prod_local_13058) => { let prod_local_13059 = (prod_local_13055).guard; match prod_local_13059 {
        false => prod_local_13057,
        true => { let prod_local_13061 = (prod_local_13055).sticky; match prod_local_13061 {
        false => { let prod_local_13065 = 1; { let prod_local_13066 = (prod_local_13058 & prod_local_13065); { let prod_local_13067 = (prod_local_13066 == prod_local_13065); match prod_local_13067 {
        false => prod_local_13057,
        true => { let prod_local_13069 = 1; { let prod_local_13070 = (prod_local_13058).checked_add(prod_local_13069); prod_local_13070 } },
    } } } },
        true => { let prod_local_13072 = 1; { let prod_local_13073 = (prod_local_13058).checked_add(prod_local_13072); prod_local_13073 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_13074 = prod_local_12958; { let prod_local_13078 = 128; { let prod_local_13079 = (val_2857 & prod_local_13078); { let prod_local_13080 = 0; { let prod_local_13081 = (prod_local_13079 == prod_local_13080); { let prod_local_13085 = match prod_local_13081 {
        false => { let prod_local_13083 = false; prod_local_13083 },
        true => { let prod_local_13084 = true; prod_local_13084 },
    }; match prod_local_13085 {
        false => { let prod_local_13087 = Some(prod_local_13074); { let prod_local_13088 = round128(prod_local_13087); match prod_local_13088 {
        None => { let prod_local_13089 = prod_local_13088; match prod_local_13089 {
        None => None,
        Some(prod_local_13091) => { let prod_local_13092 = prod_local_13091; { let prod_local_13093 = (prod_local_13092).value; { let prod_local_13094 = low64(prod_local_13093); match prod_local_13094 {
        None => prod_local_13094,
        Some(prod_local_13095) => { let prod_local_13096 = (prod_local_13092).guard; match prod_local_13096 {
        false => prod_local_13094,
        true => { let prod_local_13098 = (prod_local_13092).sticky; match prod_local_13098 {
        false => { let prod_local_13102 = 1; { let prod_local_13103 = (prod_local_13095 & prod_local_13102); { let prod_local_13104 = (prod_local_13103 == prod_local_13102); match prod_local_13104 {
        false => prod_local_13094,
        true => { let prod_local_13106 = 1; { let prod_local_13107 = (prod_local_13095).checked_add(prod_local_13106); prod_local_13107 } },
    } } } },
        true => { let prod_local_13109 = 1; { let prod_local_13110 = (prod_local_13095).checked_add(prod_local_13109); prod_local_13110 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_13111) => { let prod_local_13112 = prod_local_13111; { let prod_local_13113 = prod_local_13112; { let prod_local_13114 = (prod_local_13113).value; { let prod_local_13115 = low64(prod_local_13114); match prod_local_13115 {
        None => prod_local_13115,
        Some(prod_local_13116) => { let prod_local_13117 = (prod_local_13113).guard; match prod_local_13117 {
        false => prod_local_13115,
        true => { let prod_local_13119 = (prod_local_13113).sticky; match prod_local_13119 {
        false => { let prod_local_13123 = 1; { let prod_local_13124 = (prod_local_13116 & prod_local_13123); { let prod_local_13125 = (prod_local_13124 == prod_local_13123); match prod_local_13125 {
        false => prod_local_13115,
        true => { let prod_local_13127 = 1; { let prod_local_13128 = (prod_local_13116).checked_add(prod_local_13127); prod_local_13128 } },
    } } } },
        true => { let prod_local_13130 = 1; { let prod_local_13131 = (prod_local_13116).checked_add(prod_local_13130); prod_local_13131 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_13132 = prod_local_13074; { let prod_local_13133 = prod_local_13132; { let prod_local_13134 = (prod_local_13133).value; { let prod_local_13135 = low64(prod_local_13134); match prod_local_13135 {
        None => prod_local_13135,
        Some(prod_local_13136) => { let prod_local_13137 = (prod_local_13133).guard; match prod_local_13137 {
        false => prod_local_13135,
        true => { let prod_local_13139 = (prod_local_13133).sticky; match prod_local_13139 {
        false => { let prod_local_13143 = 1; { let prod_local_13144 = (prod_local_13136 & prod_local_13143); { let prod_local_13145 = (prod_local_13144 == prod_local_13143); match prod_local_13145 {
        false => prod_local_13135,
        true => { let prod_local_13147 = 1; { let prod_local_13148 = (prod_local_13136).checked_add(prod_local_13147); prod_local_13148 } },
    } } } },
        true => { let prod_local_13150 = 1; { let prod_local_13151 = (prod_local_13136).checked_add(prod_local_13150); prod_local_13151 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_13152 = prod_local_12920; { let prod_local_13156 = 64; { let prod_local_13157 = (val_2857 & prod_local_13156); { let prod_local_13158 = 0; { let prod_local_13159 = (prod_local_13157 == prod_local_13158); { let prod_local_13163 = match prod_local_13159 {
        false => { let prod_local_13161 = false; prod_local_13161 },
        true => { let prod_local_13162 = true; prod_local_13162 },
    }; match prod_local_13163 {
        false => { let prod_local_13165 = Some(prod_local_13152); { let prod_local_13166 = round64(prod_local_13165); match prod_local_13166 {
        None => { let prod_local_13167 = prod_local_13166; match prod_local_13167 {
        None => None,
        Some(prod_local_13169) => { let prod_local_13170 = prod_local_13169; { let prod_local_13171 = (prod_local_13170).value; { let prod_local_13172 = low64(prod_local_13171); match prod_local_13172 {
        None => prod_local_13172,
        Some(prod_local_13173) => { let prod_local_13174 = (prod_local_13170).guard; match prod_local_13174 {
        false => prod_local_13172,
        true => { let prod_local_13176 = (prod_local_13170).sticky; match prod_local_13176 {
        false => { let prod_local_13180 = 1; { let prod_local_13181 = (prod_local_13173 & prod_local_13180); { let prod_local_13182 = (prod_local_13181 == prod_local_13180); match prod_local_13182 {
        false => prod_local_13172,
        true => { let prod_local_13184 = 1; { let prod_local_13185 = (prod_local_13173).checked_add(prod_local_13184); prod_local_13185 } },
    } } } },
        true => { let prod_local_13187 = 1; { let prod_local_13188 = (prod_local_13173).checked_add(prod_local_13187); prod_local_13188 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_13189) => { let prod_local_13190 = prod_local_13189; { let prod_local_13194 = 128; { let prod_local_13195 = (val_2857 & prod_local_13194); { let prod_local_13196 = 0; { let prod_local_13197 = (prod_local_13195 == prod_local_13196); { let prod_local_13201 = match prod_local_13197 {
        false => { let prod_local_13199 = false; prod_local_13199 },
        true => { let prod_local_13200 = true; prod_local_13200 },
    }; match prod_local_13201 {
        false => { let prod_local_13203 = Some(prod_local_13190); { let prod_local_13204 = round128(prod_local_13203); match prod_local_13204 {
        None => { let prod_local_13205 = prod_local_13204; match prod_local_13205 {
        None => None,
        Some(prod_local_13207) => { let prod_local_13208 = prod_local_13207; { let prod_local_13209 = (prod_local_13208).value; { let prod_local_13210 = low64(prod_local_13209); match prod_local_13210 {
        None => prod_local_13210,
        Some(prod_local_13211) => { let prod_local_13212 = (prod_local_13208).guard; match prod_local_13212 {
        false => prod_local_13210,
        true => { let prod_local_13214 = (prod_local_13208).sticky; match prod_local_13214 {
        false => { let prod_local_13218 = 1; { let prod_local_13219 = (prod_local_13211 & prod_local_13218); { let prod_local_13220 = (prod_local_13219 == prod_local_13218); match prod_local_13220 {
        false => prod_local_13210,
        true => { let prod_local_13222 = 1; { let prod_local_13223 = (prod_local_13211).checked_add(prod_local_13222); prod_local_13223 } },
    } } } },
        true => { let prod_local_13225 = 1; { let prod_local_13226 = (prod_local_13211).checked_add(prod_local_13225); prod_local_13226 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_13227) => { let prod_local_13228 = prod_local_13227; { let prod_local_13229 = prod_local_13228; { let prod_local_13230 = (prod_local_13229).value; { let prod_local_13231 = low64(prod_local_13230); match prod_local_13231 {
        None => prod_local_13231,
        Some(prod_local_13232) => { let prod_local_13233 = (prod_local_13229).guard; match prod_local_13233 {
        false => prod_local_13231,
        true => { let prod_local_13235 = (prod_local_13229).sticky; match prod_local_13235 {
        false => { let prod_local_13239 = 1; { let prod_local_13240 = (prod_local_13232 & prod_local_13239); { let prod_local_13241 = (prod_local_13240 == prod_local_13239); match prod_local_13241 {
        false => prod_local_13231,
        true => { let prod_local_13243 = 1; { let prod_local_13244 = (prod_local_13232).checked_add(prod_local_13243); prod_local_13244 } },
    } } } },
        true => { let prod_local_13246 = 1; { let prod_local_13247 = (prod_local_13232).checked_add(prod_local_13246); prod_local_13247 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_13248 = prod_local_13190; { let prod_local_13249 = prod_local_13248; { let prod_local_13250 = (prod_local_13249).value; { let prod_local_13251 = low64(prod_local_13250); match prod_local_13251 {
        None => prod_local_13251,
        Some(prod_local_13252) => { let prod_local_13253 = (prod_local_13249).guard; match prod_local_13253 {
        false => prod_local_13251,
        true => { let prod_local_13255 = (prod_local_13249).sticky; match prod_local_13255 {
        false => { let prod_local_13259 = 1; { let prod_local_13260 = (prod_local_13252 & prod_local_13259); { let prod_local_13261 = (prod_local_13260 == prod_local_13259); match prod_local_13261 {
        false => prod_local_13251,
        true => { let prod_local_13263 = 1; { let prod_local_13264 = (prod_local_13252).checked_add(prod_local_13263); prod_local_13264 } },
    } } } },
        true => { let prod_local_13266 = 1; { let prod_local_13267 = (prod_local_13252).checked_add(prod_local_13266); prod_local_13267 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_13268 = prod_local_13152; { let prod_local_13272 = 128; { let prod_local_13273 = (val_2857 & prod_local_13272); { let prod_local_13274 = 0; { let prod_local_13275 = (prod_local_13273 == prod_local_13274); { let prod_local_13279 = match prod_local_13275 {
        false => { let prod_local_13277 = false; prod_local_13277 },
        true => { let prod_local_13278 = true; prod_local_13278 },
    }; match prod_local_13279 {
        false => { let prod_local_13281 = Some(prod_local_13268); { let prod_local_13282 = round128(prod_local_13281); match prod_local_13282 {
        None => { let prod_local_13283 = prod_local_13282; match prod_local_13283 {
        None => None,
        Some(prod_local_13285) => { let prod_local_13286 = prod_local_13285; { let prod_local_13287 = (prod_local_13286).value; { let prod_local_13288 = low64(prod_local_13287); match prod_local_13288 {
        None => prod_local_13288,
        Some(prod_local_13289) => { let prod_local_13290 = (prod_local_13286).guard; match prod_local_13290 {
        false => prod_local_13288,
        true => { let prod_local_13292 = (prod_local_13286).sticky; match prod_local_13292 {
        false => { let prod_local_13296 = 1; { let prod_local_13297 = (prod_local_13289 & prod_local_13296); { let prod_local_13298 = (prod_local_13297 == prod_local_13296); match prod_local_13298 {
        false => prod_local_13288,
        true => { let prod_local_13300 = 1; { let prod_local_13301 = (prod_local_13289).checked_add(prod_local_13300); prod_local_13301 } },
    } } } },
        true => { let prod_local_13303 = 1; { let prod_local_13304 = (prod_local_13289).checked_add(prod_local_13303); prod_local_13304 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_13305) => { let prod_local_13306 = prod_local_13305; { let prod_local_13307 = prod_local_13306; { let prod_local_13308 = (prod_local_13307).value; { let prod_local_13309 = low64(prod_local_13308); match prod_local_13309 {
        None => prod_local_13309,
        Some(prod_local_13310) => { let prod_local_13311 = (prod_local_13307).guard; match prod_local_13311 {
        false => prod_local_13309,
        true => { let prod_local_13313 = (prod_local_13307).sticky; match prod_local_13313 {
        false => { let prod_local_13317 = 1; { let prod_local_13318 = (prod_local_13310 & prod_local_13317); { let prod_local_13319 = (prod_local_13318 == prod_local_13317); match prod_local_13319 {
        false => prod_local_13309,
        true => { let prod_local_13321 = 1; { let prod_local_13322 = (prod_local_13310).checked_add(prod_local_13321); prod_local_13322 } },
    } } } },
        true => { let prod_local_13324 = 1; { let prod_local_13325 = (prod_local_13310).checked_add(prod_local_13324); prod_local_13325 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_13326 = prod_local_13268; { let prod_local_13327 = prod_local_13326; { let prod_local_13328 = (prod_local_13327).value; { let prod_local_13329 = low64(prod_local_13328); match prod_local_13329 {
        None => prod_local_13329,
        Some(prod_local_13330) => { let prod_local_13331 = (prod_local_13327).guard; match prod_local_13331 {
        false => prod_local_13329,
        true => { let prod_local_13333 = (prod_local_13327).sticky; match prod_local_13333 {
        false => { let prod_local_13337 = 1; { let prod_local_13338 = (prod_local_13330 & prod_local_13337); { let prod_local_13339 = (prod_local_13338 == prod_local_13337); match prod_local_13339 {
        false => prod_local_13329,
        true => { let prod_local_13341 = 1; { let prod_local_13342 = (prod_local_13330).checked_add(prod_local_13341); prod_local_13342 } },
    } } } },
        true => { let prod_local_13344 = 1; { let prod_local_13345 = (prod_local_13330).checked_add(prod_local_13344); prod_local_13345 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_13346 = prod_local_12882; { let prod_local_13350 = 32; { let prod_local_13351 = (val_2857 & prod_local_13350); { let prod_local_13352 = 0; { let prod_local_13353 = (prod_local_13351 == prod_local_13352); { let prod_local_13357 = match prod_local_13353 {
        false => { let prod_local_13355 = false; prod_local_13355 },
        true => { let prod_local_13356 = true; prod_local_13356 },
    }; match prod_local_13357 {
        false => { let prod_local_13359 = Some(prod_local_13346); { let prod_local_13360 = round32(prod_local_13359); match prod_local_13360 {
        None => { let prod_local_13361 = prod_local_13360; match prod_local_13361 {
        None => None,
        Some(prod_local_13363) => { let prod_local_13364 = prod_local_13363; { let prod_local_13365 = (prod_local_13364).value; { let prod_local_13366 = low64(prod_local_13365); match prod_local_13366 {
        None => prod_local_13366,
        Some(prod_local_13367) => { let prod_local_13368 = (prod_local_13364).guard; match prod_local_13368 {
        false => prod_local_13366,
        true => { let prod_local_13370 = (prod_local_13364).sticky; match prod_local_13370 {
        false => { let prod_local_13374 = 1; { let prod_local_13375 = (prod_local_13367 & prod_local_13374); { let prod_local_13376 = (prod_local_13375 == prod_local_13374); match prod_local_13376 {
        false => prod_local_13366,
        true => { let prod_local_13378 = 1; { let prod_local_13379 = (prod_local_13367).checked_add(prod_local_13378); prod_local_13379 } },
    } } } },
        true => { let prod_local_13381 = 1; { let prod_local_13382 = (prod_local_13367).checked_add(prod_local_13381); prod_local_13382 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_13383) => { let prod_local_13384 = prod_local_13383; { let prod_local_13388 = 64; { let prod_local_13389 = (val_2857 & prod_local_13388); { let prod_local_13390 = 0; { let prod_local_13391 = (prod_local_13389 == prod_local_13390); { let prod_local_13395 = match prod_local_13391 {
        false => { let prod_local_13393 = false; prod_local_13393 },
        true => { let prod_local_13394 = true; prod_local_13394 },
    }; match prod_local_13395 {
        false => { let prod_local_13397 = Some(prod_local_13384); { let prod_local_13398 = round64(prod_local_13397); match prod_local_13398 {
        None => { let prod_local_13399 = prod_local_13398; match prod_local_13399 {
        None => None,
        Some(prod_local_13401) => { let prod_local_13402 = prod_local_13401; { let prod_local_13403 = (prod_local_13402).value; { let prod_local_13404 = low64(prod_local_13403); match prod_local_13404 {
        None => prod_local_13404,
        Some(prod_local_13405) => { let prod_local_13406 = (prod_local_13402).guard; match prod_local_13406 {
        false => prod_local_13404,
        true => { let prod_local_13408 = (prod_local_13402).sticky; match prod_local_13408 {
        false => { let prod_local_13412 = 1; { let prod_local_13413 = (prod_local_13405 & prod_local_13412); { let prod_local_13414 = (prod_local_13413 == prod_local_13412); match prod_local_13414 {
        false => prod_local_13404,
        true => { let prod_local_13416 = 1; { let prod_local_13417 = (prod_local_13405).checked_add(prod_local_13416); prod_local_13417 } },
    } } } },
        true => { let prod_local_13419 = 1; { let prod_local_13420 = (prod_local_13405).checked_add(prod_local_13419); prod_local_13420 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_13421) => { let prod_local_13422 = prod_local_13421; { let prod_local_13426 = 128; { let prod_local_13427 = (val_2857 & prod_local_13426); { let prod_local_13428 = 0; { let prod_local_13429 = (prod_local_13427 == prod_local_13428); { let prod_local_13433 = match prod_local_13429 {
        false => { let prod_local_13431 = false; prod_local_13431 },
        true => { let prod_local_13432 = true; prod_local_13432 },
    }; match prod_local_13433 {
        false => { let prod_local_13435 = Some(prod_local_13422); { let prod_local_13436 = round128(prod_local_13435); match prod_local_13436 {
        None => { let prod_local_13437 = prod_local_13436; match prod_local_13437 {
        None => None,
        Some(prod_local_13439) => { let prod_local_13440 = prod_local_13439; { let prod_local_13441 = (prod_local_13440).value; { let prod_local_13442 = low64(prod_local_13441); match prod_local_13442 {
        None => prod_local_13442,
        Some(prod_local_13443) => { let prod_local_13444 = (prod_local_13440).guard; match prod_local_13444 {
        false => prod_local_13442,
        true => { let prod_local_13446 = (prod_local_13440).sticky; match prod_local_13446 {
        false => { let prod_local_13450 = 1; { let prod_local_13451 = (prod_local_13443 & prod_local_13450); { let prod_local_13452 = (prod_local_13451 == prod_local_13450); match prod_local_13452 {
        false => prod_local_13442,
        true => { let prod_local_13454 = 1; { let prod_local_13455 = (prod_local_13443).checked_add(prod_local_13454); prod_local_13455 } },
    } } } },
        true => { let prod_local_13457 = 1; { let prod_local_13458 = (prod_local_13443).checked_add(prod_local_13457); prod_local_13458 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_13459) => { let prod_local_13460 = prod_local_13459; { let prod_local_13461 = prod_local_13460; { let prod_local_13462 = (prod_local_13461).value; { let prod_local_13463 = low64(prod_local_13462); match prod_local_13463 {
        None => prod_local_13463,
        Some(prod_local_13464) => { let prod_local_13465 = (prod_local_13461).guard; match prod_local_13465 {
        false => prod_local_13463,
        true => { let prod_local_13467 = (prod_local_13461).sticky; match prod_local_13467 {
        false => { let prod_local_13471 = 1; { let prod_local_13472 = (prod_local_13464 & prod_local_13471); { let prod_local_13473 = (prod_local_13472 == prod_local_13471); match prod_local_13473 {
        false => prod_local_13463,
        true => { let prod_local_13475 = 1; { let prod_local_13476 = (prod_local_13464).checked_add(prod_local_13475); prod_local_13476 } },
    } } } },
        true => { let prod_local_13478 = 1; { let prod_local_13479 = (prod_local_13464).checked_add(prod_local_13478); prod_local_13479 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_13480 = prod_local_13422; { let prod_local_13481 = prod_local_13480; { let prod_local_13482 = (prod_local_13481).value; { let prod_local_13483 = low64(prod_local_13482); match prod_local_13483 {
        None => prod_local_13483,
        Some(prod_local_13484) => { let prod_local_13485 = (prod_local_13481).guard; match prod_local_13485 {
        false => prod_local_13483,
        true => { let prod_local_13487 = (prod_local_13481).sticky; match prod_local_13487 {
        false => { let prod_local_13491 = 1; { let prod_local_13492 = (prod_local_13484 & prod_local_13491); { let prod_local_13493 = (prod_local_13492 == prod_local_13491); match prod_local_13493 {
        false => prod_local_13483,
        true => { let prod_local_13495 = 1; { let prod_local_13496 = (prod_local_13484).checked_add(prod_local_13495); prod_local_13496 } },
    } } } },
        true => { let prod_local_13498 = 1; { let prod_local_13499 = (prod_local_13484).checked_add(prod_local_13498); prod_local_13499 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_13500 = prod_local_13384; { let prod_local_13504 = 128; { let prod_local_13505 = (val_2857 & prod_local_13504); { let prod_local_13506 = 0; { let prod_local_13507 = (prod_local_13505 == prod_local_13506); { let prod_local_13511 = match prod_local_13507 {
        false => { let prod_local_13509 = false; prod_local_13509 },
        true => { let prod_local_13510 = true; prod_local_13510 },
    }; match prod_local_13511 {
        false => { let prod_local_13513 = Some(prod_local_13500); { let prod_local_13514 = round128(prod_local_13513); match prod_local_13514 {
        None => { let prod_local_13515 = prod_local_13514; match prod_local_13515 {
        None => None,
        Some(prod_local_13517) => { let prod_local_13518 = prod_local_13517; { let prod_local_13519 = (prod_local_13518).value; { let prod_local_13520 = low64(prod_local_13519); match prod_local_13520 {
        None => prod_local_13520,
        Some(prod_local_13521) => { let prod_local_13522 = (prod_local_13518).guard; match prod_local_13522 {
        false => prod_local_13520,
        true => { let prod_local_13524 = (prod_local_13518).sticky; match prod_local_13524 {
        false => { let prod_local_13528 = 1; { let prod_local_13529 = (prod_local_13521 & prod_local_13528); { let prod_local_13530 = (prod_local_13529 == prod_local_13528); match prod_local_13530 {
        false => prod_local_13520,
        true => { let prod_local_13532 = 1; { let prod_local_13533 = (prod_local_13521).checked_add(prod_local_13532); prod_local_13533 } },
    } } } },
        true => { let prod_local_13535 = 1; { let prod_local_13536 = (prod_local_13521).checked_add(prod_local_13535); prod_local_13536 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_13537) => { let prod_local_13538 = prod_local_13537; { let prod_local_13539 = prod_local_13538; { let prod_local_13540 = (prod_local_13539).value; { let prod_local_13541 = low64(prod_local_13540); match prod_local_13541 {
        None => prod_local_13541,
        Some(prod_local_13542) => { let prod_local_13543 = (prod_local_13539).guard; match prod_local_13543 {
        false => prod_local_13541,
        true => { let prod_local_13545 = (prod_local_13539).sticky; match prod_local_13545 {
        false => { let prod_local_13549 = 1; { let prod_local_13550 = (prod_local_13542 & prod_local_13549); { let prod_local_13551 = (prod_local_13550 == prod_local_13549); match prod_local_13551 {
        false => prod_local_13541,
        true => { let prod_local_13553 = 1; { let prod_local_13554 = (prod_local_13542).checked_add(prod_local_13553); prod_local_13554 } },
    } } } },
        true => { let prod_local_13556 = 1; { let prod_local_13557 = (prod_local_13542).checked_add(prod_local_13556); prod_local_13557 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_13558 = prod_local_13500; { let prod_local_13559 = prod_local_13558; { let prod_local_13560 = (prod_local_13559).value; { let prod_local_13561 = low64(prod_local_13560); match prod_local_13561 {
        None => prod_local_13561,
        Some(prod_local_13562) => { let prod_local_13563 = (prod_local_13559).guard; match prod_local_13563 {
        false => prod_local_13561,
        true => { let prod_local_13565 = (prod_local_13559).sticky; match prod_local_13565 {
        false => { let prod_local_13569 = 1; { let prod_local_13570 = (prod_local_13562 & prod_local_13569); { let prod_local_13571 = (prod_local_13570 == prod_local_13569); match prod_local_13571 {
        false => prod_local_13561,
        true => { let prod_local_13573 = 1; { let prod_local_13574 = (prod_local_13562).checked_add(prod_local_13573); prod_local_13574 } },
    } } } },
        true => { let prod_local_13576 = 1; { let prod_local_13577 = (prod_local_13562).checked_add(prod_local_13576); prod_local_13577 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_13578 = prod_local_13346; { let prod_local_13582 = 64; { let prod_local_13583 = (val_2857 & prod_local_13582); { let prod_local_13584 = 0; { let prod_local_13585 = (prod_local_13583 == prod_local_13584); { let prod_local_13589 = match prod_local_13585 {
        false => { let prod_local_13587 = false; prod_local_13587 },
        true => { let prod_local_13588 = true; prod_local_13588 },
    }; match prod_local_13589 {
        false => { let prod_local_13591 = Some(prod_local_13578); { let prod_local_13592 = round64(prod_local_13591); match prod_local_13592 {
        None => { let prod_local_13593 = prod_local_13592; match prod_local_13593 {
        None => None,
        Some(prod_local_13595) => { let prod_local_13596 = prod_local_13595; { let prod_local_13597 = (prod_local_13596).value; { let prod_local_13598 = low64(prod_local_13597); match prod_local_13598 {
        None => prod_local_13598,
        Some(prod_local_13599) => { let prod_local_13600 = (prod_local_13596).guard; match prod_local_13600 {
        false => prod_local_13598,
        true => { let prod_local_13602 = (prod_local_13596).sticky; match prod_local_13602 {
        false => { let prod_local_13606 = 1; { let prod_local_13607 = (prod_local_13599 & prod_local_13606); { let prod_local_13608 = (prod_local_13607 == prod_local_13606); match prod_local_13608 {
        false => prod_local_13598,
        true => { let prod_local_13610 = 1; { let prod_local_13611 = (prod_local_13599).checked_add(prod_local_13610); prod_local_13611 } },
    } } } },
        true => { let prod_local_13613 = 1; { let prod_local_13614 = (prod_local_13599).checked_add(prod_local_13613); prod_local_13614 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_13615) => { let prod_local_13616 = prod_local_13615; { let prod_local_13620 = 128; { let prod_local_13621 = (val_2857 & prod_local_13620); { let prod_local_13622 = 0; { let prod_local_13623 = (prod_local_13621 == prod_local_13622); { let prod_local_13627 = match prod_local_13623 {
        false => { let prod_local_13625 = false; prod_local_13625 },
        true => { let prod_local_13626 = true; prod_local_13626 },
    }; match prod_local_13627 {
        false => { let prod_local_13629 = Some(prod_local_13616); { let prod_local_13630 = round128(prod_local_13629); match prod_local_13630 {
        None => { let prod_local_13631 = prod_local_13630; match prod_local_13631 {
        None => None,
        Some(prod_local_13633) => { let prod_local_13634 = prod_local_13633; { let prod_local_13635 = (prod_local_13634).value; { let prod_local_13636 = low64(prod_local_13635); match prod_local_13636 {
        None => prod_local_13636,
        Some(prod_local_13637) => { let prod_local_13638 = (prod_local_13634).guard; match prod_local_13638 {
        false => prod_local_13636,
        true => { let prod_local_13640 = (prod_local_13634).sticky; match prod_local_13640 {
        false => { let prod_local_13644 = 1; { let prod_local_13645 = (prod_local_13637 & prod_local_13644); { let prod_local_13646 = (prod_local_13645 == prod_local_13644); match prod_local_13646 {
        false => prod_local_13636,
        true => { let prod_local_13648 = 1; { let prod_local_13649 = (prod_local_13637).checked_add(prod_local_13648); prod_local_13649 } },
    } } } },
        true => { let prod_local_13651 = 1; { let prod_local_13652 = (prod_local_13637).checked_add(prod_local_13651); prod_local_13652 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_13653) => { let prod_local_13654 = prod_local_13653; { let prod_local_13655 = prod_local_13654; { let prod_local_13656 = (prod_local_13655).value; { let prod_local_13657 = low64(prod_local_13656); match prod_local_13657 {
        None => prod_local_13657,
        Some(prod_local_13658) => { let prod_local_13659 = (prod_local_13655).guard; match prod_local_13659 {
        false => prod_local_13657,
        true => { let prod_local_13661 = (prod_local_13655).sticky; match prod_local_13661 {
        false => { let prod_local_13665 = 1; { let prod_local_13666 = (prod_local_13658 & prod_local_13665); { let prod_local_13667 = (prod_local_13666 == prod_local_13665); match prod_local_13667 {
        false => prod_local_13657,
        true => { let prod_local_13669 = 1; { let prod_local_13670 = (prod_local_13658).checked_add(prod_local_13669); prod_local_13670 } },
    } } } },
        true => { let prod_local_13672 = 1; { let prod_local_13673 = (prod_local_13658).checked_add(prod_local_13672); prod_local_13673 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_13674 = prod_local_13616; { let prod_local_13675 = prod_local_13674; { let prod_local_13676 = (prod_local_13675).value; { let prod_local_13677 = low64(prod_local_13676); match prod_local_13677 {
        None => prod_local_13677,
        Some(prod_local_13678) => { let prod_local_13679 = (prod_local_13675).guard; match prod_local_13679 {
        false => prod_local_13677,
        true => { let prod_local_13681 = (prod_local_13675).sticky; match prod_local_13681 {
        false => { let prod_local_13685 = 1; { let prod_local_13686 = (prod_local_13678 & prod_local_13685); { let prod_local_13687 = (prod_local_13686 == prod_local_13685); match prod_local_13687 {
        false => prod_local_13677,
        true => { let prod_local_13689 = 1; { let prod_local_13690 = (prod_local_13678).checked_add(prod_local_13689); prod_local_13690 } },
    } } } },
        true => { let prod_local_13692 = 1; { let prod_local_13693 = (prod_local_13678).checked_add(prod_local_13692); prod_local_13693 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_13694 = prod_local_13578; { let prod_local_13698 = 128; { let prod_local_13699 = (val_2857 & prod_local_13698); { let prod_local_13700 = 0; { let prod_local_13701 = (prod_local_13699 == prod_local_13700); { let prod_local_13705 = match prod_local_13701 {
        false => { let prod_local_13703 = false; prod_local_13703 },
        true => { let prod_local_13704 = true; prod_local_13704 },
    }; match prod_local_13705 {
        false => { let prod_local_13707 = Some(prod_local_13694); { let prod_local_13708 = round128(prod_local_13707); match prod_local_13708 {
        None => { let prod_local_13709 = prod_local_13708; match prod_local_13709 {
        None => None,
        Some(prod_local_13711) => { let prod_local_13712 = prod_local_13711; { let prod_local_13713 = (prod_local_13712).value; { let prod_local_13714 = low64(prod_local_13713); match prod_local_13714 {
        None => prod_local_13714,
        Some(prod_local_13715) => { let prod_local_13716 = (prod_local_13712).guard; match prod_local_13716 {
        false => prod_local_13714,
        true => { let prod_local_13718 = (prod_local_13712).sticky; match prod_local_13718 {
        false => { let prod_local_13722 = 1; { let prod_local_13723 = (prod_local_13715 & prod_local_13722); { let prod_local_13724 = (prod_local_13723 == prod_local_13722); match prod_local_13724 {
        false => prod_local_13714,
        true => { let prod_local_13726 = 1; { let prod_local_13727 = (prod_local_13715).checked_add(prod_local_13726); prod_local_13727 } },
    } } } },
        true => { let prod_local_13729 = 1; { let prod_local_13730 = (prod_local_13715).checked_add(prod_local_13729); prod_local_13730 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_13731) => { let prod_local_13732 = prod_local_13731; { let prod_local_13733 = prod_local_13732; { let prod_local_13734 = (prod_local_13733).value; { let prod_local_13735 = low64(prod_local_13734); match prod_local_13735 {
        None => prod_local_13735,
        Some(prod_local_13736) => { let prod_local_13737 = (prod_local_13733).guard; match prod_local_13737 {
        false => prod_local_13735,
        true => { let prod_local_13739 = (prod_local_13733).sticky; match prod_local_13739 {
        false => { let prod_local_13743 = 1; { let prod_local_13744 = (prod_local_13736 & prod_local_13743); { let prod_local_13745 = (prod_local_13744 == prod_local_13743); match prod_local_13745 {
        false => prod_local_13735,
        true => { let prod_local_13747 = 1; { let prod_local_13748 = (prod_local_13736).checked_add(prod_local_13747); prod_local_13748 } },
    } } } },
        true => { let prod_local_13750 = 1; { let prod_local_13751 = (prod_local_13736).checked_add(prod_local_13750); prod_local_13751 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_13752 = prod_local_13694; { let prod_local_13753 = prod_local_13752; { let prod_local_13754 = (prod_local_13753).value; { let prod_local_13755 = low64(prod_local_13754); match prod_local_13755 {
        None => prod_local_13755,
        Some(prod_local_13756) => { let prod_local_13757 = (prod_local_13753).guard; match prod_local_13757 {
        false => prod_local_13755,
        true => { let prod_local_13759 = (prod_local_13753).sticky; match prod_local_13759 {
        false => { let prod_local_13763 = 1; { let prod_local_13764 = (prod_local_13756 & prod_local_13763); { let prod_local_13765 = (prod_local_13764 == prod_local_13763); match prod_local_13765 {
        false => prod_local_13755,
        true => { let prod_local_13767 = 1; { let prod_local_13768 = (prod_local_13756).checked_add(prod_local_13767); prod_local_13768 } },
    } } } },
        true => { let prod_local_13770 = 1; { let prod_local_13771 = (prod_local_13756).checked_add(prod_local_13770); prod_local_13771 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } } } } } },
    } } } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_13772 = prod_local_12844; { let prod_local_13776 = 16; { let prod_local_13777 = (val_2857 & prod_local_13776); { let prod_local_13778 = 0; { let prod_local_13779 = (prod_local_13777 == prod_local_13778); { let prod_local_13783 = match prod_local_13779 {
        false => { let prod_local_13781 = false; prod_local_13781 },
        true => { let prod_local_13782 = true; prod_local_13782 },
    }; match prod_local_13783 {
        false => { let prod_local_13785 = Some(prod_local_13772); { let prod_local_13786 = round16(prod_local_13785); match prod_local_13786 {
        None => { let prod_local_13787 = prod_local_13786; match prod_local_13787 {
        None => None,
        Some(prod_local_13789) => { let prod_local_13790 = prod_local_13789; { let prod_local_13791 = (prod_local_13790).value; { let prod_local_13792 = low64(prod_local_13791); match prod_local_13792 {
        None => prod_local_13792,
        Some(prod_local_13793) => { let prod_local_13794 = (prod_local_13790).guard; match prod_local_13794 {
        false => prod_local_13792,
        true => { let prod_local_13796 = (prod_local_13790).sticky; match prod_local_13796 {
        false => { let prod_local_13800 = 1; { let prod_local_13801 = (prod_local_13793 & prod_local_13800); { let prod_local_13802 = (prod_local_13801 == prod_local_13800); match prod_local_13802 {
        false => prod_local_13792,
        true => { let prod_local_13804 = 1; { let prod_local_13805 = (prod_local_13793).checked_add(prod_local_13804); prod_local_13805 } },
    } } } },
        true => { let prod_local_13807 = 1; { let prod_local_13808 = (prod_local_13793).checked_add(prod_local_13807); prod_local_13808 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_13809) => { let prod_local_13810 = prod_local_13809; { let prod_local_13814 = 32; { let prod_local_13815 = (val_2857 & prod_local_13814); { let prod_local_13816 = 0; { let prod_local_13817 = (prod_local_13815 == prod_local_13816); { let prod_local_13821 = match prod_local_13817 {
        false => { let prod_local_13819 = false; prod_local_13819 },
        true => { let prod_local_13820 = true; prod_local_13820 },
    }; match prod_local_13821 {
        false => { let prod_local_13823 = Some(prod_local_13810); { let prod_local_13824 = round32(prod_local_13823); match prod_local_13824 {
        None => { let prod_local_13825 = prod_local_13824; match prod_local_13825 {
        None => None,
        Some(prod_local_13827) => { let prod_local_13828 = prod_local_13827; { let prod_local_13829 = (prod_local_13828).value; { let prod_local_13830 = low64(prod_local_13829); match prod_local_13830 {
        None => prod_local_13830,
        Some(prod_local_13831) => { let prod_local_13832 = (prod_local_13828).guard; match prod_local_13832 {
        false => prod_local_13830,
        true => { let prod_local_13834 = (prod_local_13828).sticky; match prod_local_13834 {
        false => { let prod_local_13838 = 1; { let prod_local_13839 = (prod_local_13831 & prod_local_13838); { let prod_local_13840 = (prod_local_13839 == prod_local_13838); match prod_local_13840 {
        false => prod_local_13830,
        true => { let prod_local_13842 = 1; { let prod_local_13843 = (prod_local_13831).checked_add(prod_local_13842); prod_local_13843 } },
    } } } },
        true => { let prod_local_13845 = 1; { let prod_local_13846 = (prod_local_13831).checked_add(prod_local_13845); prod_local_13846 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_13847) => { let prod_local_13848 = prod_local_13847; { let prod_local_13852 = 64; { let prod_local_13853 = (val_2857 & prod_local_13852); { let prod_local_13854 = 0; { let prod_local_13855 = (prod_local_13853 == prod_local_13854); { let prod_local_13859 = match prod_local_13855 {
        false => { let prod_local_13857 = false; prod_local_13857 },
        true => { let prod_local_13858 = true; prod_local_13858 },
    }; match prod_local_13859 {
        false => { let prod_local_13861 = Some(prod_local_13848); { let prod_local_13862 = round64(prod_local_13861); match prod_local_13862 {
        None => { let prod_local_13863 = prod_local_13862; match prod_local_13863 {
        None => None,
        Some(prod_local_13865) => { let prod_local_13866 = prod_local_13865; { let prod_local_13867 = (prod_local_13866).value; { let prod_local_13868 = low64(prod_local_13867); match prod_local_13868 {
        None => prod_local_13868,
        Some(prod_local_13869) => { let prod_local_13870 = (prod_local_13866).guard; match prod_local_13870 {
        false => prod_local_13868,
        true => { let prod_local_13872 = (prod_local_13866).sticky; match prod_local_13872 {
        false => { let prod_local_13876 = 1; { let prod_local_13877 = (prod_local_13869 & prod_local_13876); { let prod_local_13878 = (prod_local_13877 == prod_local_13876); match prod_local_13878 {
        false => prod_local_13868,
        true => { let prod_local_13880 = 1; { let prod_local_13881 = (prod_local_13869).checked_add(prod_local_13880); prod_local_13881 } },
    } } } },
        true => { let prod_local_13883 = 1; { let prod_local_13884 = (prod_local_13869).checked_add(prod_local_13883); prod_local_13884 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_13885) => { let prod_local_13886 = prod_local_13885; { let prod_local_13890 = 128; { let prod_local_13891 = (val_2857 & prod_local_13890); { let prod_local_13892 = 0; { let prod_local_13893 = (prod_local_13891 == prod_local_13892); { let prod_local_13897 = match prod_local_13893 {
        false => { let prod_local_13895 = false; prod_local_13895 },
        true => { let prod_local_13896 = true; prod_local_13896 },
    }; match prod_local_13897 {
        false => { let prod_local_13899 = Some(prod_local_13886); { let prod_local_13900 = round128(prod_local_13899); match prod_local_13900 {
        None => { let prod_local_13901 = prod_local_13900; match prod_local_13901 {
        None => None,
        Some(prod_local_13903) => { let prod_local_13904 = prod_local_13903; { let prod_local_13905 = (prod_local_13904).value; { let prod_local_13906 = low64(prod_local_13905); match prod_local_13906 {
        None => prod_local_13906,
        Some(prod_local_13907) => { let prod_local_13908 = (prod_local_13904).guard; match prod_local_13908 {
        false => prod_local_13906,
        true => { let prod_local_13910 = (prod_local_13904).sticky; match prod_local_13910 {
        false => { let prod_local_13914 = 1; { let prod_local_13915 = (prod_local_13907 & prod_local_13914); { let prod_local_13916 = (prod_local_13915 == prod_local_13914); match prod_local_13916 {
        false => prod_local_13906,
        true => { let prod_local_13918 = 1; { let prod_local_13919 = (prod_local_13907).checked_add(prod_local_13918); prod_local_13919 } },
    } } } },
        true => { let prod_local_13921 = 1; { let prod_local_13922 = (prod_local_13907).checked_add(prod_local_13921); prod_local_13922 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_13923) => { let prod_local_13924 = prod_local_13923; { let prod_local_13925 = prod_local_13924; { let prod_local_13926 = (prod_local_13925).value; { let prod_local_13927 = low64(prod_local_13926); match prod_local_13927 {
        None => prod_local_13927,
        Some(prod_local_13928) => { let prod_local_13929 = (prod_local_13925).guard; match prod_local_13929 {
        false => prod_local_13927,
        true => { let prod_local_13931 = (prod_local_13925).sticky; match prod_local_13931 {
        false => { let prod_local_13935 = 1; { let prod_local_13936 = (prod_local_13928 & prod_local_13935); { let prod_local_13937 = (prod_local_13936 == prod_local_13935); match prod_local_13937 {
        false => prod_local_13927,
        true => { let prod_local_13939 = 1; { let prod_local_13940 = (prod_local_13928).checked_add(prod_local_13939); prod_local_13940 } },
    } } } },
        true => { let prod_local_13942 = 1; { let prod_local_13943 = (prod_local_13928).checked_add(prod_local_13942); prod_local_13943 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_13944 = prod_local_13886; { let prod_local_13945 = prod_local_13944; { let prod_local_13946 = (prod_local_13945).value; { let prod_local_13947 = low64(prod_local_13946); match prod_local_13947 {
        None => prod_local_13947,
        Some(prod_local_13948) => { let prod_local_13949 = (prod_local_13945).guard; match prod_local_13949 {
        false => prod_local_13947,
        true => { let prod_local_13951 = (prod_local_13945).sticky; match prod_local_13951 {
        false => { let prod_local_13955 = 1; { let prod_local_13956 = (prod_local_13948 & prod_local_13955); { let prod_local_13957 = (prod_local_13956 == prod_local_13955); match prod_local_13957 {
        false => prod_local_13947,
        true => { let prod_local_13959 = 1; { let prod_local_13960 = (prod_local_13948).checked_add(prod_local_13959); prod_local_13960 } },
    } } } },
        true => { let prod_local_13962 = 1; { let prod_local_13963 = (prod_local_13948).checked_add(prod_local_13962); prod_local_13963 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_13964 = prod_local_13848; { let prod_local_13968 = 128; { let prod_local_13969 = (val_2857 & prod_local_13968); { let prod_local_13970 = 0; { let prod_local_13971 = (prod_local_13969 == prod_local_13970); { let prod_local_13975 = match prod_local_13971 {
        false => { let prod_local_13973 = false; prod_local_13973 },
        true => { let prod_local_13974 = true; prod_local_13974 },
    }; match prod_local_13975 {
        false => { let prod_local_13977 = Some(prod_local_13964); { let prod_local_13978 = round128(prod_local_13977); match prod_local_13978 {
        None => { let prod_local_13979 = prod_local_13978; match prod_local_13979 {
        None => None,
        Some(prod_local_13981) => { let prod_local_13982 = prod_local_13981; { let prod_local_13983 = (prod_local_13982).value; { let prod_local_13984 = low64(prod_local_13983); match prod_local_13984 {
        None => prod_local_13984,
        Some(prod_local_13985) => { let prod_local_13986 = (prod_local_13982).guard; match prod_local_13986 {
        false => prod_local_13984,
        true => { let prod_local_13988 = (prod_local_13982).sticky; match prod_local_13988 {
        false => { let prod_local_13992 = 1; { let prod_local_13993 = (prod_local_13985 & prod_local_13992); { let prod_local_13994 = (prod_local_13993 == prod_local_13992); match prod_local_13994 {
        false => prod_local_13984,
        true => { let prod_local_13996 = 1; { let prod_local_13997 = (prod_local_13985).checked_add(prod_local_13996); prod_local_13997 } },
    } } } },
        true => { let prod_local_13999 = 1; { let prod_local_14000 = (prod_local_13985).checked_add(prod_local_13999); prod_local_14000 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_14001) => { let prod_local_14002 = prod_local_14001; { let prod_local_14003 = prod_local_14002; { let prod_local_14004 = (prod_local_14003).value; { let prod_local_14005 = low64(prod_local_14004); match prod_local_14005 {
        None => prod_local_14005,
        Some(prod_local_14006) => { let prod_local_14007 = (prod_local_14003).guard; match prod_local_14007 {
        false => prod_local_14005,
        true => { let prod_local_14009 = (prod_local_14003).sticky; match prod_local_14009 {
        false => { let prod_local_14013 = 1; { let prod_local_14014 = (prod_local_14006 & prod_local_14013); { let prod_local_14015 = (prod_local_14014 == prod_local_14013); match prod_local_14015 {
        false => prod_local_14005,
        true => { let prod_local_14017 = 1; { let prod_local_14018 = (prod_local_14006).checked_add(prod_local_14017); prod_local_14018 } },
    } } } },
        true => { let prod_local_14020 = 1; { let prod_local_14021 = (prod_local_14006).checked_add(prod_local_14020); prod_local_14021 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_14022 = prod_local_13964; { let prod_local_14023 = prod_local_14022; { let prod_local_14024 = (prod_local_14023).value; { let prod_local_14025 = low64(prod_local_14024); match prod_local_14025 {
        None => prod_local_14025,
        Some(prod_local_14026) => { let prod_local_14027 = (prod_local_14023).guard; match prod_local_14027 {
        false => prod_local_14025,
        true => { let prod_local_14029 = (prod_local_14023).sticky; match prod_local_14029 {
        false => { let prod_local_14033 = 1; { let prod_local_14034 = (prod_local_14026 & prod_local_14033); { let prod_local_14035 = (prod_local_14034 == prod_local_14033); match prod_local_14035 {
        false => prod_local_14025,
        true => { let prod_local_14037 = 1; { let prod_local_14038 = (prod_local_14026).checked_add(prod_local_14037); prod_local_14038 } },
    } } } },
        true => { let prod_local_14040 = 1; { let prod_local_14041 = (prod_local_14026).checked_add(prod_local_14040); prod_local_14041 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_14042 = prod_local_13810; { let prod_local_14046 = 64; { let prod_local_14047 = (val_2857 & prod_local_14046); { let prod_local_14048 = 0; { let prod_local_14049 = (prod_local_14047 == prod_local_14048); { let prod_local_14053 = match prod_local_14049 {
        false => { let prod_local_14051 = false; prod_local_14051 },
        true => { let prod_local_14052 = true; prod_local_14052 },
    }; match prod_local_14053 {
        false => { let prod_local_14055 = Some(prod_local_14042); { let prod_local_14056 = round64(prod_local_14055); match prod_local_14056 {
        None => { let prod_local_14057 = prod_local_14056; match prod_local_14057 {
        None => None,
        Some(prod_local_14059) => { let prod_local_14060 = prod_local_14059; { let prod_local_14061 = (prod_local_14060).value; { let prod_local_14062 = low64(prod_local_14061); match prod_local_14062 {
        None => prod_local_14062,
        Some(prod_local_14063) => { let prod_local_14064 = (prod_local_14060).guard; match prod_local_14064 {
        false => prod_local_14062,
        true => { let prod_local_14066 = (prod_local_14060).sticky; match prod_local_14066 {
        false => { let prod_local_14070 = 1; { let prod_local_14071 = (prod_local_14063 & prod_local_14070); { let prod_local_14072 = (prod_local_14071 == prod_local_14070); match prod_local_14072 {
        false => prod_local_14062,
        true => { let prod_local_14074 = 1; { let prod_local_14075 = (prod_local_14063).checked_add(prod_local_14074); prod_local_14075 } },
    } } } },
        true => { let prod_local_14077 = 1; { let prod_local_14078 = (prod_local_14063).checked_add(prod_local_14077); prod_local_14078 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_14079) => { let prod_local_14080 = prod_local_14079; { let prod_local_14084 = 128; { let prod_local_14085 = (val_2857 & prod_local_14084); { let prod_local_14086 = 0; { let prod_local_14087 = (prod_local_14085 == prod_local_14086); { let prod_local_14091 = match prod_local_14087 {
        false => { let prod_local_14089 = false; prod_local_14089 },
        true => { let prod_local_14090 = true; prod_local_14090 },
    }; match prod_local_14091 {
        false => { let prod_local_14093 = Some(prod_local_14080); { let prod_local_14094 = round128(prod_local_14093); match prod_local_14094 {
        None => { let prod_local_14095 = prod_local_14094; match prod_local_14095 {
        None => None,
        Some(prod_local_14097) => { let prod_local_14098 = prod_local_14097; { let prod_local_14099 = (prod_local_14098).value; { let prod_local_14100 = low64(prod_local_14099); match prod_local_14100 {
        None => prod_local_14100,
        Some(prod_local_14101) => { let prod_local_14102 = (prod_local_14098).guard; match prod_local_14102 {
        false => prod_local_14100,
        true => { let prod_local_14104 = (prod_local_14098).sticky; match prod_local_14104 {
        false => { let prod_local_14108 = 1; { let prod_local_14109 = (prod_local_14101 & prod_local_14108); { let prod_local_14110 = (prod_local_14109 == prod_local_14108); match prod_local_14110 {
        false => prod_local_14100,
        true => { let prod_local_14112 = 1; { let prod_local_14113 = (prod_local_14101).checked_add(prod_local_14112); prod_local_14113 } },
    } } } },
        true => { let prod_local_14115 = 1; { let prod_local_14116 = (prod_local_14101).checked_add(prod_local_14115); prod_local_14116 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_14117) => { let prod_local_14118 = prod_local_14117; { let prod_local_14119 = prod_local_14118; { let prod_local_14120 = (prod_local_14119).value; { let prod_local_14121 = low64(prod_local_14120); match prod_local_14121 {
        None => prod_local_14121,
        Some(prod_local_14122) => { let prod_local_14123 = (prod_local_14119).guard; match prod_local_14123 {
        false => prod_local_14121,
        true => { let prod_local_14125 = (prod_local_14119).sticky; match prod_local_14125 {
        false => { let prod_local_14129 = 1; { let prod_local_14130 = (prod_local_14122 & prod_local_14129); { let prod_local_14131 = (prod_local_14130 == prod_local_14129); match prod_local_14131 {
        false => prod_local_14121,
        true => { let prod_local_14133 = 1; { let prod_local_14134 = (prod_local_14122).checked_add(prod_local_14133); prod_local_14134 } },
    } } } },
        true => { let prod_local_14136 = 1; { let prod_local_14137 = (prod_local_14122).checked_add(prod_local_14136); prod_local_14137 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_14138 = prod_local_14080; { let prod_local_14139 = prod_local_14138; { let prod_local_14140 = (prod_local_14139).value; { let prod_local_14141 = low64(prod_local_14140); match prod_local_14141 {
        None => prod_local_14141,
        Some(prod_local_14142) => { let prod_local_14143 = (prod_local_14139).guard; match prod_local_14143 {
        false => prod_local_14141,
        true => { let prod_local_14145 = (prod_local_14139).sticky; match prod_local_14145 {
        false => { let prod_local_14149 = 1; { let prod_local_14150 = (prod_local_14142 & prod_local_14149); { let prod_local_14151 = (prod_local_14150 == prod_local_14149); match prod_local_14151 {
        false => prod_local_14141,
        true => { let prod_local_14153 = 1; { let prod_local_14154 = (prod_local_14142).checked_add(prod_local_14153); prod_local_14154 } },
    } } } },
        true => { let prod_local_14156 = 1; { let prod_local_14157 = (prod_local_14142).checked_add(prod_local_14156); prod_local_14157 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_14158 = prod_local_14042; { let prod_local_14162 = 128; { let prod_local_14163 = (val_2857 & prod_local_14162); { let prod_local_14164 = 0; { let prod_local_14165 = (prod_local_14163 == prod_local_14164); { let prod_local_14169 = match prod_local_14165 {
        false => { let prod_local_14167 = false; prod_local_14167 },
        true => { let prod_local_14168 = true; prod_local_14168 },
    }; match prod_local_14169 {
        false => { let prod_local_14171 = Some(prod_local_14158); { let prod_local_14172 = round128(prod_local_14171); match prod_local_14172 {
        None => { let prod_local_14173 = prod_local_14172; match prod_local_14173 {
        None => None,
        Some(prod_local_14175) => { let prod_local_14176 = prod_local_14175; { let prod_local_14177 = (prod_local_14176).value; { let prod_local_14178 = low64(prod_local_14177); match prod_local_14178 {
        None => prod_local_14178,
        Some(prod_local_14179) => { let prod_local_14180 = (prod_local_14176).guard; match prod_local_14180 {
        false => prod_local_14178,
        true => { let prod_local_14182 = (prod_local_14176).sticky; match prod_local_14182 {
        false => { let prod_local_14186 = 1; { let prod_local_14187 = (prod_local_14179 & prod_local_14186); { let prod_local_14188 = (prod_local_14187 == prod_local_14186); match prod_local_14188 {
        false => prod_local_14178,
        true => { let prod_local_14190 = 1; { let prod_local_14191 = (prod_local_14179).checked_add(prod_local_14190); prod_local_14191 } },
    } } } },
        true => { let prod_local_14193 = 1; { let prod_local_14194 = (prod_local_14179).checked_add(prod_local_14193); prod_local_14194 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_14195) => { let prod_local_14196 = prod_local_14195; { let prod_local_14197 = prod_local_14196; { let prod_local_14198 = (prod_local_14197).value; { let prod_local_14199 = low64(prod_local_14198); match prod_local_14199 {
        None => prod_local_14199,
        Some(prod_local_14200) => { let prod_local_14201 = (prod_local_14197).guard; match prod_local_14201 {
        false => prod_local_14199,
        true => { let prod_local_14203 = (prod_local_14197).sticky; match prod_local_14203 {
        false => { let prod_local_14207 = 1; { let prod_local_14208 = (prod_local_14200 & prod_local_14207); { let prod_local_14209 = (prod_local_14208 == prod_local_14207); match prod_local_14209 {
        false => prod_local_14199,
        true => { let prod_local_14211 = 1; { let prod_local_14212 = (prod_local_14200).checked_add(prod_local_14211); prod_local_14212 } },
    } } } },
        true => { let prod_local_14214 = 1; { let prod_local_14215 = (prod_local_14200).checked_add(prod_local_14214); prod_local_14215 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_14216 = prod_local_14158; { let prod_local_14217 = prod_local_14216; { let prod_local_14218 = (prod_local_14217).value; { let prod_local_14219 = low64(prod_local_14218); match prod_local_14219 {
        None => prod_local_14219,
        Some(prod_local_14220) => { let prod_local_14221 = (prod_local_14217).guard; match prod_local_14221 {
        false => prod_local_14219,
        true => { let prod_local_14223 = (prod_local_14217).sticky; match prod_local_14223 {
        false => { let prod_local_14227 = 1; { let prod_local_14228 = (prod_local_14220 & prod_local_14227); { let prod_local_14229 = (prod_local_14228 == prod_local_14227); match prod_local_14229 {
        false => prod_local_14219,
        true => { let prod_local_14231 = 1; { let prod_local_14232 = (prod_local_14220).checked_add(prod_local_14231); prod_local_14232 } },
    } } } },
        true => { let prod_local_14234 = 1; { let prod_local_14235 = (prod_local_14220).checked_add(prod_local_14234); prod_local_14235 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_14236 = prod_local_13772; { let prod_local_14240 = 32; { let prod_local_14241 = (val_2857 & prod_local_14240); { let prod_local_14242 = 0; { let prod_local_14243 = (prod_local_14241 == prod_local_14242); { let prod_local_14247 = match prod_local_14243 {
        false => { let prod_local_14245 = false; prod_local_14245 },
        true => { let prod_local_14246 = true; prod_local_14246 },
    }; match prod_local_14247 {
        false => { let prod_local_14249 = Some(prod_local_14236); { let prod_local_14250 = round32(prod_local_14249); match prod_local_14250 {
        None => { let prod_local_14251 = prod_local_14250; match prod_local_14251 {
        None => None,
        Some(prod_local_14253) => { let prod_local_14254 = prod_local_14253; { let prod_local_14255 = (prod_local_14254).value; { let prod_local_14256 = low64(prod_local_14255); match prod_local_14256 {
        None => prod_local_14256,
        Some(prod_local_14257) => { let prod_local_14258 = (prod_local_14254).guard; match prod_local_14258 {
        false => prod_local_14256,
        true => { let prod_local_14260 = (prod_local_14254).sticky; match prod_local_14260 {
        false => { let prod_local_14264 = 1; { let prod_local_14265 = (prod_local_14257 & prod_local_14264); { let prod_local_14266 = (prod_local_14265 == prod_local_14264); match prod_local_14266 {
        false => prod_local_14256,
        true => { let prod_local_14268 = 1; { let prod_local_14269 = (prod_local_14257).checked_add(prod_local_14268); prod_local_14269 } },
    } } } },
        true => { let prod_local_14271 = 1; { let prod_local_14272 = (prod_local_14257).checked_add(prod_local_14271); prod_local_14272 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_14273) => { let prod_local_14274 = prod_local_14273; { let prod_local_14278 = 64; { let prod_local_14279 = (val_2857 & prod_local_14278); { let prod_local_14280 = 0; { let prod_local_14281 = (prod_local_14279 == prod_local_14280); { let prod_local_14285 = match prod_local_14281 {
        false => { let prod_local_14283 = false; prod_local_14283 },
        true => { let prod_local_14284 = true; prod_local_14284 },
    }; match prod_local_14285 {
        false => { let prod_local_14287 = Some(prod_local_14274); { let prod_local_14288 = round64(prod_local_14287); match prod_local_14288 {
        None => { let prod_local_14289 = prod_local_14288; match prod_local_14289 {
        None => None,
        Some(prod_local_14291) => { let prod_local_14292 = prod_local_14291; { let prod_local_14293 = (prod_local_14292).value; { let prod_local_14294 = low64(prod_local_14293); match prod_local_14294 {
        None => prod_local_14294,
        Some(prod_local_14295) => { let prod_local_14296 = (prod_local_14292).guard; match prod_local_14296 {
        false => prod_local_14294,
        true => { let prod_local_14298 = (prod_local_14292).sticky; match prod_local_14298 {
        false => { let prod_local_14302 = 1; { let prod_local_14303 = (prod_local_14295 & prod_local_14302); { let prod_local_14304 = (prod_local_14303 == prod_local_14302); match prod_local_14304 {
        false => prod_local_14294,
        true => { let prod_local_14306 = 1; { let prod_local_14307 = (prod_local_14295).checked_add(prod_local_14306); prod_local_14307 } },
    } } } },
        true => { let prod_local_14309 = 1; { let prod_local_14310 = (prod_local_14295).checked_add(prod_local_14309); prod_local_14310 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_14311) => { let prod_local_14312 = prod_local_14311; { let prod_local_14316 = 128; { let prod_local_14317 = (val_2857 & prod_local_14316); { let prod_local_14318 = 0; { let prod_local_14319 = (prod_local_14317 == prod_local_14318); { let prod_local_14323 = match prod_local_14319 {
        false => { let prod_local_14321 = false; prod_local_14321 },
        true => { let prod_local_14322 = true; prod_local_14322 },
    }; match prod_local_14323 {
        false => { let prod_local_14325 = Some(prod_local_14312); { let prod_local_14326 = round128(prod_local_14325); match prod_local_14326 {
        None => { let prod_local_14327 = prod_local_14326; match prod_local_14327 {
        None => None,
        Some(prod_local_14329) => { let prod_local_14330 = prod_local_14329; { let prod_local_14331 = (prod_local_14330).value; { let prod_local_14332 = low64(prod_local_14331); match prod_local_14332 {
        None => prod_local_14332,
        Some(prod_local_14333) => { let prod_local_14334 = (prod_local_14330).guard; match prod_local_14334 {
        false => prod_local_14332,
        true => { let prod_local_14336 = (prod_local_14330).sticky; match prod_local_14336 {
        false => { let prod_local_14340 = 1; { let prod_local_14341 = (prod_local_14333 & prod_local_14340); { let prod_local_14342 = (prod_local_14341 == prod_local_14340); match prod_local_14342 {
        false => prod_local_14332,
        true => { let prod_local_14344 = 1; { let prod_local_14345 = (prod_local_14333).checked_add(prod_local_14344); prod_local_14345 } },
    } } } },
        true => { let prod_local_14347 = 1; { let prod_local_14348 = (prod_local_14333).checked_add(prod_local_14347); prod_local_14348 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_14349) => { let prod_local_14350 = prod_local_14349; { let prod_local_14351 = prod_local_14350; { let prod_local_14352 = (prod_local_14351).value; { let prod_local_14353 = low64(prod_local_14352); match prod_local_14353 {
        None => prod_local_14353,
        Some(prod_local_14354) => { let prod_local_14355 = (prod_local_14351).guard; match prod_local_14355 {
        false => prod_local_14353,
        true => { let prod_local_14357 = (prod_local_14351).sticky; match prod_local_14357 {
        false => { let prod_local_14361 = 1; { let prod_local_14362 = (prod_local_14354 & prod_local_14361); { let prod_local_14363 = (prod_local_14362 == prod_local_14361); match prod_local_14363 {
        false => prod_local_14353,
        true => { let prod_local_14365 = 1; { let prod_local_14366 = (prod_local_14354).checked_add(prod_local_14365); prod_local_14366 } },
    } } } },
        true => { let prod_local_14368 = 1; { let prod_local_14369 = (prod_local_14354).checked_add(prod_local_14368); prod_local_14369 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_14370 = prod_local_14312; { let prod_local_14371 = prod_local_14370; { let prod_local_14372 = (prod_local_14371).value; { let prod_local_14373 = low64(prod_local_14372); match prod_local_14373 {
        None => prod_local_14373,
        Some(prod_local_14374) => { let prod_local_14375 = (prod_local_14371).guard; match prod_local_14375 {
        false => prod_local_14373,
        true => { let prod_local_14377 = (prod_local_14371).sticky; match prod_local_14377 {
        false => { let prod_local_14381 = 1; { let prod_local_14382 = (prod_local_14374 & prod_local_14381); { let prod_local_14383 = (prod_local_14382 == prod_local_14381); match prod_local_14383 {
        false => prod_local_14373,
        true => { let prod_local_14385 = 1; { let prod_local_14386 = (prod_local_14374).checked_add(prod_local_14385); prod_local_14386 } },
    } } } },
        true => { let prod_local_14388 = 1; { let prod_local_14389 = (prod_local_14374).checked_add(prod_local_14388); prod_local_14389 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_14390 = prod_local_14274; { let prod_local_14394 = 128; { let prod_local_14395 = (val_2857 & prod_local_14394); { let prod_local_14396 = 0; { let prod_local_14397 = (prod_local_14395 == prod_local_14396); { let prod_local_14401 = match prod_local_14397 {
        false => { let prod_local_14399 = false; prod_local_14399 },
        true => { let prod_local_14400 = true; prod_local_14400 },
    }; match prod_local_14401 {
        false => { let prod_local_14403 = Some(prod_local_14390); { let prod_local_14404 = round128(prod_local_14403); match prod_local_14404 {
        None => { let prod_local_14405 = prod_local_14404; match prod_local_14405 {
        None => None,
        Some(prod_local_14407) => { let prod_local_14408 = prod_local_14407; { let prod_local_14409 = (prod_local_14408).value; { let prod_local_14410 = low64(prod_local_14409); match prod_local_14410 {
        None => prod_local_14410,
        Some(prod_local_14411) => { let prod_local_14412 = (prod_local_14408).guard; match prod_local_14412 {
        false => prod_local_14410,
        true => { let prod_local_14414 = (prod_local_14408).sticky; match prod_local_14414 {
        false => { let prod_local_14418 = 1; { let prod_local_14419 = (prod_local_14411 & prod_local_14418); { let prod_local_14420 = (prod_local_14419 == prod_local_14418); match prod_local_14420 {
        false => prod_local_14410,
        true => { let prod_local_14422 = 1; { let prod_local_14423 = (prod_local_14411).checked_add(prod_local_14422); prod_local_14423 } },
    } } } },
        true => { let prod_local_14425 = 1; { let prod_local_14426 = (prod_local_14411).checked_add(prod_local_14425); prod_local_14426 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_14427) => { let prod_local_14428 = prod_local_14427; { let prod_local_14429 = prod_local_14428; { let prod_local_14430 = (prod_local_14429).value; { let prod_local_14431 = low64(prod_local_14430); match prod_local_14431 {
        None => prod_local_14431,
        Some(prod_local_14432) => { let prod_local_14433 = (prod_local_14429).guard; match prod_local_14433 {
        false => prod_local_14431,
        true => { let prod_local_14435 = (prod_local_14429).sticky; match prod_local_14435 {
        false => { let prod_local_14439 = 1; { let prod_local_14440 = (prod_local_14432 & prod_local_14439); { let prod_local_14441 = (prod_local_14440 == prod_local_14439); match prod_local_14441 {
        false => prod_local_14431,
        true => { let prod_local_14443 = 1; { let prod_local_14444 = (prod_local_14432).checked_add(prod_local_14443); prod_local_14444 } },
    } } } },
        true => { let prod_local_14446 = 1; { let prod_local_14447 = (prod_local_14432).checked_add(prod_local_14446); prod_local_14447 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_14448 = prod_local_14390; { let prod_local_14449 = prod_local_14448; { let prod_local_14450 = (prod_local_14449).value; { let prod_local_14451 = low64(prod_local_14450); match prod_local_14451 {
        None => prod_local_14451,
        Some(prod_local_14452) => { let prod_local_14453 = (prod_local_14449).guard; match prod_local_14453 {
        false => prod_local_14451,
        true => { let prod_local_14455 = (prod_local_14449).sticky; match prod_local_14455 {
        false => { let prod_local_14459 = 1; { let prod_local_14460 = (prod_local_14452 & prod_local_14459); { let prod_local_14461 = (prod_local_14460 == prod_local_14459); match prod_local_14461 {
        false => prod_local_14451,
        true => { let prod_local_14463 = 1; { let prod_local_14464 = (prod_local_14452).checked_add(prod_local_14463); prod_local_14464 } },
    } } } },
        true => { let prod_local_14466 = 1; { let prod_local_14467 = (prod_local_14452).checked_add(prod_local_14466); prod_local_14467 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_14468 = prod_local_14236; { let prod_local_14472 = 64; { let prod_local_14473 = (val_2857 & prod_local_14472); { let prod_local_14474 = 0; { let prod_local_14475 = (prod_local_14473 == prod_local_14474); { let prod_local_14479 = match prod_local_14475 {
        false => { let prod_local_14477 = false; prod_local_14477 },
        true => { let prod_local_14478 = true; prod_local_14478 },
    }; match prod_local_14479 {
        false => { let prod_local_14481 = Some(prod_local_14468); { let prod_local_14482 = round64(prod_local_14481); match prod_local_14482 {
        None => { let prod_local_14483 = prod_local_14482; match prod_local_14483 {
        None => None,
        Some(prod_local_14485) => { let prod_local_14486 = prod_local_14485; { let prod_local_14487 = (prod_local_14486).value; { let prod_local_14488 = low64(prod_local_14487); match prod_local_14488 {
        None => prod_local_14488,
        Some(prod_local_14489) => { let prod_local_14490 = (prod_local_14486).guard; match prod_local_14490 {
        false => prod_local_14488,
        true => { let prod_local_14492 = (prod_local_14486).sticky; match prod_local_14492 {
        false => { let prod_local_14496 = 1; { let prod_local_14497 = (prod_local_14489 & prod_local_14496); { let prod_local_14498 = (prod_local_14497 == prod_local_14496); match prod_local_14498 {
        false => prod_local_14488,
        true => { let prod_local_14500 = 1; { let prod_local_14501 = (prod_local_14489).checked_add(prod_local_14500); prod_local_14501 } },
    } } } },
        true => { let prod_local_14503 = 1; { let prod_local_14504 = (prod_local_14489).checked_add(prod_local_14503); prod_local_14504 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_14505) => { let prod_local_14506 = prod_local_14505; { let prod_local_14510 = 128; { let prod_local_14511 = (val_2857 & prod_local_14510); { let prod_local_14512 = 0; { let prod_local_14513 = (prod_local_14511 == prod_local_14512); { let prod_local_14517 = match prod_local_14513 {
        false => { let prod_local_14515 = false; prod_local_14515 },
        true => { let prod_local_14516 = true; prod_local_14516 },
    }; match prod_local_14517 {
        false => { let prod_local_14519 = Some(prod_local_14506); { let prod_local_14520 = round128(prod_local_14519); match prod_local_14520 {
        None => { let prod_local_14521 = prod_local_14520; match prod_local_14521 {
        None => None,
        Some(prod_local_14523) => { let prod_local_14524 = prod_local_14523; { let prod_local_14525 = (prod_local_14524).value; { let prod_local_14526 = low64(prod_local_14525); match prod_local_14526 {
        None => prod_local_14526,
        Some(prod_local_14527) => { let prod_local_14528 = (prod_local_14524).guard; match prod_local_14528 {
        false => prod_local_14526,
        true => { let prod_local_14530 = (prod_local_14524).sticky; match prod_local_14530 {
        false => { let prod_local_14534 = 1; { let prod_local_14535 = (prod_local_14527 & prod_local_14534); { let prod_local_14536 = (prod_local_14535 == prod_local_14534); match prod_local_14536 {
        false => prod_local_14526,
        true => { let prod_local_14538 = 1; { let prod_local_14539 = (prod_local_14527).checked_add(prod_local_14538); prod_local_14539 } },
    } } } },
        true => { let prod_local_14541 = 1; { let prod_local_14542 = (prod_local_14527).checked_add(prod_local_14541); prod_local_14542 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_14543) => { let prod_local_14544 = prod_local_14543; { let prod_local_14545 = prod_local_14544; { let prod_local_14546 = (prod_local_14545).value; { let prod_local_14547 = low64(prod_local_14546); match prod_local_14547 {
        None => prod_local_14547,
        Some(prod_local_14548) => { let prod_local_14549 = (prod_local_14545).guard; match prod_local_14549 {
        false => prod_local_14547,
        true => { let prod_local_14551 = (prod_local_14545).sticky; match prod_local_14551 {
        false => { let prod_local_14555 = 1; { let prod_local_14556 = (prod_local_14548 & prod_local_14555); { let prod_local_14557 = (prod_local_14556 == prod_local_14555); match prod_local_14557 {
        false => prod_local_14547,
        true => { let prod_local_14559 = 1; { let prod_local_14560 = (prod_local_14548).checked_add(prod_local_14559); prod_local_14560 } },
    } } } },
        true => { let prod_local_14562 = 1; { let prod_local_14563 = (prod_local_14548).checked_add(prod_local_14562); prod_local_14563 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_14564 = prod_local_14506; { let prod_local_14565 = prod_local_14564; { let prod_local_14566 = (prod_local_14565).value; { let prod_local_14567 = low64(prod_local_14566); match prod_local_14567 {
        None => prod_local_14567,
        Some(prod_local_14568) => { let prod_local_14569 = (prod_local_14565).guard; match prod_local_14569 {
        false => prod_local_14567,
        true => { let prod_local_14571 = (prod_local_14565).sticky; match prod_local_14571 {
        false => { let prod_local_14575 = 1; { let prod_local_14576 = (prod_local_14568 & prod_local_14575); { let prod_local_14577 = (prod_local_14576 == prod_local_14575); match prod_local_14577 {
        false => prod_local_14567,
        true => { let prod_local_14579 = 1; { let prod_local_14580 = (prod_local_14568).checked_add(prod_local_14579); prod_local_14580 } },
    } } } },
        true => { let prod_local_14582 = 1; { let prod_local_14583 = (prod_local_14568).checked_add(prod_local_14582); prod_local_14583 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } },
        true => { let prod_local_14584 = prod_local_14468; { let prod_local_14588 = 128; { let prod_local_14589 = (val_2857 & prod_local_14588); { let prod_local_14590 = 0; { let prod_local_14591 = (prod_local_14589 == prod_local_14590); { let prod_local_14595 = match prod_local_14591 {
        false => { let prod_local_14593 = false; prod_local_14593 },
        true => { let prod_local_14594 = true; prod_local_14594 },
    }; match prod_local_14595 {
        false => { let prod_local_14597 = Some(prod_local_14584); { let prod_local_14598 = round128(prod_local_14597); match prod_local_14598 {
        None => { let prod_local_14599 = prod_local_14598; match prod_local_14599 {
        None => None,
        Some(prod_local_14601) => { let prod_local_14602 = prod_local_14601; { let prod_local_14603 = (prod_local_14602).value; { let prod_local_14604 = low64(prod_local_14603); match prod_local_14604 {
        None => prod_local_14604,
        Some(prod_local_14605) => { let prod_local_14606 = (prod_local_14602).guard; match prod_local_14606 {
        false => prod_local_14604,
        true => { let prod_local_14608 = (prod_local_14602).sticky; match prod_local_14608 {
        false => { let prod_local_14612 = 1; { let prod_local_14613 = (prod_local_14605 & prod_local_14612); { let prod_local_14614 = (prod_local_14613 == prod_local_14612); match prod_local_14614 {
        false => prod_local_14604,
        true => { let prod_local_14616 = 1; { let prod_local_14617 = (prod_local_14605).checked_add(prod_local_14616); prod_local_14617 } },
    } } } },
        true => { let prod_local_14619 = 1; { let prod_local_14620 = (prod_local_14605).checked_add(prod_local_14619); prod_local_14620 } },
    } },
    } },
    } } } },
    } },
        Some(prod_local_14621) => { let prod_local_14622 = prod_local_14621; { let prod_local_14623 = prod_local_14622; { let prod_local_14624 = (prod_local_14623).value; { let prod_local_14625 = low64(prod_local_14624); match prod_local_14625 {
        None => prod_local_14625,
        Some(prod_local_14626) => { let prod_local_14627 = (prod_local_14623).guard; match prod_local_14627 {
        false => prod_local_14625,
        true => { let prod_local_14629 = (prod_local_14623).sticky; match prod_local_14629 {
        false => { let prod_local_14633 = 1; { let prod_local_14634 = (prod_local_14626 & prod_local_14633); { let prod_local_14635 = (prod_local_14634 == prod_local_14633); match prod_local_14635 {
        false => prod_local_14625,
        true => { let prod_local_14637 = 1; { let prod_local_14638 = (prod_local_14626).checked_add(prod_local_14637); prod_local_14638 } },
    } } } },
        true => { let prod_local_14640 = 1; { let prod_local_14641 = (prod_local_14626).checked_add(prod_local_14640); prod_local_14641 } },
    } },
    } },
    } } } } },
    } } },
        true => { let prod_local_14642 = prod_local_14584; { let prod_local_14643 = prod_local_14642; { let prod_local_14644 = (prod_local_14643).value; { let prod_local_14645 = low64(prod_local_14644); match prod_local_14645 {
        None => prod_local_14645,
        Some(prod_local_14646) => { let prod_local_14647 = (prod_local_14643).guard; match prod_local_14647 {
        false => prod_local_14645,
        true => { let prod_local_14649 = (prod_local_14643).sticky; match prod_local_14649 {
        false => { let prod_local_14653 = 1; { let prod_local_14654 = (prod_local_14646 & prod_local_14653); { let prod_local_14655 = (prod_local_14654 == prod_local_14653); match prod_local_14655 {
        false => prod_local_14645,
        true => { let prod_local_14657 = 1; { let prod_local_14658 = (prod_local_14646).checked_add(prod_local_14657); prod_local_14658 } },
    } } } },
        true => { let prod_local_14660 = 1; { let prod_local_14661 = (prod_local_14646).checked_add(prod_local_14660); prod_local_14661 } },
    } },
    } },
    } } } } },
    } } } } } } },
    } } } } } } },
    } } } } } } },
    } } } } } } },
    } } } } } } },
    } } } } } } },
    } } } } } } },
    } } } } } } },
    } },
        true => { let _x_3216 = 0; { let _x_3217 = Some(_x_3216); _x_3217 } },
    } } } },
        true => { let _x_3218 = int16Negate(amount); match _x_3218 {
        None => None,
        Some(val_3220) => { let _x_3221 = convertInt16ToUInt32(val_3220); match _x_3221 {
        None => None,
        Some(val_3223) => { let _x_3224 = low64(w); match _x_3224 {
        None => _x_3224,
        Some(val_3225) => { let _x_3227 = (val_3225).checked_shl(val_3223); _x_3227 },
    } },
    } },
    } },
    } }
}

pub fn round128(state: Option<crate::Rounding>) -> Option<crate::Rounding> {
    { let _x_1 = round64(state); { let _x_2 = round64(_x_1); _x_2 } }
}

pub fn round16(state: Option<crate::Rounding>) -> Option<crate::Rounding> {
    { let _x_1 = round8(state); { let _x_2 = round8(_x_1); _x_2 } }
}

pub fn round2(state: Option<crate::Rounding>) -> Option<crate::Rounding> {
    { let _x_1 = roundStep(state); { let _x_2 = roundStep(_x_1); _x_2 } }
}

pub fn round32(state: Option<crate::Rounding>) -> Option<crate::Rounding> {
    { let _x_1 = round16(state); { let _x_2 = round16(_x_1); _x_2 } }
}

pub fn round4(state: Option<crate::Rounding>) -> Option<crate::Rounding> {
    { let _x_1 = round2(state); { let _x_2 = round2(_x_1); _x_2 } }
}

pub fn round64(state: Option<crate::Rounding>) -> Option<crate::Rounding> {
    { let _x_1 = round32(state); { let _x_2 = round32(_x_1); _x_2 } }
}

pub fn round8(state: Option<crate::Rounding>) -> Option<crate::Rounding> {
    { let _x_1 = round4(state); { let _x_2 = round4(_x_1); _x_2 } }
}

pub fn roundStep(state: Option<crate::Rounding>) -> Option<crate::Rounding> {
    match state {
        None => state,
        Some(val_51) => { let _x_89 = (val_51).value; { let _x_90 = right(_x_89); match _x_90 {
        None => None,
        Some(val_93) => { let _x_99 = (val_51).value; { let _x_100 = (_x_99).l0; { let _x_102 = 1; { let _x_103 = (_x_100 & _x_102); { let _x_104 = (_x_103 == _x_102); { let _x_109 = (val_51).sticky; match _x_109 {
        false => { let _x_118 = (val_51).guard; { let _y_111 = _x_118; { let _x_112 = crate::Rounding { value: val_93, guard: _x_104, sticky: _y_111 }; { let _x_113 = Some(_x_112); _x_113 } } } },
        true => { let prod_local_0 = _x_109; { let prod_local_1 = crate::Rounding { value: val_93, guard: _x_104, sticky: prod_local_0 }; { let prod_local_2 = Some(prod_local_1); prod_local_2 } } },
    } } } } } } },
    } } },
    }
}

pub fn signedLess(a: i16, b: i16) -> bool {
    { let _x_7 = int16Subtract(a, b); match _x_7 {
        None => { let _x_15 = negative(a); _x_15 },
        Some(val_10) => { let _x_16 = negative(val_10); _x_16 },
    } }
}

pub fn unsignedLess(a: u64, b: u64) -> bool {
    { let _x_9 = (a).checked_sub(b); match _x_9 {
        None => { let _x_17 = true; _x_17 },
        Some(val_12) => { let _x_18 = false; _x_18 },
    } }
}

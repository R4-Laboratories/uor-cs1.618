# Numeric compatibility diagnostic

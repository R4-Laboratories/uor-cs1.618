import hashlib, json, os, pathlib, shutil, subprocess, sys
root = pathlib.Path(__file__).parent
helper = pathlib.Path('/workspace/scratch/prismpm-numeric/scripts/conditional-capture-candidate.py')
code = r'''import importlib.util,json,os,pathlib,sys,time
s=importlib.util.spec_from_file_location('candidate',sys.argv[1]);c=importlib.util.module_from_spec(s);s.loader.exec_module(c)
mode,output=sys.argv[2],pathlib.Path(sys.argv[3]);output.mkdir(mode=0o700)
for fd in (1,2):
 os.set_blocking(fd,False)
 try:
  while True: os.write(fd,b'x'*4096)
 except BlockingIOError: pass
 os.set_blocking(fd,True)
started=time.monotonic();diag=c.Diagnostics(started+0.2);diag.bind_output(output)
owner=c.Lifecycle(diag.deadline,None,[],diagnostics=diag)
if mode=='attachments':
 for role in ('stage','execute'): diag.attachment(role).write((role+' attachment diagnostic').encode())
owner.finish(False)
if mode=='exception':
 error=RuntimeError('probe original failure');error.stdout=b'original stdout';error.stderr=b'original stderr'
 diag.exception(error)
if mode=='expired-attachments':
 diag.attachment('stage').write(b'persisted before expiry');diag.deadline=time.monotonic()-1
locator=diag.locator();diag.close()
pathlib.Path(sys.argv[4]).write_text(json.dumps({'locator':locator,'elapsed_seconds':time.monotonic()-started,
 'owner_token':owner.token,'no_envelope':not (output/c.ENVELOPE_NAME).exists(),'fds_restored':os.get_blocking(1) and os.get_blocking(2)}))
'''
for mode in ('finish', 'attachments', 'exception', 'expired-attachments'):
    output = root / ('probe-' + mode + '-output')
    observation = root / ('probe-' + mode + '.json')
    child = subprocess.Popen([sys.executable, '-I', '-B', '-c', code, str(helper), mode, str(output), str(observation)],
                             stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    try:
        status = child.wait(timeout=0.8)
        stdout, stderr = child.communicate(timeout=0.2)
        assert status == 0, (mode, stderr[-1000:])
        row = json.loads(observation.read_bytes())
        try:
            os.waitpid(child.pid, os.WNOHANG)
            raise AssertionError('unreaped child')
        except ChildProcessError:
            reaped = True
        assert row['no_envelope'] and row['fds_restored'] and row['elapsed_seconds'] < 0.2
        spool = pathlib.Path(row['locator']['directory'])
        assert spool == output.with_name(output.name + '.candidate-diagnostics')
        manifest = (spool / 'manifest.json').read_bytes()
        assert hashlib.sha256(manifest).hexdigest() == row['locator']['manifest_sha256']
        assert json.loads(manifest)['owner_token'] == row['owner_token']
        row.update({'mode': mode, 'pid': child.pid, 'wait_status': status, 'reaped': reaped,
                    'saturated_stdout_bytes': len(stdout), 'saturated_stderr_bytes': len(stderr),
                    'retained': [{'path': str(p.relative_to(root)), 'bytes': p.stat().st_size,
                                  'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}
                                 for p in sorted(spool.iterdir())]})
        observation.write_text(json.dumps(row, sort_keys=True, indent=2) + '\n')
        print(json.dumps(row, sort_keys=True))
    finally:
        if child.poll() is None:
            child.kill(); child.wait(timeout=2)
        child.stdout.close(); child.stderr.close()

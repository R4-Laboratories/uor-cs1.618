import pathlib,hashlib,json,subprocess,shutil,re
root=pathlib.Path('/workspace/scratch/prismpm-numeric'); out=pathlib.Path(__file__).parent
base='331431bc6c2b71ca06d5e145d9e6a825f6218053'
owned=['tests/publication-context-linkage/compile.mjs','tests/publication-context-linkage/capture-owner.mjs','tests/publication-context-linkage/capture-retained-controls.mjs','tests/publication-context-linkage/capture-retained-controls.test.mjs']
rows=json.loads((out/'protected-before.json').read_text()); changed=[]
for row in rows:
 p=root/row['path']; data=p.readlink().as_posix().encode() if row['kind']=='symlink' else p.read_bytes()
 if hashlib.sha256(data).hexdigest()!=row['sha256']: changed.append(row['path'])
assert sorted(changed)==sorted(owned)
assert sorted(subprocess.check_output(['git','diff',base,'--name-only'],cwd=root,text=True).splitlines())==sorted(owned)
def original(path): return subprocess.check_output(['git','show',base+':'+path],cwd=root)
helper=root/owned[2]; assert helper.read_bytes().startswith(original(owned[2]))
owner=(root/owned[1]).read_text(); old=original(owned[1]).decode()
start='export async function verifyCapturedFactory(t) {'; end='export async function verifyCapturedPublicationLinkage'
assert owner[owner.index(start):owner.index(end)]==old[old.index(start):old.index(end)]
assert owner.count('await prerequisite(')==old.count('await prerequisite(')==6
assert 't.test(' not in owner
register=(root/'crates/conformance/src/cases/mod.rs').read_text(); begin=register.index('"OC-10" =>'); stop=register.index('"OC-01" |',begin)
assert 'owner.test.mjs", 65' in register[begin:stop] and 'capture-guard.test.mjs",\n                    2,' in register[begin:stop]
focused=(root/owned[3]).read_text(); assert not re.search(r'(?:process\.env\[.*?\]|process\.env\.\w+)\s*=|delete\s+process\.env',focused)
prior=json.loads(pathlib.Path('/workspace/diagnostic-tools/candidate-capture-retained/scope-audit.json').read_text())
protected=[]
for oldrow in prior['protected']:
 path=oldrow['path']
 if path in owned: continue
 data=(root/path).read_bytes(); assert data==original(path)
 protected.append(dict(path=path,bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),base_equal=True))
for path in ['crates/conformance/src/cases/node_suite.rs','scripts/owning-node-reporter.mjs','tests/publication-context-linkage/checks.mjs','xtask/src/main.rs']:
 data=(root/path).read_bytes(); assert data==original(path)
 if path not in {x['path'] for x in protected}: protected.append(dict(path=path,bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),base_equal=True))
result=dict(base=base,base_tree=subprocess.check_output(['git','rev-parse',base+'^{tree}'],cwd=root,text=True).strip(),owned=owned,protected=protected,all_tracked_baseline_members=len(rows),unchanged_nonowned_members=len(rows)-len(owned),changed_existing=changed,original_oc10_counts=[65,2],original_node_boundary_code_identical=True,original_capture_factory_body_identical=True,original_retained_controls_and_capture_locator_identical=True,original_outer_forward_receipt_identical=True,owner_prerequisite_calls=6,new_global_environment_mutations=False,free_bytes=shutil.disk_usage(root).free)
assert result['free_bytes']>=8*1024**3
(out/'scope-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='protected'},indent=2))
measured=[]
for path in ['/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node','/usr/bin/python3','/usr/bin/timeout','/workspace/diagnostic-tools/rust-1.97.1/bin/rustc','/workspace/scratch/prismpm-numeric/target/debug/prismpm-semantic-source']:
 p=pathlib.Path(path); data=p.read_bytes(); measured.append(dict(path=path,realpath=str(p.resolve()),bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
(out/'tool-hashes.json').write_text(json.dumps(measured,indent=2)+'\n')
(out/'reviewed-source.diff').write_bytes(subprocess.check_output(['git','diff',base,'--',*owned],cwd=root))

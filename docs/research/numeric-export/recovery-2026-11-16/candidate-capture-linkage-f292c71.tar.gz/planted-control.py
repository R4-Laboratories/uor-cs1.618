import pathlib,subprocess,json,hashlib
root=pathlib.Path('/workspace/scratch/prismpm-numeric'); out=pathlib.Path(__file__).parent
cases=[
 ('05-planted-early-locator','tests/publication-context-linkage/compile.mjs','  createLinkageLocator({sourceRoot:repository, work});\n','component actual prepareStage discovers work','early linkage locator must precede source/project reads'),
 ('06-planted-location-validation','tests/publication-context-linkage/capture-owner.mjs','  validateLinkageLocation({sourceRoot:repository, work:build.work});\n','component actual owner writes the held linkage','Missing expected rejection'),
]
rows=[]
for name,relative,remove,pattern,witness in cases:
 path=root/relative; original=path.read_bytes(); assert remove.encode() in original
 try:
  path.write_bytes(original.replace(remove.encode(),b''))
  planted=hashlib.sha256(path.read_bytes()).hexdigest()
  p=subprocess.run(['python3',str(out/'run.py'),name,'node','--test','--test-name-pattern='+pattern,'tests/publication-context-linkage/capture-retained-controls.test.mjs'],cwd=root)
  assert p.returncode==1
  assert witness in (out/(name+'.stdout')).read_text()
 finally:
  path.write_bytes(original)
 assert path.read_bytes()==original
 rows.append(dict(name=name,path=relative,planted_sha256=planted,restored_sha256=hashlib.sha256(original).hexdigest(),observed_witness=witness,restored_exact=True))
(out/'planted-control.json').write_text(json.dumps(rows,indent=2)+'\n')

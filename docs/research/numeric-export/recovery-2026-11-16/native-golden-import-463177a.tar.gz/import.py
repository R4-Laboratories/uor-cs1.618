from pathlib import Path
import hashlib, json, os, shutil, stat, subprocess, time

SOURCE = Path('/workspace/scratch/prismpm-numeric')
GAME = Path('/workspace/scratch/cs-numeric-kernels')
EVIDENCE = Path('/workspace/diagnostic-tools/native-golden-import')
BASE = 'f292c7100874c0e0b2d1e0e81b27caeec8391f77'
BASE_TREE = 'd48cdfd94e6d46925e9269e364c2b7a6eb975d8a'
RUN_SOURCE = '881df278923ff271fc179703e55ea91c45f2394d'
RUN_GAME = 'e0355a99c8717724e0d1fd072dfac15013603d17'
EXPECTED = [
 ('amd64','golden-manifest.json',108102,'dc66dd81db48ff91e9b45ad953583b928913ec46754dba9ce29fe5722e2798a6'),
 ('amd64','verified/lexlean-attestation.json',2022137,'8ae59081acbcd24da4e5559f1f84d5e74773a2a7f9d81061420d9dfbe3ece217'),
 ('amd64','verified/manifest.json',2284137,'c342d0e095f43b7e326acc02e44c8eb5aee2ec42d4ed1f0c0af31cadf3f09f7a'),
 ('arm64','golden-manifest.json',108104,'5ad4808f3980df59a7431dda1d45cb08b690de163144a70228633eeede0f0fa3'),
 ('arm64','verified/lexlean-attestation.json',2022139,'0c46c09399f0e927db6f3678a41ca8a66c77eff88ccd83317e8ec092a87833e6'),
 ('arm64','verified/manifest.json',2284139,'9f45ff62f78f8804c6bcab4d5670c09f229b90e8fe436d4462505fdaf8debe80'),
]
OWNED = [f'tests/golden/native/linux-{arch}-ubuntu-24.04/{relative}' for arch,relative,_,_ in EXPECTED]
COMMANDS = []

def save(name, value):
    (EVIDENCE/name).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')

def sha(data): return hashlib.sha256(data).hexdigest()

def disk():
    free=shutil.disk_usage(SOURCE).free
    assert free>8*1024**3,free
    return free

def git(*args):
    disk()
    argv=['git',*args]
    started=time.time()
    result=subprocess.run(argv,cwd=SOURCE,capture_output=True,timeout=120)
    ordinal=len(COMMANDS)+1
    stem=f'command-{ordinal:02d}'
    (EVIDENCE/f'{stem}.stdout').write_bytes(result.stdout)
    (EVIDENCE/f'{stem}.stderr').write_bytes(result.stderr)
    COMMANDS.append({'argv':argv,'cwd':str(SOURCE),'exit_code':result.returncode,'elapsed_seconds':time.time()-started,'stdout':f'{stem}.stdout','stderr':f'{stem}.stderr'})
    save('commands.json',COMMANDS)
    assert result.returncode==0,(argv,result.returncode,result.stderr[:1000])
    return result.stdout

def descriptor(path,relative):
    st=path.lstat()
    if stat.S_ISLNK(st.st_mode):
        data=os.fsencode(os.readlink(path)); kind='symlink'
    else:
        assert stat.S_ISREG(st.st_mode),relative
        data=path.read_bytes();kind='regular'
    return {'path':relative,'kind':kind,'mode':stat.S_IMODE(st.st_mode),'bytes':len(data),'sha256':sha(data)}

def inventory():
    names=git('ls-files','-z').decode().split('\0')[:-1]
    assert len(names)==len(set(names))
    return [descriptor(SOURCE/name,name) for name in names]

def regular(path):
    st=path.lstat()
    assert stat.S_ISREG(st.st_mode) and st.st_nlink==1,str(path)
    for parent in path.parents:
        assert not parent.is_symlink(),str(parent)
    return path.read_bytes()

initial={'head':git('rev-parse','HEAD').decode().strip(),'tree':git('rev-parse','HEAD^{tree}').decode().strip(),'status':git('status','--porcelain=v1').decode(),'free_bytes':disk()}
assert initial['head']==BASE and initial['tree']==BASE_TREE and initial['status']==''
save('initial-state.json',initial)
index_before=git('ls-files','--stage','-z')
before=inventory();save('tracked-before.json',before)
assert len(before)==12837,len(before)
artifacts=GAME/'artifacts/numeric-native/ci-44060585070'
run=json.loads((GAME/'docs/research/numeric-export/recovery-2026-11-16/ci-44060585070/completed-run.json').read_text())
assert run['databaseId']==44060585070 and run['headSha']==RUN_GAME and run['status']=='completed' and run['conclusion']=='success'
assert len(run['jobs'])==2 and all(j['conclusion']=='success' for j in run['jobs'])
review_path=GAME/'.superpowers/sdd/native-golden-game-adapter/task-2-arm64-review.md'
review_text=review_path.read_text()
assert 'Joint native-baseline import eligibility: PASS' in review_text
rows=[]
for arch,relative,length,digest in EXPECTED:
    assert digest in review_text
    root=artifacts/arch
    original_review=regular(root/'owner/review.json')
    review=json.loads(original_review)
    envelope=json.loads(regular(root/'evidence/orchestration.json'))
    assert review['source_revision']==RUN_SOURCE and str(review['run_id'])=='44060585070' and str(review['run_attempt'])=='1'
    assert review['platform']==f'linux-{arch}-ubuntu-24.04'
    assert envelope['status']=='complete-review-required' and envelope['diagnostic_only'] is True and envelope['error'] is None
    assert envelope['game']['sha']==RUN_GAME and envelope['game']['run_id']=='44060585070'
    assert envelope['owner']['review_sha256']==sha(original_review)
    assert envelope['owner']['source_revision']==RUN_SOURCE
    assert {'byte_length':length,'path':relative,'sha256':digest} in review['records']
    raw=regular(root/'owner/records'/relative)
    assert len(raw)==length and sha(raw)==digest
    expected={'bytes':length,'path':'owner/records/'+relative,'sha256':digest}
    assert expected in envelope['owner']['records'] and expected in envelope['files']
    destination=f'tests/golden/native/linux-{arch}-ubuntu-24.04/{relative}'
    prior=regular(SOURCE/destination)
    backup=EVIDENCE/'before'/destination;backup.parent.mkdir(parents=True,exist_ok=True);backup.write_bytes(prior)
    rows.append({'architecture':arch,'source':str(root/'owner/records'/relative),'destination':destination,'bytes':length,'sha256':digest,'before_bytes':len(prior),'before_sha256':sha(prior),'owner_review_sha256':sha(original_review)})
save('import-inputs.json',{'run':44060585070,'run_source':RUN_SOURCE,'run_game':RUN_GAME,'import_base':BASE,'joint_review_sha256':sha(review_path.read_bytes()),'files':rows})

assert git('status','--porcelain=v1')==b''
assert git('ls-files','--stage','-z')==index_before
for row in rows:
    disk()
    raw=regular(Path(row['source']))
    assert sha(raw)==row['sha256'] and len(raw)==row['bytes']
    (SOURCE/row['destination']).write_bytes(raw)

after=inventory();save('tracked-after-import.json',after)
bm={r['path']:r for r in before}; am={r['path']:r for r in after}
assert bm.keys()==am.keys()
changed=[p for p in bm if bm[p]!=am[p]]
assert set(changed)==set(OWNED),changed
assert all(bm[p]==am[p] for p in bm if p not in OWNED)
assert git('ls-files','--stage','-z')==index_before
diffnames=git('diff','--no-renames','--name-only','-z').decode().split('\0')[:-1]
assert set(diffnames)==set(OWNED)
assert git('diff','--cached','--name-only')==b''
git('diff','--check')
for row in rows:
    raw=regular(SOURCE/row['destination'])
    assert raw==regular(Path(row['source']))
save('precommit-audit.json',{'tracked_members':len(before),'nonowned_unchanged':len(before)-len(OWNED),'changed':changed,'index_unchanged_before_commit':True,'exact_six_original_bytes':True,'free_bytes':disk()})
git('commit','--only','-m','test: import reviewed AMD64 and ARM64 native golden records','--',*OWNED)
head=git('rev-parse','HEAD').decode().strip();tree=git('rev-parse','HEAD^{tree}').decode().strip()
assert git('rev-parse','HEAD^').decode().strip()==BASE
assert git('status','--porcelain=v1')==b''
assert set(git('diff','--no-renames','--name-only','-z',BASE,head).decode().split('\0')[:-1])==set(OWNED)
committed=inventory();save('tracked-after-commit.json',committed);assert committed==after
for row in rows:
    committed_bytes=git('show',head+':'+row['destination'])
    assert len(committed_bytes)==row['bytes'] and sha(committed_bytes)==row['sha256']
    assert committed_bytes==regular(Path(row['source']))
patch=git('diff','--binary',BASE,head);(EVIDENCE/'import.patch').write_bytes(patch)
save('final-state.json',{'base':BASE,'base_tree':BASE_TREE,'head':head,'tree':tree,'status':'','tracked_members':len(before),'nonowned_unchanged':len(before)-6,'exact_six_original_bytes':True,'source_run_revision_unchanged':RUN_SOURCE,'source_run_game_unchanged':RUN_GAME,'patch_bytes':len(patch),'patch_sha256':sha(patch),'free_bytes':disk(),'scope':'exact native baseline byte import only; no tests or SDK/full-VV qualification performed'})
files=[]
for p in sorted(EVIDENCE.rglob('*')):
    if p.is_file() and p.name!='index.json':files.append({'path':str(p.relative_to(EVIDENCE)),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())})
save('index.json',{'scope':'native six-file import audit only','files':files,'total_bytes':sum(r['bytes'] for r in files)})
print(json.dumps({'head':head,'tree':tree,'nonowned_unchanged':len(before)-6,'files':len(files),'evidence_bytes':sum(r['bytes'] for r in files),'index_sha256':sha((EVIDENCE/'index.json').read_bytes()),'free_bytes':disk()}))

bash scripts/check-scalar-length.sh 

bash -c cd\ rust\ \&\&\ cargo\ test\ --locked\ --offline\ --workspace\ --no-fail-fast 

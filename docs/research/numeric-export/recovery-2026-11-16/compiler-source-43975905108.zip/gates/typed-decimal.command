bash scripts/check-typed-decimal.sh 

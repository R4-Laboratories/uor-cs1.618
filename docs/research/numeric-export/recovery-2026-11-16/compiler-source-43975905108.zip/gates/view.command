bash scripts/check-view.sh 

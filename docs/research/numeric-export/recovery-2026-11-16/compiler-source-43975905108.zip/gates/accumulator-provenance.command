node scripts/check-owned-accumulator-provenance.mjs 

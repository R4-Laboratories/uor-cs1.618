bash -c cd\ lean\ \&\&\ lake\ exe\ prod-export 

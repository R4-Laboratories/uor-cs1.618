bash scripts/check-named-export.sh 

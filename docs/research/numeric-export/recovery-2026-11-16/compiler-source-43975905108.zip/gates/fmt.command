bash -c cd\ rust\ \&\&\ cargo\ fmt\ --all\ --\ --check 

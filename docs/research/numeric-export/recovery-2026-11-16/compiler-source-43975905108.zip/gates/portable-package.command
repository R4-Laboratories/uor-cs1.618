bash scripts/check-portable-package.sh 

bash scripts/check-core-wasm.sh 

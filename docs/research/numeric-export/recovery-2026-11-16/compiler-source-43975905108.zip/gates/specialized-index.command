bash scripts/check-specialized-index.sh 

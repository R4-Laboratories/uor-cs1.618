bash scripts/check-text-view.sh 

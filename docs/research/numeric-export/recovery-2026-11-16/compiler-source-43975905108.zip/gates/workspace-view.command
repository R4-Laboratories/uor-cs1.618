bash scripts/check-workspace-view.sh 

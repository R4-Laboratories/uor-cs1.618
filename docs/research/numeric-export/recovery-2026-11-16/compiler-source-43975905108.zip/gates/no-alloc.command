bash -c cd\ rust\ \&\&\ cargo\ test\ --locked\ --offline\ -p\ prod-core\ --test\ no_alloc\ --\ --test-threads=1 

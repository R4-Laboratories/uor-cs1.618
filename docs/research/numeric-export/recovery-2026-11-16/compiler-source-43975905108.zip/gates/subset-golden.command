git diff --exit-code -- specs/lean-for-production.md 

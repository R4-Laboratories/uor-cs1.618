bash -c set\ -euo\ pipefail\;\ git\ rev-parse\ HEAD\;\ git\ diff\ --binary\;\ lean\ --version\;\ lake\ --version\;\ rustc\ -vV\;\ cargo\ -V\;\ node\ --version 

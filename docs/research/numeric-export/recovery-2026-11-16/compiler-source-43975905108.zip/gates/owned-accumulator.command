bash scripts/check-owned-accumulator.sh 

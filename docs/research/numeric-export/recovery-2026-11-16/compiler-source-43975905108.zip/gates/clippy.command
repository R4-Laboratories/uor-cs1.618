bash -c cd\ rust\ \&\&\ cargo\ clippy\ --locked\ --offline\ --all-targets\ --\ -D\ warnings 

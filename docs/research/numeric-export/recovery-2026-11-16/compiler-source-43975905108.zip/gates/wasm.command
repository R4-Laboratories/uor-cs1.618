bash -c cd\ rust\ \&\&\ cargo\ build\ --locked\ --offline\ -p\ prod-ir\ -p\ prod-codegen\ -p\ prod-wasm\ --target\ wasm32-unknown-unknown 

bash -c cd\ rust\ \&\&\ cargo\ test\ --locked\ --offline\ --workspace\ --profile\ release-assertions\ --no-fail-fast 

bash scripts/check-numeric-conversion.sh 

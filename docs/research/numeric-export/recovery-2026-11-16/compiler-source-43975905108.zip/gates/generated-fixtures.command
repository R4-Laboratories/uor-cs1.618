bash scripts/check-generated-fixtures.sh 

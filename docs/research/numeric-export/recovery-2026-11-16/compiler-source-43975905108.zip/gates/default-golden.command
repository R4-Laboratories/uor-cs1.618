git diff --exit-code -- lean/Conformance/golden.ir 

bash scripts/check-shared-decidable.sh 

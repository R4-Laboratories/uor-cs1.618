bash -c cd\ rust\ \&\&\ cargo\ run\ --locked\ --offline\ -p\ prod-cli\ --\ subset\ ../subset.json\ --output\ ../specs/lean-for-production.md 

bash -c cd\ lean\ \&\&\ lake\ build\ ProofFixtures\ PrismPMGeneratedFixture 

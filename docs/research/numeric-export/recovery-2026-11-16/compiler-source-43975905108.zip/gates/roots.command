bash -c cd\ rust\ \&\&\ cargo\ run\ --locked\ --offline\ -p\ prod-cli\ --\ roots\ check\ ../roots.json 

module
public import Init
public import LexLeanRuntime.Laws
set_option autoImplicit false
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000000
set_option linter.constructorNameAsVariable false
namespace ConstructiveComponent.Bounds

public theorem limbAddBound (a : Nat) (b : Nat) (carry : Nat) : ((a <= 4294967295) -> ((b <= 4294967295) -> ((carry <= 1) -> (((a + b) + carry) <= 8589934591)))) := by
  intro __cnh0 __cnh1 __cnh2
  let __cnt0 : Nat := a
  let __cnt1 : Nat := (nat_lit 4294967295)
  let __cnt2 : Nat := b
  let __cnt3 : Nat := carry
  let __cnt4 : Nat := (nat_lit 1)
  let __cnt5 : Nat := __cnt0 + __cnt2
  let __cnt6 : Nat := __cnt5 + __cnt3
  let __cnt7 : Nat := (nat_lit 8589934591)
  let __cnt8 : Nat := (nat_lit 0)
  let __cnt9 : Nat := __cnt0 + __cnt8
  let __cnt10 : Nat := __cnt9 + __cnt8
  let __cnt11 : Nat := __cnt8 + __cnt8
  let __cnt12 : Nat := __cnt0 + __cnt11
  let __cnt13 : Nat := __cnt2 + __cnt8
  let __cnt14 : Nat := __cnt13 + __cnt8
  let __cnt15 : Nat := __cnt2 + __cnt11
  let __cnt16 : Nat := __cnt3 + __cnt8
  let __cnt17 : Nat := __cnt16 + __cnt8
  let __cnt18 : Nat := __cnt3 + __cnt11
  let __cnt19 : Nat := __cnt1 + __cnt1
  let __cnt20 : Nat := __cnt19 + __cnt4
  let __cnt21 : Nat := (nat_lit 8589934590)
  let __cnt22 : Nat := __cnt21 + __cnt4
  have __cnp0 : __cnt0 ≤ __cnt1 := __cnh0
  have __cnp1 : __cnt9 = __cnt0 := Nat.add_zero __cnt0
  have __cnp2 : __cnt0 = __cnt9 := Eq.symm __cnp1
  have __cnp3 : __cnt8 = __cnt8 := Eq.refl __cnt8
  have __cnp4 : __cnt9 = __cnt10 := congrArg₂ Nat.add __cnp2 __cnp3
  have __cnp5 : __cnt10 = __cnt12 := Nat.add_assoc __cnt0 __cnt8 __cnt8
  have __cnp6 : __cnt11 = __cnt8 := Eq.refl __cnt8
  have __cnp7 : __cnt0 = __cnt0 := Eq.refl __cnt0
  have __cnp8 : __cnt12 = __cnt9 := congrArg₂ Nat.add __cnp7 __cnp6
  have __cnp9 : __cnt10 = __cnt9 := Eq.trans __cnp5 __cnp8
  have __cnp10 : __cnt9 = __cnt9 := Eq.trans __cnp4 __cnp9
  have __cnp11 : __cnt9 = __cnt9 := Eq.symm __cnp10
  have __cnp12 : __cnt0 = __cnt9 := Eq.trans __cnp2 __cnp11
  have __cnp13 : __cnt9 ≤ __cnt1 := Eq.mp (congrArg (fun __cnz : Nat => __cnz ≤ __cnt1) __cnp12) __cnp0
  have __cnp14 : __cnt9 = __cnt0 := Eq.symm __cnp2
  have __cnp15 : __cnt9 = __cnt0 := Eq.trans __cnp10 __cnp14
  have __cnp16 : __cnt0 ≤ __cnt1 := Eq.mp (congrArg (fun __cnz : Nat => __cnz ≤ __cnt1) __cnp15) __cnp13
  have __cnp17 : __cnt2 ≤ __cnt1 := __cnh1
  have __cnp18 : __cnt13 = __cnt2 := Nat.add_zero __cnt2
  have __cnp19 : __cnt2 = __cnt13 := Eq.symm __cnp18
  have __cnp20 : __cnt13 = __cnt14 := congrArg₂ Nat.add __cnp19 __cnp3
  have __cnp21 : __cnt14 = __cnt15 := Nat.add_assoc __cnt2 __cnt8 __cnt8
  have __cnp22 : __cnt11 = __cnt8 := Eq.refl __cnt8
  have __cnp23 : __cnt2 = __cnt2 := Eq.refl __cnt2
  have __cnp24 : __cnt15 = __cnt13 := congrArg₂ Nat.add __cnp23 __cnp22
  have __cnp25 : __cnt14 = __cnt13 := Eq.trans __cnp21 __cnp24
  have __cnp26 : __cnt13 = __cnt13 := Eq.trans __cnp20 __cnp25
  have __cnp27 : __cnt13 = __cnt13 := Eq.symm __cnp26
  have __cnp28 : __cnt2 = __cnt13 := Eq.trans __cnp19 __cnp27
  have __cnp29 : __cnt13 ≤ __cnt1 := Eq.mp (congrArg (fun __cnz : Nat => __cnz ≤ __cnt1) __cnp28) __cnp17
  have __cnp30 : __cnt13 = __cnt2 := Eq.symm __cnp19
  have __cnp31 : __cnt13 = __cnt2 := Eq.trans __cnp26 __cnp30
  have __cnp32 : __cnt2 ≤ __cnt1 := Eq.mp (congrArg (fun __cnz : Nat => __cnz ≤ __cnt1) __cnp31) __cnp29
  have __cnp33 : __cnt3 ≤ __cnt4 := __cnh2
  have __cnp34 : __cnt16 = __cnt3 := Nat.add_zero __cnt3
  have __cnp35 : __cnt3 = __cnt16 := Eq.symm __cnp34
  have __cnp36 : __cnt16 = __cnt17 := congrArg₂ Nat.add __cnp35 __cnp3
  have __cnp37 : __cnt17 = __cnt18 := Nat.add_assoc __cnt3 __cnt8 __cnt8
  have __cnp38 : __cnt11 = __cnt8 := Eq.refl __cnt8
  have __cnp39 : __cnt3 = __cnt3 := Eq.refl __cnt3
  have __cnp40 : __cnt18 = __cnt16 := congrArg₂ Nat.add __cnp39 __cnp38
  have __cnp41 : __cnt17 = __cnt16 := Eq.trans __cnp37 __cnp40
  have __cnp42 : __cnt16 = __cnt16 := Eq.trans __cnp36 __cnp41
  have __cnp43 : __cnt16 = __cnt16 := Eq.symm __cnp42
  have __cnp44 : __cnt3 = __cnt16 := Eq.trans __cnp35 __cnp43
  have __cnp45 : __cnt16 ≤ __cnt4 := Eq.mp (congrArg (fun __cnz : Nat => __cnz ≤ __cnt4) __cnp44) __cnp33
  have __cnp46 : __cnt16 = __cnt3 := Eq.symm __cnp35
  have __cnp47 : __cnt16 = __cnt3 := Eq.trans __cnp42 __cnp46
  have __cnp48 : __cnt3 ≤ __cnt4 := Eq.mp (congrArg (fun __cnz : Nat => __cnz ≤ __cnt4) __cnp47) __cnp45
  have __cnp49 : __cnt5 ≤ __cnt19 := Nat.add_le_add __cnp16 __cnp32
  have __cnp50 : __cnt6 ≤ __cnt20 := Nat.add_le_add __cnp49 __cnp48
  have __cnp51 : __cnt1 = __cnt1 := Eq.refl __cnt1
  have __cnp52 : __cnt19 = __cnt19 := congrArg₂ Nat.add __cnp51 __cnp51
  have __cnp53 : __cnt19 = __cnt21 := Eq.refl __cnt21
  have __cnp54 : __cnt19 = __cnt21 := Eq.trans __cnp52 __cnp53
  have __cnp55 : __cnt4 = __cnt4 := Eq.refl __cnt4
  have __cnp56 : __cnt20 = __cnt22 := congrArg₂ Nat.add __cnp54 __cnp55
  have __cnp57 : __cnt22 = __cnt7 := Eq.refl __cnt7
  have __cnp58 : __cnt20 = __cnt7 := Eq.trans __cnp56 __cnp57
  have __cnp59 : __cnt7 = __cnt7 := Eq.refl __cnt7
  have __cnp60 : __cnt7 = __cnt7 := Eq.symm __cnp59
  have __cnp61 : __cnt20 = __cnt7 := Eq.trans __cnp58 __cnp60
  have __cnp62 : __cnt6 ≤ __cnt7 := Eq.mp (congrArg (fun __cnz : Nat => __cnt6 ≤ __cnz) __cnp61) __cnp50
  have __cnp63 : __cnt7 ≤ __cnt7 := of_decide_eq_true (Eq.refl true)
  have __cnp64 : __cnt6 ≤ __cnt7 := Nat.le_trans __cnp62 __cnp63
  exact __cnp64

public theorem cellAddBound (product : Nat) (out : Nat) (carry : Nat) : ((product <= 18446744065119617025) -> ((out <= 4294967295) -> ((carry <= 4294967295) -> (((product + out) + carry) <= 18446744073709551615)))) := by
  intro __cnh0 __cnh1 __cnh2
  let __cnt0 : Nat := product
  let __cnt1 : Nat := (nat_lit 18446744065119617025)
  let __cnt2 : Nat := out
  let __cnt3 : Nat := (nat_lit 4294967295)
  let __cnt4 : Nat := carry
  let __cnt5 : Nat := __cnt0 + __cnt2
  let __cnt6 : Nat := __cnt5 + __cnt4
  let __cnt7 : Nat := (nat_lit 18446744073709551615)
  let __cnt8 : Nat := (nat_lit 0)
  let __cnt9 : Nat := __cnt0 + __cnt8
  let __cnt10 : Nat := __cnt9 + __cnt8
  let __cnt11 : Nat := __cnt8 + __cnt8
  let __cnt12 : Nat := __cnt0 + __cnt11
  let __cnt13 : Nat := __cnt2 + __cnt8
  let __cnt14 : Nat := __cnt13 + __cnt8
  let __cnt15 : Nat := __cnt2 + __cnt11
  let __cnt16 : Nat := __cnt4 + __cnt8
  let __cnt17 : Nat := __cnt16 + __cnt8
  let __cnt18 : Nat := __cnt4 + __cnt11
  let __cnt19 : Nat := __cnt1 + __cnt3
  let __cnt20 : Nat := __cnt19 + __cnt3
  let __cnt21 : Nat := (nat_lit 18446744069414584320)
  let __cnt22 : Nat := __cnt21 + __cnt3
  have __cnp0 : __cnt0 ≤ __cnt1 := __cnh0
  have __cnp1 : __cnt9 = __cnt0 := Nat.add_zero __cnt0
  have __cnp2 : __cnt0 = __cnt9 := Eq.symm __cnp1
  have __cnp3 : __cnt8 = __cnt8 := Eq.refl __cnt8
  have __cnp4 : __cnt9 = __cnt10 := congrArg₂ Nat.add __cnp2 __cnp3
  have __cnp5 : __cnt10 = __cnt12 := Nat.add_assoc __cnt0 __cnt8 __cnt8
  have __cnp6 : __cnt11 = __cnt8 := Eq.refl __cnt8
  have __cnp7 : __cnt0 = __cnt0 := Eq.refl __cnt0
  have __cnp8 : __cnt12 = __cnt9 := congrArg₂ Nat.add __cnp7 __cnp6
  have __cnp9 : __cnt10 = __cnt9 := Eq.trans __cnp5 __cnp8
  have __cnp10 : __cnt9 = __cnt9 := Eq.trans __cnp4 __cnp9
  have __cnp11 : __cnt9 = __cnt9 := Eq.symm __cnp10
  have __cnp12 : __cnt0 = __cnt9 := Eq.trans __cnp2 __cnp11
  have __cnp13 : __cnt9 ≤ __cnt1 := Eq.mp (congrArg (fun __cnz : Nat => __cnz ≤ __cnt1) __cnp12) __cnp0
  have __cnp14 : __cnt9 = __cnt0 := Eq.symm __cnp2
  have __cnp15 : __cnt9 = __cnt0 := Eq.trans __cnp10 __cnp14
  have __cnp16 : __cnt0 ≤ __cnt1 := Eq.mp (congrArg (fun __cnz : Nat => __cnz ≤ __cnt1) __cnp15) __cnp13
  have __cnp17 : __cnt2 ≤ __cnt3 := __cnh1
  have __cnp18 : __cnt13 = __cnt2 := Nat.add_zero __cnt2
  have __cnp19 : __cnt2 = __cnt13 := Eq.symm __cnp18
  have __cnp20 : __cnt13 = __cnt14 := congrArg₂ Nat.add __cnp19 __cnp3
  have __cnp21 : __cnt14 = __cnt15 := Nat.add_assoc __cnt2 __cnt8 __cnt8
  have __cnp22 : __cnt11 = __cnt8 := Eq.refl __cnt8
  have __cnp23 : __cnt2 = __cnt2 := Eq.refl __cnt2
  have __cnp24 : __cnt15 = __cnt13 := congrArg₂ Nat.add __cnp23 __cnp22
  have __cnp25 : __cnt14 = __cnt13 := Eq.trans __cnp21 __cnp24
  have __cnp26 : __cnt13 = __cnt13 := Eq.trans __cnp20 __cnp25
  have __cnp27 : __cnt13 = __cnt13 := Eq.symm __cnp26
  have __cnp28 : __cnt2 = __cnt13 := Eq.trans __cnp19 __cnp27
  have __cnp29 : __cnt13 ≤ __cnt3 := Eq.mp (congrArg (fun __cnz : Nat => __cnz ≤ __cnt3) __cnp28) __cnp17
  have __cnp30 : __cnt13 = __cnt2 := Eq.symm __cnp19
  have __cnp31 : __cnt13 = __cnt2 := Eq.trans __cnp26 __cnp30
  have __cnp32 : __cnt2 ≤ __cnt3 := Eq.mp (congrArg (fun __cnz : Nat => __cnz ≤ __cnt3) __cnp31) __cnp29
  have __cnp33 : __cnt4 ≤ __cnt3 := __cnh2
  have __cnp34 : __cnt16 = __cnt4 := Nat.add_zero __cnt4
  have __cnp35 : __cnt4 = __cnt16 := Eq.symm __cnp34
  have __cnp36 : __cnt16 = __cnt17 := congrArg₂ Nat.add __cnp35 __cnp3
  have __cnp37 : __cnt17 = __cnt18 := Nat.add_assoc __cnt4 __cnt8 __cnt8
  have __cnp38 : __cnt11 = __cnt8 := Eq.refl __cnt8
  have __cnp39 : __cnt4 = __cnt4 := Eq.refl __cnt4
  have __cnp40 : __cnt18 = __cnt16 := congrArg₂ Nat.add __cnp39 __cnp38
  have __cnp41 : __cnt17 = __cnt16 := Eq.trans __cnp37 __cnp40
  have __cnp42 : __cnt16 = __cnt16 := Eq.trans __cnp36 __cnp41
  have __cnp43 : __cnt16 = __cnt16 := Eq.symm __cnp42
  have __cnp44 : __cnt4 = __cnt16 := Eq.trans __cnp35 __cnp43
  have __cnp45 : __cnt16 ≤ __cnt3 := Eq.mp (congrArg (fun __cnz : Nat => __cnz ≤ __cnt3) __cnp44) __cnp33
  have __cnp46 : __cnt16 = __cnt4 := Eq.symm __cnp35
  have __cnp47 : __cnt16 = __cnt4 := Eq.trans __cnp42 __cnp46
  have __cnp48 : __cnt4 ≤ __cnt3 := Eq.mp (congrArg (fun __cnz : Nat => __cnz ≤ __cnt3) __cnp47) __cnp45
  have __cnp49 : __cnt5 ≤ __cnt19 := Nat.add_le_add __cnp16 __cnp32
  have __cnp50 : __cnt6 ≤ __cnt20 := Nat.add_le_add __cnp49 __cnp48
  have __cnp51 : __cnt1 = __cnt1 := Eq.refl __cnt1
  have __cnp52 : __cnt3 = __cnt3 := Eq.refl __cnt3
  have __cnp53 : __cnt19 = __cnt19 := congrArg₂ Nat.add __cnp51 __cnp52
  have __cnp54 : __cnt19 = __cnt21 := Eq.refl __cnt21
  have __cnp55 : __cnt19 = __cnt21 := Eq.trans __cnp53 __cnp54
  have __cnp56 : __cnt20 = __cnt22 := congrArg₂ Nat.add __cnp55 __cnp52
  have __cnp57 : __cnt22 = __cnt7 := Eq.refl __cnt7
  have __cnp58 : __cnt20 = __cnt7 := Eq.trans __cnp56 __cnp57
  have __cnp59 : __cnt7 = __cnt7 := Eq.refl __cnt7
  have __cnp60 : __cnt7 = __cnt7 := Eq.symm __cnp59
  have __cnp61 : __cnt20 = __cnt7 := Eq.trans __cnp58 __cnp60
  have __cnp62 : __cnt6 ≤ __cnt7 := Eq.mp (congrArg (fun __cnz : Nat => __cnt6 ≤ __cnz) __cnp61) __cnp50
  have __cnp63 : __cnt7 ≤ __cnt7 := of_decide_eq_true (Eq.refl true)
  have __cnp64 : __cnt6 ≤ __cnt7 := Nat.le_trans __cnp62 __cnp63
  exact __cnp64

public theorem divDoubleRemainderBound (r : Nat) (d : Nat) : ((r < d) -> ((d <= 9007199254740991) -> ((r + r) <= 18014398509481982))) := by
  intro __cnh0 __cnh1
  let __cnt0 : Nat := r
  let __cnt1 : Nat := d
  let __cnt2 : Nat := (nat_lit 9007199254740991)
  let __cnt3 : Nat := __cnt0 + __cnt0
  let __cnt4 : Nat := (nat_lit 18014398509481982)
  let __cnt5 : Nat := (nat_lit 0)
  let __cnt6 : Nat := __cnt0 + __cnt5
  let __cnt7 : Nat := __cnt1 + __cnt5
  let __cnt8 : Nat := __cnt6 + __cnt5
  let __cnt9 : Nat := __cnt5 + __cnt5
  let __cnt10 : Nat := __cnt0 + __cnt9
  let __cnt11 : Nat := __cnt7 + __cnt5
  let __cnt12 : Nat := __cnt1 + __cnt9
  let __cnt13 : Nat := __cnt2 + __cnt2
  have __cnp0 : __cnt0 < __cnt1 := __cnh0
  have __cnp1 : __cnt0 ≤ __cnt1 := Nat.le_of_lt __cnp0
  have __cnp2 : __cnt6 = __cnt0 := Nat.add_zero __cnt0
  have __cnp3 : __cnt0 = __cnt6 := Eq.symm __cnp2
  have __cnp4 : __cnt5 = __cnt5 := Eq.refl __cnt5
  have __cnp5 : __cnt6 = __cnt8 := congrArg₂ Nat.add __cnp3 __cnp4
  have __cnp6 : __cnt8 = __cnt10 := Nat.add_assoc __cnt0 __cnt5 __cnt5
  have __cnp7 : __cnt9 = __cnt5 := Eq.refl __cnt5
  have __cnp8 : __cnt0 = __cnt0 := Eq.refl __cnt0
  have __cnp9 : __cnt10 = __cnt6 := congrArg₂ Nat.add __cnp8 __cnp7
  have __cnp10 : __cnt8 = __cnt6 := Eq.trans __cnp6 __cnp9
  have __cnp11 : __cnt6 = __cnt6 := Eq.trans __cnp5 __cnp10
  have __cnp12 : __cnt6 = __cnt6 := Eq.symm __cnp11
  have __cnp13 : __cnt0 = __cnt6 := Eq.trans __cnp3 __cnp12
  have __cnp14 : __cnt6 ≤ __cnt1 := Eq.mp (congrArg (fun __cnz : Nat => __cnz ≤ __cnt1) __cnp13) __cnp1
  have __cnp15 : __cnt7 = __cnt1 := Nat.add_zero __cnt1
  have __cnp16 : __cnt1 = __cnt7 := Eq.symm __cnp15
  have __cnp17 : __cnt7 = __cnt11 := congrArg₂ Nat.add __cnp16 __cnp4
  have __cnp18 : __cnt11 = __cnt12 := Nat.add_assoc __cnt1 __cnt5 __cnt5
  have __cnp19 : __cnt9 = __cnt5 := Eq.refl __cnt5
  have __cnp20 : __cnt1 = __cnt1 := Eq.refl __cnt1
  have __cnp21 : __cnt12 = __cnt7 := congrArg₂ Nat.add __cnp20 __cnp19
  have __cnp22 : __cnt11 = __cnt7 := Eq.trans __cnp18 __cnp21
  have __cnp23 : __cnt7 = __cnt7 := Eq.trans __cnp17 __cnp22
  have __cnp24 : __cnt7 = __cnt7 := Eq.symm __cnp23
  have __cnp25 : __cnt1 = __cnt7 := Eq.trans __cnp16 __cnp24
  have __cnp26 : __cnt6 ≤ __cnt7 := Eq.mp (congrArg (fun __cnz : Nat => __cnt6 ≤ __cnz) __cnp25) __cnp14
  have __cnp27 : __cnt1 ≤ __cnt2 := __cnh1
  have __cnp28 : __cnt7 = __cnt7 := Eq.symm __cnp23
  have __cnp29 : __cnt1 = __cnt7 := Eq.trans __cnp16 __cnp28
  have __cnp30 : __cnt7 ≤ __cnt2 := Eq.mp (congrArg (fun __cnz : Nat => __cnz ≤ __cnt2) __cnp29) __cnp27
  have __cnp31 : __cnt6 ≤ __cnt2 := Nat.le_trans __cnp26 __cnp30
  have __cnp32 : __cnt6 = __cnt0 := Eq.symm __cnp3
  have __cnp33 : __cnt6 = __cnt0 := Eq.trans __cnp11 __cnp32
  have __cnp34 : __cnt0 ≤ __cnt2 := Eq.mp (congrArg (fun __cnz : Nat => __cnz ≤ __cnt2) __cnp33) __cnp31
  have __cnp35 : __cnt3 ≤ __cnt13 := Nat.add_le_add __cnp34 __cnp34
  have __cnp36 : __cnt2 = __cnt2 := Eq.refl __cnt2
  have __cnp37 : __cnt13 = __cnt13 := congrArg₂ Nat.add __cnp36 __cnp36
  have __cnp38 : __cnt13 = __cnt4 := Eq.refl __cnt4
  have __cnp39 : __cnt13 = __cnt4 := Eq.trans __cnp37 __cnp38
  have __cnp40 : __cnt4 = __cnt4 := Eq.refl __cnt4
  have __cnp41 : __cnt4 = __cnt4 := Eq.symm __cnp40
  have __cnp42 : __cnt13 = __cnt4 := Eq.trans __cnp39 __cnp41
  have __cnp43 : __cnt3 ≤ __cnt4 := Eq.mp (congrArg (fun __cnz : Nat => __cnt3 ≤ __cnz) __cnp42) __cnp35
  have __cnp44 : __cnt4 ≤ __cnt4 := of_decide_eq_true (Eq.refl true)
  have __cnp45 : __cnt3 ≤ __cnt4 := Nat.le_trans __cnp43 __cnp44
  exact __cnp45

public theorem divReducedRemainderBound (r : Nat) (d : Nat) (reduced : Nat) : ((r < d) -> (((r + r) = (reduced + d)) -> (reduced < d))) := by
  intro __cnh0 __cnh1
  let __cnt0 : Nat := r
  let __cnt1 : Nat := d
  let __cnt2 : Nat := __cnt0 + __cnt0
  let __cnt3 : Nat := reduced
  let __cnt4 : Nat := __cnt3 + __cnt1
  let __cnt5 : Nat := __cnt1 + __cnt1
  let __cnt6 : Nat := (nat_lit 0)
  let __cnt7 : Nat := __cnt0 + __cnt6
  let __cnt8 : Nat := __cnt0 + __cnt7
  let __cnt9 : Nat := __cnt3 + __cnt6
  let __cnt10 : Nat := __cnt1 + __cnt9
  let __cnt11 : Nat := __cnt7 + __cnt7
  let __cnt12 : Nat := __cnt6 + __cnt7
  let __cnt13 : Nat := __cnt0 + __cnt12
  let __cnt14 : Nat := __cnt6 + __cnt0
  let __cnt15 : Nat := __cnt14 + __cnt6
  let __cnt16 : Nat := __cnt7 + __cnt6
  let __cnt17 : Nat := __cnt6 + __cnt6
  let __cnt18 : Nat := __cnt0 + __cnt17
  let __cnt19 : Nat := __cnt1 + __cnt6
  let __cnt20 : Nat := __cnt9 + __cnt19
  let __cnt21 : Nat := __cnt9 + __cnt1
  let __cnt22 : Nat := __cnt21 + __cnt6
  let __cnt23 : Nat := __cnt10 + __cnt6
  let __cnt24 : Nat := __cnt9 + __cnt6
  let __cnt25 : Nat := __cnt1 + __cnt24
  let __cnt26 : Nat := __cnt3 + __cnt17
  let __cnt27 : Nat := __cnt19 + __cnt9
  let __cnt28 : Nat := __cnt6 + __cnt9
  let __cnt29 : Nat := __cnt1 + __cnt28
  let __cnt30 : Nat := __cnt6 + __cnt3
  let __cnt31 : Nat := __cnt30 + __cnt6
  let __cnt32 : Nat := __cnt1 + __cnt19
  let __cnt33 : Nat := __cnt19 + __cnt19
  let __cnt34 : Nat := __cnt6 + __cnt19
  let __cnt35 : Nat := __cnt1 + __cnt34
  let __cnt36 : Nat := __cnt6 + __cnt1
  let __cnt37 : Nat := __cnt36 + __cnt6
  let __cnt38 : Nat := __cnt19 + __cnt6
  let __cnt39 : Nat := __cnt1 + __cnt17
  have __cnp0 : __cnt0 < __cnt1 := __cnh0
  have __cnp1 : __cnt0 ≤ __cnt1 := Nat.le_of_lt __cnp0
  have __cnp2 : __cnt2 < __cnt5 := Nat.lt_of_lt_of_le (Nat.add_lt_add_right __cnp0 __cnt0) (Nat.add_le_add (Nat.le_refl __cnt1) __cnp1)
  have __cnp3 : __cnt2 = __cnt4 := __cnh1
  have __cnp4 : __cnt7 = __cnt0 := Nat.add_zero __cnt0
  have __cnp5 : __cnt0 = __cnt7 := Eq.symm __cnp4
  have __cnp6 : __cnt2 = __cnt11 := congrArg₂ Nat.add __cnp5 __cnp5
  have __cnp7 : __cnt11 = __cnt13 := Nat.add_assoc __cnt0 __cnt6 __cnt7
  have __cnp8 : __cnt15 = __cnt12 := Nat.add_assoc __cnt6 __cnt0 __cnt6
  have __cnp9 : __cnt12 = __cnt15 := Eq.symm __cnp8
  have __cnp10 : __cnt14 = __cnt7 := Nat.add_comm __cnt6 __cnt0
  have __cnp11 : __cnt6 = __cnt6 := Eq.refl __cnt6
  have __cnp12 : __cnt15 = __cnt16 := congrArg₂ Nat.add __cnp10 __cnp11
  have __cnp13 : __cnt16 = __cnt18 := Nat.add_assoc __cnt0 __cnt6 __cnt6
  have __cnp14 : __cnt12 = __cnt16 := Eq.trans __cnp9 __cnp12
  have __cnp15 : __cnt12 = __cnt18 := Eq.trans __cnp14 __cnp13
  have __cnp16 : __cnt17 = __cnt6 := Eq.refl __cnt6
  have __cnp17 : __cnt0 = __cnt0 := Eq.refl __cnt0
  have __cnp18 : __cnt18 = __cnt7 := congrArg₂ Nat.add __cnp17 __cnp16
  have __cnp19 : __cnt12 = __cnt7 := Eq.trans __cnp15 __cnp18
  have __cnp20 : __cnt0 = __cnt0 := Eq.refl __cnt0
  have __cnp21 : __cnt13 = __cnt8 := congrArg₂ Nat.add __cnp20 __cnp19
  have __cnp22 : __cnt11 = __cnt8 := Eq.trans __cnp7 __cnp21
  have __cnp23 : __cnt2 = __cnt8 := Eq.trans __cnp6 __cnp22
  have __cnp24 : __cnt6 = __cnt6 := Eq.refl __cnt6
  have __cnp25 : __cnt7 = __cnt16 := congrArg₂ Nat.add __cnp5 __cnp24
  have __cnp26 : __cnt16 = __cnt18 := Nat.add_assoc __cnt0 __cnt6 __cnt6
  have __cnp27 : __cnt17 = __cnt6 := Eq.refl __cnt6
  have __cnp28 : __cnt0 = __cnt0 := Eq.refl __cnt0
  have __cnp29 : __cnt18 = __cnt7 := congrArg₂ Nat.add __cnp28 __cnp27
  have __cnp30 : __cnt16 = __cnt7 := Eq.trans __cnp26 __cnp29
  have __cnp31 : __cnt7 = __cnt7 := Eq.trans __cnp25 __cnp30
  have __cnp32 : __cnt8 = __cnt11 := congrArg₂ Nat.add __cnp5 __cnp31
  have __cnp33 : __cnt11 = __cnt13 := Nat.add_assoc __cnt0 __cnt6 __cnt7
  have __cnp34 : __cnt15 = __cnt12 := Nat.add_assoc __cnt6 __cnt0 __cnt6
  have __cnp35 : __cnt12 = __cnt15 := Eq.symm __cnp34
  have __cnp36 : __cnt14 = __cnt7 := Nat.add_comm __cnt6 __cnt0
  have __cnp37 : __cnt6 = __cnt6 := Eq.refl __cnt6
  have __cnp38 : __cnt15 = __cnt16 := congrArg₂ Nat.add __cnp36 __cnp37
  have __cnp39 : __cnt16 = __cnt18 := Nat.add_assoc __cnt0 __cnt6 __cnt6
  have __cnp40 : __cnt12 = __cnt16 := Eq.trans __cnp35 __cnp38
  have __cnp41 : __cnt12 = __cnt18 := Eq.trans __cnp40 __cnp39
  have __cnp42 : __cnt17 = __cnt6 := Eq.refl __cnt6
  have __cnp43 : __cnt0 = __cnt0 := Eq.refl __cnt0
  have __cnp44 : __cnt18 = __cnt7 := congrArg₂ Nat.add __cnp43 __cnp42
  have __cnp45 : __cnt12 = __cnt7 := Eq.trans __cnp41 __cnp44
  have __cnp46 : __cnt0 = __cnt0 := Eq.refl __cnt0
  have __cnp47 : __cnt13 = __cnt8 := congrArg₂ Nat.add __cnp46 __cnp45
  have __cnp48 : __cnt11 = __cnt8 := Eq.trans __cnp33 __cnp47
  have __cnp49 : __cnt8 = __cnt8 := Eq.trans __cnp32 __cnp48
  have __cnp50 : __cnt8 = __cnt8 := Eq.symm __cnp49
  have __cnp51 : __cnt2 = __cnt8 := Eq.trans __cnp23 __cnp50
  have __cnp52 : __cnt8 = __cnt4 := Eq.mp (congrArg (fun __cnz : Nat => __cnz = __cnt4) __cnp51) __cnp3
  have __cnp53 : __cnt9 = __cnt3 := Nat.add_zero __cnt3
  have __cnp54 : __cnt3 = __cnt9 := Eq.symm __cnp53
  have __cnp55 : __cnt19 = __cnt1 := Nat.add_zero __cnt1
  have __cnp56 : __cnt1 = __cnt19 := Eq.symm __cnp55
  have __cnp57 : __cnt4 = __cnt20 := congrArg₂ Nat.add __cnp54 __cnp56
  have __cnp58 : __cnt22 = __cnt20 := Nat.add_assoc __cnt9 __cnt1 __cnt6
  have __cnp59 : __cnt20 = __cnt22 := Eq.symm __cnp58
  have __cnp60 : __cnt21 = __cnt10 := Nat.add_comm __cnt9 __cnt1
  have __cnp61 : __cnt6 = __cnt6 := Eq.refl __cnt6
  have __cnp62 : __cnt22 = __cnt23 := congrArg₂ Nat.add __cnp60 __cnp61
  have __cnp63 : __cnt23 = __cnt25 := Nat.add_assoc __cnt1 __cnt9 __cnt6
  have __cnp64 : __cnt20 = __cnt23 := Eq.trans __cnp59 __cnp62
  have __cnp65 : __cnt20 = __cnt25 := Eq.trans __cnp64 __cnp63
  have __cnp66 : __cnt24 = __cnt26 := Nat.add_assoc __cnt3 __cnt6 __cnt6
  have __cnp67 : __cnt17 = __cnt6 := Eq.refl __cnt6
  have __cnp68 : __cnt3 = __cnt3 := Eq.refl __cnt3
  have __cnp69 : __cnt26 = __cnt9 := congrArg₂ Nat.add __cnp68 __cnp67
  have __cnp70 : __cnt24 = __cnt9 := Eq.trans __cnp66 __cnp69
  have __cnp71 : __cnt1 = __cnt1 := Eq.refl __cnt1
  have __cnp72 : __cnt25 = __cnt10 := congrArg₂ Nat.add __cnp71 __cnp70
  have __cnp73 : __cnt20 = __cnt10 := Eq.trans __cnp65 __cnp72
  have __cnp74 : __cnt4 = __cnt10 := Eq.trans __cnp57 __cnp73
  have __cnp75 : __cnt9 = __cnt24 := congrArg₂ Nat.add __cnp54 __cnp24
  have __cnp76 : __cnt24 = __cnt26 := Nat.add_assoc __cnt3 __cnt6 __cnt6
  have __cnp77 : __cnt17 = __cnt6 := Eq.refl __cnt6
  have __cnp78 : __cnt3 = __cnt3 := Eq.refl __cnt3
  have __cnp79 : __cnt26 = __cnt9 := congrArg₂ Nat.add __cnp78 __cnp77
  have __cnp80 : __cnt24 = __cnt9 := Eq.trans __cnp76 __cnp79
  have __cnp81 : __cnt9 = __cnt9 := Eq.trans __cnp75 __cnp80
  have __cnp82 : __cnt10 = __cnt27 := congrArg₂ Nat.add __cnp56 __cnp81
  have __cnp83 : __cnt27 = __cnt29 := Nat.add_assoc __cnt1 __cnt6 __cnt9
  have __cnp84 : __cnt31 = __cnt28 := Nat.add_assoc __cnt6 __cnt3 __cnt6
  have __cnp85 : __cnt28 = __cnt31 := Eq.symm __cnp84
  have __cnp86 : __cnt30 = __cnt9 := Nat.add_comm __cnt6 __cnt3
  have __cnp87 : __cnt6 = __cnt6 := Eq.refl __cnt6
  have __cnp88 : __cnt31 = __cnt24 := congrArg₂ Nat.add __cnp86 __cnp87
  have __cnp89 : __cnt24 = __cnt26 := Nat.add_assoc __cnt3 __cnt6 __cnt6
  have __cnp90 : __cnt28 = __cnt24 := Eq.trans __cnp85 __cnp88
  have __cnp91 : __cnt28 = __cnt26 := Eq.trans __cnp90 __cnp89
  have __cnp92 : __cnt17 = __cnt6 := Eq.refl __cnt6
  have __cnp93 : __cnt3 = __cnt3 := Eq.refl __cnt3
  have __cnp94 : __cnt26 = __cnt9 := congrArg₂ Nat.add __cnp93 __cnp92
  have __cnp95 : __cnt28 = __cnt9 := Eq.trans __cnp91 __cnp94
  have __cnp96 : __cnt1 = __cnt1 := Eq.refl __cnt1
  have __cnp97 : __cnt29 = __cnt10 := congrArg₂ Nat.add __cnp96 __cnp95
  have __cnp98 : __cnt27 = __cnt10 := Eq.trans __cnp83 __cnp97
  have __cnp99 : __cnt10 = __cnt10 := Eq.trans __cnp82 __cnp98
  have __cnp100 : __cnt10 = __cnt10 := Eq.symm __cnp99
  have __cnp101 : __cnt4 = __cnt10 := Eq.trans __cnp74 __cnp100
  have __cnp102 : __cnt8 = __cnt10 := Eq.mp (congrArg (fun __cnz : Nat => __cnt8 = __cnz) __cnp101) __cnp52
  have __cnp103 : __cnt8 = __cnt8 := Eq.symm __cnp49
  have __cnp104 : __cnt2 = __cnt8 := Eq.trans __cnp23 __cnp103
  have __cnp105 : __cnt8 < __cnt5 := Eq.mp (congrArg (fun __cnz : Nat => __cnz < __cnt5) __cnp104) __cnp2
  have __cnp106 : __cnt5 = __cnt33 := congrArg₂ Nat.add __cnp56 __cnp56
  have __cnp107 : __cnt33 = __cnt35 := Nat.add_assoc __cnt1 __cnt6 __cnt19
  have __cnp108 : __cnt37 = __cnt34 := Nat.add_assoc __cnt6 __cnt1 __cnt6
  have __cnp109 : __cnt34 = __cnt37 := Eq.symm __cnp108
  have __cnp110 : __cnt36 = __cnt19 := Nat.add_comm __cnt6 __cnt1
  have __cnp111 : __cnt6 = __cnt6 := Eq.refl __cnt6
  have __cnp112 : __cnt37 = __cnt38 := congrArg₂ Nat.add __cnp110 __cnp111
  have __cnp113 : __cnt38 = __cnt39 := Nat.add_assoc __cnt1 __cnt6 __cnt6
  have __cnp114 : __cnt34 = __cnt38 := Eq.trans __cnp109 __cnp112
  have __cnp115 : __cnt34 = __cnt39 := Eq.trans __cnp114 __cnp113
  have __cnp116 : __cnt17 = __cnt6 := Eq.refl __cnt6
  have __cnp117 : __cnt1 = __cnt1 := Eq.refl __cnt1
  have __cnp118 : __cnt39 = __cnt19 := congrArg₂ Nat.add __cnp117 __cnp116
  have __cnp119 : __cnt34 = __cnt19 := Eq.trans __cnp115 __cnp118
  have __cnp120 : __cnt1 = __cnt1 := Eq.refl __cnt1
  have __cnp121 : __cnt35 = __cnt32 := congrArg₂ Nat.add __cnp120 __cnp119
  have __cnp122 : __cnt33 = __cnt32 := Eq.trans __cnp107 __cnp121
  have __cnp123 : __cnt5 = __cnt32 := Eq.trans __cnp106 __cnp122
  have __cnp124 : __cnt19 = __cnt38 := congrArg₂ Nat.add __cnp56 __cnp24
  have __cnp125 : __cnt38 = __cnt39 := Nat.add_assoc __cnt1 __cnt6 __cnt6
  have __cnp126 : __cnt17 = __cnt6 := Eq.refl __cnt6
  have __cnp127 : __cnt1 = __cnt1 := Eq.refl __cnt1
  have __cnp128 : __cnt39 = __cnt19 := congrArg₂ Nat.add __cnp127 __cnp126
  have __cnp129 : __cnt38 = __cnt19 := Eq.trans __cnp125 __cnp128
  have __cnp130 : __cnt19 = __cnt19 := Eq.trans __cnp124 __cnp129
  have __cnp131 : __cnt32 = __cnt33 := congrArg₂ Nat.add __cnp56 __cnp130
  have __cnp132 : __cnt33 = __cnt35 := Nat.add_assoc __cnt1 __cnt6 __cnt19
  have __cnp133 : __cnt37 = __cnt34 := Nat.add_assoc __cnt6 __cnt1 __cnt6
  have __cnp134 : __cnt34 = __cnt37 := Eq.symm __cnp133
  have __cnp135 : __cnt36 = __cnt19 := Nat.add_comm __cnt6 __cnt1
  have __cnp136 : __cnt6 = __cnt6 := Eq.refl __cnt6
  have __cnp137 : __cnt37 = __cnt38 := congrArg₂ Nat.add __cnp135 __cnp136
  have __cnp138 : __cnt38 = __cnt39 := Nat.add_assoc __cnt1 __cnt6 __cnt6
  have __cnp139 : __cnt34 = __cnt38 := Eq.trans __cnp134 __cnp137
  have __cnp140 : __cnt34 = __cnt39 := Eq.trans __cnp139 __cnp138
  have __cnp141 : __cnt17 = __cnt6 := Eq.refl __cnt6
  have __cnp142 : __cnt1 = __cnt1 := Eq.refl __cnt1
  have __cnp143 : __cnt39 = __cnt19 := congrArg₂ Nat.add __cnp142 __cnp141
  have __cnp144 : __cnt34 = __cnt19 := Eq.trans __cnp140 __cnp143
  have __cnp145 : __cnt1 = __cnt1 := Eq.refl __cnt1
  have __cnp146 : __cnt35 = __cnt32 := congrArg₂ Nat.add __cnp145 __cnp144
  have __cnp147 : __cnt33 = __cnt32 := Eq.trans __cnp132 __cnp146
  have __cnp148 : __cnt32 = __cnt32 := Eq.trans __cnp131 __cnp147
  have __cnp149 : __cnt32 = __cnt32 := Eq.symm __cnp148
  have __cnp150 : __cnt5 = __cnt32 := Eq.trans __cnp123 __cnp149
  have __cnp151 : __cnt8 < __cnt32 := Eq.mp (congrArg (fun __cnz : Nat => __cnt8 < __cnz) __cnp150) __cnp105
  have __cnp152 : __cnt10 < __cnt32 := Eq.mp (congrArg (fun __cnz : Nat => __cnz < __cnt32) __cnp102) __cnp151
  have __cnp153 : __cnt20 = __cnt20 := congrArg₂ Nat.add __cnp81 __cnp130
  have __cnp154 : __cnt22 = __cnt20 := Nat.add_assoc __cnt9 __cnt1 __cnt6
  have __cnp155 : __cnt20 = __cnt22 := Eq.symm __cnp154
  have __cnp156 : __cnt21 = __cnt10 := Nat.add_comm __cnt9 __cnt1
  have __cnp157 : __cnt6 = __cnt6 := Eq.refl __cnt6
  have __cnp158 : __cnt22 = __cnt23 := congrArg₂ Nat.add __cnp156 __cnp157
  have __cnp159 : __cnt23 = __cnt25 := Nat.add_assoc __cnt1 __cnt9 __cnt6
  have __cnp160 : __cnt20 = __cnt23 := Eq.trans __cnp155 __cnp158
  have __cnp161 : __cnt20 = __cnt25 := Eq.trans __cnp160 __cnp159
  have __cnp162 : __cnt24 = __cnt26 := Nat.add_assoc __cnt3 __cnt6 __cnt6
  have __cnp163 : __cnt17 = __cnt6 := Eq.refl __cnt6
  have __cnp164 : __cnt3 = __cnt3 := Eq.refl __cnt3
  have __cnp165 : __cnt26 = __cnt9 := congrArg₂ Nat.add __cnp164 __cnp163
  have __cnp166 : __cnt24 = __cnt9 := Eq.trans __cnp162 __cnp165
  have __cnp167 : __cnt1 = __cnt1 := Eq.refl __cnt1
  have __cnp168 : __cnt25 = __cnt10 := congrArg₂ Nat.add __cnp167 __cnp166
  have __cnp169 : __cnt20 = __cnt10 := Eq.trans __cnp161 __cnp168
  have __cnp170 : __cnt20 = __cnt10 := Eq.trans __cnp153 __cnp169
  have __cnp171 : __cnt10 = __cnt20 := Eq.symm __cnp170
  have __cnp172 : __cnt10 = __cnt20 := Eq.trans __cnp99 __cnp171
  have __cnp173 : __cnt20 < __cnt32 := Eq.mp (congrArg (fun __cnz : Nat => __cnz < __cnt32) __cnp172) __cnp152
  have __cnp174 : __cnt33 = __cnt33 := congrArg₂ Nat.add __cnp130 __cnp130
  have __cnp175 : __cnt33 = __cnt35 := Nat.add_assoc __cnt1 __cnt6 __cnt19
  have __cnp176 : __cnt37 = __cnt34 := Nat.add_assoc __cnt6 __cnt1 __cnt6
  have __cnp177 : __cnt34 = __cnt37 := Eq.symm __cnp176
  have __cnp178 : __cnt36 = __cnt19 := Nat.add_comm __cnt6 __cnt1
  have __cnp179 : __cnt6 = __cnt6 := Eq.refl __cnt6
  have __cnp180 : __cnt37 = __cnt38 := congrArg₂ Nat.add __cnp178 __cnp179
  have __cnp181 : __cnt38 = __cnt39 := Nat.add_assoc __cnt1 __cnt6 __cnt6
  have __cnp182 : __cnt34 = __cnt38 := Eq.trans __cnp177 __cnp180
  have __cnp183 : __cnt34 = __cnt39 := Eq.trans __cnp182 __cnp181
  have __cnp184 : __cnt17 = __cnt6 := Eq.refl __cnt6
  have __cnp185 : __cnt1 = __cnt1 := Eq.refl __cnt1
  have __cnp186 : __cnt39 = __cnt19 := congrArg₂ Nat.add __cnp185 __cnp184
  have __cnp187 : __cnt34 = __cnt19 := Eq.trans __cnp183 __cnp186
  have __cnp188 : __cnt1 = __cnt1 := Eq.refl __cnt1
  have __cnp189 : __cnt35 = __cnt32 := congrArg₂ Nat.add __cnp188 __cnp187
  have __cnp190 : __cnt33 = __cnt32 := Eq.trans __cnp175 __cnp189
  have __cnp191 : __cnt33 = __cnt32 := Eq.trans __cnp174 __cnp190
  have __cnp192 : __cnt32 = __cnt33 := Eq.symm __cnp191
  have __cnp193 : __cnt32 = __cnt33 := Eq.trans __cnp148 __cnp192
  have __cnp194 : __cnt20 < __cnt33 := Eq.mp (congrArg (fun __cnz : Nat => __cnt20 < __cnz) __cnp193) __cnp173
  have __cnp195 : __cnt9 < __cnt19 := Nat.lt_of_add_lt_add_right __cnp194
  have __cnp196 : __cnt9 = __cnt3 := Eq.symm __cnp54
  have __cnp197 : __cnt9 = __cnt3 := Eq.trans __cnp81 __cnp196
  have __cnp198 : __cnt3 < __cnt19 := Eq.mp (congrArg (fun __cnz : Nat => __cnz < __cnt19) __cnp197) __cnp195
  have __cnp199 : __cnt19 = __cnt1 := Eq.symm __cnp56
  have __cnp200 : __cnt19 = __cnt1 := Eq.trans __cnp130 __cnp199
  have __cnp201 : __cnt3 < __cnt1 := Eq.mp (congrArg (fun __cnz : Nat => __cnt3 < __cnz) __cnp200) __cnp198
  exact __cnp201

public theorem divQuotientStepBound (q : Nat) : ((q <= 18014398509481983) -> (((q + q) + 1) <= 36028797018963967)) := by
  intro __cnh0
  let __cnt0 : Nat := q
  let __cnt1 : Nat := (nat_lit 18014398509481983)
  let __cnt2 : Nat := __cnt0 + __cnt0
  let __cnt3 : Nat := (nat_lit 1)
  let __cnt4 : Nat := __cnt2 + __cnt3
  let __cnt5 : Nat := (nat_lit 36028797018963967)
  let __cnt6 : Nat := (nat_lit 0)
  let __cnt7 : Nat := __cnt0 + __cnt6
  let __cnt8 : Nat := __cnt7 + __cnt6
  let __cnt9 : Nat := __cnt6 + __cnt6
  let __cnt10 : Nat := __cnt0 + __cnt9
  let __cnt11 : Nat := __cnt1 + __cnt1
  let __cnt12 : Nat := __cnt11 + __cnt3
  let __cnt13 : Nat := (nat_lit 36028797018963966)
  let __cnt14 : Nat := __cnt13 + __cnt3
  have __cnp0 : __cnt0 ≤ __cnt1 := __cnh0
  have __cnp1 : __cnt7 = __cnt0 := Nat.add_zero __cnt0
  have __cnp2 : __cnt0 = __cnt7 := Eq.symm __cnp1
  have __cnp3 : __cnt6 = __cnt6 := Eq.refl __cnt6
  have __cnp4 : __cnt7 = __cnt8 := congrArg₂ Nat.add __cnp2 __cnp3
  have __cnp5 : __cnt8 = __cnt10 := Nat.add_assoc __cnt0 __cnt6 __cnt6
  have __cnp6 : __cnt9 = __cnt6 := Eq.refl __cnt6
  have __cnp7 : __cnt0 = __cnt0 := Eq.refl __cnt0
  have __cnp8 : __cnt10 = __cnt7 := congrArg₂ Nat.add __cnp7 __cnp6
  have __cnp9 : __cnt8 = __cnt7 := Eq.trans __cnp5 __cnp8
  have __cnp10 : __cnt7 = __cnt7 := Eq.trans __cnp4 __cnp9
  have __cnp11 : __cnt7 = __cnt7 := Eq.symm __cnp10
  have __cnp12 : __cnt0 = __cnt7 := Eq.trans __cnp2 __cnp11
  have __cnp13 : __cnt7 ≤ __cnt1 := Eq.mp (congrArg (fun __cnz : Nat => __cnz ≤ __cnt1) __cnp12) __cnp0
  have __cnp14 : __cnt7 = __cnt0 := Eq.symm __cnp2
  have __cnp15 : __cnt7 = __cnt0 := Eq.trans __cnp10 __cnp14
  have __cnp16 : __cnt0 ≤ __cnt1 := Eq.mp (congrArg (fun __cnz : Nat => __cnz ≤ __cnt1) __cnp15) __cnp13
  have __cnp17 : __cnt2 ≤ __cnt11 := Nat.add_le_add __cnp16 __cnp16
  have __cnp18 : __cnt3 ≤ __cnt3 := Nat.le_refl __cnt3
  have __cnp19 : __cnt4 ≤ __cnt12 := Nat.add_le_add __cnp17 __cnp18
  have __cnp20 : __cnt1 = __cnt1 := Eq.refl __cnt1
  have __cnp21 : __cnt11 = __cnt11 := congrArg₂ Nat.add __cnp20 __cnp20
  have __cnp22 : __cnt11 = __cnt13 := Eq.refl __cnt13
  have __cnp23 : __cnt11 = __cnt13 := Eq.trans __cnp21 __cnp22
  have __cnp24 : __cnt3 = __cnt3 := Eq.refl __cnt3
  have __cnp25 : __cnt12 = __cnt14 := congrArg₂ Nat.add __cnp23 __cnp24
  have __cnp26 : __cnt14 = __cnt5 := Eq.refl __cnt5
  have __cnp27 : __cnt12 = __cnt5 := Eq.trans __cnp25 __cnp26
  have __cnp28 : __cnt5 = __cnt5 := Eq.refl __cnt5
  have __cnp29 : __cnt5 = __cnt5 := Eq.symm __cnp28
  have __cnp30 : __cnt12 = __cnt5 := Eq.trans __cnp27 __cnp29
  have __cnp31 : __cnt4 ≤ __cnt5 := Eq.mp (congrArg (fun __cnz : Nat => __cnt4 ≤ __cnz) __cnp30) __cnp19
  have __cnp32 : __cnt5 ≤ __cnt5 := of_decide_eq_true (Eq.refl true)
  have __cnp33 : __cnt4 ≤ __cnt5 := Nat.le_trans __cnp31 __cnp32
  exact __cnp33

end ConstructiveComponent.Bounds

module
import BoundedNumeric.Compatibility
#print axioms BoundedNumeric.Compatibility.comparison
#print axioms BoundedNumeric.Compatibility.constantIteration
#print axioms BoundedNumeric.Compatibility.fixedSigned
#print axioms BoundedNumeric.Compatibility.iteration
#print axioms BoundedNumeric.Compatibility.step

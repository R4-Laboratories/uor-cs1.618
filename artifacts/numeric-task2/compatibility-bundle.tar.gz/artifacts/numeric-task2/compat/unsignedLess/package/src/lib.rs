#![cfg_attr(not(feature = "std"), no_std)]
#![allow(dead_code, non_snake_case, unused_parens, unused_variables)]
extern crate alloc;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ComputeError {
    AddOverflow,
    MulOverflow,
    ShiftExponentTooLarge,
    ShiftOverflow,
    PowExponentTooLarge,
    PowOverflow,
    OutputTooSmall,
}

pub fn unsignedLess(a: u64, b: u64) -> bool {
    { let _x_9 = (a).checked_sub(b); match _x_9 {
        None => { let _x_17 = true; _x_17 },
        Some(val_12) => { let _x_18 = false; _x_18 },
    } }
}

#![cfg_attr(not(feature = "std"), no_std)]
#![allow(dead_code, non_snake_case, unused_parens, unused_variables)]
extern crate alloc;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ComputeError {
    AddOverflow,
    MulOverflow,
    ShiftExponentTooLarge,
    ShiftOverflow,
    PowExponentTooLarge,
    PowOverflow,
    OutputTooSmall,
}

pub fn step(s: Option<u32>) -> Option<u32> {
    match s {
        None => s,
        Some(val_13) => { let _x_23 = 1; { let _x_24 = (val_13).checked_add(_x_23); _x_24 } },
    }
}

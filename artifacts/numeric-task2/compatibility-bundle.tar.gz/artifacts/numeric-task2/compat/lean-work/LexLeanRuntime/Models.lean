module
public import Init
import Lean
import all Lean.Meta.Constructions.SparseCasesOn
set_option autoImplicit false
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000000
set_option Elab.async false

open Lean

namespace LexLeanCore.Runtime

private def fail {α : Type} (message : String) : Except String α := .error message

private def field (json : Json) (name : String) : Except String Json :=
  json.getObjVal? name

private def stringField (json : Json) (name : String) : Except String String := do
  (← field json name).getStr?

private def natField (json : Json) (name : String) : Except String Nat := do
  (← field json name).getNat?

private def boolField (json : Json) (name : String) : Except String Bool := do
  (← field json name).getBool?

private def arrayField (json : Json) (name : String) : Except String (Array Json) := do
  (← field json name).getArr?

private def optionalField (json : Json) (name : String) : Option Json :=
  match json.getObjVal? name with
  | .ok value => some value
  | .error _ => none

private def unescapeSegment (segment : String) : String := Id.run do
  let mut out := ""
  let mut pending := false
  for c in segment.toList do
    if pending then
      out := out.push (if c.toNat == 100 then Char.ofNat 46 else if c.toNat == 104 then Char.ofNat 35 else c)
      pending := false
    else if c.toNat == 92 then pending := true
    else out := out.push c
  return out

private def segmentIsNumeric (segment : String) : Bool :=
  segment.startsWith "#" && segment.length > 1 && (segment.drop 1).all Char.isDigit

private def nameOf (value : String) : Name :=
  if value.isEmpty then .anonymous else
  value.splitOn "." |>.foldl (fun name part =>
    if segmentIsNumeric part then name.num (part.drop 1).toNat! else name.str (unescapeSegment part)) .anonymous

private partial def levelOf (json : Json) : Except String Level := do
  match ← stringField json "k" with
  | "z" => pure .zero
  | "s" => pure (.succ (← levelOf (← field json "a")))
  | "m" | "i" =>
      let values ← (← field json "a").getArr?
      let some left := values[0]? | fail "core level pair lacks its left value"
      let some right := values[1]? | fail "core level pair lacks its right value"
      if values.size != 2 then fail "core level pair has extra values"
      let left ← levelOf left
      let right ← levelOf right
      if (← stringField json "k") == "m" then pure (.max left right) else pure (.imax left right)
  | "p" => pure (.param (nameOf (← stringField json "a")))
  | kind => fail s!"unknown core level kind '{kind}'"

private def levelsOf (json : Json) : Except String (List Level) := do
  let values ← json.getArr?
  values.toList.mapM levelOf

private def namesOf (json : Json) : Except String (List Name) := do
  let values ← json.getArr?
  values.toList.mapM fun value => do pure (nameOf (← value.getStr?))

private def binderOf (value : String) : Except String BinderInfo :=
  match value with
  | "e" => pure .default
  | "i" => pure .implicit
  | "s" => pure .strictImplicit
  | "c" => pure .instImplicit
  | kind => fail s!"unknown core binder kind '{kind}'"

private def nodeAt (nodes : Array Expr) (index : Nat) : Except String Expr :=
  match nodes[index]? with
  | some node => .ok node
  | none => fail s!"core node reference {index} is out of range"

private def dataValueOf (json : Json) : Except String DataValue := do
  match ← stringField json "t" with
  | "b" => return .ofBool (← boolField json "v")
  | "n" =>
    let some n := (← stringField json "v").toNat? | fail "invalid mdata natural"
    return .ofNat n
  | "i" =>
    let some n := (← stringField json "v").toInt? | fail "invalid mdata integer"
    return .ofInt n
  | "s" => return .ofString (← stringField json "v")
  | "m" => return .ofName (nameOf (← stringField json "v"))
  | other => fail s!"unknown mdata value kind '{other}'"

private def nodeOf (nodes : Array Expr) (json : Json) : Except String Expr := do
  match ← stringField json "k" with
  | "b" => pure (.bvar (← natField json "i"))
  | "s" => pure (.sort (← levelOf (← field json "l")))
  | "c" => pure (.const (nameOf (← stringField json "n")) (← levelsOf (← field json "u")))
  | "a" => pure (.app (← nodeAt nodes (← natField json "f")) (← nodeAt nodes (← natField json "x")))
  | "l" => pure (.lam (nameOf (← stringField json "n")) (← nodeAt nodes (← natField json "t"))
      (← nodeAt nodes (← natField json "v")) (← binderOf (← stringField json "b")))
  | "p" => pure (.forallE (nameOf (← stringField json "n")) (← nodeAt nodes (← natField json "t"))
      (← nodeAt nodes (← natField json "v")) (← binderOf (← stringField json "b")))
  | "e" => pure (.letE (nameOf (← stringField json "n")) (← nodeAt nodes (← natField json "t"))
      (← nodeAt nodes (← natField json "v")) (← nodeAt nodes (← natField json "body"))
      (← boolField json "d"))
  | "n" =>
      let value ← stringField json "v"
      let some value := value.toNat? | fail s!"invalid core natural literal '{value}'"
      pure (.lit (.natVal value))
  | "t" =>
      let values ← (← field json "v").getArr?
      let chars ← values.toList.mapM fun value => do pure (Char.ofNat (← value.getNat?))
      pure (.lit (.strVal (String.ofList chars)))
  | "j" => pure (.proj (nameOf (← stringField json "s")) (← natField json "i")
      (← nodeAt nodes (← natField json "x")))
  | "d" =>
      let rows ← arrayField json "m"
      let mut data : KVMap := {}
      for row in rows do
        data := data.insert (nameOf (← stringField row "n")) (← dataValueOf (← field row "v"))
      pure (.mdata data (← nodeAt nodes (← natField json "x")))
  | kind => fail s!"unknown core node kind '{kind}'"

private def liftString {α : Type} : Except String α → CoreM α
  | .ok value => pure value
  | .error message => throwError message

private def findDeclaration (declarations : Array Json) (name : String) : CoreM Json := do
  for declaration in declarations do
    if (← liftString (stringField declaration "name")) == name then return declaration
  throwError s!"core declaration '{name}' is absent"

private def sparseIndices (last : String) : Option (List Nat) :=
  match last.dropPrefix? "_sparseCasesOn_" with
  | none => none
  | some rest =>
      let numbers := rest.toString.splitOn "_" |>.map String.toNat?
      if numbers.any Option.isNone then none else
      let numbers := numbers.filterMap id
      if numbers.isEmpty then none else some numbers.reverse

private def natsOf (json : Json) : Except String (Array Nat) := do
  (← json.getArr?).mapM fun v => v.getNat?

private def optNatOf (json : Json) : Except String (Option Nat) := do
  let values ← json.getArr?
  match values.size with
  | 0 => pure none
  | 1 => pure (some (← values[0]!.getNat?))
  | _ => fail "an optional natural has more than one value"

private def hasTag (json : Json) (wanted : String) : CoreM Bool := do
  let some tags := optionalField json "tags" | return false
  for tag in ← liftString tags.getArr? do
    if (← liftString tag.getStr?) == wanted then return true
  return false

private def installMatcher (name : Name) (info : Json) : CoreM Unit := do
  let altRows ← liftString (arrayField info "alts")
  let mut alts : Array Lean.Meta.Match.AltParamInfo := #[]
  for row in altRows do
    let numFields ← liftString (natField row "fields")
    let numOverlaps ← liftString (natField row "overlaps")
    let hasUnitThunk ← liftString (boolField row "unit_thunk")
    alts := alts.push { numFields, numOverlaps, hasUnitThunk }
  let discrRows ← liftString (arrayField info "discrs")
  let mut discrs : Array Lean.Meta.Match.DiscrInfo := #[]
  for row in discrRows do
    let cells ← liftString row.getArr?
    match cells.size with
    | 0 => discrs := discrs.push {}
    | 1 => discrs := discrs.push { hName? := some (nameOf (← liftString cells[0]!.getStr?)) }
    | _ => throwError "a matcher discriminant has more than one name"
  let uElimPos? ← match optionalField info "u_elim_pos" with
    | some v => pure (some (← liftString v.getNat?))
    | none => pure none
  let numParams ← liftString (natField info "num_params")
  let numDiscrs ← liftString (natField info "num_discrs")
  let mut overlaps : Lean.Meta.Match.Overlaps := {}
  for row in ← liftString (arrayField info "overlaps") do
    let pair ← liftString row.getArr?
    let some overlappedJson := pair[0]? | throwError "overlap entry lacks its key"
    let some overlappingJson := pair[1]? | throwError "overlap entry lacks its values"
    let overlapped ← liftString overlappedJson.getNat?
    for overlapping in ← liftString (natsOf overlappingJson) do
      overlaps := overlaps.insert overlapping overlapped
  modifyEnv (Lean.Meta.Match.Extension.addMatcherInfo · name
    { numParams, numDiscrs, altInfos := alts, uElimPos?, discrInfos := discrs, overlaps })

private def installEqnInfo (nodes : Array Expr) (name : Name) (info : Json) : CoreM Unit := do
  let permRows ← liftString (arrayField info "perms")
  let mut perms : Array (Array (Option Nat)) := #[]
  for row in permRows do
    let cells ← liftString row.getArr?
    perms := perms.push (← liftString (cells.mapM optNatOf))
  let revRows ← liftString (arrayField info "rev_deps")
  let mut rev : Array (Array (Array Nat)) := #[]
  for a in revRows do
    let mut inner : Array (Array Nat) := #[]
    for b in ← liftString a.getArr? do inner := inner.push (← liftString (natsOf b))
    rev := rev.push inner
  let levelParams ← liftString (namesOf (← liftString (field info "levels")))
  let type ← liftString (nodeAt nodes (← liftString (natField info "type")))
  let value ← liftString (nodeAt nodes (← liftString (natField info "value")))
  let recArgPos ← liftString (natField info "rec_arg_pos")
  let declNames := (← liftString (namesOf (← liftString (field info "declarations")))).toArray
  let numFixed ← liftString (natField info "num_fixed")
  let value : Lean.Elab.Structural.EqnInfo := {
    declName := name, levelParams, type, value, recArgPos, declNames,
    fixedParamPerms := { numFixed, perms, revDeps := rev } }
  modifyEnv (Lean.Elab.Structural.eqnInfoExt.insert · name value)

private def sameAsRow (nodes : Array Expr) (json : Json) (name : Name) (levelParams : List Name)
    (type : Expr) (kindString : String) : CoreM Unit := do
  let some made := (← getEnv).find? name | throwError s!"core declaration '{name}' is absent"
  let stored ← match optionalField json "value" with
    | some v => pure (some (← liftString (nodeAt nodes (← liftString v.getNat?))))
    | none => pure none
  let sameKind := match made, kindString with
    | .thmInfo _, "theorem" => true
    | .defnInfo _, "definition" => true
    | .defnInfo _, "abbrev" => true
    | _, _ => false
  unless sameKind && made.levelParams == levelParams && made.type == type
      && made.value? (allowOpaque := true) == stored do
    throwError s!"core declaration '{name}' is not what the elaborator's construction makes"

private def installAtRow (nodes : Array Expr) (json : Json) : CoreM Unit := do
  let name := nameOf (← liftString (stringField json "name"))
  unless (← getEnv).contains name do return
  if ← hasTag json "recursive" then modifyEnv (Lean.Meta.recExt.tag · name)
  match ← liftString (stringField json "transparency") with
  | "reducible" => Lean.setReducibilityStatus name .reducible
  | "irreducible" => Lean.setReducibilityStatus name .irreducible
  | "implicit-reducible" => Lean.setReducibilityStatus name .implicitReducible
  | _ => pure ()
  if let some info := optionalField json "matcher" then
    unless Lean.Meta.isMatcherCore (← getEnv) name do installMatcher name info
  match optionalField json "eqn_info" with
  | some info =>
      unless (Lean.Elab.Structural.eqnInfoExt.find? (← getEnv) name).isSome do
        installEqnInfo nodes name info
  | none => Lean.enableRealizationsForConst name
  if let .str owner "_sunfold" := name then
    if (← getEnv).contains owner then Lean.enableRealizationsForConst owner

private def kindIsMade (made : ConstantInfo) (kindString : String) : Bool :=
  match made, kindString with
  | .thmInfo _, "theorem" => true
  | .defnInfo info, "definition" => !info.hints.isAbbrev
  | .defnInfo info, "abbrev" => info.hints.isAbbrev
  | _, _ => false

private def sparseNames (env : Environment) : NameSet :=
  env.constants.map₂.foldl (fun names name _ =>
    match name with
    | .str _ last => if (sparseIndices last).isSome then names.insert name else names
    | _ => names) {}

private def remakeSparse (name : Name) (sparse : Json) : CoreM Unit := do
  let indName := nameOf (← liftString (stringField sparse "ind_name"))
  let constructors ← liftString (namesOf (← liftString (field sparse "interesting_ctors")))
  let some (.inductInfo info) := (← getEnv).find? indName
    | throwError s!"core declaration '{name}' names the type '{indName}', which is not an inductive type"
  let mut seen : List Name := []
  for constructor in constructors do
    if info.ctors.idxOf constructor >= info.ctors.length then
      throwError s!"core declaration '{name}' names '{constructor}', which is not a constructor of '{indName}'"
    if seen.contains constructor then
      throwError s!"core declaration '{name}' names the constructor '{constructor}' twice"
    seen := constructor :: seen
  let majorPos ← liftString (natField sparse "major_pos")
  let arity ← liftString (natField sparse "arity")
  let (owner, idx, parentIdxs) ← match name with
    | .str parent last =>
        match sparseIndices last with
        | some (idx :: parents) => pure (parent, idx, parents)
        | _ => throwError s!"core declaration '{name}' is not named like a sparse casesOn"
    | _ => throwError s!"core declaration '{name}' is not named like a sparse casesOn"
  Lean.enableRealizationsForConst indName
  Lean.Meta.MetaM.run' <| Lean.Meta.realizeConst indName name do
    setDeclNGen { namePrefix := owner, idx, parentIdxs }
    let made ← Lean.withExporting (isExporting := !Lean.isPrivateName name)
      (Lean.Meta.mkSparseCasesOn indName constructors.toArray)
    unless made == name do
      throwError s!"the sparse casesOn the elaborator makes is '{made}', not '{name}'"
  let some info := Lean.Meta.getSparseCasesOnInfoCore (← getEnv) name
    | throwError s!"core declaration '{name}' has no sparse casesOn record"
  unless info.indName == indName && info.majorPos == majorPos && info.arity == arity
      && info.insterestingCtors.toList == constructors do
    throwError s!"core declaration '{name}' states another sparse casesOn record than the elaborator keeps"
  for isPrivate in [false, true] do
    modifyEnv fun env => Lean.Meta.sparseCasesOnCacheExt.modifyState env fun s =>
      let key : Lean.Meta.SparseCasesOnKey := { indName, ctors := constructors.toArray, isPrivate }
      if s.contains key then s else s.insert key name

private def addDerived (json : Json) (name : Name) (kindString : String) : CoreM Unit := do
  unless (← getEnv).contains name do
    if let some sparse := optionalField json "sparse" then
      remakeSparse name sparse
    else if Lean.isReservedName (← getEnv) name then
      Lean.withExporting (isExporting := true) (Lean.executeReservedNameAction name)
    else
      throwError s!"derived core declaration '{name}' bears a name the elaborator does not reserve and states no sparse casesOn record"
  let some made := (← getEnv).find? name
    | throwError s!"derived core declaration '{name}' bears a name the elaborator reserves, and its construction does not make it"
  unless kindIsMade made kindString do
    throwError s!"derived core declaration '{name}' is not a {kindString} as the elaborator's construction makes it"

private def addOneUnchecked (nodes : Array Expr) (declarations : Array Json)
    (json : Json) : CoreM Unit := do
  if ← liftString (boolField json "generated") then return
  let nameString ← liftString (stringField json "name")
  let name := nameOf nameString
  let kindString ← liftString (stringField json "kind")
  if (optionalField json "derived").isSome then
    addDerived json name kindString
    return
  let levelParams ← liftString (namesOf (← liftString (field json "levels")))
  let type ← liftString (nodeAt nodes (← liftString (natField json "type")))
  let all ← match optionalField json "all" with
    | some value => liftString (namesOf value)
    | none => pure [name]
  if (← getEnv).contains name then
    sameAsRow nodes json name levelParams type kindString
    return
  if Lean.isReservedName (← getEnv) name then
    Lean.withExporting (isExporting := true) (Lean.executeReservedNameAction name)
    unless (← getEnv).contains name do
      throwError s!"core declaration '{name}' bears a name the elaborator reserves, and its construction does not make it"
    sameAsRow nodes json name levelParams type kindString
    return
  if let some sparse := optionalField json "sparse" then
    remakeSparse name sparse
    let some made := (← getEnv).find? name | throwError s!"core declaration '{name}' is absent"
    let value ← liftString (nodeAt nodes (← liftString (natField json "value")))
    unless made.type == type && made.value? == some value do
      throwError s!"core declaration '{name}' is not the sparse casesOn the elaborator makes"
    return
  match kindString with
  | "inductive" =>
      let metadata ← liftString (field json "inductive")
      let numParams ← liftString (natField metadata "num_params")
      let constructorNames ← liftString (arrayField metadata "constructors")
      let mut constructors : List Constructor := []
      for constructorName in constructorNames do
        let constructorName ← liftString constructorName.getStr?
        let row ← findDeclaration declarations constructorName
        let constructorType ← liftString (nodeAt nodes (← liftString (natField row "type")))
        constructors := constructors.concat { name := nameOf constructorName, type := constructorType }
      Lean.addDecl (.inductDecl levelParams numParams [{ name, type, ctors := constructors }] false)
        (forceExpose := true)
  | "abbrev" | "definition" =>
      let valueIndex ← liftString (natField json "value")
      let value ← liftString (nodeAt nodes valueIndex)
      let metadata ← liftString (field json "reducibility")
      let reducibilityKind ← liftString (stringField metadata "kind")
      let hints ← match reducibilityKind with
        | "abbrev" => pure ReducibilityHints.abbrev
        | "opaque" => pure (default : ReducibilityHints)
        | "regular" => pure (ReducibilityHints.regular
            (UInt32.ofNat (← liftString (natField metadata "height"))))
        | other => throwError s!"unknown core reducibility kind '{other}'"
      let safety ← match optionalField json "safety" with
        | none => pure DefinitionSafety.safe
        | some v => match ← liftString v.getStr? with
          | "partial" => pure DefinitionSafety.partial
          | "unsafe" => pure DefinitionSafety.«unsafe»
          | other => throwError s!"unknown core definition safety '{other}'"
      let defn : DefinitionVal := { name, levelParams, type, value, hints, safety, all }
      if safety == .safe then Lean.addDecl (.defnDecl defn) (forceExpose := true)
      else
        if (← getEnv).contains name then return
        let mut group : List DefinitionVal := []
        for member in all do
          let row ← findDeclaration declarations member.toString
          let memberType ← liftString (nodeAt nodes (← liftString (natField row "type")))
          let memberValue ← liftString (nodeAt nodes (← liftString (natField row "value")))
          let memberLevels ← liftString (namesOf (← liftString (field row "levels")))
          let memberMetadata ← liftString (field row "reducibility")
          let memberHints ← match ← liftString (stringField memberMetadata "kind") with
            | "abbrev" => pure ReducibilityHints.abbrev
            | "opaque" => pure (default : ReducibilityHints)
            | "regular" => pure (ReducibilityHints.regular
                (UInt32.ofNat (← liftString (natField memberMetadata "height"))))
            | other => throwError s!"unknown core reducibility kind '{other}'"
          let memberDefn : DefinitionVal := {
            name := member
            levelParams := memberLevels
            type := memberType
            value := memberValue
            hints := memberHints
            safety
            all }
          group := group.concat memberDefn
        Lean.addDecl (.mutualDefnDecl group) (forceExpose := true)
  | "theorem" =>
      let value ← liftString (nodeAt nodes (← liftString (natField json "value")))
      Lean.addDecl (.thmDecl { name, levelParams, type, value, all }) (forceExpose := true)
  | "constructor" | "recursor" =>
      throwError s!"non-generated primitive core declaration '{nameString}'"
  | kind => throwError s!"unknown core declaration kind '{kind}'"

private def addOne (nodes : Array Expr) (declarations : Array Json) (json : Json) : CoreM Unit := do
  let name ← liftString (stringField json "name")
  try
    addOneUnchecked nodes declarations json
    installAtRow nodes json
  catch error =>
    throwError m!"native core declaration '{name}':{indentD error.toMessageData}"

private def decodeNodeBatch (nodes : Array Expr) (data : String) : CoreM (Array Expr) := do
  let json ← liftString (Json.parse data)
  let rows ← liftString json.getArr?
  let mut nodes := nodes
  for row in rows do
    nodes := nodes.push (← liftString (nodeOf nodes row))
  pure nodes

private def installMetadata (nodes : Array Expr) (declaration : Json) : CoreM Unit := do
  let name := nameOf (← liftString (stringField declaration "name"))
  let status ← match ← liftString (stringField declaration "transparency") with
    | "reducible" => pure ReducibilityStatus.reducible
    | "semireducible" => pure ReducibilityStatus.semireducible
    | "irreducible" => pure ReducibilityStatus.irreducible
    | "implicit-reducible" => pure ReducibilityStatus.implicitReducible
    | other => throwError s!"unknown core transparency '{other}'"
  Lean.setReducibilityStatus name status
  if let some kind := optionalField declaration "inline" then
    let kind ← match ← liftString kind.getStr? with
      | "inline" => pure Lean.Compiler.InlineAttributeKind.inline
      | "noinline" => pure Lean.Compiler.InlineAttributeKind.noinline
      | "macro_inline" => pure Lean.Compiler.InlineAttributeKind.macroInline
      | "inline_if_reduce" => pure Lean.Compiler.InlineAttributeKind.inlineIfReduce
      | "always_inline" => pure Lean.Compiler.InlineAttributeKind.alwaysInline
      | other => throwError s!"unknown core inlining attribute '{other}'"
    unless Lean.Compiler.getInlineAttribute? (← getEnv) name == some kind do
      match Lean.Compiler.setInlineAttribute (← getEnv) name kind with
      | .ok env => setEnv env
      | .error message => throwError message
  if let some tags := optionalField declaration "tags" then
    for tag in ← liftString tags.getArr? do
      match ← liftString tag.getStr? with
      | "protected" => modifyEnv (Lean.addProtected · name)
      | "aux_recursor" => modifyEnv (Lean.markAuxRecursor · name)
      | "elab_as_elim" => Lean.Elab.Term.elabAsElim.setTag name
      | "defeq" => Lean.defeqAttr.setTag name
      | "backward_defeq" => Lean.backwardDefeqAttr.setTag name
      | "recursive" => modifyEnv (Lean.Meta.recExt.tag · name)
      | "sparse_cases_on" => pure ()
      | other => throwError s!"unknown core declaration tag '{other}'"
  if let some info := optionalField declaration "no_confusion" then
    let arity ← liftString (natField info "arity")
    let value ← match ← liftString (stringField info "kind") with
      | "regular" => pure (Lean.NoConfusionInfo.regular arity (← liftString (natField info "lhs")) (← liftString (natField info "rhs")))
      | "per_ctor" => pure (Lean.NoConfusionInfo.perCtor arity (← liftString (natField info "fields")))
      | other => throwError s!"unknown no-confusion kind '{other}'"
    modifyEnv (Lean.markNoConfusion · name value)
  if let some info := optionalField declaration "matcher" then
    unless Lean.Meta.isMatcherCore (← getEnv) name do installMatcher name info
  if let some info := optionalField declaration "projection" then
    modifyEnv (Lean.addProjectionFnInfo · name (nameOf (← liftString (stringField info "constructor")))
      (← liftString (natField info "num_params")) (← liftString (natField info "index")) (← liftString (boolField info "from_class")))
  if let some info := optionalField declaration "simp" then
    let kind ← match ← liftString (stringField info "attribute") with
      | "global" => pure AttributeKind.global
      | "local" => pure AttributeKind.local
      | "scoped" => pure AttributeKind.scoped
      | other => throwError s!"unknown core simp attribute kind '{other}'"
    Lean.Meta.MetaM.run' <| Lean.Meta.addSimpTheorem Lean.Meta.simpExtension name
      (← liftString (boolField info "post")) false kind (← liftString (natField info "priority"))
  if let some info := optionalField declaration "eqn_info" then
    unless (Lean.Elab.Structural.eqnInfoExt.find? (← getEnv) name).isSome do
      installEqnInfo nodes name info

private def compileRows (declarations : Array Json) : CoreM Unit := do
  let mut compiledRows : Array (Json × Name) := #[]
  for declaration in declarations do
    if let some flag := optionalField declaration "compiled" then
      if ← liftString flag.getBool? then
        compiledRows := compiledRows.push (declaration, nameOf (← liftString (stringField declaration "name")))
  for (declaration, name) in compiledRows do
    if (← liftString (stringField declaration "kind")) == "inductive" then
      Lean.compileDecls #[name]
  for (declaration, name) in compiledRows do
    if (← liftString (stringField declaration "kind")) != "inductive" && (optionalField declaration "safety").isSome then
      Lean.compileDecls #[name]
  let mut done : NameSet := {}
  for declaration in declarations do
    let name := nameOf (← liftString (stringField declaration "name"))
    if (← liftString (stringField declaration "kind")) != "inductive" && (optionalField declaration "safety").isNone
        && compiledRows.any (·.2 == name) && !done.contains name then
      let all ← match optionalField declaration "all" with
        | some v => liftString (namesOf v)
        | none => pure [name]
      let group := all.filter fun n => compiledRows.any (·.2 == n)
      for n in group do done := done.insert n
      Lean.compileDecls group.toArray
    if let some tags := optionalField declaration "tags" then
      for tag in ← liftString tags.getArr? do
        if (← liftString tag.getStr?) == "sparse_cases_on" then
          modifyEnv (Lean.markSparseCasesOn · name)

def decodeAndAdd (nodeBatches : Array String) (data : String) : CoreM Unit := do
  modifyEnv fun env => Lean.Meta.sparseCasesOnCacheExt.modifyState env fun s =>
    s.toList.foldl (init := {}) fun kept (key, made) =>
      if (Lean.privateToUserName made).components.contains `LexLeanCore then kept else kept.insert key made
  let mut nodes : Array Expr := #[]
  for batch in nodeBatches do
    nodes ← decodeNodeBatch nodes batch
  let document ← liftString (Json.parse data)
  let declarations ← liftString (arrayField document "declarations")
  let order ← liftString (arrayField document "order")
  let sparseBefore := sparseNames (← getEnv)
  for index in order do
    let index ← liftString index.getNat?
    let some declaration := declarations[index]? |
      throwError s!"core declaration order index {index} is out of range"
    addOne nodes declarations declaration
  let mut stated : NameSet := {}
  if let some names := optionalField document "module_sparse" then
    for name in ← liftString names.getArr? do
      stated := stated.insert (nameOf (← liftString name.getStr?))
  for declaration in declarations do
    stated := stated.insert (nameOf (← liftString (stringField declaration "name")))
  for made in (sparseNames (← getEnv)).toList do
    unless sparseBefore.contains made || stated.contains made do
      throwError s!"the construction made the sparse casesOn '{made}', which the module does not state"
  if let some scan := optionalField document "module_scan" then
    let env ← getEnv
    let mut used : NameSet := {}
    for row in ← liftString (arrayField scan "rows") do
      if let some info := env.find? (nameOf (← liftString row.getStr?)) then
        for name in info.type.getUsedConstants do used := used.insert name
        if let some value := info.value? then
          for name in value.getUsedConstants do used := used.insert name
    for row in ← liftString (arrayField scan "sparse") do
      let name := nameOf (← liftString row.getStr?)
      unless used.contains name do
        throwError s!"the derived sparse casesOn '{name}' is referred to by no row of the module"
  for declaration in declarations do
    if (← liftString (stringField declaration "kind")) == "inductive" then
      let metadata ← liftString (field declaration "inductive")
      if let some structureData := optionalField metadata "structure" then
        let name := nameOf (← liftString (stringField declaration "name"))
        let fieldRows ← liftString (arrayField structureData "fields")
        let mut fields : Array StructureFieldInfo := #[]
        for row in fieldRows do
          let subobject? : Option Name ← match optionalField row "subobject" with
            | some value => pure (some (nameOf (← liftString value.getStr?)))
            | none => pure none
          let autoParam? : Option Expr ← match optionalField row "auto_param" with
            | some value => pure (some (← liftString (nodeAt nodes (← liftString value.getNat?))))
            | none => pure none
          let fieldName := nameOf (← liftString (stringField row "name"))
          let projFn := nameOf (← liftString (stringField row "projection"))
          let binderInfo ← liftString (binderOf (← liftString (stringField row "binder")))
          fields := fields.push {
            fieldName
            projFn
            subobject?
            binderInfo
            autoParam? }
        setEnv <| Lean.registerStructure (← getEnv) { structName := name, fields }
  for declaration in declarations do
    if (← liftString (stringField declaration "kind")) == "inductive" then
      let metadata ← liftString (field declaration "inductive")
      if let some structureData := optionalField metadata "structure" then
        let name := nameOf (← liftString (stringField declaration "name"))
        let parentRows ← liftString (arrayField structureData "parents")
        let mut parents : Array StructureParentInfo := #[]
        for row in parentRows do
          let structName := nameOf (← liftString (stringField row "name"))
          let subobject ← liftString (boolField row "subobject")
          let projFn := nameOf (← liftString (stringField row "projection"))
          parents := parents.push {
            structName
            subobject
            projFn }
        Lean.setStructureParents name parents
  for declaration in declarations do
    if (← liftString (stringField declaration "kind")) == "inductive" then
      let metadata ← liftString (field declaration "inductive")
      if (optionalField metadata "structure").isSome then
        discard <| Lean.computeStructureResolutionOrder
          (nameOf (← liftString (stringField declaration "name"))) true
  for declaration in declarations do
    installMetadata nodes declaration
  compileRows declarations
  for declaration in declarations do
    if let some kind := optionalField declaration "grind" then
      let name := nameOf (← liftString (stringField declaration "name"))
      let kind ← match ← liftString kind.getStr? with
        | "eq_lhs" => pure (Lean.Meta.Grind.EMatchTheoremKind.eqLhs false)
        | "eq_rhs" => pure (Lean.Meta.Grind.EMatchTheoremKind.eqRhs false)
        | "eq_both" => pure (Lean.Meta.Grind.EMatchTheoremKind.eqBoth false)
        | "eq_bwd" => pure Lean.Meta.Grind.EMatchTheoremKind.eqBwd
        | "fwd" => pure Lean.Meta.Grind.EMatchTheoremKind.fwd
        | "bwd" => pure (Lean.Meta.Grind.EMatchTheoremKind.bwd false)
        | "left_right" => pure Lean.Meta.Grind.EMatchTheoremKind.leftRight
        | "right_left" => pure Lean.Meta.Grind.EMatchTheoremKind.rightLeft
        | "default" => pure (Lean.Meta.Grind.EMatchTheoremKind.default false)
        | other => throwError s!"unknown core grind attribute '{other}'"
      Lean.Meta.MetaM.run' (Lean.Meta.Grind.grindExt.addEMatchAttr name AttributeKind.global kind {})
  for declaration in declarations do
    let generated ← liftString (boolField declaration "generated")
    if !generated && (← liftString (boolField declaration "class")) then
      let name := nameOf (← liftString (stringField declaration "name"))
      match Lean.addClass (← getEnv) name with
      | .ok env => setEnv env
      | .error message => throwError message
  for declaration in declarations do
    if let some metadata := optionalField declaration "instance" then
      let name := nameOf (← liftString (stringField declaration "name"))
      let priority ← liftString (natField metadata "priority")
      let attributeKind ← match ← liftString (stringField metadata "attribute") with
        | "global" => pure AttributeKind.global
        | "local" => pure AttributeKind.local
        | "scoped" => pure AttributeKind.scoped
        | other => throwError s!"unknown core instance attribute kind '{other}'"
      Lean.Meta.MetaM.run' <| Lean.Meta.addInstance name attributeKind priority
      let expectedRows ← liftString (arrayField metadata "synthesis_order")
      let mut expected : Array Nat := #[]
      for row in expectedRows do expected := expected.push (← liftString row.getNat?)
      let some actual := (Lean.Meta.instanceExtension.getState (← getEnv)
          |>.instanceNames.find? name) |
        throwError s!"core instance '{name}' was not registered"
      unless actual.synthOrder == expected do
        throwError s!"core instance '{name}' reconstructed synthesis order {actual.synthOrder.toList} instead of {expected.toList}"

end LexLeanCore.Runtime

run_cmd Lean.Elab.Command.liftCoreM (LexLeanCore.Runtime.decodeAndAdd #[
  (
    "[{\"k\":\"s\",\"l\":{\"k\":\"s\",\"a\":{\"k\":\"z\"}}},{\"k\":\"b\",\"i\":1},{\"k\":\"p\",\"n\":\"a._@._internal._hyg.#0\",\"b\":\"e\",\"t\":1,\"v\":1},{\"k\":\"b\",\"i\":2},{\"k\":\"c\",\"n\":\"Bool\",\"u\":[]},{\"k\":\"p\",\"n\":\"a._@._internal._hyg.#0\",\"b\":\"e\",\"t\":3,\"v\":4},{\"k\":\"p\",\"n\":\"a._@._internal._hyg.#0\",\"b\":\"e\",\"t\":1,\"v\":5},{\"k\":\"c\",\"n\":\"List\",\"u\":[{\"k\":\"z\"}]},{\"k\":\"c\",\"n\":\"Prod\",\"u\":[{\"k\":\"z\"},{\"k\":\"z\"}]},{\"k\":\"b\",\"i\":3},{\"k\":\"a\",\"f\":8,\"x\":9},{\"k\":\"a\",\"f\":10,\"x\":3},{\"k\":\"a\",\"f\":7,\"x\":11},{\"k\":\"c\",\"n\":\"Nat\",\"u\":[]},{\"k\":\"s\",\"l\":{\"k\":\"z\"}},{\"k\":\"p\",\"n\":\"agreements\",\"b\":\"e\",\"t\":13,\"v\":14},{\"k\":\"p\",\"n\":\"examples\",\"b\":\"e\",\"t\":13,\"v\":15},{\"k\":\"p\",\"n\":\"d\",\"b\":\"e\",\"t\":12,\"v\":16},{\"k\":\"p\",\"n\":\"cmp\",\"b\":\"e\",\"t\":6,\"v\":17},{\"k\":\"p\",\"n\":\"r\",\"b\":\"e\",\"t\":2,\"v\":18},{\"k\":\"p\",\"n\":\"β\",\"b\":\"i\",\"t\":0,\"v\":19},{\"k\":\"p\",\"n\":\"α\",\"b\":\"i\",\"t\":0,\"v\":20},{\"k\":\"c\",\"n\":\"And\",\"u\":[]},{\"k\":\"c\",\"n\":\"Eq\",\"u\":[{\"k\":\"s\",\"a\":{\"k\":\"z\"}}]},{\"k\":\"a\",\"f\":23,\"x\":13},{\"k\":\"c\",\"n\":\"List.length\",\"u\":[{\"k\":\"z\"}]},{\"k\":\"b\",\"i\":6},{\"k\":\"a\",\"f\":8,\"x\":26},{\"k\":\"b\",\"i\":5},{\"k\":\"a\",\"f\":27,\"x\":28},{\"k\":\"a\",\"f\":25,\"x\":29},{\"k\":\"a\",\"f\":30,\"x\":3},{\"k\":\"a\",\"f\":24,\"x\":31},{\"k\":\"a\",\"f\":32,\"x\":1},{\"k\":\"a\",\"f\":22,\"x\":33},{\"k\":\"c\",\"n\":\"List.foldl\",\"u\":[{\"k\":\"z\"},{\"k\":\"z\"}]},{\"k\":\"a\",\"f\":35,\"x\":13},{\"k\":\"a\",\"f\":36,\"x\":29},{\"k\":\"b\",\"i\":7},{\"k\":\"a\",\"f\":8,\"x\":38},{\"k\":\"a\",\"f\":39,\"x\":26},{\"k\":\"c\",\"n\":\"ite\",\"u\":[{\"k\":\"s\",\"a\":{\"k\":\"z\"}}]},{\"k\":\"a\",\"f\":41,\"x\":13},{\"k\":\"a\",\"f\":23,\"x\":4},{\"k\":\"c\",\"n\":\"Prod.fst\",\"u\":[{\"k\":\"z\"},{\"k\":\"z\"}]},{\"k\":\"b\",\"i\":8},{\"k\":\"a\",\"f\":44,\"x\":45},{\"k\":\"a\",\"f\":46,\"x\":38},{\"k\":\"b\",\"i\":0},{\"k\":\"a\",\"f\":47,\"x\":48},{\"k\":\"a\",\"f\":26,\"x\":49},{\"k\":\"a\",\"f\":28,\"x\":50},{\"k\":\"c\",\"n\":\"Prod.snd\",\"u\":[{\"k\":\"z\"},{\"k\":\"z\"}]},{\"k\":\"a\",\"f\":52,\"x\":45},{\"k\":\"a\",\"f\":53,\"x\":38},{\"k\":\"a\",\"f\":54,\"x\":48},{\"k\":\"a\",\"f\":51,\"x\":55},{\"k\":\"a\",\"f\":43,\"x\":56},{\"k\":\"c\",\"n\":\"Bool.true\",\"u\":[]},{\"k\":\"a\",\"f\":57,\"x\":58},{\"k\":\"a\",\"f\":42,\"x\":59},{\"k\":\"c\",\"n\":\"instDecidableEqBool\",\"u\":[]},{\"k\":\"a\",\"f\":61,\"x\":56},{\"k\":\"a\",\"f\":62,\"x\":58},{\"k\":\"a\",\"f\":60,\"x\":63},{\"k\":\"c\",\"n\":\"HAdd.hAdd\",\"u\":[{\"k\":\"z\"},{\"k\":\"z\"},{\"k\":\"z\"}]},{\"k\":\"a\",\"f\":65,\"x\":13},{\"k\":\"a\",\"f\":66,\"x\":13},{\"k\":\"a\",\"f\":67,\"x\":13},{\"k\":\"c\",\"n\":\"instHAdd\",\"u\":[{\"k\":\"z\"}]},{\"k\":\"a\",\"f\":69,\"x\":13},{\"k\":\"c\",\"n\":\"instAddNat\",\"u\":[]},{\"k\":\"a\",\"f\":70,\"x\":71},{\"k\":\"a\",\"f\":68,\"x\":72},{\"k\":\"a\",\"f\":73,\"x\":1},{\"k\":\"c\",\"n\":\"OfNat.ofNat\",\"u\":[{\"k\":\"z\"}]},{\"k\":\"a\",\"f\":75,\"x\":13},{\"k\":\"n\",\"v\":\"1\"},{\"k\":\"a\",\"f\":76,\"x\":77},{\"k\":\"c\",\"n\":\"instOfNatNat\",\"u\":[]},{\"k\":\"a\",\"f\":79,\"x\":77},{\"k\":\"a\",\"f\":78,\"x\":80},{\"k\":\"a\",\"f\":74,\"x\":81},{\"k\":\"a\",\"f\":64,\"x\":82},{\"k\":\"a\",\"f\":83,\"x\":1},{\"k\":\"l\",\"n\":\"e\",\"b\":\"e\",\"t\":40,\"v\":84},{\"k\":\"l\",\"n\":\"c\",\"b\":\"e\",\"t\":13,\"v\":85},{\"k\":\"a\",\"f\":37,\"x\":86},{\"k\":\"n\",\"v\":\"0\"},{\"k\":\"a\",\"f\":76,\"x\":88},{\"k\":\"a\",\"f\":79,\"x\":88},{\"k\":\"a\",\"f\":89,\"x\":90},{\"k\":\"a\",\"f\":87,\"x\":91},{\"k\":\"a\",\"f\":92,\"x\":3},{\"k\":\"a\",\"f\":24,\"x\":93},{\"k\":\"a\",\"f\":94,\"x\":48},{\"k\":\"a\",\"f\":34,\"x\":95},{\"k\":\"l\",\"n\":\"agreements\",\"b\":\"e\",\"t\":13,\"v\":96},{\"k\":\"l\",\"n\":\"examples\",\"b\":\"e\",\"t\":13,\"v\":97},{\"k\":\"l\",\"n\":\"d\",\"b\":\"e\",\"t\":12,\"v\":98},{\"k\":\"l\",\"n\":\"cmp\",\"b\":\"e\",\"t\":6,\"v\":99},{\"k\":\"l\",\"n\":\"r\",\"b\":\"e\",\"t\":2,\"v\":100},{\"k\":\"l\",\"n\":\"β\",\"b\":\"i\",\"t\":0,\"v\":101},{\"k\":\"l\",\"n\":\"α\",\"b\":\"i\",\"t\":0,\"v\":102},{\"k\":\"p\",\"n\":\"a._@._internal._hyg.#0\",\"b\":\"e\",\"t\":48,\"v\":4},{\"k\":\"p\",\"n\":\"a._@._internal._hyg.#0\",\"b\":\"e\",\"t\":1,\"v\":14},{\"k\":\"p\",\"n\":\"p\",\"b\":\"e\",\"t\":105,\"v\":14},{\"k\":\"p\",\"n\":\"v\",\"b\":\"e\",\"t\":104,\"v\":106},{\"k\":\"p\",\"n\":\"α\",\"b\":\"i\",\"t\":0,\"v\":107},{\"k\":\"a\",\"f\":1,\"x\":48},{\"k\":\"a\",\"f\":9,\"x\":1},{\"k\":\"a\",\"f\":43,\"x\":110},{\"k\":\"a\",\"f\":111,\"x\":58},{\"k\":\"p\",\"n\":\"a._@._internal._hyg.#0\",\"b\":\"e\",\"t\":109,\"v\":112},{\"k\":\"p\",\"n\":\"a\",\"b\":\"e\",\"t\":3,\"v\":113},{\"k\":\"l\",\"n\":\"p\",\"b\":\"e\",\"t\":105,\"v\":114},{\"k\":\"l\",\"n\":\"v\",\"b\":\"e\",\"t\":104,\"v\":115},{\"k\":\"l\",\"n\":\"α\",\"b\":\"i\",\"t\":0,\"v\":116},{\"k\":\"p\",\"n\":\"a._@._internal._hyg.#0\",\"b\":\"e\",\"t\":1,\"v\":4},{\"k\":\"p\",\"n\":\"a._@._internal._hyg.#0\",\"b\":\"e\",\"t\":1,\"v\":118},{\"k\":\"p\",\"n\":\"a._@._internal._hyg.#0\",\"b\":\"e\",\"t\":3,\"v\":14},{\"k\":\"p\",\"n\":\"a._@._internal._hyg.#0\",\"b\":\"e\",\"t\":3,\"v\":120},{\"k\":\"p\",\"n\":\"p\",\"b\":\"e\",\"t\":121,\"v\":14},{\"k\":\"p\",\"n\":\"v\",\"b\":\"e\",\"t\":119,\"v\":122},{\"k\":\"p\",\"n\":\"β\",\"b\":\"i\",\"t\":0,\"v\":123},{\"k\":\"p\",\"n\":\"α\",\"b\":\"i\",\"t\":0,\"v\":124},{\"k\":\"a\",\"f\":3,\"x\":1},{\"k\":\"a\",\"f\":126,\"x\":48},{\"k\":\"b\",\"i\":4},{\"k\":\"a\",\"f\":128,\"x\":3},{\"k\":\"a\",\"f\":129,\"x\":1},{\"k\":\"a\",\"f\":43,\"x\":130},{\"k\":\"a\",\"f\":131,\"x\":58},{\"k\":\"p\",\"n\":\"a._@._internal._hyg.#0\",\"b\":\"e\",\"t\":127,\"v\":132},{\"k\":\"p\",\"n\":\"b\",\"b\":\"e\",\"t\":9,\"v\":133},{\"k\":\"p\",\"n\":\"a\",\"b\":\"e\",\"t\":9,\"v\":134},{\"k\":\"l\",\"n\":\"p\",\"b\":\"e\",\"t\":121,\"v\":135},{\"k\":\"l\",\"n\":\"v\",\"b\":\"e\",\"t\":119,\"v\":136},{\"k\":\"l\",\"n\":\"β\",\"b\":\"i\",\"t\":0,\"v\":137},{\"k\":\"l\",\"n\":\"α\",\"b\":\"i\",\"t\":0,\"v\":138},{\"k\":\"p\",\"n\":\"a._@._internal._hyg.#0\",\"b\":\"e\",\"t\":9,\"v\":4},{\"k\":\"p\",\"n\":\"a._@._internal._hyg.#0\",\"b\":\"e\",\"t\":9,\"v\":140},{\"k\":\"p\",\"n\":\"a._@._internal._hyg.#0\",\"b\":\"e\",\"t\":9,\"v\":141},{\"k\":\"p\",\"n\":\"a._@._internal._hyg.#0\",\"b\":\"e\",\"t\":9,\"v\":142},{\"k\":\"p\",\"n\":\"a._@._internal._hyg.#0\",\"b\":\"e\",\"t\":128,\"v\":14},{\"k\":\"p\",\"n\":\"a._@._internal._hyg.#0\",\"b\":\"e\",\"t\":128,\"v\":144},{\"k\":\"p\",\"n\":\"a._@._internal._hyg.#0\",\"b\":\"e\",\"t\":128,\"v\":145},{\"k\":\"p\",\"n\":\"a._@._internal._hyg.#0\",\"b\":\"e\",\"t\":128,\"v\":146},{\"k\":\"p\",\"n\":\"p\",\"b\":\"e\",\"t\":147,\"v\":14},{\"k\":\"p\",\"n\":\"v\",\"b\":\"e\",\"t\":143,\"v\":148},{\"k\":\"p\",\"n\":\"δ\",\"b\":\"i\",\"t\":0,\"v\":149},{\"k\":\"p\",\"n\":\"γ\",\"b\":\"i\",\"t\":0,\"v\":150},{\"k\":\"p\",\"n\":\"β\",\"b\":\"i\",\"t\":0,\"v\":151},{\"k\":\"p\",\"n\":\"α\",\"b\":\"i\",\"t\":0,\"v\":152},{\"k\":\"a\",\"f\":128,\"x\":9},{\"k\":\"a\",\"f\":154,\"x\":3},{\"k\":\"a\",\"f\":155,\"x\":1},{\"k\":\"a\",\"f\":156,\"x\":48},{\"k\":\"a\",\"f\":26,\"x\":128},{\"k\":\"a\",\"f\":158,\"x\":9},{\"k\":\"a\",\"f\":159,\"x\":3},{\"k\":\"a\",\"f\":160,\"x\":1},{\"k\":\"a\",\"f\":43,\"x\":161},{\"k\":\"a\",\"f\":162,\"x\":58},{\"k\":\"p\",\"n\":\"a._@._internal._hyg.#0\",\"b\":\"e\",\"t\":157,\"v\":163},{\"k\":\"p\",\"n\":\"d\",\"b\":\"e\",\"t\":28,\"v\":164},{\"k\":\"p\",\"n\":\"c\",\"b\":\"e\",\"t\":28,\"v\":165},{\"k\":\"p\",\"n\":\"b\",\"b\":\"e\",\"t\":28,\"v\":166},{\"k\":\"p\",\"n\":\"a\",\"b\":\"e\",\"t\":28,\"v\":167},{\"k\":\"l\",\"n\":\"p\",\"b\":\"e\",\"t\":147,\"v\":168},{\"k\":\"l\",\"n\":\"v\",\"b\":\"e\",\"t\":143,\"v\":169},{\"k\":\"l\",\"n\":\"δ\",\"b\":\"i\",\"t\":0,\"v\":170},{\"k\":\"l\",\"n\":\"γ\",\"b\":\"i\",\"t\":0,\"v\":171},{\"k\":\"l\",\"n\":\"β\",\"b\":\"i\",\"t\":0,\"v\":172},{\"k\":\"l\",\"n\":\"α\",\"b\":\"i\",\"t\":0,\"v\":173},{\"k\":\"p\",\"n\":\"a._@._internal._hyg.#0\",\"b\":\"e\",\"t\":3,\"v\":3},{\"k\":\"p\",\"n\":\"a._@._internal._hyg.#0\",\"b\":\"e\",\"t\":9,\"v\":9},{\"k\":\"p\",\"n\":\"f\",\"b\":\"e\",\"t\":176,\"v\":14},{\"k\":\"p\",\"n\":\"r\",\"b\":\"e\",\"t\":175,\"v\":177},{\"k\":\"p\",\"n\":\"p\",\"b\":\"e\",\"t\":105,\"v\":178},{\"k\":\"p\",\"n\":\"β\",\"b\":\"i\",\"t\":0,\"v\":179},{\"k\":\"p\",\"n\":\"α\",\"b\":\"i\",\"t\":0,\"v\":180},{\"k\":\"a\",\"f\":9,\"x\":48},{\"k\":\"a\",\"f\":23,\"x\":28},{\"k\":\"a\",\"f\":183,\"x\":110},{\"k\":\"a\",\"f\":184,\"x\":126},{\"k\":\"p\",\"n\":\"a._@._internal._hyg.#0\",\"b\":\"e\",\"t\":182,\"v\":185},{\"k\":\"p\",\"n\":\"a\",\"b\":\"e\",\"t\":128,\"v\":186},{\"k\":\"l\",\"n\":\"f\",\"b\":\"e\",\"t\":176,\"v\":187},{\"k\":\"l\",\"n\":\"r\",\"b\":\"e\",\"t\":175,\"v\":188},{\"k\":\"l\",\"n\":\"p\",\"b\":\"e\",\"t\":105,\"v\":189},{\"k\":\"l\",\"n\":\"β\",\"b\":\"i\",\"t\":0,\"v\":190},{\"k\":\"l\",\"n\":\"α\",\"b\":\"i\",\"t\":0,\"v\":191},{\"k\":\"p\",\"n\":\"a._@._internal._hyg.#0\",\"b\":\"e\",\"t\":9,\"v\":14},{\"k\":\"p\",\"n\":\"a._@._internal._hyg.#0\",\"b\":\"e\",\"t\":9,\"v\":193},{\"k\":\"a\",\"f\":27,\"x\":128},{\"k\":\"p\",\"n\":\"a._@._internal._hyg.#0\",\"b\":\"e\",\"t\":128,\"v\":195},{\"k\":\"p\",\"n\":\"a._@._internal._hyg.#0\",\"b\":\"e\",\"t\":128,\"v\":196},{\"k\":\"a\",\"f\":39,\"x\":28},{\"k\":\"p\",\"n\":\"a._@._internal._hyg.#0\",\"b\":\"e\",\"t\":28,\"v\":198},{\"k\":\"p\",\"n\":\"a._@._internal._hyg.#0\",\"b\":\"e\",\"t\":28,\"v\":199},{\"k\":\"p\",\"n\":\"f\",\"b\":\"e\",\"t\":200,\"v\":14},{\"k\":\"p\",\"n\":\"r\",\"b\":\"e\",\"t\":197,\"v\":201},{\"k\":\"p\",\"n\":\"p\",\"b\":\"e\",\"t\":194,\"v\":202},{\"k\":\"p\",\"n\":\"j\",\"b\":\"e\",\"t\":120,\"v\":203},{\"k\":\"p\",\"n\":\"β\",\"b\":\"i\",\"t\":0,\"v\":204},{\"k\":\"p\",\"n\":\"α\",\"b\":\"i\",\"t\":0,\"v\":205},{\"k\":\"p\",\"n\":\"σ\",\"b\":\"i\",\"t\":0,\"v\":206},{\"k\":\"a\",\"f\":28,\"x\":1},{\"k\":\"a\",\"f\":28,\"x\":3},{\"k\":\"a\",\"f\":209,\"x\":1},{\"k\":\"b\",\"i\":10},{\"k\":\"a\",\"f\":8,\"x\":211},{\"k\":\"a\",\"f\":212,\"x\":45},{\"k\":\"a\",\"f\":23,\"x\":213},{\"k\":\"a\",\"f\":28,\"x\":9},{\"k\":\"a\",\"f\":215,\"x\":3},{\"k\":\"a\",\"f\":214,\"x\":216},{\"k\":\"a\",\"f\":217,\"x\":155},{\"k\":\"p\",\"n\":\"a._@._internal._hyg.#0\",\"b\":\"e\",\"t\":210,\"v\":218},{\"k\":\"p\",\"n\":\"a._@._internal._hyg.#0\",\"b\":\"e\",\"t\":208,\"v\":219},{\"k\":\"p\",\"n\":\"a\",\"b\":\"e\",\"t\":26,\"v\":220},{\"k\":\"p\",\"n\":\"s\",\"b\":\"e\",\"t\":26,\"v\":221},{\"k\":\"l\",\"n\":\"f\",\"b\":\"e\",\"t\":200,\"v\":222},{\"k\":\"l\",\"n\":\"r\",\"b\":\"e\",\"t\":197,\"v\":223},{\"k\":\"l\",\"n\":\"p\",\"b\":\"e\",\"t\":194,\"v\":224},{\"k\":\"l\",\"n\":\"j\",\"b\":\"e\",\"t\":120,\"v\":225},{\"k\":\"l\",\"n\":\"β\",\"b\":\"i\",\"t\":0,\"v\":226},{\"k\":\"l\",\"n\":\"α\",\"b\":\"i\",\"t\":0,\"v\":227},{\"k\":\"l\",\"n\":\"σ\",\"b\":\"i\",\"t\":0,\"v\":228},{\"k\":\"a\",\"f\":8,\"x\":28},{\"k\":\"a\",\"f\":230,\"x\":9},{\"k\":\"p\",\"n\":\"a._@._internal._hyg.#0\",\"b\":\"e\",\"t\":9,\"v\":231},{\"k\":\"p\",\"n\":\"a._@._internal._hyg.#0\",\"b\":\"e\",\"t\":9,\"v\":232},{\"k\":\"p\",\"n\":\"f\",\"b\":\"e\",\"t\":197,\"v\":14},{\"k\":\"p\",\"n\":\"r\",\"b\":\"e\",\"t\":233,\"v\":234},{\"k\":\"p\",\"n\":\"p\",\"b\":\"e\",\"t\":121,\"v\":235},{\"k\":\"p\",\"n\":\"β\",\"b\":\"i\",\"t\":0,\"v\":236},{\"k\":\"p\",\"n\":\"α\",\"b\":\"i\",\"t\":0,\"v\":237},{\"k\":\"p\",\"n\":\"σ\",\"b\":\"i\",\"t\":0,\"v\":238},{\"k\":\"a\",\"f\":128,\"x\":1},{\"k\":\"a\",\"f\":240,\"x\":48},{\"k\":\"a\",\"f\":8,\"x\":45},{\"k\":\"a\",\"f\":242,\"x\":26},{\"k\":\"a\",\"f\":23,\"x\":243},{\"k\":\"a\",\"f\":244,\"x\":130},{\"k\":\"a\",\"f\":9,\"x\":3},{\"k\":\"a\",\"f\":246,\"x\":1},{\"k\":\"a\",\"f\":245,\"x\":247},{\"k\":\"p\",\"n\":\"a._@._internal._hyg.#0\",\"b\":\"e\",\"t\":241,\"v\":248},{\"k\":\"p\",\"n\":\"a\",\"b\":\"e\",\"t\":28,\"v\":249},{\"k\":\"p\",\"n\":\"s\",\"b\":\"e\",\"t\":28,\"v\":250},{\"k\":\"l\",\"n\":\"f\",\"b\":\"e\",\"t\":197,\"v\":251},{\"k\":\"l\",\"n\":\"r\",\"b\":\"e\",\"t\":233,\"v\":252},{\"k\":\"l\",\"n\":\"p\",\"b\":\"e\",\"t\":121,\"v\":253},{\"k\":\"l\",\"n\":\"β\",\"b\":\"i\",\"t\":0,\"v\":254},{\"k\":\"l\",\"n\":\"α\",\"b\":\"i\",\"t\":0,\"v\":255},{\"k\":\"l\",\"n\":\"σ\",\"b\":\"i\",\"t\":0,\"v\":256},{\"k\":\"p\",\"n\":\"j\",\"b\":\"e\",\"t\":120,\"v\":235},{\"k\":\"p\",\"n\":\"β\",\"b\":\"i\",\"t\":0,\"v\":258},{\"k\":\"p\",\"n\":\"α\",\"b\":\"i\",\"t\":0,\"v\":259},{\"k\":\"p\",\"n\":\"σ\",\"b\":\"i\",\"t\":0,\"v\":260},{\"k\":\"p\",\"n\":\"a._@._internal._hyg.#0\",\"b\":\"e\",\"t\":240,\"v\":248},{\"k\":\"p\",\"n\":\"a\",\"b\":\"e\",\"t\":28,\"v\":262},{\"k\":\"p\",\"n\":\"s\",\"b\":\"e\",\"t\":28,\"v\":263},{\"k\":\"l\",\"n\":\"f\",\"b\":\"e\",\"t\":197,\"v\":264},{\"k\":\"l\",\"n\":\"r\",\"b\":\"e\",\"t\":233,\"v\":265},{\"k\":\"l\",\"n\":\"j\",\"b\":\"e\",\"t\":120,\"v\":266},{\"k\":\"l\",\"n\":\"β\",\"b\":\"i\",\"t\":0,\"v\":267},{\"k\":\"l\",\"n\":\"α\",\"b\":\"i\",\"t\":0,\"v\":268},{\"k\":\"l\",\"n\":\"σ\",\"b\":\"i\",\"t\":0,\"v\":269},{\"k\":\"a\",\"f\":8,\"x\":128},{\"k\":\"a\",\"f\":271,\"x\":3},{\"k\":\"p\",\"n\":\"a._@._internal._hyg.#0\",\"b\":\"e\",\"t\":3,\"v\":272},{\"k\":\"p\",\"n\":\"a._@._internal._hyg.#0\",\"b\":\"e\",\"t\":3,\"v\":273},{\"k\":\"p\",\"n\":\"f\",\"b\":\"e\",\"t\":233,\"v\":14},{\"k\":\"p\",\"n\":\"r\",\"b\":\"e\",\"t\":274,\"v\":275},{\"k\":\"p\",\"n\":\"β\",\"b\":\"i\",\"t\":0,\"v\":276},{\"k\":\"p\",\"n\":\"α\",\"b\":\"i\",\"t\":0,\"v\":277},{\"k\":\"p\",\"n\":\"σ\",\"b\":\"i\",\"t\":0,\"v\":278},{\"k\":\"a\",\"f\":23,\"x\":195},{\"k\":\"a\",\"f\":110,\"x\":48},{\"k\":\"a\",\"f\":280,\"x\":281},{\"k\":\"a\",\"f\":282,\"x\":127},{\"k\":\"p\",\"n\":\"a\",\"b\":\"e\",\"t\":128,\"v\":283},{\"k\":\"p\",\"n\":\"s\",\"b\":\"e\",\"t\":128,\"v\":284},{\"k\":\"l\",\"n\":\"f\",\"b\":\"e\",\"t\":233,\"v\":285},{\"k\":\"l\",\"n\":\"r\",\"b\":\"e\",\"t\":274,\"v\":286},{\"k\":\"l\",\"n\":\"β\",\"b\":\"i\",\"t\":0,\"v\":287},{\"k\":\"l\",\"n\":\"α\",\"b\":\"i\",\"t\":0,\"v\":288},{\"k\":\"l\",\"n\":\"σ\",\"b\":\"i\",\"t\":0,\"v\":289},{\"k\":\"p\",\"n\":\"f\",\"b\":\"e\",\"t\":175,\"v\":14},{\"k\":\"p\",\"n\":\"r\",\"b\":\"e\",\"t\":2,\"v\":291},{\"k\":\"p\",\"n\":\"β\",\"b\":\"i\",\"t\":0,\"v\":292},{\"k\":\"p\",\"n\":\"α\",\"b\":\"i\",\"t\":0,\"v\":293},{\"k\":\"a\",\"f\":23,\"x\":9},{\"k\":\"a\",\"f\":3,\"x\":48},{\"k\":\"a\",\"f\":295,\"x\":296},{\"k\":\"a\",\"f\":297,\"x\":109},{\"k\":\"p\",\"n\":\"a\",\"b\":\"e\",\"t\":9,\"v\":298},{\"k\":\"l\",\"n\":\"f\",\"b\":\"e\",\"t\":175,\"v\":299},{\"k\":\"l\",\"n\":\"r\",\"b\":\"e\",\"t\":2,\"v\":300},{\"k\":\"l\",\"n\":\"β\",\"b\":\"i\",\"t\":0,\"v\":301},{\"k\":\"l\",\"n\":\"α\",\"b\":\"i\",\"t\":0,\"v\":302},{\"k\":\"p\",\"n\":\"a._@._internal._hyg.#0\",\"b\":\"e\",\"t\":48,\"v\":14},{\"k\":\"p\",\"n\":\"i\",\"b\":\"e\",\"t\":1,\"v\":14},{\"k\":\"p\",\"n\":\"j\",\"b\":\"e\",\"t\":304,\"v\":305},{\"k\":\"p\",\"n\":\"σ\",\"b\":\"i\",\"t\":0,\"v\":306},{\"k\":\"l\",\"n\":\"i\",\"b\":\"e\",\"t\":1,\"v\":109},{\"k\":\"l\",\"n\":\"j\",\"b\":\"e\",\"t\":304,\"v\":308},{\"k\":\"l\",\"n\":\"σ\",\"b\":\"i\",\"t\":0,\"v\":309},{\"k\":\"p\",\"n\":\"r\",\"b\":\"e\",\"t\":197,\"v\":14},{\"k\":\"p\",\"n\":\"p\",\"b\":\"e\",\"t\":194,\"v\":311},{\"k\":\"p\",\"n\":\"j\",\"b\":\"e\",\"t\":120,\"v\":312},{\"k\":\"p\",\"n\":\"β\",\"b\":\"i\",\"t\":0,\"v\":313},{\"k\":\"p\",\"n\":\"α\",\"b\":\"i\",\"t\":0,\"v\":314},{\"k\":\"p\",\"n\":\"σ\",\"b\":\"i\",\"t\":0,\"v\":315},{\"k\":\"b\",\"i\":9},{\"k\":\"a\",\"f\":44,\"x\":317},{\"k\":\"a\",\"f\":318,\"x\":38},{\"k\":\"a\",\"f\":319,\"x\":155},{\"k\":\"a\",\"f\":26,\"x\":320},{\"k\":\"p\",\"n\":\"a._@._internal._hyg.#0\",\"b\":\"e\",\"t\":130,\"v\":321},{\"k\":\"p\",\"n\":\"a._@._internal._hyg.#0\",\"b\":\"e\",\"t\":240,\"v\":322},{\"k\":\"p\",\"n\":\"a\",\"b\":\"e\",\"t\":28,\"v\":323},{\"k\":\"p\",\"n\":\"s\",\"b\":\"e\",\"t\":28,\"v\":324},{\"k\":\"l\",\"n\":\"r\",\"b\":\"e\",\"t\":197,\"v\":325},{\"k\":\"l\",\"n\":\"p\",\"b\":\"e\",\"t\":194,\"v\":326},{\"k\":\"l\",\"n\":\"j\",\"b\":\"e\",\"t\":120,\"v\":327},{\"k\":\"l\",\"n\":\"β\",\"b\":\"i\",\"t\":0,\"v\":328},{\"k\":\"l\",\"n\":\"α\",\"b\":\"i\",\"t\":0,\"v\":329},{\"k\":\"l\",\"n\":\"σ\",\"b\":\"i\",\"t\":0,\"v\":330},{\"k\":\"p\",\"n\":\"r\",\"b\":\"e\",\"t\":233,\"v\":14},{\"k\":\"p\",\"n\":\"j\",\"b\":\"e\",\"t\":120,\"v\":332},{\"k\":\"p\",\"n\":\"β\",\"b\":\"i\",\"t\":0,\"v\":333},{\"k\":\"p\",\"n\":\"α\",\"b\":\"i\",\"t\":0,\"v\":334},{\"k\":\"p\",\"n\":\"σ\",\"b\":\"i\",\"t\":0,\"v\":335},{\"k\":\"a\",\"f\":44,\"x\":38},{\"k\":\"a\",\"f\":337,\"x\":28},{\"k\":\"a\",\"f\":338,\"x\":247},{\"k\":\"a\",\"f\":128,\"x\":339},{\"k\":\"p\",\"n\":\"a._@._internal._hyg.#0\",\"b\":\"e\",\"t\":110,\"v\":340},{\"k\":\"p\",\"n\":\"a\",\"b\":\"e\",\"t\":128,\"v\":341},{\"k\":\"p\",\"n\":\"s\",\"b\":\"e\",\"t\":128,\"v\":342},{\"k\":\"l\",\"n\":\"r\",\"b\":\"e\",\"t\":233,\"v\":343},{\"k\":\"l\",\"n\":\"j\",\"b\":\"e\",\"t\":120,\"v\":344},{\"k\":\"l\",\"n\":\"β\",\"b\":\"i\",\"t\":0,\"v\":345},{\"k\":\"l\",\"n\":\"α\",\"b\":\"i\",\"t\":0,\"v\":346},{\"k\":\"l\",\"n\":\"σ\",\"b\":\"i\",\"t\":0,\"v\":347},{\"k\":\"p\",\"n\":\"r\",\"b\":\"e\",\"t\":176,\"v\":14},{\"k\":\"p\",\"n\":\"q\",\"b\":\"e\",\"t\":121,\"v\":349},{\"k\":\"p\",\"n\":\"p\",\"b\":\"e\",\"t\":105,\"v\":350},{\"k\":\"p\",\"n\":\"β\",\"b\":\"i\",\"t\":0,\"v\":351},{\"k\":\"p\",\"n\":\"α\",\"b\":\"i\",\"t\":0,\"v\":352},{\"k\":\"a\",\"f\":110,\"x\":126},{\"k\":\"p\",\"n\":\"a._@._internal._hyg.#0\",\"b\":\"e\",\"t\":182,\"v\":354},{\"k\":\"p\",\"n\":\"a\",\"b\":\"e\",\"t\":128,\"v\":355},{\"k\":\"l\",\"n\":\"r\",\"b\":\"e\",\"t\":176,\"v\":356},{\"k\":\"l\",\"n\":\"q\",\"b\":\"e\",\"t\":121,\"v\":357},{\"k\":\"l\",\"n\":\"p\",\"b\":\"e\",\"t\":105,\"v\":358},{\"k\":\"l\",\"n\":\"β\",\"b\":\"i\",\"t\":0,\"v\":359},{\"k\":\"l\",\"n\":\"α\",\"b\":\"i\",\"t\":0,\"v\":360},{\"k\":\"p\",\"n\":\"a._@._internal._hyg.#0\",\"b\":\"e\",\"t\":28,\"v\":14},{\"k\":\"p\",\"n\":\"a._@._internal._hyg.#0\",\"b\":\"e\",\"t\":26,\"v\":362},{\"k\":\"p\",\"n\":\"a._@._internal._hyg.#0\",\"b\":\"e\",\"t\":128,\"v\":363},{\"k\":\"p\",\"n\":\"a._@._internal._hyg.#0\",\"b\":\"e\",\"t\":128,\"v\":364},{\"k\":\"p\",\"n\":\"r\",\"b\":\"e\",\"t\":200,\"v\":14},{\"k\":\"p\",\"n\":\"q\",\"b\":\"e\",\"t\":365,\"v\":366},{\"k\":\"p\",\"n\":\"p\",\"b\":\"e\",\"t\":194,\"v\":367},{\"k\":\"p\",\"n\":\"j\",\"b\":\"e\",\"t\":120,\"v\":368},{\"k\":\"p\",\"n\":\"β\",\"b\":\"i\",\"t\":0,\"v\":369},{\"k\":\"p\",\"n\":\"α\",\"b\":\"i\",\"t\":0,\"v\":370},{\"k\":\"p\",\"n\":\"σ\",\"b\":\"i\",\"t\":0,\"v\":371},{\"k\":\"a\",\"f\":44,\"x\":211},{\"k\":\"a\",\"f\":373,\"x\":45},{\"k\":\"a\",\"f\":374,\"x\":155},{\"k\":\"a\",\"f\":216,\"x\":375},{\"k\":\"a\",\"f\":52,\"x\":211},{\"k\":\"a\",\"f\":377,\"x\":45},{\"k\":\"a\",\"f\":378,\"x\":155},{\"k\":\"a\",\"f\":376,\"x\":379},{\"k\":\"p\",\"n\":\"a._@._internal._hyg.#0\",\"b\":\"e\",\"t\":210,\"v\":380},{\"k\":\"p\",\"n\":\"a._@._internal._hyg.#0\",\"b\":\"e\",\"t\":208,\"v\":381},{\"k\":\"p\",\"n\":\"a\",\"b\":\"e\",\"t\":26,\"v\":382},{\"k\":\"p\",\"n\":\"s\",\"b\":\"e\",\"t\":26,\"v\":383},{\"k\":\"l\",\"n\":\"r\",\"b\":\"e\",\"t\":200,\"v\":384},{\"k\":\"l\",\"n\":\"q\",\"b\":\"e\",\"t\":365,\"v\":385},{\"k\":\"l\",\"n\":\"p\",\"b\":\"e\",\"t\":194,\"v\":386},{\"k\":\"l\",\"n\":\"j\",\"b\":\"e\",\"t\":120,\"v\":387},{\"k\":\"l\",\"n\":\"β\",\"b\":\"i\",\"t\":0,\"v\":388},{\"k\":\"l\",\"n\":\"α\",\"b\":\"i\",\"t\":0,\"v\":389},{\"k\":\"l\",\"n\":\"σ\",\"b\":\"i\",\"t\":0,\"v\":390},{\"k\":\"p\",\"n\":\"a._@._internal._hyg.#0\",\"b\":\"e\",\"t\":28,\"v\":144},{\"k\":\"p\",\"n\":\"a._@._internal._hyg.#0\",\"b\":\"e\",\"t\":9,\"v\":392},{\"k\":\"p\",\"n\":\"a._@._internal._hyg.#0\",\"b\":\"e\",\"t\":9,\"v\":393},{\"k\":\"p\",\"n\":\"q\",\"b\":\"e\",\"t\":394,\"v\":311},{\"k\":\"p\",\"n\":\"p\",\"b\":\"e\",\"t\":121,\"v\":395},{\"k\":\"p\",\"n\":\"β\",\"b\":\"i\",\"t\":0,\"v\":396},{\"k\":\"p\",\"n\":\"α\",\"b\":\"i\",\"t\":0,\"v\":397},{\"k\":\"p\",\"n\":\"σ\",\"b\":\"i\",\"t\":0,\"v\":398},{\"k\":\"a\",\"f\":46,\"x\":26},{\"k\":\"a\",\"f\":400,\"x\":247},{\"k\":\"a\",\"f\":130,\"x\":401},{\"k\":\"a\",\"f\":53,\"x\":26},{\"k\":\"a\",\"f\":403,\"x\":247},{\"k\":\"a\",\"f\":402,\"x\":404},{\"k\":\"p\",\"n\":\"a._@._internal._hyg.#0\",\"b\":\"e\",\"t\":241,\"v\":405},{\"k\":\"p\",\"n\":\"a\",\"b\":\"e\",\"t\":28,\"v\":406},{\"k\":\"p\",\"n\":\"s\",\"b\":\"e\",\"t\":28,\"v\":407},{\"k\":\"l\",\"n\":\"r\",\"b\":\"e\",\"t\":197,\"v\":408},{\"k\":\"l\",\"n\":\"q\",\"b\":\"e\",\"t\":394,\"v\":409},{\"k\":\"l\",\"n\":\"p\",\"b\":\"e\",\"t\":121,\"v\":410},{\"k\":\"l\",\"n\":\"β\",\"b\":\"i\",\"t\":0,\"v\":411},{\"k\":\"l\",\"n\":\"α\",\"b\":\"i\",\"t\":0,\"v\":412},{\"k\":\"l\",\"n\":\"σ\",\"b\":\"i\",\"t\":0,\"v\":413},{\"k\":\"p\",\"n\":\"j\",\"b\":\"e\",\"t\":120,\"v\":395},{\"k\":\"p\",\"n\":\"β\",\"b\":\"i\",\"t\":0,\"v\":415},{\"k\":\"p\",\"n\":\"α\",\"b\":\"i\",\"t\":0,\"v\":416},{\"k\":\"p\",\"n\":\"σ\",\"b\":\"i\",\"t\":0,\"v\":417},{\"k\":\"p\",\"n\":\"a._@._internal._hyg.#0\",\"b\":\"e\",\"t\":240,\"v\":405},{\"k\":\"p\",\"n\":\"a\",\"b\":\"e\",\"t\":28,\"v\":419},{\"k\":\"p\",\"n\":\"s\",\"b\":\"e\",\"t\":28,\"v\":420},{\"k\":\"l\",\"n\":\"r\",\"b\":\"e\",\"t\":197,\"v\":421},{\"k\":\"l\",\"n\":\"q\",\"b\":\"e\",\"t\":394,\"v\":422},{\"k\":\"l\",\"n\":\"j\",\"b\":\"e\",\"t\":120,\"v\":423},{\"k\":\"l\",\"n\":\"β\",\"b\":\"i\",\"t\":0,\"v\":424},{\"k\":\"l\",\"n\":\"α\",\"b\":\"i\",\"t\":0,\"v\":425},{\"k\":\"l\",\"n\":\"σ\",\"b\":\"i\",\"t\":0,\"v\":426},{\"k\":\"p\",\"n\":\"a._@._internal._hyg.#0\",\"b\":\"e\",\"t\":128,\"v\":193},{\"k\":\"p\",\"n\":\"a._@._internal._hyg.#0\",\"b\":\"e\",\"t\":3,\"v\":428},{\"k\":\"p\",\"n\":\"a._@._internal._hyg.#0\",\"b\":\"e\",\"t\":3,\"v\":429},{\"k\":\"p\",\"n\":\"q\",\"b\":\"e\",\"t\":430,\"v\":332},{\"k\":\"p\",\"n\":\"β\",\"b\":\"i\",\"t\":0,\"v\":431},{\"k\":\"p\",\"n\":\"α\",\"b\":\"i\",\"t\":0,\"v\":432},{\"k\":\"p\",\"n\":\"σ\",\"b\":\"i\",\"t\":0,\"v\":433},{\"k\":\"a\",\"f\":44,\"x\":26},{\"k\":\"a\",\"f\":435,\"x\":128},{\"k\":\"a\",\"f\":436,\"x\":127},{\"k\":\"a\",\"f\":281,\"x\":437},{\"k\":\"a\",\"f\":52,\"x\":26},{\"k\":\"a\",\"f\":439,\"x\":128},{\"k\":\"a\",\"f\":440,\"x\":127},{\"k\":\"a\",\"f\":438,\"x\":441},{\"k\":\"p\",\"n\":\"a\",\"b\":\"e\",\"t\":128,\"v\":442},{\"k\":\"p\",\"n\":\"s\",\"b\":\"e\",\"t\":128,\"v\":443},{\"k\":\"l\",\"n\":\"r\",\"b\":\"e\",\"t\":233,\"v\":444},{\"k\":\"l\",\"n\":\"q\",\"b\":\"e\",\"t\":430,\"v\":445},{\"k\":\"l\",\"n\":\"β\",\"b\":\"i\",\"t\":0,\"v\":446},{\"k\":\"l\",\"n\":\"α\",\"b\":\"i\",\"t\":0,\"v\":447},{\"k\":\"l\",\"n\":\"σ\",\"b\":\"i\",\"t\":0,\"v\":448},{\"k\":\"p\",\"n\":\"a._@._internal._hyg.#0\",\"b\":\"e\",\"t\":1,\"v\":105},{\"k\":\"p\",\"n\":\"r\",\"b\":\"e\",\"t\":175,\"v\":14},{\"k\":\"p\",\"n\":\"q\",\"b\":\"e\",\"t\":450,\"v\":451},{\"k\":\"p\",\"n\":\"β\",\"b\":\"i\",\"t\":0,\"v\":452},{\"k\":\"p\",\"n\":\"α\",\"b\":\"i\",\"t\":0,\"v\":453},{\"k\":\"a\",\"f\":296,\"x\":109},{\"k\":\"p\",\"n\":\"a\",\"b\":\"e\",\"t\":9,\"v\":455},{\"k\":\"l\",\"n\":\"r\",\"b\":\"e\",\"t\":175,\"v\":456},{\"k\":\"l\",\"n\":\"q\",\"b\":\"e\",\"t\":450,\"v\":457},{\"k\":\"l\",\"n\":\"β\",\"b\":\"i\",\"t\":0,\"v\":458},{\"k\":\"l\",\"n\":\"α\",\"b\":\"i\",\"t\":0,\"v\":459},{\"k\":\"a\",\"f\":43,\"x\":296},{\"k\":\"a\",\"f\":461,\"x\":58},{\"k\":\"p\",\"n\":\"a._@._internal._hyg.#0\",\"b\":\"e\",\"t\":462,\"v\":126},{\"k\":\"p\",\"n\":\"a\",\"b\":\"e\",\"t\":3,\"v\":463},{\"k\":\"l\",\"n\":\"p\",\"b\":\"e\",\"t\":105,\"v\":464},{\"k\":\"l\",\"n\":\"v\",\"b\":\"e\",\"t\":104,\"v\":465},{\"k\":\"l\",\"n\":\"α\",\"b\":\"i\",\"t\":0,\"v\":466},{\"k\":\"a\",\"f\":43,\"x\":281},{\"k\":\"a\",\"f\":468,\"x\":58},{\"k\":\"p\",\"n\":\"a._@._internal._hyg.#0\",\"b\":\"e\",\"t\":469,\"v\":247},{\"k\":\"p\",\"n\":\"b\",\"b\":\"e\",\"t\":9,\"v\":470},{\"k\":\"p\",\"n\":\"a\",\"b\":\"e\",\"t\":9,\"v\":471},{\"k\":\"l\",\"n\":\"p\",\"b\":\"e\",\"t\":121,\"v\":472},{\"k\":\"l\",\"n\":\"v\",\"b\":\"e\",\"t\":119,\"v\":473},{\"k\":\"l\",\"n\":\"β\",\"b\":\"i\",\"t\":0,\"v\":474},{\"k\":\"l\",\"n\":\"α\",\"b\":\"i\",\"t\":0,\"v\":475},{\"k\":\"a\",\"f\":216,\"x\":1},{\"k\":\"a\",\"f\":477,\"x\":48},{\"k\":\"a\",\"f\":43,\"x\":478},{\"k\":\"a\",\"f\":479,\"x\":58},{\"k\":\"a\",\"f\":28,\"x\":128},{\"k\":\"a\",\"f\":481,\"x\":9},{\"k\":\"a\",\"f\":482,\"x\":3},{\"k\":\"a\",\"f\":483,\"x\":1},{\"k\":\"p\",\"n\":\"a._@._internal._hyg.#0\",\"b\":\"e\",\"t\":480,\"v\":484},{\"k\":\"p\",\"n\":\"d\",\"b\":\"e\",\"t\":28,\"v\":485},{\"k\":\"p\",\"n\":\"c\",\"b\":\"e\",\"t\":28,\"v\":486},{\"k\":\"p\",\"n\":\"b\",\"b\":\"e\",\"t\":28,\"v\":487},{\"k\":\"p\",\"n\":\"a\",\"b\":\"e\",\"t\":28,\"v\":488},{\"k\":\"l\",\"n\":\"p\",\"b\":\"e\",\"t\":147,\"v\":489},{\"k\":\"l\",\"n\":\"v\",\"b\":\"e\",\"t\":143,\"v\":490},{\"k\":\"l\",\"n\":\"δ\",\"b\":\"i\",\"t\":0,\"v\":491},{\"k\":\"l\",\"n\":\"γ\",\"b\":\"i\",\"t\":0,\"v\":492},{\"k\":\"l\",\"n\":\"β\",\"b\":\"i\",\"t\":0,\"v\":493},{\"k\":\"l\",\"n\":\"α\",\"b\":\"i\",\"t\":0,\"v\":494},{\"k\":\"c\",\"n\":\"Int\",\"u\":[]},{\"k\":\"a\",\"f\":7,\"x\":13},{\"k\":\"p\",\"n\":\"value\",\"b\":\"e\",\"t\":496,\"v\":497},{\"k\":\"p\",\"n\":\"width\",\"b\":\"e\",\"t\":13,\"v\":498},{\"k\":\"a\",\"f\":41,\"x\":496},{\"k\":\"c\",\"n\":\"LT.lt\",\"u\":[{\"k\":\"z\"}]},{\"k\":\"a\",\"f\":501,\"x\":496},{\"k\":\"c\",\"n\":\"Int.instLTInt\",\"u\":[]},{\"k\":\"a\",\"f\":502,\"x\":503},{\"k\":\"a\",\"f\":504,\"x\":48},{\"k\":\"a\",\"f\":75,\"x\":496},{\"k\":\"a\",\"f\":506,\"x\":88},{\"k\":\"c\",\"n\":\"instOfNat\",\"u\":[]},{\"k\":\"a\",\"f\":508,\"x\":88},{\"k\":\"a\",\"f\":507,\"x\":509},{\"k\":\"a\",\"f\":505,\"x\":510},{\"k\":\"a\",\"f\":500,\"x\":511},{\"k\":\"c\",\"n\":\"Int.decLt\",\"u\":[]},{\"k\":\"a\",\"f\":513,\"x\":48},{\"k\":\"a\",\"f\":514,\"x\":510},{\"k\":\"a\",\"f\":512,\"x\":515},{\"k\":\"a\",\"f\":65,\"x\":496},{\"k\":\"a\",\"f\":517,\"x\":496},{\"k\":\"a\",\"f\":518,\"x\":496},{\"k\":\"a\",\"f\":69,\"x\":496},{\"k\":\"c\",\"n\":\"Int.instAdd\",\"u\":[]},{\"k\":\"a\",\"f\":520,\"x\":521},{\"k\":\"a\",\"f\":519,\"x\":522},{\"k\":\"a\",\"f\":523,\"x\":48},{\"k\":\"c\",\"n\":\"HPow.hPow\",\"u\":[{\"k\":\"z\"},{\"k\":\"z\"},{\"k\":\"z\"}]},{\"k\":\"a\",\"f\":525,\"x\":496},{\"k\":\"a\",\"f\":526,\"x\":13},{\"k\":\"a\",\"f\":527,\"x\":496},{\"k\":\"c\",\"n\":\"instHPow\",\"u\":[{\"k\":\"z\"},{\"k\":\"z\"}]},{\"k\":\"a\",\"f\":529,\"x\":496},{\"k\":\"a\",\"f\":530,\"x\":13},{\"k\":\"c\",\"n\":\"instPowNat\",\"u\":[{\"k\":\"z\"}]},{\"k\":\"a\",\"f\":532,\"x\":496},{\"k\":\"c\",\"n\":\"Int.instNatPow\",\"u\":[]},{\"k\":\"a\",\"f\":533,\"x\":534},{\"k\":\"a\",\"f\":531,\"x\":535},{\"k\":\"a\",\"f\":528,\"x\":536},{\"k\":\"n\",\"v\":\"2\"},{\"k\":\"a\",\"f\":506,\"x\":538},{\"k\":\"a\",\"f\":508,\"x\":538},{\"k\":\"a\",\"f\":539,\"x\":540},{\"k\":\"a\",\"f\":537,\"x\":541},{\"k\":\"c\",\"n\":\"HMul.hMul\",\"u\":[{\"k\":\"z\"},{\"k\":\"z\"},{\"k\":\"z\"}]},{\"k\":\"a\",\"f\":543,\"x\":13},{\"k\":\"a\",\"f\":544,\"x\":13},{\"k\":\"a\",\"f\":545,\"x\":13},{\"k\":\"c\",\"n\":\"instHMul\",\"u\":[{\"k\":\"z\"}]},{\"k\":\"a\",\"f\":547,\"x\":13},{\"k\":\"c\",\"n\":\"instMulNat\",\"u\":[]},{\"k\":\"a\",\"f\":548,\"x\":549},{\"k\":\"a\",\"f\":546,\"x\":550},{\"k\":\"n\",\"v\":\"8\"},{\"k\":\"a\",\"f\":76,\"x\":552},{\"k\":\"a\",\"f\":79,\"x\":552},{\"k\":\"a\",\"f\":553,\"x\":554},{\"k\":\"a\",\"f\":551,\"x\":555},{\"k\":\"a\",\"f\":556,\"x\":1},{\"k\":\"a\",\"f\":542,\"x\":557},{\"k\":\"a\",\"f\":524,\"x\":558},{\"k\":\"a\",\"f\":516,\"x\":559},{\"k\":\"a\",\"f\":560,\"x\":48},{\"k\":\"c\",\"n\":\"List.map\",\"u\":[{\"k\":\"z\"},{\"k\":\"z\"}]},{\"k\":\"a\",\"f\":562,\"x\":13},{\"k\":\"a\",\"f\":563,\"x\":13},{\"k\":\"c\",\"n\":\"HMod.hMod\",\"u\":[{\"k\":\"z\"},{\"k\":\"z\"},{\"k\":\"z\"}]},{\"k\":\"a\",\"f\":565,\"x\":13},{\"k\":\"a\",\"f\":566,\"x\":13},{\"k\":\"a\",\"f\":567,\"x\":13},{\"k\":\"c\",\"n\":\"instHMod\",\"u\":[{\"k\":\"z\"}]},{\"k\":\"a\",\"f\":569,\"x\":13},{\"k\":\"c\",\"n\":\"Nat.instMod\",\"u\":[]},{\"k\":\"a\",\"f\":570,\"x\":571},{\"k\":\"a\",\"f\":568,\"x\":572},{\"k\":\"c\",\"n\":\"HDiv.hDiv\",\"u\":[{\"k\":\"z\"},{\"k\":\"z\"},{\"k\":\"z\"}]},{\"k\":\"a\",\"f\":574,\"x\":13},{\"k\":\"a\",\"f\":575,\"x\":13},{\"k\":\"a\",\"f\":576,\"x\":13},{\"k\":\"c\",\"n\":\"instHDiv\",\"u\":[{\"k\":\"z\"}]},{\"k\":\"a\",\"f\":578,\"x\":13},{\"k\":\"c\",\"n\":\"Nat.instDiv\",\"u\":[]},{\"k\":\"a\",\"f\":579,\"x\":580},{\"k\":\"a\",\"f\":577,\"x\":581},{\"k\":\"c\",\"n\":\"Int.toNat\",\"u\":[]},{\"k\":\"a\",\"f\":583,\"x\":1},{\"k\":\"a\",\"f\":582,\"x\":584},{\"k\":\"a\",\"f\":525,\"x\":13},{\"k\":\"a\",\"f\":586,\"x\":13},{\"k\":\"a\",\"f\":587,\"x\":13},{\"k\":\"a\",\"f\":529,\"x\":13},{\"k\":\"a\",\"f\":589,\"x\":13},{\"k\":\"a\",\"f\":532,\"x\":13},{\"k\":\"c\",\"n\":\"instNatPowNat\",\"u\":[]},{\"k\":\"a\",\"f\":591,\"x\":592},{\"k\":\"a\",\"f\":590,\"x\":593},{\"k\":\"a\",\"f\":588,\"x\":594},{\"k\":\"n\",\"v\":\"256\"},{\"k\":\"a\",\"f\":76,\"x\":596},{\"k\":\"a\",\"f\":79,\"x\":596},{\"k\":\"a\",\"f\":597,\"x\":598},{\"k\":\"a\",\"f\":595,\"x\":599},{\"k\":\"a\",\"f\":600,\"x\":48},{\"k\":\"a\",\"f\":585,\"x\":601},{\"k\":\"a\",\"f\":573,\"x\":602},{\"k\":\"a\",\"f\":603,\"x\":599},{\"k\":\"l\",\"n\":\"i\",\"b\":\"e\",\"t\":13,\"v\":604},{\"k\":\"a\",\"f\":564,\"x\":605},{\"k\":\"c\",\"n\":\"List.range\",\"u\":[]},{\"k\":\"a\",\"f\":607,\"x\":3},{\"k\":\"a\",\"f\":606,\"x\":608},{\"k\":\"e\",\"n\":\"unsigned\",\"t\":496,\"v\":561,\"body\":609,\"d\":true},{\"k\":\"l\",\"n\":\"value\",\"b\":\"e\",\"t\":496,\"v\":610},{\"k\":\"l\",\"n\":\"width\",\"b\":\"e\",\"t\":13,\"v\":611},{\"k\":\"p\",\"n\":\"value\",\"b\":\"e\",\"t\":496,\"v\":4},{\"k\":\"p\",\"n\":\"signed\",\"b\":\"e\",\"t\":4,\"v\":613},{\"k\":\"p\",\"n\":\"width\",\"b\":\"e\",\"t\":13,\"v\":614},{\"k\":\"a\",\"f\":41,\"x\":4},{\"k\":\"a\",\"f\":43,\"x\":1},{\"k\":\"a\",\"f\":617,\"x\":58},{\"k\":\"a\",\"f\":616,\"x\":618},{\"k\":\"a\",\"f\":61,\"x\":1},{\"k\":\"a\",\"f\":620,\"x\":58},{\"k\":\"a\",\"f\":619,\"x\":621},{\"k\":\"c\",\"n\":\"Bool.and\",\"u\":[]},{\"k\":\"c\",\"n\":\"Decidable.decide\",\"u\":[]},{\"k\":\"c\",\"n\":\"LE.le\",\"u\":[{\"k\":\"z\"}]},{\"k\":\"a\",\"f\":625,\"x\":496},{\"k\":\"c\",\"n\":\"Int.instLEInt\",\"u\":[]},{\"k\":\"a\",\"f\":626,\"x\":627},{\"k\":\"c\",\"n\":\"Neg.neg\",\"u\":[{\"k\":\"z\"}]},{\"k\":\"a\",\"f\":629,\"x\":496},{\"k\":\"c\",\"n\":\"Int.instNegInt\",\"u\":[]},{\"k\":\"a\",\"f\":630,\"x\":631},{\"k\":\"c\",\"n\":\"HSub.hSub\",\"u\":[{\"k\":\"z\"},{\"k\":\"z\"},{\"k\":\"z\"}]},{\"k\":\"a\",\"f\":633,\"x\":13},{\"k\":\"a\",\"f\":634,\"x\":13},{\"k\":\"a\",\"f\":635,\"x\":13},{\"k\":\"c\",\"n\":\"instHSub\",\"u\":[{\"k\":\"z\"}]},{\"k\":\"a\",\"f\":637,\"x\":13},{\"k\":\"c\",\"n\":\"instSubNat\",\"u\":[]},{\"k\":\"a\",\"f\":638,\"x\":639},{\"k\":\"a\",\"f\":636,\"x\":640},{\"k\":\"a\",\"f\":556,\"x\":3},{\"k\":\"a\",\"f\":641,\"x\":642},{\"k\":\"a\",\"f\":643,\"x\":81},{\"k\":\"a\",\"f\":542,\"x\":644},{\"k\":\"a\",\"f\":632,\"x\":645},{\"k\":\"a\",\"f\":628,\"x\":646},{\"k\":\"a\",\"f\":647,\"x\":48},{\"k\":\"a\",\"f\":624,\"x\":648},{\"k\":\"c\",\"n\":\"Int.decLe\",\"u\":[]},{\"k\":\"a\",\"f\":650,\"x\":646},{\"k\":\"a\",\"f\":651,\"x\":48},{\"k\":\"a\",\"f\":649,\"x\":652},{\"k\":\"a\",\"f\":623,\"x\":653},{\"k\":\"a\",\"f\":505,\"x\":645},{\"k\":\"a\",\"f\":624,\"x\":655},{\"k\":\"a\",\"f\":514,\"x\":645},{\"k\":\"a\",\"f\":656,\"x\":657},{\"k\":\"a\",\"f\":654,\"x\":658},{\"k\":\"a\",\"f\":622,\"x\":659},{\"k\":\"a\",\"f\":628,\"x\":510},{\"k\":\"a\",\"f\":661,\"x\":48},{\"k\":\"a\",\"f\":624,\"x\":662},{\"k\":\"a\",\"f\":650,\"x\":510},{\"k\":\"a\",\"f\":664,\"x\":48},{\"k\":\"a\",\"f\":663,\"x\":665},{\"k\":\"a\",\"f\":623,\"x\":666},{\"k\":\"a\",\"f\":542,\"x\":642},{\"k\":\"a\",\"f\":505,\"x\":668},{\"k\":\"a\",\"f\":624,\"x\":669},{\"k\":\"a\",\"f\":514,\"x\":668},{\"k\":\"a\",\"f\":670,\"x\":671},{\"k\":\"a\",\"f\":667,\"x\":672},{\"k\":\"a\",\"f\":660,\"x\":673},{\"k\":\"l\",\"n\":\"value\",\"b\":\"e\",\"t\":496,\"v\":674},{\"k\":\"l\",\"n\":\"signed\",\"b\":\"e\",\"t\":4,\"v\":675},{\"k\":\"l\",\"n\":\"width\",\"b\":\"e\",\"t\":13,\"v\":676},{\"k\":\"c\",\"n\":\"Char\",\"u\":[]},{\"k\":\"p\",\"n\":\"c\",\"b\":\"e\",\"t\":678,\"v\":497},{\"k\":\"c\",\"n\":\"Char.toNat\",\"u\":[]},{\"k\":\"a\",\"f\":680,\"x\":48},{\"k\":\"a\",\"f\":41,\"x\":497},{\"k\":\"a\",\"f\":501,\"x\":13},{\"k\":\"c\",\"n\":\"instLTNat\",\"u\":[]},{\"k\":\"a\",\"f\":683,\"x\":684},{\"k\":\"a\",\"f\":685,\"x\":48},{\"k\":\"n\",\"v\":\"128\"},{\"k\":\"a\",\"f\":76,\"x\":687},{\"k\":\"a\",\"f\":79,\"x\":687},{\"k\":\"a\",\"f\":688,\"x\":689},{\"k\":\"a\",\"f\":686,\"x\":690},{\"k\":\"a\",\"f\":682,\"x\":691},{\"k\":\"c\",\"n\":\"Nat.decLt\",\"u\":[]},{\"k\":\"a\",\"f\":693,\"x\":48},{\"k\":\"a\",\"f\":694,\"x\":690},{\"k\":\"a\",\"f\":692,\"x\":695},{\"k\":\"c\",\"n\":\"List.cons\",\"u\":[{\"k\":\"z\"}]},{\"k\":\"a\",\"f\":697,\"x\":13},{\"k\":\"a\",\"f\":698,\"x\":48},{\"k\":\"c\",\"n\":\"List.nil\",\"u\":[{\"k\":\"z\"}]},{\"k\":\"a\",\"f\":700,\"x\":13},{\"k\":\"a\",\"f\":699,\"x\":701},{\"k\":\"a\",\"f\":696,\"x\":702},{\"k\":\"n\",\"v\":\"2048\"},{\"k\":\"a\",\"f\":76,\"x\":704},{\"k\":\"a\",\"f\":79,\"x\":704},{\"k\":\"a\",\"f\":705,\"x\":706},{\"k\":\"a\",\"f\":686,\"x\":707},{\"k\":\"a\",\"f\":682,\"x\":708},{\"k\":\"a\",\"f\":694,\"x\":707},{\"k\":\"a\",\"f\":709,\"x\":710},{\"k\":\"n\",\"v\":\"192\"},{\"k\":\"a\",\"f\":76,\"x\":712},{\"k\":\"a\",\"f\":79,\"x\":712},{\"k\":\"a\",\"f\":713,\"x\":714},{\"k\":\"a\",\"f\":73,\"x\":715},{\"k\":\"a\",\"f\":582,\"x\":48},{\"k\":\"n\",\"v\":\"64\"},{\"k\":\"a\",\"f\":76,\"x\":718},{\"k\":\"a\",\"f\":79,\"x\":718},{\"k\":\"a\",\"f\":719,\"x\":720},{\"k\":\"a\",\"f\":717,\"x\":721},{\"k\":\"a\",\"f\":716,\"x\":722},{\"k\":\"a\",\"f\":698,\"x\":723},{\"k\":\"a\",\"f\":73,\"x\":690},{\"k\":\"a\",\"f\":573,\"x\":48},{\"k\":\"a\",\"f\":726,\"x\":721},{\"k\":\"a\",\"f\":725,\"x\":727},{\"k\":\"a\",\"f\":698,\"x\":728},{\"k\":\"a\",\"f\":729,\"x\":701},{\"k\":\"a\",\"f\":724,\"x\":730},{\"k\":\"a\",\"f\":711,\"x\":731},{\"k\":\"n\",\"v\":\"65536\"},{\"k\":\"a\",\"f\":76,\"x\":733},{\"k\":\"a\",\"f\":79,\"x\":733},{\"k\":\"a\",\"f\":734,\"x\":735},{\"k\":\"a\",\"f\":686,\"x\":736},{\"k\":\"a\",\"f\":682,\"x\":737},{\"k\":\"a\",\"f\":694,\"x\":736},{\"k\":\"a\",\"f\":738,\"x\":739},{\"k\":\"n\",\"v\":\"224\"},{\"k\":\"a\",\"f\":76,\"x\":741},{\"k\":\"a\",\"f\":79,\"x\":741},{\"k\":\"a\",\"f\":742,\"x\":743},{\"k\":\"a\",\"f\":73,\"x\":744},{\"k\":\"n\",\"v\":\"4096\"},{\"k\":\"a\",\"f\":76,\"x\":746},{\"k\":\"a\",\"f\":79,\"x\":746},{\"k\":\"a\",\"f\":747,\"x\":748},{\"k\":\"a\",\"f\":717,\"x\":749},{\"k\":\"a\",\"f\":745,\"x\":750},{\"k\":\"a\",\"f\":698,\"x\":751},{\"k\":\"a\",\"f\":573,\"x\":722},{\"k\":\"a\",\"f\":753,\"x\":721},{\"k\":\"a\",\"f\":725,\"x\":754},{\"k\":\"a\",\"f\":698,\"x\":755},{\"k\":\"a\",\"f\":756,\"x\":730},{\"k\":\"a\",\"f\":752,\"x\":757},{\"k\":\"a\",\"f\":740,\"x\":758},{\"k\":\"n\",\"v\":\"240\"},{\"k\":\"a\",\"f\":76,\"x\":760},{\"k\":\"a\",\"f\":79,\"x\":760},{\"k\":\"a\",\"f\":761,\"x\":762},{\"k\":\"a\",\"f\":73,\"x\":763},{\"k\":\"n\",\"v\":\"262144\"},{\"k\":\"a\",\"f\":76,\"x\":765},{\"k\":\"a\",\"f\":79,\"x\":765},{\"k\":\"a\",\"f\":766,\"x\":767},{\"k\":\"a\",\"f\":717,\"x\":768},{\"k\":\"a\",\"f\":764,\"x\":769},{\"k\":\"a\",\"f\":698,\"x\":770},{\"k\":\"a\",\"f\":573,\"x\":750},{\"k\":\"a\",\"f\":772,\"x\":721},{\"k\":\"a\",\"f\":725,\"x\":773},{\"k\":\"a\",\"f\":698,\"x\":774},{\"k\":\"a\",\"f\":775,\"x\":757},{\"k\":\"a\",\"f\":771,\"x\":776},{\"k\":\"a\",\"f\":759,\"x\":777},{\"k\":\"a\",\"f\":732,\"x\":778},{\"k\":\"a\",\"f\":703,\"x\":779},{\"k\":\"e\",\"n\":\"n\",\"t\":13,\"v\":681,\"body\":780,\"d\":true},{\"k\":\"l\",\"n\":\"c\",\"b\":\"e\",\"t\":678,\"v\":781},{\"k\":\"c\",\"n\":\"String\",\"u\":[]},{\"k\":\"a\",\"f\":7,\"x\":783},{\"k\":\"c\",\"n\":\"ByteArray\",\"u\":[]},{\"k\":\"p\",\"n\":\"bytes\",\"b\":\"e\",\"t\":785,\"v\":4},{\"k\":\"p\",\"n\":\"lines\",\"b\":\"e\",\"t\":784,\"v\":786},{\"k\":\"c\",\"n\":\"List.all\",\"u\":[{\"k\":\"z\"}]},{\"k\":\"a\",\"f\":788,\"x\":783},{\"k\":\"a\",\"f\":789,\"x\":1},{\"k\":\"a\",\"f\":788,\"x\":678},{\"k\":\"c\",\"n\":\"String.toList\",\"u\":[]},{\"k\":\"a\",\"f\":792,\"x\":48},{\"k\":\"a\",\"f\":791,\"x\":793},{\"k\":\"c\",\"n\":\"bne\",\"u\":[{\"k\":\"z\"}]},{\"k\":\"a\",\"f\":795,\"x\":13},{\"k\":\"c\",\"n\":\"instBEqOfDecidableEq\",\"u\":[{\"k\":\"z\"}]},{\"k\":\"a\",\"f\":797,\"x\":13},{\"k\":\"c\",\"n\":\"instDecidableEqNat\",\"u\":[]},{\"k\":\"a\",\"f\":798,\"x\":799},{\"k\":\"a\",\"f\":796,\"x\":800},{\"k\":\"a\",\"f\":801,\"x\":681},{\"k\":\"n\",\"v\":\"10\"},{\"k\":\"a\",\"f\":76,\"x\":803},{\"k\":\"a\",\"f\":79,\"x\":803},{\"k\":\"a\",\"f\":804,\"x\":805},{\"k\":\"a\",\"f\":802,\"x\":806},{\"k\":\"a\",\"f\":623,\"x\":807},{\"k\":\"n\",\"v\":\"13\"},{\"k\":\"a\",\"f\":76,\"x\":809},{\"k\":\"a\",\"f\":79,\"x\":809},{\"k\":\"a\",\"f\":810,\"x\":811},{\"k\":\"a\",\"f\":802,\"x\":812},{\"k\":\"a\",\"f\":808,\"x\":813},{\"k\":\"l\",\"n\":\"c\",\"b\":\"e\",\"t\":678,\"v\":814},{\"k\":\"a\",\"f\":794,\"x\":815},{\"k\":\"l\",\"n\":\"line\",\"b\":\"e\",\"t\":783,\"v\":816},{\"k\":\"a\",\"f\":790,\"x\":817},{\"k\":\"a\",\"f\":623,\"x\":818},{\"k\":\"c\",\"n\":\"BEq.beq\",\"u\":[{\"k\":\"z\"}]},{\"k\":\"a\",\"f\":820,\"x\":497},{\"k\":\"c\",\"n\":\"List.instBEq\",\"u\":[{\"k\":\"z\"}]},{\"k\":\"a\",\"f\":822,\"x\":13},{\"k\":\"a\",\"f\":823,\"x\":800},{\"k\":\"a\",\"f\":821,\"x\":824},{\"k\":\"c\",\"n\":\"List.foldr\",\"u\":[{\"k\":\"z\"},{\"k\":\"z\"}]},{\"k\":\"a\",\"f\":826,\"x\":783},{\"k\":\"a\",\"f\":827,\"x\":497},{\"k\":\"c\",\"n\":\"HAppend.hAppend\",\"u\":[{\"k\":\"z\"},{\"k\":\"z\"},{\"k\":\"z\"}]},{\"k\":\"a\",\"f\":829,\"x\":497},{\"k\":\"a\",\"f\":830,\"x\":497},{\"k\":\"a\",\"f\":831,\"x\":497},{\"k\":\"c\",\"n\":\"instHAppendOfAppend\",\"u\":[{\"k\":\"z\"}]},{\"k\":\"a\",\"f\":833,\"x\":497},{\"k\":\"c\",\"n\":\"List.instAppend\",\"u\":[{\"k\":\"z\"}]},{\"k\":\"a\",\"f\":835,\"x\":13},{\"k\":\"a\",\"f\":834,\"x\":836},{\"k\":\"a\",\"f\":832,\"x\":837},{\"k\":\"a\",\"f\":826,\"x\":678},{\"k\":\"a\",\"f\":839,\"x\":497},{\"k\":\"c\",\"n\":\"LexLeanModels.utf8Char\",\"u\":[]},{\"k\":\"a\",\"f\":841,\"x\":1},{\"k\":\"a\",\"f\":838,\"x\":842},{\"k\":\"a\",\"f\":843,\"x\":48},{\"k\":\"l\",\"n\":\"tail\",\"b\":\"e\",\"t\":497,\"v\":844},{\"k\":\"l\",\"n\":\"c\",\"b\":\"e\",\"t\":678,\"v\":845},{\"k\":\"a\",\"f\":840,\"x\":846},{\"k\":\"a\",\"f\":698,\"x\":806},{\"k\":\"a\",\"f\":848,\"x\":701},{\"k\":\"a\",\"f\":847,\"x\":849},{\"k\":\"a\",\"f\":792,\"x\":1},{\"k\":\"a\",\"f\":850,\"x\":851},{\"k\":\"a\",\"f\":838,\"x\":852},{\"k\":\"a\",\"f\":853,\"x\":48},{\"k\":\"l\",\"n\":\"rest\",\"b\":\"e\",\"t\":497,\"v\":854},{\"k\":\"l\",\"n\":\"line\",\"b\":\"e\",\"t\":783,\"v\":855},{\"k\":\"a\",\"f\":828,\"x\":856},{\"k\":\"a\",\"f\":857,\"x\":701},{\"k\":\"a\",\"f\":858,\"x\":1},{\"k\":\"a\",\"f\":825,\"x\":859},{\"k\":\"c\",\"n\":\"UInt8\",\"u\":[]},{\"k\":\"a\",\"f\":562,\"x\":861},{\"k\":\"a\",\"f\":862,\"x\":13},{\"k\":\"c\",\"n\":\"UInt8.toNat\",\"u\":[]},{\"k\":\"a\",\"f\":863,\"x\":864},{\"k\":\"c\",\"n\":\"Array.toList\",\"u\":[{\"k\":\"z\"}]},{\"k\":\"a\",\"f\":866,\"x\":861},{\"k\":\"c\",\"n\":\"ByteArray.data\",\"u\":[]},{\"k\":\"a\",\"f\":868,\"x\":48},{\"k\":\"a\",\"f\":867,\"x\":869},{\"k\":\"a\",\"f\":865,\"x\":870},{\"k\":\"a\",\"f\":860,\"x\":871},{\"k\":\"a\",\"f\":819,\"x\":872},{\"k\":\"l\",\"n\":\"bytes\",\"b\":\"e\",\"t\":785,\"v\":873},{\"k\":\"l\",\"n\":\"lines\",\"b\":\"e\",\"t\":784,\"v\":874},{\"k\":\"a\",\"f\":7,\"x\":496},{\"k\":\"p\",\"n\":\"values\",\"b\":\"e\",\"t\":876,\"v\":786},{\"k\":\"p\",\"n\":\"signed\",\"b\":\"e\",\"t\":4,\"v\":877},{\"k\":\"p\",\"n\":\"width\",\"b\":\"e\",\"t\":13,\"v\":878},{\"k\":\"a\",\"f\":788,\"x\":496},{\"k\":\"a\",\"f\":880,\"x\":1},{\"k\":\"c\",\"n\":\"LexLeanModels.inRange\",\"u\":[]},{\"k\":\"a\",\"f\":882,\"x\":9},{\"k\":\"a\",\"f\":883,\"x\":3},{\"k\":\"a\",\"f\":881,\"x\":884},{\"k\":\"a\",\"f\":623,\"x\":885},{\"k\":\"c\",\"n\":\"List.flatMap\",\"u\":[{\"k\":\"z\"},{\"k\":\"z\"}]},{\"k\":\"a\",\"f\":887,\"x\":496},{\"k\":\"a\",\"f\":888,\"x\":13},{\"k\":\"c\",\"n\":\"LexLeanModels.encodeInt\",\"u\":[]},{\"k\":\"a\",\"f\":890,\"x\":9},{\"k\":\"a\",\"f\":889,\"x\":891},{\"k\":\"a\",\"f\":892,\"x\":1},{\"k\":\"a\",\"f\":825,\"x\":893},{\"k\":\"a\",\"f\":894,\"x\":871},{\"k\":\"a\",\"f\":886,\"x\":895},{\"k\":\"l\",\"n\":\"bytes\",\"b\":\"e\",\"t\":785,\"v\":896},{\"k\":\"l\",\"n\":\"values\",\"b\":\"e\",\"t\":876,\"v\":897},{\"k\":\"l\",\"n\":\"signed\",\"b\":\"e\",\"t\":4,\"v\":898},{\"k\":\"l\",\"n\":\"width\",\"b\":\"e\",\"t\":13,\"v\":899}]"
    )
] (
  "{\"declarations\":[{\"name\":\"LexLeanModels.Agreement\",\"levels\":[],\"kind\":\"definition\",\"reducibility\":{\"kind\":\"regular\",\"height\":4},\"transparency\":\"reducible\",\"policy\":{\"kind\":\"exact\",\"axioms\":[]},\"type\":21,\"value\":103,\"class\":false,\"generated\":false,\"all\":[\"LexLeanModels.Agreement\"]},{\"name\":\"LexLeanModels.Complete1\",\"levels\":[],\"kind\":\"definition\",\"reducibility\":{\"kind\":\"regular\",\"height\":1},\"transparency\":\"semireducible\",\"policy\":{\"kind\":\"exact\",\"axioms\":[]},\"type\":108,\"value\":117,\"class\":false,\"generated\":false,\"all\":[\"LexLeanModels.Complete1\"]},{\"name\":\"LexLeanModels.Complete2\",\"levels\":[],\"kind\":\"definition\",\"reducibility\":{\"kind\":\"regular\",\"height\":1},\"transparency\":\"semireducible\",\"policy\":{\"kind\":\"exact\",\"axioms\":[]},\"type\":125,\"value\":139,\"class\":false,\"generated\":false,\"all\":[\"LexLeanModels.Complete2\"]},{\"name\":\"LexLeanModels.Complete4\",\"levels\":[],\"kind\":\"definition\",\"reducibility\":{\"kind\":\"regular\",\"height\":1},\"transparency\":\"semireducible\",\"policy\":{\"kind\":\"exact\",\"axioms\":[]},\"type\":153,\"value\":174,\"class\":false,\"generated\":false,\"all\":[\"LexLeanModels.Complete4\"]},{\"name\":\"LexLeanModels.Equivalent\",\"levels\":[],\"kind\":\"definition\",\"reducibility\":{\"kind\":\"regular\",\"height\":1},\"transparency\":\"semireducible\",\"policy\":{\"kind\":\"exact\",\"axioms\":[]},\"type\":181,\"value\":192,\"class\":false,\"generated\":false,\"all\":[\"LexLeanModels.Equivalent\"]},{\"name\":\"LexLeanModels.EquivalentStep\",\"levels\":[],\"kind\":\"definition\",\"reducibility\":{\"kind\":\"regular\",\"height\":1},\"transparency\":\"semireducible\",\"policy\":{\"kind\":\"exact\",\"axioms\":[]},\"type\":207,\"value\":229,\"class\":false,\"generated\":false,\"all\":[\"LexLeanModels.EquivalentStep\"]},{\"name\":\"LexLeanModels.EquivalentStepNoInvariant\",\"levels\":[],\"kind\":\"definition\",\"reducibility\":{\"kind\":\"regular\",\"height\":1},\"transparency\":\"semireducible\",\"policy\":{\"kind\":\"exact\",\"axioms\":[]},\"type\":239,\"value\":257,\"class\":false,\"generated\":false,\"all\":[\"LexLeanModels.EquivalentStepNoInvariant\"]},{\"name\":\"LexLeanModels.EquivalentStepNoPrecondition\",\"levels\":[],\"kind\":\"definition\",\"reducibility\":{\"kind\":\"regular\",\"height\":1},\"transparency\":\"semireducible\",\"policy\":{\"kind\":\"exact\",\"axioms\":[]},\"type\":261,\"value\":270,\"class\":false,\"generated\":false,\"all\":[\"LexLeanModels.EquivalentStepNoPrecondition\"]},{\"name\":\"LexLeanModels.EquivalentStepTotal\",\"levels\":[],\"kind\":\"definition\",\"reducibility\":{\"kind\":\"regular\",\"height\":1},\"transparency\":\"semireducible\",\"policy\":{\"kind\":\"exact\",\"axioms\":[]},\"type\":279,\"value\":290,\"class\":false,\"generated\":false,\"all\":[\"LexLeanModels.EquivalentStepTotal\"]},{\"name\":\"LexLeanModels.EquivalentTotal\",\"levels\":[],\"kind\":\"definition\",\"reducibility\":{\"kind\":\"regular\",\"height\":1},\"transparency\":\"semireducible\",\"policy\":{\"kind\":\"exact\",\"axioms\":[]},\"type\":294,\"value\":303,\"class\":false,\"generated\":false,\"all\":[\"LexLeanModels.EquivalentTotal\"]},{\"name\":\"LexLeanModels.Initial\",\"levels\":[],\"kind\":\"definition\",\"reducibility\":{\"kind\":\"regular\",\"height\":1},\"transparency\":\"semireducible\",\"policy\":{\"kind\":\"exact\",\"axioms\":[]},\"type\":307,\"value\":310,\"class\":false,\"generated\":false,\"all\":[\"LexLeanModels.Initial\"]},{\"name\":\"LexLeanModels.Preserves\",\"levels\":[],\"kind\":\"definition\",\"reducibility\":{\"kind\":\"regular\",\"height\":1},\"transparency\":\"semireducible\",\"policy\":{\"kind\":\"exact\",\"axioms\":[]},\"type\":316,\"value\":331,\"class\":false,\"generated\":false,\"all\":[\"LexLeanModels.Preserves\"]},{\"name\":\"LexLeanModels.PreservesTotal\",\"levels\":[],\"kind\":\"definition\",\"reducibility\":{\"kind\":\"regular\",\"height\":1},\"transparency\":\"semireducible\",\"policy\":{\"kind\":\"exact\",\"axioms\":[]},\"type\":336,\"value\":348,\"class\":false,\"generated\":false,\"all\":[\"LexLeanModels.PreservesTotal\"]},{\"name\":\"LexLeanModels.Satisfies\",\"levels\":[],\"kind\":\"definition\",\"reducibility\":{\"kind\":\"regular\",\"height\":1},\"transparency\":\"semireducible\",\"policy\":{\"kind\":\"exact\",\"axioms\":[]},\"type\":353,\"value\":361,\"class\":false,\"generated\":false,\"all\":[\"LexLeanModels.Satisfies\"]},{\"name\":\"LexLeanModels.SatisfiesStep\",\"levels\":[],\"kind\":\"definition\",\"reducibility\":{\"kind\":\"regular\",\"height\":1},\"transparency\":\"semireducible\",\"policy\":{\"kind\":\"exact\",\"axioms\":[]},\"type\":372,\"value\":391,\"class\":false,\"generated\":false,\"all\":[\"LexLeanModels.SatisfiesStep\"]},{\"name\":\"LexLeanModels.SatisfiesStepNoInvariant\",\"levels\":[],\"kind\":\"definition\",\"reducibility\":{\"kind\":\"regular\",\"height\":1},\"transparency\":\"semireducible\",\"policy\":{\"kind\":\"exact\",\"axioms\":[]},\"type\":399,\"value\":414,\"class\":false,\"generated\":false,\"all\":[\"LexLeanModels.SatisfiesStepNoInvariant\"]},{\"name\":\"LexLeanModels.SatisfiesStepNoPrecondition\",\"levels\":[],\"kind\":\"definition\",\"reducibility\":{\"kind\":\"regular\",\"height\":1},\"transparency\":\"semireducible\",\"policy\":{\"kind\":\"exact\",\"axioms\":[]},\"type\":418,\"value\":427,\"class\":false,\"generated\":false,\"all\":[\"LexLeanModels.SatisfiesStepNoPrecondition\"]},{\"name\":\"LexLeanModels.SatisfiesStepTotal\",\"levels\":[],\"kind\":\"definition\",\"reducibility\":{\"kind\":\"regular\",\"height\":1},\"transparency\":\"semireducible\",\"policy\":{\"kind\":\"exact\",\"axioms\":[]},\"type\":434,\"value\":449,\"class\":false,\"generated\":false,\"all\":[\"LexLeanModels.SatisfiesStepTotal\"]},{\"name\":\"LexLeanModels.SatisfiesTotal\",\"levels\":[],\"kind\":\"definition\",\"reducibility\":{\"kind\":\"regular\",\"height\":1},\"transparency\":\"semireducible\",\"policy\":{\"kind\":\"exact\",\"axioms\":[]},\"type\":454,\"value\":460,\"class\":false,\"generated\":false,\"all\":[\"LexLeanModels.SatisfiesTotal\"]},{\"name\":\"LexLeanModels.Sound1\",\"levels\":[],\"kind\":\"definition\",\"reducibility\":{\"kind\":\"regular\",\"height\":1},\"transparency\":\"semireducible\",\"policy\":{\"kind\":\"exact\",\"axioms\":[]},\"type\":108,\"value\":467,\"class\":false,\"generated\":false,\"all\":[\"LexLeanModels.Sound1\"]},{\"name\":\"LexLeanModels.Sound2\",\"levels\":[],\"kind\":\"definition\",\"reducibility\":{\"kind\":\"regular\",\"height\":1},\"transparency\":\"semireducible\",\"policy\":{\"kind\":\"exact\",\"axioms\":[]},\"type\":125,\"value\":476,\"class\":false,\"generated\":false,\"all\":[\"LexLeanModels.Sound2\"]},{\"name\":\"LexLeanModels.Sound4\",\"levels\":[],\"kind\":\"definition\",\"reducibility\":{\"kind\":\"regular\",\"height\":1},\"transparency\":\"semireducible\",\"policy\":{\"kind\":\"exact\",\"axioms\":[]},\"type\":153,\"value\":495,\"class\":false,\"generated\":false,\"all\":[\"LexLeanModels.Sound4\"]},{\"name\":\"LexLeanModels.encodeInt\",\"levels\":[],\"kind\":\"definition\",\"reducibility\":{\"kind\":\"regular\",\"height\":14},\"transparency\":\"semireducible\",\"policy\":{\"kind\":\"exact\",\"axioms\":[]},\"type\":499,\"value\":612,\"class\":false,\"generated\":false,\"all\":[\"LexLeanModels.encodeInt\"],\"compiled\":true},{\"name\":\"LexLeanModels.inRange\",\"levels\":[],\"kind\":\"definition\",\"reducibility\":{\"kind\":\"regular\",\"height\":14},\"transparency\":\"semireducible\",\"policy\":{\"kind\":\"exact\",\"axioms\":[]},\"type\":615,\"value\":677,\"class\":false,\"generated\":false,\"all\":[\"LexLeanModels.inRange\"],\"compiled\":true},{\"name\":\"LexLeanModels.utf8Char\",\"levels\":[],\"kind\":\"definition\",\"reducibility\":{\"kind\":\"regular\",\"height\":9},\"transparency\":\"semireducible\",\"policy\":{\"kind\":\"exact\",\"axioms\":[]},\"type\":679,\"value\":782,\"class\":false,\"generated\":false,\"all\":[\"LexLeanModels.utf8Char\"],\"compiled\":true},{\"name\":\"LexLeanModels.linesMatch\",\"levels\":[],\"kind\":\"definition\",\"reducibility\":{\"kind\":\"regular\",\"height\":24},\"transparency\":\"semireducible\",\"policy\":{\"kind\":\"exact\",\"axioms\":[\"Classical.choice\",\"Quot.sound\",\"propext\"]},\"type\":787,\"value\":875,\"class\":false,\"generated\":false,\"all\":[\"LexLeanModels.linesMatch\"],\"compiled\":true},{\"name\":\"LexLeanModels.tensorMatches\",\"levels\":[],\"kind\":\"definition\",\"reducibility\":{\"kind\":\"regular\",\"height\":15},\"transparency\":\"semireducible\",\"policy\":{\"kind\":\"exact\",\"axioms\":[]},\"type\":879,\"value\":900,\"class\":false,\"generated\":false,\"all\":[\"LexLeanModels.tensorMatches\"],\"compiled\":true}],\"imports\":[\"Init\"],\"module_sparse\":[],\"module_scan\":{\"rows\":[\"LexLeanModels.Agreement\",\"LexLeanModels.Complete1\",\"LexLeanModels.Complete2\",\"LexLeanModels.Complete4\",\"LexLeanModels.Equivalent\",\"LexLeanModels.EquivalentStep\",\"LexLeanModels.EquivalentStepNoInvariant\",\"LexLeanModels.EquivalentStepNoPrecondition\",\"LexLeanModels.EquivalentStepTotal\",\"LexLeanModels.EquivalentTotal\",\"LexLeanModels.Initial\",\"LexLeanModels.Preserves\",\"LexLeanModels.PreservesTotal\",\"LexLeanModels.Satisfies\",\"LexLeanModels.SatisfiesStep\",\"LexLeanModels.SatisfiesStepNoInvariant\",\"LexLeanModels.SatisfiesStepNoPrecondition\",\"LexLeanModels.SatisfiesStepTotal\",\"LexLeanModels.SatisfiesTotal\",\"LexLeanModels.Sound1\",\"LexLeanModels.Sound2\",\"LexLeanModels.Sound4\",\"LexLeanModels.encodeInt\",\"LexLeanModels.inRange\",\"LexLeanModels.utf8Char\",\"LexLeanModels.linesMatch\",\"LexLeanModels.tensorMatches\"],\"sparse\":[]},\"order\":[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,26,24,25],\"proof_nodes\":[],\"spec\":\"lexlean/core-module/2\"}"
  ))

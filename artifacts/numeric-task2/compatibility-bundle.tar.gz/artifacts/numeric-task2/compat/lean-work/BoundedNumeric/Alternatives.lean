module
public import Init
public import LexLeanRuntime.Portable
set_option autoImplicit false
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000000
set_option linter.constructorNameAsVariable false
namespace BoundedNumeric.Alternatives

@[expose] public def addInt16 (a : Int16) (b : Int16) : Option (Int16) := (LexLeanRuntime.checkedAdd (a) (b) : Option (Int16))

@[expose] public def addInt32 (a : Int32) (b : Int32) : Option (Int32) := (LexLeanRuntime.checkedAdd (a) (b) : Option (Int32))

@[expose] public def addInt64 (a : Int64) (b : Int64) : Option (Int64) := (LexLeanRuntime.checkedAddInt64 (a) (b) : Option (Int64))

@[expose] public def addUInt32 (a : UInt32) (b : UInt32) : Option (UInt32) := (LexLeanRuntime.checkedAdd (a) (b) : Option (UInt32))

@[expose] public def addUInt64 (a : UInt64) (b : UInt64) : Option (UInt64) := (LexLeanRuntime.checkedAdd (a) (b) : Option (UInt64))

@[expose] public def convertUInt64 (a : UInt32) : Option (UInt64) := (LexLeanRuntime.checkedConvert (a) : Option (UInt64))

@[expose] public def convertInt64 (a : UInt16) : Option (Int64) := (LexLeanRuntime.checkedConvert (a) : Option (Int64))

@[expose] public def repeat4 (a : UInt32) : Option (UInt32) := (match addUInt32 (a) ((1 : UInt32)) with | Option.some b => (match addUInt32 (b) ((1 : UInt32)) with | Option.some c => (match addUInt32 (c) ((1 : UInt32)) with | Option.some d => addUInt32 (d) ((1 : UInt32)) | Option.none => Option.none) | Option.none => Option.none) | Option.none => Option.none)

@[expose] public def nested4 (a : UInt32) : Option (UInt32) := (match (LexLeanRuntime.checkedAdd (a) ((1 : UInt32)) : Option (UInt32)) with | Option.some b => (match (LexLeanRuntime.checkedAdd (b) ((1 : UInt32)) : Option (UInt32)) with | Option.some c => (match (LexLeanRuntime.checkedAdd (c) ((1 : UInt32)) : Option (UInt32)) with | Option.some d => (LexLeanRuntime.checkedAdd (d) ((1 : UInt32)) : Option (UInt32)) | Option.none => Option.none) | Option.none => Option.none) | Option.none => Option.none)

@[expose] public def unsignedLess (a : UInt64) (b : UInt64) : Bool := (match (LexLeanRuntime.checkedSubtract (a) (b) : Option (UInt64)) with | Option.some _ => false | Option.none => true)

@[expose] public def shiftUInt64 (a : UInt64) : Option (UInt64) := (LexLeanRuntime.shiftRight (a) ((32 : UInt32)) : Option (UInt64))

@[expose] public def equalUInt64 (a : UInt64) (b : UInt64) : Bool := (LexLeanRuntime.equal (a) (b) : Bool)

end BoundedNumeric.Alternatives

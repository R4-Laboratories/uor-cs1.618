module
public import Init
public import LexLeanRuntime.Portable
public import LexLeanRuntime.Collections
set_option autoImplicit false
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000000
set_option linter.constructorNameAsVariable false
namespace BoundedNumeric.Compatibility

@[expose] public def fixedSigned (a : UInt16) (b : Int16) : Option (Int16) := (match (LexLeanRuntime.checkedConvert (a) : Option (Int16)) with | Option.some x => (LexLeanRuntime.checkedSubtract (x) (b) : Option (Int16)) | Option.none => Option.none)

@[expose] public def comparison (a : Int16) (b : Int16) : Bool := (LexLeanCollections.lessThan (a) (b) : Bool)

@[expose] public def step (s : Option (UInt32)) : Option (UInt32) := (match s with | Option.some x => (LexLeanRuntime.checkedAdd (x) ((1 : UInt32)) : Option (UInt32)) | Option.none => Option.none)

@[expose] public def iteration (n : UInt8) (a : UInt32) : Option (UInt32) := (LexLeanCollections.iterate ((fun (s : Option (UInt32)) => step (s))) ((let __widen0 : UInt8 := n; ((((if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (__widen0) ((128 : UInt8)) : UInt8)) ((128 : UInt8)) : Bool) then 128 else 0) + (if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (__widen0) ((64 : UInt8)) : UInt8)) ((64 : UInt8)) : Bool) then 64 else 0)) + ((if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (__widen0) ((32 : UInt8)) : UInt8)) ((32 : UInt8)) : Bool) then 32 else 0) + (if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (__widen0) ((16 : UInt8)) : UInt8)) ((16 : UInt8)) : Bool) then 16 else 0))) + (((if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (__widen0) ((8 : UInt8)) : UInt8)) ((8 : UInt8)) : Bool) then 8 else 0) + (if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (__widen0) ((4 : UInt8)) : UInt8)) ((4 : UInt8)) : Bool) then 4 else 0)) + ((if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (__widen0) ((2 : UInt8)) : UInt8)) ((2 : UInt8)) : Bool) then 2 else 0) + (if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (__widen0) ((1 : UInt8)) : UInt8)) ((1 : UInt8)) : Bool) then 1 else 0)))))) (Option.some (a)) : Option (UInt32))

@[expose] public def constantIteration (a : UInt32) : Option (UInt32) := (LexLeanCollections.iterate ((fun (s : Option (UInt32)) => step (s))) (4) (Option.some (a)) : Option (UInt32))

end BoundedNumeric.Compatibility

#![cfg_attr(not(feature = "std"), no_std)]
#![allow(dead_code, non_snake_case, unused_parens, unused_variables)]
extern crate alloc;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ComputeError {
    AddOverflow,
    MulOverflow,
    ShiftExponentTooLarge,
    ShiftOverflow,
    PowExponentTooLarge,
    PowOverflow,
    OutputTooSmall,
}

pub fn nested4(a: u32) -> Option<u32> {
    { let _x_62 = 1; { let _x_45 = (a).checked_add(_x_62); match _x_45 {
        None => _x_45,
        Some(val_48) => { let _x_81 = 1; { let _x_82 = (val_48).checked_add(_x_81); match _x_82 {
        None => _x_82,
        Some(val_84) => { let _x_93 = 1; { let _x_94 = (val_84).checked_add(_x_93); match _x_94 {
        None => _x_94,
        Some(val_96) => { let _x_100 = 1; { let _x_101 = (val_96).checked_add(_x_100); _x_101 } },
    } } },
    } } },
    } } }
}

#![forbid(unsafe_code)]
use core::cmp::Ordering;

use core::sync::atomic::{AtomicU64, Ordering as Memory};

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub struct Overflow;

pub type R<T> = Result<T, Overflow>;

static WORK: AtomicU64 = AtomicU64::new(0);

pub fn tick(units: u64) { WORK.fetch_add(units, Memory::Relaxed); }

pub fn work() -> u64 { WORK.load(Memory::Relaxed) }

pub trait Same {
    fn same(&self, other: &Self) -> bool;
}

pub trait Key {
    fn key(&self, other: &Self) -> Ordering;
}

impl Same for bool {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for bool {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u8 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u8 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u16 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u16 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u32 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u32 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u64 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u64 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i8 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i8 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i16 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i16 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i32 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i32 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i64 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i64 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for Ordering {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl<A: Key, B: Key> Key for (A, B) {
    fn key(&self, other: &Self) -> Ordering { match self.0.key(&other.0) { Ordering::Equal => self.1.key(&other.1), decided => decided, } }
}

pub fn equal<T: Same>(a: T, b: T) -> bool { a.same(&b) }

pub fn compare<T: Key>(a: T, b: T) -> Ordering { a.key(&b) }

pub fn nat_add(p0: u64, p1: u64) -> R<u64> {
    match u64::checked_add(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<u64, Overflow>(Overflow)
        }
    }
}

pub fn nat_sub(p0: u64, p1: u64) -> u64 {
    u64::saturating_sub(p0, p1)
}

pub fn nat_mul(p0: u64, p1: u64) -> R<u64> {
    match u64::checked_mul(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<u64, Overflow>(Overflow)
        }
    }
}

pub fn nat_quot(p0: u64, p1: u64, p2: u64) -> u64 {
    u64::checked_div(p0, p1).unwrap_or(p2)
}

pub fn nat_rem(p0: u64, p1: u64, p2: u64) -> u64 {
    u64::checked_rem(p0, p1).unwrap_or(p2)
}

pub fn nat_eq(p0: u64, p1: u64) -> bool {
    core::cmp::PartialEq::eq(&p0, &p1)
}

pub fn nat_le(p0: u64, p1: u64) -> bool {
    core::cmp::PartialOrd::le(&p0, &p1)
}

pub fn nat_lt(p0: u64, p1: u64) -> bool {
    core::cmp::PartialOrd::lt(&p0, &p1)
}

pub fn nat_succ(p0: u64) -> R<u64> {
    match u64::checked_add(p0, 1u64) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<u64, Overflow>(Overflow)
        }
    }
}

pub fn int_add(p0: i64, p1: i64) -> R<i64> {
    match i64::checked_add(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_sub(p0: i64, p1: i64) -> R<i64> {
    match i64::checked_sub(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_mul(p0: i64, p1: i64) -> R<i64> {
    match i64::checked_mul(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_neg(p0: i64) -> R<i64> {
    match i64::checked_neg(p0) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_quot(p0: i64, p1: i64, p2: i64) -> R<i64> {
    { let value = { let (a, b, z): (i64, i64, i64) = (p0, p1, p2); if b == 0 { Some(z) } else { a.checked_div(b) } }; match value {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    } }
}

pub fn int_rem(p0: i64, p1: i64, p2: i64) -> i64 {
    { let (a, b, z): (i64, i64, i64) = (p0, p1, p2); if b == 0 { z } else { a.wrapping_rem(b) } }
}

pub fn bool_not(p0: bool) -> bool {
    !p0
}

pub fn bool_and(p0: bool, p1: bool) -> bool {
    if p0 {
        p1
    } else {
        false
    }
}

pub fn bool_or(p0: bool, p1: bool) -> bool {
    if p0 {
        true
    } else {
        p1
    }
}

pub mod fixed_u8 {
    pub fn checked_add(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u8, p1: u8) -> u8 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u8, p1: u8) -> u8 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u8, p1: u8) -> u8 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u8) -> u8 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u8, p1: u32) -> Option<u8> {
        u8::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u8, p1: u32) -> Option<u8> {
        u8::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u8> {
        u8::try_from(p0).ok()
    }
}

pub mod fixed_u16 {
    pub fn checked_add(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u16, p1: u16) -> u16 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u16, p1: u16) -> u16 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u16, p1: u16) -> u16 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u16) -> u16 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u16, p1: u32) -> Option<u16> {
        u16::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u16, p1: u32) -> Option<u16> {
        u16::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u16> {
        u16::try_from(p0).ok()
    }
}

pub mod fixed_u32 {
    pub fn checked_add(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u32, p1: u32) -> u32 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u32, p1: u32) -> u32 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u32, p1: u32) -> u32 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u32) -> u32 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u32> {
        u32::try_from(p0).ok()
    }
}

pub mod fixed_u64 {
    pub fn checked_add(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u64, p1: u64) -> u64 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u64, p1: u64) -> u64 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u64, p1: u64) -> u64 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u64) -> u64 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u64, p1: u32) -> Option<u64> {
        u64::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u64, p1: u32) -> Option<u64> {
        u64::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u64> {
        u64::try_from(p0).ok()
    }
}

pub mod fixed_i8 {
    pub fn checked_add(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i8, p1: i8) -> i8 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i8, p1: i8) -> i8 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i8, p1: i8) -> i8 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i8) -> i8 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i8, p1: u32) -> Option<i8> {
        i8::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i8, p1: u32) -> Option<i8> {
        i8::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i8> {
        i8::try_from(p0).ok()
    }
}

pub fn checked_neg_i8(p0: i8) -> Option<i8> {
    i8::checked_neg(p0)
}

pub mod fixed_i16 {
    pub fn checked_add(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i16, p1: i16) -> i16 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i16, p1: i16) -> i16 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i16, p1: i16) -> i16 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i16) -> i16 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i16, p1: u32) -> Option<i16> {
        i16::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i16, p1: u32) -> Option<i16> {
        i16::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i16> {
        i16::try_from(p0).ok()
    }
}

pub fn checked_neg_i16(p0: i16) -> Option<i16> {
    i16::checked_neg(p0)
}

pub mod fixed_i32 {
    pub fn checked_add(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i32, p1: i32) -> i32 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i32, p1: i32) -> i32 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i32, p1: i32) -> i32 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i32) -> i32 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i32, p1: u32) -> Option<i32> {
        i32::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i32, p1: u32) -> Option<i32> {
        i32::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i32> {
        i32::try_from(p0).ok()
    }
}

pub fn checked_neg_i32(p0: i32) -> Option<i32> {
    i32::checked_neg(p0)
}

pub mod fixed_i64 {
    pub fn checked_add(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i64, p1: i64) -> i64 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i64, p1: i64) -> i64 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i64, p1: i64) -> i64 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i64) -> i64 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i64, p1: u32) -> Option<i64> {
        i64::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i64, p1: u32) -> Option<i64> {
        i64::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i64> {
        i64::try_from(p0).ok()
    }
}

pub fn checked_neg_i64(p0: i64) -> Option<i64> {
    i64::checked_neg(p0)
}
use core::str;

use std::mem;

use std::rc::Rc;

#[derive(Clone)]
pub struct Str(Rc<str>);

impl Str {
    pub fn lit(text: &str) -> Str { Str(Rc::from(text)) }
    pub fn text(&self) -> &str { &self.0 }
    pub fn length(&self) -> u64 { chars(&self.0) }
    pub fn utf8_encode(&self) -> Bytes { tick(self.0.len() as u64); Bytes::lit(self.0.as_bytes()) }
    pub fn split_exact(&self, delimiter: &Str, maximum: u32) -> Option<List<Str>> { if delimiter.0.is_empty() { return None; }; chars(&self.0); let mut fields: Vec<Str> = Vec::new(); for piece in self.0.split(&*delimiter.0) { fields.push(Str::lit(piece)); }; if fields.len() as u128 > u128::from(maximum) { return None; }; Some(List::onto(fields, List::nil())) }
    pub fn join(texts: List<Str>, delimiter: &Str) -> Str { let mut out = String::new(); let mut first = true; let mut cursor = &texts; while let Repr::Cell(cell) = &cursor.0 { tick(1); if !first { chars(&delimiter.0); out.push_str(&delimiter.0); }; first = false; chars(&cell.head.0); out.push_str(&cell.head.0); cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for text in buffer[..*len].iter().rev() { tick(1); if !first { chars(&delimiter.0); out.push_str(&delimiter.0); }; first = false; chars(&text.0); out.push_str(&text.0); } }, _ => { }, }; Str::lit(&out) }
}

#[derive(Clone)]
pub struct Bytes(Rc<[u8]>);

impl Bytes {
    pub fn lit(octets: &[u8]) -> Bytes { Bytes(Rc::from(octets)) }
    pub fn octets(&self) -> &[u8] { &self.0 }
    pub fn append(a: Bytes, b: Bytes) -> Bytes { tick((a.0.len() + b.0.len()) as u64); let mut out = Vec::with_capacity(a.0.len() + b.0.len()); out.extend_from_slice(&a.0); out.extend_from_slice(&b.0); Bytes(Rc::from(out)) }
    pub fn length(&self) -> u64 { self.0.len() as u64 }
    pub fn index(&self, i: u64) -> Option<u8> { match usize::try_from(i) { Ok(at) => self.0.get(at).copied(), Err(_) => None, } }
    pub fn slice(&self, start: u64, count: u64) -> Option<Bytes> { let end = u128::from(start) + u128::from(count); if end > self.0.len() as u128 { return None; }; tick(count); Some(Bytes::lit(&self.0[start as usize..end as usize])) }
    pub fn utf8_decode(&self) -> Option<Str> { tick(self.0.len() as u64); match str::from_utf8(&self.0) { Ok(text) => Some(Str::lit(text)), Err(_) => None, } }
    pub fn compare(&self, other: &Bytes) -> Ordering { tick(1 + self.0.len().min(other.0.len()) as u64); self.0.cmp(&other.0) }
}

pub struct Node<T> { head: T, tail: List<T> }

pub enum Repr<T> { Nil, Run { buffer: Rc<Vec<T>>, len: usize }, Cell(Rc<Node<T>>) }

pub struct List<T>(Repr<T>);

impl<T> Clone for List<T> {
    fn clone(&self) -> Self { List(match &self.0 { Repr::Nil => Repr::Nil, Repr::Run { buffer, len } => Repr::Run { buffer: buffer.clone(), len: *len }, Repr::Cell(cell) => Repr::Cell(cell.clone()), }) }
}

impl<T> List<T> {
    fn take(&mut self) -> Repr<T> { mem::replace(&mut self.0, Repr::Nil) }
}

impl<T> Drop for Node<T> {
    fn drop(&mut self) { let mut next = match self.tail.take() { Repr::Cell(cell) => Some(cell), _ => None, }; while let Some(cell) = next { match Rc::try_unwrap(cell) { Ok(mut node) => next = match node.tail.take() { Repr::Cell(cell) => Some(cell), _ => None, }, Err(_) => break, } } }
}

impl<T: Clone> List<T> {
    pub fn nil() -> Self { List(Repr::Nil) }
    pub fn cons(head: T, mut tail: List<T>) -> Self { List(match tail.take() { Repr::Nil => { let mut buffer = Vec::with_capacity(16); buffer.push(head); Repr::Run { buffer: Rc::new(buffer), len: 1 } }, Repr::Run { mut buffer, len } => { match Rc::get_mut(&mut buffer) { Some(cells) => { cells.truncate(len); cells.push(head); Repr::Run { buffer, len: len + 1 } }, None => Repr::Cell(Rc::new(Node { head, tail: List(Repr::Run { buffer, len }) })), } }, rest => Repr::Cell(Rc::new(Node { head, tail: List(rest) })), }) }
    pub fn uncons(&self) -> Option<(T, List<T>)> { match &self.0 { Repr::Nil => None, Repr::Run { buffer, len } => { let head = buffer[len - 1].clone(); Some((head, List(if *len == 1 { Repr::Nil } else { Repr::Run { buffer: buffer.clone(), len: len - 1 } }))) }, Repr::Cell(cell) => Some((cell.head.clone(), cell.tail.clone())), } }
    pub fn length(&self) -> u64 { let mut count = 0; let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); count += 1; cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for _ in buffer[..*len].iter().rev() { tick(1); count += 1; } }, _ => { }, }; count }
    pub fn append(a: List<T>, b: List<T>) -> List<T> { List::onto(a.items(), b) }
    pub fn index(&self, i: u64) -> Option<T> { let mut position = 0; let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); if position == i { return Some(cell.head.clone()); }; position += 1; cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for item in buffer[..*len].iter().rev() { tick(1); if position == i { return Some(item.clone()); }; position += 1; } }, _ => { }, }; None }
    pub fn slice(&self, start: u64, count: u64) -> Option<List<T>> { let end = u128::from(start) + u128::from(count); let mut part = Vec::new(); let mut position: u128 = 0; let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); if position >= end { return Some(List::onto(part, List::nil())); }; if position >= u128::from(start) { part.push(cell.head.clone()); }; position += 1; cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for item in buffer[..*len].iter().rev() { tick(1); if position >= end { return Some(List::onto(part, List::nil())); }; if position >= u128::from(start) { part.push(item.clone()); }; position += 1; } }, _ => { }, }; if position < end { None } else { Some(List::onto(part, List::nil())) } }
    fn items(&self) -> Vec<T> { let mut out = Vec::new(); let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); out.push(cell.head.clone()); cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for item in buffer[..*len].iter().rev() { tick(1); out.push(item.clone()); } }, _ => { }, }; out }
    fn onto(mut items: Vec<T>, tail: List<T>) -> List<T> { let mut out = tail; while let Some(item) = items.pop() { tick(1); out = List::cons(item, out); }; out }
}

pub fn chars(text: &str) -> u64 { let mut count = 0; for _ in text.chars() { tick(1); count += 1; }; count }

impl Same for Str {
    fn same(&self, other: &Self) -> bool { let mut left = self.0.chars(); let mut right = other.0.chars(); loop { tick(1); match (left.next(), right.next()) { (None, None) => return true, (a, b) if a != b => return false, _ => { }, } } }
}

impl Same for Bytes {
    fn same(&self, other: &Self) -> bool { tick(1 + self.0.len().min(other.0.len()) as u64); self.0 == other.0 }
}

impl Key for Str {
    fn key(&self, other: &Self) -> Ordering { let mut left = self.0.chars(); let mut right = other.0.chars(); loop { tick(1); match (left.next(), right.next()) { (None, None) => return Ordering::Equal, (None, Some(_)) => return Ordering::Less, (Some(_), None) => return Ordering::Greater, (Some(a), Some(b)) => match a.cmp(&b) { Ordering::Equal => { }, decided => return decided, }, } } }
}

pub fn canonical_decimal(text: &str) -> Option<Option<i128>> { let digits = match text.strip_prefix('-') { Some(rest) => rest, None => text, }; let mut canonical = !digits.is_empty() && (digits == "0" || !digits.starts_with('0')) && text != "-0"; for c in digits.chars() { tick(1); canonical = canonical && c.is_ascii_digit(); }; if !canonical { return None; }; Some(text.parse::<i128>().ok()) }

pub fn parse_int(text: Str) -> R<Option<i64>> { match canonical_decimal(&text.0) { None => Ok(None), Some(Some(n)) => match i64::try_from(n) { Ok(value) => Ok(Some(value)), Err(_) => Err(Overflow), }, Some(None) => Err(Overflow), } }

pub fn format_u8(a: u8) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u8(text: Str) -> Option<u8> { match canonical_decimal(&text.0) { Some(Some(n)) => u8::try_from(n).ok(), _ => None, } }

pub fn format_u16(a: u16) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u16(text: Str) -> Option<u16> { match canonical_decimal(&text.0) { Some(Some(n)) => u16::try_from(n).ok(), _ => None, } }

pub fn format_u32(a: u32) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u32(text: Str) -> Option<u32> { match canonical_decimal(&text.0) { Some(Some(n)) => u32::try_from(n).ok(), _ => None, } }

pub fn format_u64(a: u64) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u64(text: Str) -> Option<u64> { match canonical_decimal(&text.0) { Some(Some(n)) => u64::try_from(n).ok(), _ => None, } }

pub fn format_i8(a: i8) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i8(text: Str) -> Option<i8> { match canonical_decimal(&text.0) { Some(Some(n)) => i8::try_from(n).ok(), _ => None, } }

pub fn format_i16(a: i16) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i16(text: Str) -> Option<i16> { match canonical_decimal(&text.0) { Some(Some(n)) => i16::try_from(n).ok(), _ => None, } }

pub fn format_i32(a: i32) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i32(text: Str) -> Option<i32> { match canonical_decimal(&text.0) { Some(Some(n)) => i32::try_from(n).ok(), _ => None, } }

pub fn format_i64(a: i64) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i64(text: Str) -> Option<i64> { match canonical_decimal(&text.0) { Some(Some(n)) => i64::try_from(n).ok(), _ => None, } }

pub fn append_list<T: Clone>(p0: List<T>, p1: List<T>) -> List<T> {
    List::append(p0, p1)
}

pub fn length_list<T: Clone>(p0: List<T>) -> u64 {
    List::length(&p0)
}

pub fn index_list<T: Clone>(p0: List<T>, p1: u64) -> Option<T> {
    List::index(&p0, p1)
}

pub fn slice_list<T: Clone>(p0: List<T>, p1: u64, p2: u64) -> Option<List<T>> {
    List::slice(&p0, p1, p2)
}

pub fn append_bytes(p0: Bytes, p1: Bytes) -> Bytes {
    Bytes::append(p0, p1)
}

pub fn length_bytes(p0: Bytes) -> u64 {
    Bytes::length(&p0)
}

pub fn length_string(p0: Str) -> u64 {
    Str::length(&p0)
}

pub fn index_bytes(p0: Bytes, p1: u64) -> Option<u8> {
    Bytes::index(&p0, p1)
}

pub fn slice_bytes(p0: Bytes, p1: u64, p2: u64) -> Option<Bytes> {
    Bytes::slice(&p0, p1, p2)
}

pub fn utf8_encode(p0: Str) -> Bytes {
    Str::utf8_encode(&p0)
}

pub fn utf8_decode(p0: Bytes) -> Option<Str> {
    Bytes::utf8_decode(&p0)
}

pub fn compare_bytes(p0: Bytes, p1: Bytes) -> Ordering {
    Bytes::compare(&p0, &p1)
}

pub fn split_exact(p0: Str, p1: Str, p2: u32) -> Option<List<Str>> {
    Str::split_exact(&p0, &p1, p2)
}

pub fn join(p0: List<Str>, p1: Str) -> Str {
    Str::join(p0, &p1)
}

#[derive(Clone)]
pub enum Adt0 {
    C0(u32, u32, u32, u32),
}

#[derive(Clone)]
pub enum Adt1 {
    C0(u64, u64, u64),
}

#[derive(Clone)]
pub enum Adt2 {
    C0(Adt0, bool, bool),
}

#[derive(Clone)]
pub enum Fn0 {
    F8,
}

impl Fn0 {
    pub fn apply(&self, p0: Option<Adt1>) -> Option<Adt1> {
        match self {
            Fn0::F8 => f8(p0),
        }
    }
}

#[derive(Clone)]
pub enum Fn1 {
    F11,
}

impl Fn1 {
    pub fn apply(&self, p0: Option<Adt2>) -> Option<Adt2> {
        match self {
            Fn1::F11 => f11(p0),
        }
    }
}

#[derive(Clone)]
pub enum Fn2 {
    F13,
}

impl Fn2 {
    pub fn apply(&self, p0: Option<(u32, i64)>) -> R<Option<(u32, i64)>> {
        match self {
            Fn2::F13 => f13(p0),
        }
    }
}

pub fn f0(v0: u64, v1: u64) -> R<Option<u64>> {
    f1(v0, v1)
}

pub fn f1(v0: u64, v1: u64) -> R<Option<u64>> {
    let v2: u64 = {
        let a3 = {
            let a1 = v0;
            let a2 = v1;
            fixed_u64::bit_xor(a1, a2)
        };
        let a4 = 9223372036854775808u64;
        fixed_u64::bit_and(a3, a4)
    };
    let v3: u64 = {
        let a5 = v0;
        let a6 = 4503599627370495u64;
        fixed_u64::bit_and(a5, a6)
    };
    let v4: u64 = {
        let a7 = v1;
        let a8 = 4503599627370495u64;
        fixed_u64::bit_and(a7, a8)
    };
    let m11 = {
        let a9 = v0;
        let a10 = 52u32;
        fixed_u64::shift_right(a9, a10)
    };
    match m11 {
        None => {
            Ok(None::<u64>)
        }
        Some(v5) => {
            let m14 = {
                let a12 = v1;
                let a13 = 52u32;
                fixed_u64::shift_right(a12, a13)
            };
            match m14 {
                None => {
                    Ok(None::<u64>)
                }
                Some(v6) => {
                    let v7: u64 = {
                        let a15 = v5;
                        let a16 = 2047u64;
                        fixed_u64::bit_and(a15, a16)
                    };
                    let v8: u64 = {
                        let a17 = v6;
                        let a18 = 2047u64;
                        fixed_u64::bit_and(a17, a18)
                    };
                    let a19 = v7;
                    let a20 = 2047u64;
                    if if equal(a19, a20) {
                        let a23 = {
                            let a21 = v3;
                            let a22 = 0u64;
                            equal(a21, a22)
                        };
                        bool_not(a23)
                    } else {
                        false
                    } {
                        Ok(Some({
                            let a24 = v0;
                            let a25 = 2251799813685248u64;
                            fixed_u64::bit_or(a24, a25)
                        }))
                    } else {
                        let a26 = v8;
                        let a27 = 2047u64;
                        if if equal(a26, a27) {
                            let a30 = {
                                let a28 = v4;
                                let a29 = 0u64;
                                equal(a28, a29)
                            };
                            bool_not(a30)
                        } else {
                            false
                        } {
                            Ok(Some({
                                let a31 = v1;
                                let a32 = 2251799813685248u64;
                                fixed_u64::bit_or(a31, a32)
                            }))
                        } else {
                            let a35 = {
                                let a33 = v0;
                                let a34 = 9223372036854775807u64;
                                fixed_u64::bit_and(a33, a34)
                            };
                            let a36 = 0u64;
                            if if if equal(a35, a36) {
                                let a39 = {
                                    let a37 = v1;
                                    let a38 = 9223372036854775807u64;
                                    fixed_u64::bit_and(a37, a38)
                                };
                                let a40 = 0u64;
                                equal(a39, a40)
                            } else {
                                false
                            } {
                                true
                            } else {
                                let a41 = v7;
                                let a42 = 2047u64;
                                if equal(a41, a42) {
                                    let a43 = v8;
                                    let a44 = 2047u64;
                                    equal(a43, a44)
                                } else {
                                    false
                                }
                            } {
                                Ok(Some(9221120237041090560u64))
                            } else {
                                let a45 = v7;
                                let a46 = 2047u64;
                                if if equal(a45, a46) {
                                    true
                                } else {
                                    let a49 = {
                                        let a47 = v1;
                                        let a48 = 9223372036854775807u64;
                                        fixed_u64::bit_and(a47, a48)
                                    };
                                    let a50 = 0u64;
                                    equal(a49, a50)
                                } {
                                    Ok(Some({
                                        let a51 = v2;
                                        let a52 = 9218868437227405312u64;
                                        fixed_u64::bit_or(a51, a52)
                                    }))
                                } else {
                                    let a53 = v8;
                                    let a54 = 2047u64;
                                    if if equal(a53, a54) {
                                        true
                                    } else {
                                        let a57 = {
                                            let a55 = v0;
                                            let a56 = 9223372036854775807u64;
                                            fixed_u64::bit_and(a55, a56)
                                        };
                                        let a58 = 0u64;
                                        equal(a57, a58)
                                    } {
                                        Ok(Some(v2))
                                    } else {
                                        let m60 = {
                                            let a59 = v7;
                                            fixed_u16::convert(i128::from(a59))
                                        };
                                        match m60 {
                                            None => {
                                                Ok(None::<u64>)
                                            }
                                            Some(v9) => {
                                                let m62 = {
                                                    let a61 = v8;
                                                    fixed_u16::convert(i128::from(a61))
                                                };
                                                match m62 {
                                                    None => {
                                                        Ok(None::<u64>)
                                                    }
                                                    Some(v10) => {
                                                        let v11: u64 = {
                                                            let a63 = v7;
                                                            let a64 = 0u64;
                                                            if equal(a63, a64) {
                                                                v3
                                                            } else {
                                                                let a65 = v3;
                                                                let a66 = 4503599627370496u64;
                                                                fixed_u64::bit_or(a65, a66)
                                                            }
                                                        };
                                                        let v12: u64 = {
                                                            let a67 = v8;
                                                            let a68 = 0u64;
                                                            if equal(a67, a68) {
                                                                v4
                                                            } else {
                                                                let a69 = v4;
                                                                let a70 = 4503599627370496u64;
                                                                fixed_u64::bit_or(a69, a70)
                                                            }
                                                        };
                                                        let v14: i64 = {
                                                            let a71 = v7;
                                                            let a72 = 0u64;
                                                            if equal(a71, a72) {
                                                                1i64
                                                            } else {
                                                                let v13: u16 = v9;
                                                                let a180 = {
                                                                    let a124 = {
                                                                        let a96 = {
                                                                            let a82 = {
                                                                                let a75 = {
                                                                                    let a73 = v13;
                                                                                    let a74 = 32768u16;
                                                                                    fixed_u16::bit_and(a73, a74)
                                                                                };
                                                                                let a76 = 32768u16;
                                                                                if equal(a75, a76) {
                                                                                    32768i64
                                                                                } else {
                                                                                    0i64
                                                                                }
                                                                            };
                                                                            let a83 = {
                                                                                let a81 = {
                                                                                    let a79 = {
                                                                                        let a77 = v13;
                                                                                        let a78 = 16384u16;
                                                                                        fixed_u16::bit_and(a77, a78)
                                                                                    };
                                                                                    let a80 = 16384u16;
                                                                                    if equal(a79, a80) {
                                                                                        16384i64
                                                                                    } else {
                                                                                        0i64
                                                                                    }
                                                                                };
                                                                                int_neg(a81)?
                                                                            };
                                                                            int_sub(a82, a83)?
                                                                        };
                                                                        let a97 = {
                                                                            let a95 = {
                                                                                let a93 = {
                                                                                    let a86 = {
                                                                                        let a84 = v13;
                                                                                        let a85 = 8192u16;
                                                                                        fixed_u16::bit_and(a84, a85)
                                                                                    };
                                                                                    let a87 = 8192u16;
                                                                                    if equal(a86, a87) {
                                                                                        8192i64
                                                                                    } else {
                                                                                        0i64
                                                                                    }
                                                                                };
                                                                                let a94 = {
                                                                                    let a92 = {
                                                                                        let a90 = {
                                                                                            let a88 = v13;
                                                                                            let a89 = 4096u16;
                                                                                            fixed_u16::bit_and(a88, a89)
                                                                                        };
                                                                                        let a91 = 4096u16;
                                                                                        if equal(a90, a91) {
                                                                                            4096i64
                                                                                        } else {
                                                                                            0i64
                                                                                        }
                                                                                    };
                                                                                    int_neg(a92)?
                                                                                };
                                                                                int_sub(a93, a94)?
                                                                            };
                                                                            int_neg(a95)?
                                                                        };
                                                                        int_sub(a96, a97)?
                                                                    };
                                                                    let a125 = {
                                                                        let a123 = {
                                                                            let a121 = {
                                                                                let a107 = {
                                                                                    let a100 = {
                                                                                        let a98 = v13;
                                                                                        let a99 = 2048u16;
                                                                                        fixed_u16::bit_and(a98, a99)
                                                                                    };
                                                                                    let a101 = 2048u16;
                                                                                    if equal(a100, a101) {
                                                                                        2048i64
                                                                                    } else {
                                                                                        0i64
                                                                                    }
                                                                                };
                                                                                let a108 = {
                                                                                    let a106 = {
                                                                                        let a104 = {
                                                                                            let a102 = v13;
                                                                                            let a103 = 1024u16;
                                                                                            fixed_u16::bit_and(a102, a103)
                                                                                        };
                                                                                        let a105 = 1024u16;
                                                                                        if equal(a104, a105) {
                                                                                            1024i64
                                                                                        } else {
                                                                                            0i64
                                                                                        }
                                                                                    };
                                                                                    int_neg(a106)?
                                                                                };
                                                                                int_sub(a107, a108)?
                                                                            };
                                                                            let a122 = {
                                                                                let a120 = {
                                                                                    let a118 = {
                                                                                        let a111 = {
                                                                                            let a109 = v13;
                                                                                            let a110 = 512u16;
                                                                                            fixed_u16::bit_and(a109, a110)
                                                                                        };
                                                                                        let a112 = 512u16;
                                                                                        if equal(a111, a112) {
                                                                                            512i64
                                                                                        } else {
                                                                                            0i64
                                                                                        }
                                                                                    };
                                                                                    let a119 = {
                                                                                        let a117 = {
                                                                                            let a115 = {
                                                                                                let a113 = v13;
                                                                                                let a114 = 256u16;
                                                                                                fixed_u16::bit_and(a113, a114)
                                                                                            };
                                                                                            let a116 = 256u16;
                                                                                            if equal(a115, a116) {
                                                                                                256i64
                                                                                            } else {
                                                                                                0i64
                                                                                            }
                                                                                        };
                                                                                        int_neg(a117)?
                                                                                    };
                                                                                    int_sub(a118, a119)?
                                                                                };
                                                                                int_neg(a120)?
                                                                            };
                                                                            int_sub(a121, a122)?
                                                                        };
                                                                        int_neg(a123)?
                                                                    };
                                                                    int_sub(a124, a125)?
                                                                };
                                                                let a181 = {
                                                                    let a179 = {
                                                                        let a177 = {
                                                                            let a149 = {
                                                                                let a135 = {
                                                                                    let a128 = {
                                                                                        let a126 = v13;
                                                                                        let a127 = 128u16;
                                                                                        fixed_u16::bit_and(a126, a127)
                                                                                    };
                                                                                    let a129 = 128u16;
                                                                                    if equal(a128, a129) {
                                                                                        128i64
                                                                                    } else {
                                                                                        0i64
                                                                                    }
                                                                                };
                                                                                let a136 = {
                                                                                    let a134 = {
                                                                                        let a132 = {
                                                                                            let a130 = v13;
                                                                                            let a131 = 64u16;
                                                                                            fixed_u16::bit_and(a130, a131)
                                                                                        };
                                                                                        let a133 = 64u16;
                                                                                        if equal(a132, a133) {
                                                                                            64i64
                                                                                        } else {
                                                                                            0i64
                                                                                        }
                                                                                    };
                                                                                    int_neg(a134)?
                                                                                };
                                                                                int_sub(a135, a136)?
                                                                            };
                                                                            let a150 = {
                                                                                let a148 = {
                                                                                    let a146 = {
                                                                                        let a139 = {
                                                                                            let a137 = v13;
                                                                                            let a138 = 32u16;
                                                                                            fixed_u16::bit_and(a137, a138)
                                                                                        };
                                                                                        let a140 = 32u16;
                                                                                        if equal(a139, a140) {
                                                                                            32i64
                                                                                        } else {
                                                                                            0i64
                                                                                        }
                                                                                    };
                                                                                    let a147 = {
                                                                                        let a145 = {
                                                                                            let a143 = {
                                                                                                let a141 = v13;
                                                                                                let a142 = 16u16;
                                                                                                fixed_u16::bit_and(a141, a142)
                                                                                            };
                                                                                            let a144 = 16u16;
                                                                                            if equal(a143, a144) {
                                                                                                16i64
                                                                                            } else {
                                                                                                0i64
                                                                                            }
                                                                                        };
                                                                                        int_neg(a145)?
                                                                                    };
                                                                                    int_sub(a146, a147)?
                                                                                };
                                                                                int_neg(a148)?
                                                                            };
                                                                            int_sub(a149, a150)?
                                                                        };
                                                                        let a178 = {
                                                                            let a176 = {
                                                                                let a174 = {
                                                                                    let a160 = {
                                                                                        let a153 = {
                                                                                            let a151 = v13;
                                                                                            let a152 = 8u16;
                                                                                            fixed_u16::bit_and(a151, a152)
                                                                                        };
                                                                                        let a154 = 8u16;
                                                                                        if equal(a153, a154) {
                                                                                            8i64
                                                                                        } else {
                                                                                            0i64
                                                                                        }
                                                                                    };
                                                                                    let a161 = {
                                                                                        let a159 = {
                                                                                            let a157 = {
                                                                                                let a155 = v13;
                                                                                                let a156 = 4u16;
                                                                                                fixed_u16::bit_and(a155, a156)
                                                                                            };
                                                                                            let a158 = 4u16;
                                                                                            if equal(a157, a158) {
                                                                                                4i64
                                                                                            } else {
                                                                                                0i64
                                                                                            }
                                                                                        };
                                                                                        int_neg(a159)?
                                                                                    };
                                                                                    int_sub(a160, a161)?
                                                                                };
                                                                                let a175 = {
                                                                                    let a173 = {
                                                                                        let a171 = {
                                                                                            let a164 = {
                                                                                                let a162 = v13;
                                                                                                let a163 = 2u16;
                                                                                                fixed_u16::bit_and(a162, a163)
                                                                                            };
                                                                                            let a165 = 2u16;
                                                                                            if equal(a164, a165) {
                                                                                                2i64
                                                                                            } else {
                                                                                                0i64
                                                                                            }
                                                                                        };
                                                                                        let a172 = {
                                                                                            let a170 = {
                                                                                                let a168 = {
                                                                                                    let a166 = v13;
                                                                                                    let a167 = 1u16;
                                                                                                    fixed_u16::bit_and(a166, a167)
                                                                                                };
                                                                                                let a169 = 1u16;
                                                                                                if equal(a168, a169) {
                                                                                                    1i64
                                                                                                } else {
                                                                                                    0i64
                                                                                                }
                                                                                            };
                                                                                            int_neg(a170)?
                                                                                        };
                                                                                        int_sub(a171, a172)?
                                                                                    };
                                                                                    int_neg(a173)?
                                                                                };
                                                                                int_sub(a174, a175)?
                                                                            };
                                                                            int_neg(a176)?
                                                                        };
                                                                        int_sub(a177, a178)?
                                                                    };
                                                                    int_neg(a179)?
                                                                };
                                                                int_sub(a180, a181)?
                                                            }
                                                        };
                                                        let v16: i64 = {
                                                            let a182 = v8;
                                                            let a183 = 0u64;
                                                            if equal(a182, a183) {
                                                                1i64
                                                            } else {
                                                                let v15: u16 = v10;
                                                                let a291 = {
                                                                    let a235 = {
                                                                        let a207 = {
                                                                            let a193 = {
                                                                                let a186 = {
                                                                                    let a184 = v15;
                                                                                    let a185 = 32768u16;
                                                                                    fixed_u16::bit_and(a184, a185)
                                                                                };
                                                                                let a187 = 32768u16;
                                                                                if equal(a186, a187) {
                                                                                    32768i64
                                                                                } else {
                                                                                    0i64
                                                                                }
                                                                            };
                                                                            let a194 = {
                                                                                let a192 = {
                                                                                    let a190 = {
                                                                                        let a188 = v15;
                                                                                        let a189 = 16384u16;
                                                                                        fixed_u16::bit_and(a188, a189)
                                                                                    };
                                                                                    let a191 = 16384u16;
                                                                                    if equal(a190, a191) {
                                                                                        16384i64
                                                                                    } else {
                                                                                        0i64
                                                                                    }
                                                                                };
                                                                                int_neg(a192)?
                                                                            };
                                                                            int_sub(a193, a194)?
                                                                        };
                                                                        let a208 = {
                                                                            let a206 = {
                                                                                let a204 = {
                                                                                    let a197 = {
                                                                                        let a195 = v15;
                                                                                        let a196 = 8192u16;
                                                                                        fixed_u16::bit_and(a195, a196)
                                                                                    };
                                                                                    let a198 = 8192u16;
                                                                                    if equal(a197, a198) {
                                                                                        8192i64
                                                                                    } else {
                                                                                        0i64
                                                                                    }
                                                                                };
                                                                                let a205 = {
                                                                                    let a203 = {
                                                                                        let a201 = {
                                                                                            let a199 = v15;
                                                                                            let a200 = 4096u16;
                                                                                            fixed_u16::bit_and(a199, a200)
                                                                                        };
                                                                                        let a202 = 4096u16;
                                                                                        if equal(a201, a202) {
                                                                                            4096i64
                                                                                        } else {
                                                                                            0i64
                                                                                        }
                                                                                    };
                                                                                    int_neg(a203)?
                                                                                };
                                                                                int_sub(a204, a205)?
                                                                            };
                                                                            int_neg(a206)?
                                                                        };
                                                                        int_sub(a207, a208)?
                                                                    };
                                                                    let a236 = {
                                                                        let a234 = {
                                                                            let a232 = {
                                                                                let a218 = {
                                                                                    let a211 = {
                                                                                        let a209 = v15;
                                                                                        let a210 = 2048u16;
                                                                                        fixed_u16::bit_and(a209, a210)
                                                                                    };
                                                                                    let a212 = 2048u16;
                                                                                    if equal(a211, a212) {
                                                                                        2048i64
                                                                                    } else {
                                                                                        0i64
                                                                                    }
                                                                                };
                                                                                let a219 = {
                                                                                    let a217 = {
                                                                                        let a215 = {
                                                                                            let a213 = v15;
                                                                                            let a214 = 1024u16;
                                                                                            fixed_u16::bit_and(a213, a214)
                                                                                        };
                                                                                        let a216 = 1024u16;
                                                                                        if equal(a215, a216) {
                                                                                            1024i64
                                                                                        } else {
                                                                                            0i64
                                                                                        }
                                                                                    };
                                                                                    int_neg(a217)?
                                                                                };
                                                                                int_sub(a218, a219)?
                                                                            };
                                                                            let a233 = {
                                                                                let a231 = {
                                                                                    let a229 = {
                                                                                        let a222 = {
                                                                                            let a220 = v15;
                                                                                            let a221 = 512u16;
                                                                                            fixed_u16::bit_and(a220, a221)
                                                                                        };
                                                                                        let a223 = 512u16;
                                                                                        if equal(a222, a223) {
                                                                                            512i64
                                                                                        } else {
                                                                                            0i64
                                                                                        }
                                                                                    };
                                                                                    let a230 = {
                                                                                        let a228 = {
                                                                                            let a226 = {
                                                                                                let a224 = v15;
                                                                                                let a225 = 256u16;
                                                                                                fixed_u16::bit_and(a224, a225)
                                                                                            };
                                                                                            let a227 = 256u16;
                                                                                            if equal(a226, a227) {
                                                                                                256i64
                                                                                            } else {
                                                                                                0i64
                                                                                            }
                                                                                        };
                                                                                        int_neg(a228)?
                                                                                    };
                                                                                    int_sub(a229, a230)?
                                                                                };
                                                                                int_neg(a231)?
                                                                            };
                                                                            int_sub(a232, a233)?
                                                                        };
                                                                        int_neg(a234)?
                                                                    };
                                                                    int_sub(a235, a236)?
                                                                };
                                                                let a292 = {
                                                                    let a290 = {
                                                                        let a288 = {
                                                                            let a260 = {
                                                                                let a246 = {
                                                                                    let a239 = {
                                                                                        let a237 = v15;
                                                                                        let a238 = 128u16;
                                                                                        fixed_u16::bit_and(a237, a238)
                                                                                    };
                                                                                    let a240 = 128u16;
                                                                                    if equal(a239, a240) {
                                                                                        128i64
                                                                                    } else {
                                                                                        0i64
                                                                                    }
                                                                                };
                                                                                let a247 = {
                                                                                    let a245 = {
                                                                                        let a243 = {
                                                                                            let a241 = v15;
                                                                                            let a242 = 64u16;
                                                                                            fixed_u16::bit_and(a241, a242)
                                                                                        };
                                                                                        let a244 = 64u16;
                                                                                        if equal(a243, a244) {
                                                                                            64i64
                                                                                        } else {
                                                                                            0i64
                                                                                        }
                                                                                    };
                                                                                    int_neg(a245)?
                                                                                };
                                                                                int_sub(a246, a247)?
                                                                            };
                                                                            let a261 = {
                                                                                let a259 = {
                                                                                    let a257 = {
                                                                                        let a250 = {
                                                                                            let a248 = v15;
                                                                                            let a249 = 32u16;
                                                                                            fixed_u16::bit_and(a248, a249)
                                                                                        };
                                                                                        let a251 = 32u16;
                                                                                        if equal(a250, a251) {
                                                                                            32i64
                                                                                        } else {
                                                                                            0i64
                                                                                        }
                                                                                    };
                                                                                    let a258 = {
                                                                                        let a256 = {
                                                                                            let a254 = {
                                                                                                let a252 = v15;
                                                                                                let a253 = 16u16;
                                                                                                fixed_u16::bit_and(a252, a253)
                                                                                            };
                                                                                            let a255 = 16u16;
                                                                                            if equal(a254, a255) {
                                                                                                16i64
                                                                                            } else {
                                                                                                0i64
                                                                                            }
                                                                                        };
                                                                                        int_neg(a256)?
                                                                                    };
                                                                                    int_sub(a257, a258)?
                                                                                };
                                                                                int_neg(a259)?
                                                                            };
                                                                            int_sub(a260, a261)?
                                                                        };
                                                                        let a289 = {
                                                                            let a287 = {
                                                                                let a285 = {
                                                                                    let a271 = {
                                                                                        let a264 = {
                                                                                            let a262 = v15;
                                                                                            let a263 = 8u16;
                                                                                            fixed_u16::bit_and(a262, a263)
                                                                                        };
                                                                                        let a265 = 8u16;
                                                                                        if equal(a264, a265) {
                                                                                            8i64
                                                                                        } else {
                                                                                            0i64
                                                                                        }
                                                                                    };
                                                                                    let a272 = {
                                                                                        let a270 = {
                                                                                            let a268 = {
                                                                                                let a266 = v15;
                                                                                                let a267 = 4u16;
                                                                                                fixed_u16::bit_and(a266, a267)
                                                                                            };
                                                                                            let a269 = 4u16;
                                                                                            if equal(a268, a269) {
                                                                                                4i64
                                                                                            } else {
                                                                                                0i64
                                                                                            }
                                                                                        };
                                                                                        int_neg(a270)?
                                                                                    };
                                                                                    int_sub(a271, a272)?
                                                                                };
                                                                                let a286 = {
                                                                                    let a284 = {
                                                                                        let a282 = {
                                                                                            let a275 = {
                                                                                                let a273 = v15;
                                                                                                let a274 = 2u16;
                                                                                                fixed_u16::bit_and(a273, a274)
                                                                                            };
                                                                                            let a276 = 2u16;
                                                                                            if equal(a275, a276) {
                                                                                                2i64
                                                                                            } else {
                                                                                                0i64
                                                                                            }
                                                                                        };
                                                                                        let a283 = {
                                                                                            let a281 = {
                                                                                                let a279 = {
                                                                                                    let a277 = v15;
                                                                                                    let a278 = 1u16;
                                                                                                    fixed_u16::bit_and(a277, a278)
                                                                                                };
                                                                                                let a280 = 1u16;
                                                                                                if equal(a279, a280) {
                                                                                                    1i64
                                                                                                } else {
                                                                                                    0i64
                                                                                                }
                                                                                            };
                                                                                            int_neg(a281)?
                                                                                        };
                                                                                        int_sub(a282, a283)?
                                                                                    };
                                                                                    int_neg(a284)?
                                                                                };
                                                                                int_sub(a285, a286)?
                                                                            };
                                                                            int_neg(a287)?
                                                                        };
                                                                        int_sub(a288, a289)?
                                                                    };
                                                                    int_neg(a290)?
                                                                };
                                                                int_sub(a291, a292)?
                                                            }
                                                        };
                                                        let m293 = f2(v11);
                                                        match m293 {
                                                            None => {
                                                                Ok(None::<u64>)
                                                            }
                                                            Some(v17) => {
                                                                let m294 = f2(v12);
                                                                match m294 {
                                                                    None => {
                                                                        Ok(None::<u64>)
                                                                    }
                                                                    Some(v18) => {
                                                                        let m295 = f3(v17)?;
                                                                        match m295 {
                                                                            None => {
                                                                                Ok(None::<u64>)
                                                                            }
                                                                            Some(v19) => {
                                                                                let m296 = f3(v18)?;
                                                                                match m296 {
                                                                                    None => {
                                                                                        Ok(None::<u64>)
                                                                                    }
                                                                                    Some(v20) => {
                                                                                        let m300 = {
                                                                                            let a299 = {
                                                                                                let a297 = 53i64;
                                                                                                let a298 = v19;
                                                                                                int_sub(a297, a298)?
                                                                                            };
                                                                                            fixed_u32::convert(i128::from(a299))
                                                                                        };
                                                                                        match m300 {
                                                                                            None => {
                                                                                                Ok(None::<u64>)
                                                                                            }
                                                                                            Some(v21) => {
                                                                                                let m304 = {
                                                                                                    let a303 = {
                                                                                                        let a301 = 53i64;
                                                                                                        let a302 = v20;
                                                                                                        int_sub(a301, a302)?
                                                                                                    };
                                                                                                    fixed_u32::convert(i128::from(a303))
                                                                                                };
                                                                                                match m304 {
                                                                                                    None => {
                                                                                                        Ok(None::<u64>)
                                                                                                    }
                                                                                                    Some(v22) => {
                                                                                                        let m307 = {
                                                                                                            let a305 = v11;
                                                                                                            let a306 = v21;
                                                                                                            fixed_u64::shift_left(a305, a306)
                                                                                                        };
                                                                                                        match m307 {
                                                                                                            None => {
                                                                                                                Ok(None::<u64>)
                                                                                                            }
                                                                                                            Some(v23) => {
                                                                                                                let m310 = {
                                                                                                                    let a308 = v12;
                                                                                                                    let a309 = v22;
                                                                                                                    fixed_u64::shift_left(a308, a309)
                                                                                                                };
                                                                                                                match m310 {
                                                                                                                    None => {
                                                                                                                        Ok(None::<u64>)
                                                                                                                    }
                                                                                                                    Some(v24) => {
                                                                                                                        let v25: bool = {
                                                                                                                            let m313 = {
                                                                                                                                let a311 = v23;
                                                                                                                                let a312 = v24;
                                                                                                                                compare(a311, a312)
                                                                                                                            };
                                                                                                                            match m313 {
                                                                                                                                Ordering::Less => {
                                                                                                                                    true
                                                                                                                                }
                                                                                                                                Ordering::Equal => {
                                                                                                                                    false
                                                                                                                                }
                                                                                                                                Ordering::Greater => {
                                                                                                                                    false
                                                                                                                                }
                                                                                                                            }
                                                                                                                        };
                                                                                                                        let v26: i64 = {
                                                                                                                            let a318 = {
                                                                                                                                let a314 = v14;
                                                                                                                                let a315 = v16;
                                                                                                                                int_sub(a314, a315)?
                                                                                                                            };
                                                                                                                            let a319 = {
                                                                                                                                let a316 = v20;
                                                                                                                                let a317 = v19;
                                                                                                                                int_sub(a316, a317)?
                                                                                                                            };
                                                                                                                            int_sub(a318, a319)?
                                                                                                                        };
                                                                                                                        let v27: i64 = if v25 {
                                                                                                                            let a320 = v26;
                                                                                                                            let a321 = 1i64;
                                                                                                                            int_sub(a320, a321)?
                                                                                                                        } else {
                                                                                                                            v26
                                                                                                                        };
                                                                                                                        let v28: i64 = {
                                                                                                                            let a322 = -1020i64;
                                                                                                                            let a323 = v27;
                                                                                                                            int_sub(a322, a323)?
                                                                                                                        };
                                                                                                                        let v29: i64 = {
                                                                                                                            let m326 = {
                                                                                                                                let a324 = 2i64;
                                                                                                                                let a325 = v28;
                                                                                                                                compare(a324, a325)
                                                                                                                            };
                                                                                                                            if match m326 {
                                                                                                                                Ordering::Less => {
                                                                                                                                    true
                                                                                                                                }
                                                                                                                                Ordering::Equal => {
                                                                                                                                    false
                                                                                                                                }
                                                                                                                                Ordering::Greater => {
                                                                                                                                    false
                                                                                                                                }
                                                                                                                            } {
                                                                                                                                v28
                                                                                                                            } else {
                                                                                                                                2i64
                                                                                                                            }
                                                                                                                        };
                                                                                                                        let m329 = if v25 {
                                                                                                                            let a327 = v23;
                                                                                                                            let a328 = 1u32;
                                                                                                                            fixed_u64::shift_left(a327, a328)
                                                                                                                        } else {
                                                                                                                            Some(v23)
                                                                                                                        };
                                                                                                                        match m329 {
                                                                                                                            None => {
                                                                                                                                Ok(None::<u64>)
                                                                                                                            }
                                                                                                                            Some(v30) => {
                                                                                                                                let m330 = f4(v30, v24);
                                                                                                                                match m330 {
                                                                                                                                    None => {
                                                                                                                                        Ok(None::<u64>)
                                                                                                                                    }
                                                                                                                                    Some(v31) => {
                                                                                                                                        let m331 = f2(v31);
                                                                                                                                        match m331 {
                                                                                                                                            None => {
                                                                                                                                                Ok(None::<u64>)
                                                                                                                                            }
                                                                                                                                            Some(v32) => {
                                                                                                                                                let m332 = f5(v32, v29)?;
                                                                                                                                                match m332 {
                                                                                                                                                    None => {
                                                                                                                                                        Ok(None::<u64>)
                                                                                                                                                    }
                                                                                                                                                    Some(v33) => {
                                                                                                                                                        let v34: bool = {
                                                                                                                                                            let a333 = v33;
                                                                                                                                                            let a334 = 9007199254740992u64;
                                                                                                                                                            equal(a333, a334)
                                                                                                                                                        };
                                                                                                                                                        let v35: i64 = if v34 {
                                                                                                                                                            let a335 = v27;
                                                                                                                                                            let a336 = -1i64;
                                                                                                                                                            int_sub(a335, a336)?
                                                                                                                                                        } else {
                                                                                                                                                            v27
                                                                                                                                                        };
                                                                                                                                                        let v36: i64 = {
                                                                                                                                                            let m339 = {
                                                                                                                                                                let a337 = v35;
                                                                                                                                                                let a338 = -1022i64;
                                                                                                                                                                compare(a337, a338)
                                                                                                                                                            };
                                                                                                                                                            if match m339 {
                                                                                                                                                                Ordering::Less => {
                                                                                                                                                                    true
                                                                                                                                                                }
                                                                                                                                                                Ordering::Equal => {
                                                                                                                                                                    false
                                                                                                                                                                }
                                                                                                                                                                Ordering::Greater => {
                                                                                                                                                                    false
                                                                                                                                                                }
                                                                                                                                                            } {
                                                                                                                                                                let m342 = {
                                                                                                                                                                    let a340 = v33;
                                                                                                                                                                    let a341 = 4503599627370496u64;
                                                                                                                                                                    compare(a340, a341)
                                                                                                                                                                };
                                                                                                                                                                if match m342 {
                                                                                                                                                                    Ordering::Less => {
                                                                                                                                                                        true
                                                                                                                                                                    }
                                                                                                                                                                    Ordering::Equal => {
                                                                                                                                                                        false
                                                                                                                                                                    }
                                                                                                                                                                    Ordering::Greater => {
                                                                                                                                                                        false
                                                                                                                                                                    }
                                                                                                                                                                } {
                                                                                                                                                                    0i64
                                                                                                                                                                } else {
                                                                                                                                                                    1i64
                                                                                                                                                                }
                                                                                                                                                            } else {
                                                                                                                                                                let a343 = v35;
                                                                                                                                                                let a344 = -1023i64;
                                                                                                                                                                int_sub(a343, a344)?
                                                                                                                                                            }
                                                                                                                                                        };
                                                                                                                                                        let m347 = {
                                                                                                                                                            let a345 = 2046i64;
                                                                                                                                                            let a346 = v36;
                                                                                                                                                            compare(a345, a346)
                                                                                                                                                        };
                                                                                                                                                        if match m347 {
                                                                                                                                                            Ordering::Less => {
                                                                                                                                                                true
                                                                                                                                                            }
                                                                                                                                                            Ordering::Equal => {
                                                                                                                                                                false
                                                                                                                                                            }
                                                                                                                                                            Ordering::Greater => {
                                                                                                                                                                false
                                                                                                                                                            }
                                                                                                                                                        } {
                                                                                                                                                            Ok(Some({
                                                                                                                                                                let a348 = v2;
                                                                                                                                                                let a349 = 9218868437227405312u64;
                                                                                                                                                                fixed_u64::bit_or(a348, a349)
                                                                                                                                                            }))
                                                                                                                                                        } else {
                                                                                                                                                            let m352 = if v34 {
                                                                                                                                                                let a350 = v33;
                                                                                                                                                                let a351 = 1u32;
                                                                                                                                                                fixed_u64::shift_right(a350, a351)
                                                                                                                                                            } else {
                                                                                                                                                                Some(v33)
                                                                                                                                                            };
                                                                                                                                                            match m352 {
                                                                                                                                                                None => {
                                                                                                                                                                    Ok(None::<u64>)
                                                                                                                                                                }
                                                                                                                                                                Some(v37) => {
                                                                                                                                                                    let m354 = {
                                                                                                                                                                        let a353 = v36;
                                                                                                                                                                        fixed_u64::convert(i128::from(a353))
                                                                                                                                                                    };
                                                                                                                                                                    match m354 {
                                                                                                                                                                        None => {
                                                                                                                                                                            Ok(None::<u64>)
                                                                                                                                                                        }
                                                                                                                                                                        Some(v38) => {
                                                                                                                                                                            let m357 = {
                                                                                                                                                                                let a355 = v38;
                                                                                                                                                                                let a356 = 52u32;
                                                                                                                                                                                fixed_u64::shift_left(a355, a356)
                                                                                                                                                                            };
                                                                                                                                                                            match m357 {
                                                                                                                                                                                None => {
                                                                                                                                                                                    Ok(None::<u64>)
                                                                                                                                                                                }
                                                                                                                                                                                Some(v39) => {
                                                                                                                                                                                    Ok(Some({
                                                                                                                                                                                        let a362 = v2;
                                                                                                                                                                                        let a363 = {
                                                                                                                                                                                            let a360 = v39;
                                                                                                                                                                                            let a361 = {
                                                                                                                                                                                                let a358 = v37;
                                                                                                                                                                                                let a359 = 4503599627370495u64;
                                                                                                                                                                                                fixed_u64::bit_and(a358, a359)
                                                                                                                                                                                            };
                                                                                                                                                                                            fixed_u64::bit_or(a360, a361)
                                                                                                                                                                                        };
                                                                                                                                                                                        fixed_u64::bit_or(a362, a363)
                                                                                                                                                                                    }))
                                                                                                                                                                                }
                                                                                                                                                                            }
                                                                                                                                                                        }
                                                                                                                                                                    }
                                                                                                                                                                }
                                                                                                                                                            }
                                                                                                                                                        }
                                                                                                                                                    }
                                                                                                                                                }
                                                                                                                                            }
                                                                                                                                        }
                                                                                                                                    }
                                                                                                                                }
                                                                                                                            }
                                                                                                                        }
                                                                                                                    }
                                                                                                                }
                                                                                                            }
                                                                                                        }
                                                                                                    }
                                                                                                }
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

pub fn f2(v0: u64) -> Option<Adt0> {
    let m367 = {
        let a366 = {
            let a364 = v0;
            let a365 = 4294967295u64;
            fixed_u64::bit_and(a364, a365)
        };
        fixed_u32::convert(i128::from(a366))
    };
    match m367 {
        None => {
            None::<Adt0>
        }
        Some(v1) => {
            let m370 = {
                let a368 = v0;
                let a369 = 32u32;
                fixed_u64::shift_right(a368, a369)
            };
            match m370 {
                None => {
                    None::<Adt0>
                }
                Some(v2) => {
                    let m372 = {
                        let a371 = v2;
                        fixed_u32::convert(i128::from(a371))
                    };
                    match m372 {
                        None => {
                            None::<Adt0>
                        }
                        Some(v3) => {
                            Some(Adt0::C0(v1, v3, 0u32, 0u32))
                        }
                    }
                }
            }
        }
    }
}

pub fn f3(v0: Adt0) -> R<Option<i64>> {
    let a374 = match v0.clone() {
        Adt0::C0(_, _, _, h373) => {
            h373
        }
    };
    let a375 = 0u32;
    if equal(a374, a375) {
        let a377 = match v0.clone() {
            Adt0::C0(_, _, h376, _) => {
                h376
            }
        };
        let a378 = 0u32;
        if equal(a377, a378) {
            let a380 = match v0.clone() {
                Adt0::C0(_, h379, _, _) => {
                    h379
                }
            };
            let a381 = 0u32;
            if equal(a380, a381) {
                f6(match v0 {
                    Adt0::C0(h382, _, _, _) => {
                        h382
                    }
                })
            } else {
                let m384 = f6(match v0 {
                    Adt0::C0(_, h383, _, _) => {
                        h383
                    }
                })?;
                match m384 {
                    None => {
                        Ok(None::<i64>)
                    }
                    Some(v1) => {
                        Ok(Some({
                            let a385 = v1;
                            let a386 = -32i64;
                            int_sub(a385, a386)?
                        }))
                    }
                }
            }
        } else {
            let m388 = f6(match v0 {
                Adt0::C0(_, _, h387, _) => {
                    h387
                }
            })?;
            match m388 {
                None => {
                    Ok(None::<i64>)
                }
                Some(v2) => {
                    Ok(Some({
                        let a389 = v2;
                        let a390 = -64i64;
                        int_sub(a389, a390)?
                    }))
                }
            }
        }
    } else {
        let m392 = f6(match v0 {
            Adt0::C0(_, _, _, h391) => {
                h391
            }
        })?;
        match m392 {
            None => {
                Ok(None::<i64>)
            }
            Some(v3) => {
                Ok(Some({
                    let a393 = v3;
                    let a394 = -96i64;
                    int_sub(a393, a394)?
                }))
            }
        }
    }
}

pub fn f4(v0: u64, v1: u64) -> Option<u64> {
    let m397 = {
        let a395 = v0;
        let a396 = v1;
        fixed_u64::checked_sub(a395, a396)
    };
    match m397 {
        None => {
            None::<u64>
        }
        Some(v2) => {
            let m398 = f7(Fn0::F8, 54u64, Some(Adt1::C0(1u64, v2, v1)));
            match m398 {
                None => {
                    None::<u64>
                }
                Some(v3) => {
                    Some({
                        let a403 = match v3.clone() {
                            Adt1::C0(h399, _, _) => {
                                h399
                            }
                        };
                        let a404 = {
                            let a401 = match v3 {
                                Adt1::C0(_, h400, _) => {
                                    h400
                                }
                            };
                            let a402 = 0u64;
                            if equal(a401, a402) {
                                0u64
                            } else {
                                1u64
                            }
                        };
                        fixed_u64::bit_or(a403, a404)
                    })
                }
            }
        }
    }
}

pub fn f5(v0: Adt0, v1: i64) -> R<Option<u64>> {
    let m407 = {
        let a405 = v1;
        let a406 = 0i64;
        compare(a405, a406)
    };
    if match m407 {
        Ordering::Less => {
            true
        }
        Ordering::Equal => {
            false
        }
        Ordering::Greater => {
            false
        }
    } {
        let m410 = {
            let a409 = {
                let a408 = v1;
                int_neg(a408)?
            };
            fixed_u32::convert(i128::from(a409))
        };
        match m410 {
            None => {
                Ok(None::<u64>)
            }
            Some(v2) => {
                let m411 = f9(v0);
                match m411 {
                    None => {
                        Ok(None::<u64>)
                    }
                    Some(v3) => {
                        let a412 = v3;
                        let a413 = v2;
                        Ok(fixed_u64::shift_left(a412, a413))
                    }
                }
            }
        }
    } else {
        let m416 = {
            let a414 = 128i64;
            let a415 = v1;
            compare(a414, a415)
        };
        if match m416 {
            Ordering::Less => {
                true
            }
            Ordering::Equal => {
                false
            }
            Ordering::Greater => {
                false
            }
        } {
            Ok(Some(0u64))
        } else {
            let m418 = {
                let a417 = v1;
                fixed_u8::convert(i128::from(a417))
            };
            match m418 {
                None => {
                    Ok(None::<u64>)
                }
                Some(v4) => {
                    let m465 = f10(Fn1::F11, {
                        let v5: u8 = v4;
                        let a463 = {
                            let a439 = {
                                let a427 = {
                                    let a421 = {
                                        let a419 = v5;
                                        let a420 = 128u8;
                                        fixed_u8::bit_and(a419, a420)
                                    };
                                    let a422 = 128u8;
                                    if equal(a421, a422) {
                                        128u64
                                    } else {
                                        0u64
                                    }
                                };
                                let a428 = {
                                    let a425 = {
                                        let a423 = v5;
                                        let a424 = 64u8;
                                        fixed_u8::bit_and(a423, a424)
                                    };
                                    let a426 = 64u8;
                                    if equal(a425, a426) {
                                        64u64
                                    } else {
                                        0u64
                                    }
                                };
                                nat_add(a427, a428)?
                            };
                            let a440 = {
                                let a437 = {
                                    let a431 = {
                                        let a429 = v5;
                                        let a430 = 32u8;
                                        fixed_u8::bit_and(a429, a430)
                                    };
                                    let a432 = 32u8;
                                    if equal(a431, a432) {
                                        32u64
                                    } else {
                                        0u64
                                    }
                                };
                                let a438 = {
                                    let a435 = {
                                        let a433 = v5;
                                        let a434 = 16u8;
                                        fixed_u8::bit_and(a433, a434)
                                    };
                                    let a436 = 16u8;
                                    if equal(a435, a436) {
                                        16u64
                                    } else {
                                        0u64
                                    }
                                };
                                nat_add(a437, a438)?
                            };
                            nat_add(a439, a440)?
                        };
                        let a464 = {
                            let a461 = {
                                let a449 = {
                                    let a443 = {
                                        let a441 = v5;
                                        let a442 = 8u8;
                                        fixed_u8::bit_and(a441, a442)
                                    };
                                    let a444 = 8u8;
                                    if equal(a443, a444) {
                                        8u64
                                    } else {
                                        0u64
                                    }
                                };
                                let a450 = {
                                    let a447 = {
                                        let a445 = v5;
                                        let a446 = 4u8;
                                        fixed_u8::bit_and(a445, a446)
                                    };
                                    let a448 = 4u8;
                                    if equal(a447, a448) {
                                        4u64
                                    } else {
                                        0u64
                                    }
                                };
                                nat_add(a449, a450)?
                            };
                            let a462 = {
                                let a459 = {
                                    let a453 = {
                                        let a451 = v5;
                                        let a452 = 2u8;
                                        fixed_u8::bit_and(a451, a452)
                                    };
                                    let a454 = 2u8;
                                    if equal(a453, a454) {
                                        2u64
                                    } else {
                                        0u64
                                    }
                                };
                                let a460 = {
                                    let a457 = {
                                        let a455 = v5;
                                        let a456 = 1u8;
                                        fixed_u8::bit_and(a455, a456)
                                    };
                                    let a458 = 1u8;
                                    if equal(a457, a458) {
                                        1u64
                                    } else {
                                        0u64
                                    }
                                };
                                nat_add(a459, a460)?
                            };
                            nat_add(a461, a462)?
                        };
                        nat_add(a463, a464)?
                    }, Some(Adt2::C0(v0, false, false)));
                    match m465 {
                        None => {
                            Ok(None::<u64>)
                        }
                        Some(v6) => {
                            let m467 = f9(match v6.clone() {
                                Adt2::C0(h466, _, _) => {
                                    h466
                                }
                            });
                            match m467 {
                                None => {
                                    Ok(None::<u64>)
                                }
                                Some(v7) => {
                                    if if match v6.clone() {
                                        Adt2::C0(_, h468, _) => {
                                            h468
                                        }
                                    } {
                                        if match v6 {
                                            Adt2::C0(_, _, h469) => {
                                                h469
                                            }
                                        } {
                                            true
                                        } else {
                                            let a472 = {
                                                let a470 = v7;
                                                let a471 = 1u64;
                                                fixed_u64::bit_and(a470, a471)
                                            };
                                            let a473 = 1u64;
                                            equal(a472, a473)
                                        }
                                    } else {
                                        false
                                    } {
                                        let a474 = v7;
                                        let a475 = 1u64;
                                        Ok(fixed_u64::checked_add(a474, a475))
                                    } else {
                                        Ok(Some(v7))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

pub fn f6(v0: u32) -> R<Option<i64>> {
    let m476 = f12(Fn2::F13, 32u64, Some((v0, 0i64)))?;
    match m476 {
        None => {
            Ok(None::<i64>)
        }
        Some(v1) => {
            Ok(Some({
                let (_, h477) = v1;
                h477
            }))
        }
    }
}

pub fn f7(v0: Fn0, p481: u64, p482: Option<Adt1>) -> Option<Adt1> {
    let m480 = (p481, p482);
    {
        let mut m480 = m480;
        loop {
            let step = {
                let (v1, v2) = m480;
                let m478 = v1;
                if m478 == 0 {
                    Err::<(u64, Option<Adt1>), Option<Adt1>>(v2)
                } else {
                    let v3 = m478 - 1;
                    Ok::<(u64, Option<Adt1>), Option<Adt1>>((v3, {
                        let c479: Fn0 = v0.clone();
                        c479.apply(v2)
                    }))
                }
            };
            match step {
                Ok(next) => { m480 = next; }
                Err(done) => break done,
            }
        }
    }
}

pub fn f8(v0: Option<Adt1>) -> Option<Adt1> {
    f14(v0)
}

pub fn f9(v0: Adt0) -> Option<u64> {
    let a484 = match v0.clone() {
        Adt0::C0(_, _, h483, _) => {
            h483
        }
    };
    let a485 = 0u32;
    if if equal(a484, a485) {
        let a487 = match v0.clone() {
            Adt0::C0(_, _, _, h486) => {
                h486
            }
        };
        let a488 = 0u32;
        equal(a487, a488)
    } else {
        false
    } {
        let m491 = {
            let a490 = match v0.clone() {
                Adt0::C0(h489, _, _, _) => {
                    h489
                }
            };
            fixed_u64::convert(i128::from(a490))
        };
        match m491 {
            None => {
                None::<u64>
            }
            Some(v1) => {
                let m494 = {
                    let a493 = match v0 {
                        Adt0::C0(_, h492, _, _) => {
                            h492
                        }
                    };
                    fixed_u64::convert(i128::from(a493))
                };
                match m494 {
                    None => {
                        None::<u64>
                    }
                    Some(v2) => {
                        let m497 = {
                            let a495 = v2;
                            let a496 = 32u32;
                            fixed_u64::shift_left(a495, a496)
                        };
                        match m497 {
                            None => {
                                None::<u64>
                            }
                            Some(v3) => {
                                Some({
                                    let a498 = v1;
                                    let a499 = v3;
                                    fixed_u64::bit_or(a498, a499)
                                })
                            }
                        }
                    }
                }
            }
        }
    } else {
        None::<u64>
    }
}

pub fn f10(v0: Fn1, p503: u64, p504: Option<Adt2>) -> Option<Adt2> {
    let m502 = (p503, p504);
    {
        let mut m502 = m502;
        loop {
            let step = {
                let (v1, v2) = m502;
                let m500 = v1;
                if m500 == 0 {
                    Err::<(u64, Option<Adt2>), Option<Adt2>>(v2)
                } else {
                    let v3 = m500 - 1;
                    Ok::<(u64, Option<Adt2>), Option<Adt2>>((v3, {
                        let c501: Fn1 = v0.clone();
                        c501.apply(v2)
                    }))
                }
            };
            match step {
                Ok(next) => { m502 = next; }
                Err(done) => break done,
            }
        }
    }
}

pub fn f11(v0: Option<Adt2>) -> Option<Adt2> {
    f15(v0)
}

pub fn f12(v0: Fn2, p508: u64, p509: Option<(u32, i64)>) -> R<Option<(u32, i64)>> {
    let m507 = (p508, p509);
    {
        let mut m507 = m507;
        loop {
            let step = {
                let (v1, v2) = m507;
                let m505 = v1;
                if m505 == 0 {
                    Err::<(u64, Option<(u32, i64)>), R<Option<(u32, i64)>>>(Ok(v2))
                } else {
                    let v3 = m505 - 1;
                    Ok::<(u64, Option<(u32, i64)>), R<Option<(u32, i64)>>>((v3, {
                        let c506: Fn2 = v0.clone();
                        c506.apply(v2)?
                    }))
                }
            };
            match step {
                Ok(next) => { m507 = next; }
                Err(done) => break done,
            }
        }
    }
}

pub fn f13(v0: Option<(u32, i64)>) -> R<Option<(u32, i64)>> {
    f16(v0)
}

pub fn f14(v0: Option<Adt1>) -> Option<Adt1> {
    let m510 = v0;
    match m510 {
        None => {
            None::<Adt1>
        }
        Some(v1) => {
            let m514 = {
                let a512 = match v1.clone() {
                    Adt1::C0(_, h511, _) => {
                        h511
                    }
                };
                let a513 = 2u64;
                fixed_u64::checked_mul(a512, a513)
            };
            match m514 {
                None => {
                    None::<Adt1>
                }
                Some(v2) => {
                    let m518 = {
                        let a516 = match v1.clone() {
                            Adt1::C0(h515, _, _) => {
                                h515
                            }
                        };
                        let a517 = 2u64;
                        fixed_u64::checked_mul(a516, a517)
                    };
                    match m518 {
                        None => {
                            None::<Adt1>
                        }
                        Some(v3) => {
                            let m522 = {
                                let a520 = v2;
                                let a521 = match v1.clone() {
                                    Adt1::C0(_, _, h519) => {
                                        h519
                                    }
                                };
                                fixed_u64::checked_sub(a520, a521)
                            };
                            match m522 {
                                None => {
                                    Some(Adt1::C0(v3, v2, match v1 {
                                        Adt1::C0(_, _, h527) => {
                                            h527
                                        }
                                    }))
                                }
                                Some(v4) => {
                                    let m525 = {
                                        let a523 = v3;
                                        let a524 = 1u64;
                                        fixed_u64::checked_add(a523, a524)
                                    };
                                    match m525 {
                                        None => {
                                            None::<Adt1>
                                        }
                                        Some(v5) => {
                                            Some(Adt1::C0(v5, v4, match v1 {
                                                Adt1::C0(_, _, h526) => {
                                                    h526
                                                }
                                            }))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

pub fn f15(v0: Option<Adt2>) -> Option<Adt2> {
    let m528 = v0;
    match m528 {
        None => {
            None::<Adt2>
        }
        Some(v1) => {
            let m530 = f17(match v1.clone() {
                Adt2::C0(h529, _, _) => {
                    h529
                }
            });
            match m530 {
                None => {
                    None::<Adt2>
                }
                Some(v2) => {
                    Some(Adt2::C0(v2, {
                        let a536 = {
                            let a534 = {
                                let m533 = match v1.clone() {
                                    Adt2::C0(h532, _, _) => {
                                        h532
                                    }
                                };
                                match m533 {
                                    Adt0::C0(h531, _, _, _) => {
                                        h531
                                    }
                                }
                            };
                            let a535 = 1u32;
                            fixed_u32::bit_and(a534, a535)
                        };
                        let a537 = 1u32;
                        equal(a536, a537)
                    }, if match v1.clone() {
                        Adt2::C0(_, _, h538) => {
                            h538
                        }
                    } {
                        true
                    } else {
                        match v1 {
                            Adt2::C0(_, h539, _) => {
                                h539
                            }
                        }
                    }))
                }
            }
        }
    }
}

pub fn f16(v0: Option<(u32, i64)>) -> R<Option<(u32, i64)>> {
    let m540 = v0;
    match m540 {
        None => {
            Ok(None::<(u32, i64)>)
        }
        Some(v1) => {
            let m544 = {
                let a542 = {
                    let (h541, _) = v1;
                    h541
                };
                let a543 = 1u32;
                fixed_u32::shift_right(a542, a543)
            };
            match m544 {
                None => {
                    Ok(None::<(u32, i64)>)
                }
                Some(v2) => {
                    Ok(Some((v2, {
                        let a546 = {
                            let (h545, _) = v1;
                            h545
                        };
                        let a547 = 0u32;
                        if equal(a546, a547) {
                            let (_, h548) = v1;
                            h548
                        } else {
                            let a550 = {
                                let (_, h549) = v1;
                                h549
                            };
                            let a551 = -1i64;
                            int_sub(a550, a551)?
                        }
                    })))
                }
            }
        }
    }
}

pub fn f17(v0: Adt0) -> Option<Adt0> {
    let m555 = {
        let a553 = match v0.clone() {
            Adt0::C0(h552, _, _, _) => {
                h552
            }
        };
        let a554 = 1u32;
        fixed_u32::shift_right(a553, a554)
    };
    match m555 {
        None => {
            None::<Adt0>
        }
        Some(v1) => {
            let m559 = {
                let a557 = match v0.clone() {
                    Adt0::C0(_, h556, _, _) => {
                        h556
                    }
                };
                let a558 = 1u32;
                fixed_u32::shift_right(a557, a558)
            };
            match m559 {
                None => {
                    None::<Adt0>
                }
                Some(v2) => {
                    let m563 = {
                        let a561 = match v0.clone() {
                            Adt0::C0(_, _, h560, _) => {
                                h560
                            }
                        };
                        let a562 = 1u32;
                        fixed_u32::shift_right(a561, a562)
                    };
                    match m563 {
                        None => {
                            None::<Adt0>
                        }
                        Some(v3) => {
                            let m567 = {
                                let a565 = match v0.clone() {
                                    Adt0::C0(_, _, _, h564) => {
                                        h564
                                    }
                                };
                                let a566 = 1u32;
                                fixed_u32::shift_right(a565, a566)
                            };
                            match m567 {
                                None => {
                                    None::<Adt0>
                                }
                                Some(v4) => {
                                    let m573 = {
                                        let a571 = {
                                            let a569 = match v0.clone() {
                                                Adt0::C0(_, h568, _, _) => {
                                                    h568
                                                }
                                            };
                                            let a570 = 1u32;
                                            fixed_u32::bit_and(a569, a570)
                                        };
                                        let a572 = 31u32;
                                        fixed_u32::shift_left(a571, a572)
                                    };
                                    match m573 {
                                        None => {
                                            None::<Adt0>
                                        }
                                        Some(v5) => {
                                            let m579 = {
                                                let a577 = {
                                                    let a575 = match v0.clone() {
                                                        Adt0::C0(_, _, h574, _) => {
                                                            h574
                                                        }
                                                    };
                                                    let a576 = 1u32;
                                                    fixed_u32::bit_and(a575, a576)
                                                };
                                                let a578 = 31u32;
                                                fixed_u32::shift_left(a577, a578)
                                            };
                                            match m579 {
                                                None => {
                                                    None::<Adt0>
                                                }
                                                Some(v6) => {
                                                    let m585 = {
                                                        let a583 = {
                                                            let a581 = match v0 {
                                                                Adt0::C0(_, _, _, h580) => {
                                                                    h580
                                                                }
                                                            };
                                                            let a582 = 1u32;
                                                            fixed_u32::bit_and(a581, a582)
                                                        };
                                                        let a584 = 31u32;
                                                        fixed_u32::shift_left(a583, a584)
                                                    };
                                                    match m585 {
                                                        None => {
                                                            None::<Adt0>
                                                        }
                                                        Some(v7) => {
                                                            Some(Adt0::C0({
                                                                let a586 = v1;
                                                                let a587 = v5;
                                                                fixed_u32::bit_or(a586, a587)
                                                            }, {
                                                                let a588 = v2;
                                                                let a589 = v6;
                                                                fixed_u32::bit_or(a588, a589)
                                                            }, {
                                                                let a590 = v3;
                                                                let a591 = v7;
                                                                fixed_u32::bit_or(a590, a591)
                                                            }, v4))
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

pub fn run(p0: u64, p1: u64) -> R<Option<u64>> {
    f0(p0, p1)
}

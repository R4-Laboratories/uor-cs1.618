#![forbid(unsafe_code)]
use core::cmp::Ordering;

use core::sync::atomic::{AtomicU64, Ordering as Memory};

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub struct Overflow;

pub type R<T> = Result<T, Overflow>;

static WORK: AtomicU64 = AtomicU64::new(0);

pub fn tick(units: u64) { WORK.fetch_add(units, Memory::Relaxed); }

pub fn work() -> u64 { WORK.load(Memory::Relaxed) }

pub trait Same {
    fn same(&self, other: &Self) -> bool;
}

pub trait Key {
    fn key(&self, other: &Self) -> Ordering;
}

impl Same for bool {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for bool {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u8 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u8 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u16 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u16 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u32 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u32 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u64 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u64 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i8 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i8 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i16 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i16 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i32 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i32 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i64 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i64 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for Ordering {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl<A: Key, B: Key> Key for (A, B) {
    fn key(&self, other: &Self) -> Ordering { match self.0.key(&other.0) { Ordering::Equal => self.1.key(&other.1), decided => decided, } }
}

pub fn equal<T: Same>(a: T, b: T) -> bool { a.same(&b) }

pub fn compare<T: Key>(a: T, b: T) -> Ordering { a.key(&b) }

pub fn nat_add(p0: u64, p1: u64) -> R<u64> {
    match u64::checked_add(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<u64, Overflow>(Overflow)
        }
    }
}

pub fn nat_sub(p0: u64, p1: u64) -> u64 {
    u64::saturating_sub(p0, p1)
}

pub fn nat_mul(p0: u64, p1: u64) -> R<u64> {
    match u64::checked_mul(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<u64, Overflow>(Overflow)
        }
    }
}

pub fn nat_quot(p0: u64, p1: u64, p2: u64) -> u64 {
    u64::checked_div(p0, p1).unwrap_or(p2)
}

pub fn nat_rem(p0: u64, p1: u64, p2: u64) -> u64 {
    u64::checked_rem(p0, p1).unwrap_or(p2)
}

pub fn nat_eq(p0: u64, p1: u64) -> bool {
    core::cmp::PartialEq::eq(&p0, &p1)
}

pub fn nat_le(p0: u64, p1: u64) -> bool {
    core::cmp::PartialOrd::le(&p0, &p1)
}

pub fn nat_lt(p0: u64, p1: u64) -> bool {
    core::cmp::PartialOrd::lt(&p0, &p1)
}

pub fn nat_succ(p0: u64) -> R<u64> {
    match u64::checked_add(p0, 1u64) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<u64, Overflow>(Overflow)
        }
    }
}

pub fn int_add(p0: i64, p1: i64) -> R<i64> {
    match i64::checked_add(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_sub(p0: i64, p1: i64) -> R<i64> {
    match i64::checked_sub(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_mul(p0: i64, p1: i64) -> R<i64> {
    match i64::checked_mul(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_neg(p0: i64) -> R<i64> {
    match i64::checked_neg(p0) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_quot(p0: i64, p1: i64, p2: i64) -> R<i64> {
    { let value = { let (a, b, z): (i64, i64, i64) = (p0, p1, p2); if b == 0 { Some(z) } else { a.checked_div(b) } }; match value {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    } }
}

pub fn int_rem(p0: i64, p1: i64, p2: i64) -> i64 {
    { let (a, b, z): (i64, i64, i64) = (p0, p1, p2); if b == 0 { z } else { a.wrapping_rem(b) } }
}

pub fn bool_not(p0: bool) -> bool {
    !p0
}

pub fn bool_and(p0: bool, p1: bool) -> bool {
    if p0 {
        p1
    } else {
        false
    }
}

pub fn bool_or(p0: bool, p1: bool) -> bool {
    if p0 {
        true
    } else {
        p1
    }
}

pub mod fixed_u8 {
    pub fn checked_add(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u8, p1: u8) -> u8 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u8, p1: u8) -> u8 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u8, p1: u8) -> u8 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u8) -> u8 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u8, p1: u32) -> Option<u8> {
        u8::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u8, p1: u32) -> Option<u8> {
        u8::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u8> {
        u8::try_from(p0).ok()
    }
}

pub mod fixed_u16 {
    pub fn checked_add(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u16, p1: u16) -> u16 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u16, p1: u16) -> u16 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u16, p1: u16) -> u16 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u16) -> u16 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u16, p1: u32) -> Option<u16> {
        u16::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u16, p1: u32) -> Option<u16> {
        u16::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u16> {
        u16::try_from(p0).ok()
    }
}

pub mod fixed_u32 {
    pub fn checked_add(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u32, p1: u32) -> u32 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u32, p1: u32) -> u32 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u32, p1: u32) -> u32 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u32) -> u32 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u32> {
        u32::try_from(p0).ok()
    }
}

pub mod fixed_u64 {
    pub fn checked_add(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u64, p1: u64) -> u64 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u64, p1: u64) -> u64 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u64, p1: u64) -> u64 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u64) -> u64 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u64, p1: u32) -> Option<u64> {
        u64::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u64, p1: u32) -> Option<u64> {
        u64::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u64> {
        u64::try_from(p0).ok()
    }
}

pub mod fixed_i8 {
    pub fn checked_add(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i8, p1: i8) -> i8 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i8, p1: i8) -> i8 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i8, p1: i8) -> i8 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i8) -> i8 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i8, p1: u32) -> Option<i8> {
        i8::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i8, p1: u32) -> Option<i8> {
        i8::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i8> {
        i8::try_from(p0).ok()
    }
}

pub fn checked_neg_i8(p0: i8) -> Option<i8> {
    i8::checked_neg(p0)
}

pub mod fixed_i16 {
    pub fn checked_add(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i16, p1: i16) -> i16 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i16, p1: i16) -> i16 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i16, p1: i16) -> i16 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i16) -> i16 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i16, p1: u32) -> Option<i16> {
        i16::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i16, p1: u32) -> Option<i16> {
        i16::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i16> {
        i16::try_from(p0).ok()
    }
}

pub fn checked_neg_i16(p0: i16) -> Option<i16> {
    i16::checked_neg(p0)
}

pub mod fixed_i32 {
    pub fn checked_add(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i32, p1: i32) -> i32 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i32, p1: i32) -> i32 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i32, p1: i32) -> i32 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i32) -> i32 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i32, p1: u32) -> Option<i32> {
        i32::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i32, p1: u32) -> Option<i32> {
        i32::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i32> {
        i32::try_from(p0).ok()
    }
}

pub fn checked_neg_i32(p0: i32) -> Option<i32> {
    i32::checked_neg(p0)
}

pub mod fixed_i64 {
    pub fn checked_add(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i64, p1: i64) -> i64 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i64, p1: i64) -> i64 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i64, p1: i64) -> i64 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i64) -> i64 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i64, p1: u32) -> Option<i64> {
        i64::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i64, p1: u32) -> Option<i64> {
        i64::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i64> {
        i64::try_from(p0).ok()
    }
}

pub fn checked_neg_i64(p0: i64) -> Option<i64> {
    i64::checked_neg(p0)
}
use core::str;

use std::mem;

use std::rc::Rc;

#[derive(Clone)]
pub struct Str(Rc<str>);

impl Str {
    pub fn lit(text: &str) -> Str { Str(Rc::from(text)) }
    pub fn text(&self) -> &str { &self.0 }
    pub fn length(&self) -> u64 { chars(&self.0) }
    pub fn utf8_encode(&self) -> Bytes { tick(self.0.len() as u64); Bytes::lit(self.0.as_bytes()) }
    pub fn split_exact(&self, delimiter: &Str, maximum: u32) -> Option<List<Str>> { if delimiter.0.is_empty() { return None; }; chars(&self.0); let mut fields: Vec<Str> = Vec::new(); for piece in self.0.split(&*delimiter.0) { fields.push(Str::lit(piece)); }; if fields.len() as u128 > u128::from(maximum) { return None; }; Some(List::onto(fields, List::nil())) }
    pub fn join(texts: List<Str>, delimiter: &Str) -> Str { let mut out = String::new(); let mut first = true; let mut cursor = &texts; while let Repr::Cell(cell) = &cursor.0 { tick(1); if !first { chars(&delimiter.0); out.push_str(&delimiter.0); }; first = false; chars(&cell.head.0); out.push_str(&cell.head.0); cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for text in buffer[..*len].iter().rev() { tick(1); if !first { chars(&delimiter.0); out.push_str(&delimiter.0); }; first = false; chars(&text.0); out.push_str(&text.0); } }, _ => { }, }; Str::lit(&out) }
}

#[derive(Clone)]
pub struct Bytes(Rc<[u8]>);

impl Bytes {
    pub fn lit(octets: &[u8]) -> Bytes { Bytes(Rc::from(octets)) }
    pub fn octets(&self) -> &[u8] { &self.0 }
    pub fn append(a: Bytes, b: Bytes) -> Bytes { tick((a.0.len() + b.0.len()) as u64); let mut out = Vec::with_capacity(a.0.len() + b.0.len()); out.extend_from_slice(&a.0); out.extend_from_slice(&b.0); Bytes(Rc::from(out)) }
    pub fn length(&self) -> u64 { self.0.len() as u64 }
    pub fn index(&self, i: u64) -> Option<u8> { match usize::try_from(i) { Ok(at) => self.0.get(at).copied(), Err(_) => None, } }
    pub fn slice(&self, start: u64, count: u64) -> Option<Bytes> { let end = u128::from(start) + u128::from(count); if end > self.0.len() as u128 { return None; }; tick(count); Some(Bytes::lit(&self.0[start as usize..end as usize])) }
    pub fn utf8_decode(&self) -> Option<Str> { tick(self.0.len() as u64); match str::from_utf8(&self.0) { Ok(text) => Some(Str::lit(text)), Err(_) => None, } }
    pub fn compare(&self, other: &Bytes) -> Ordering { tick(1 + self.0.len().min(other.0.len()) as u64); self.0.cmp(&other.0) }
}

pub struct Node<T> { head: T, tail: List<T> }

pub enum Repr<T> { Nil, Run { buffer: Rc<Vec<T>>, len: usize }, Cell(Rc<Node<T>>) }

pub struct List<T>(Repr<T>);

impl<T> Clone for List<T> {
    fn clone(&self) -> Self { List(match &self.0 { Repr::Nil => Repr::Nil, Repr::Run { buffer, len } => Repr::Run { buffer: buffer.clone(), len: *len }, Repr::Cell(cell) => Repr::Cell(cell.clone()), }) }
}

impl<T> List<T> {
    fn take(&mut self) -> Repr<T> { mem::replace(&mut self.0, Repr::Nil) }
}

impl<T> Drop for Node<T> {
    fn drop(&mut self) { let mut next = match self.tail.take() { Repr::Cell(cell) => Some(cell), _ => None, }; while let Some(cell) = next { match Rc::try_unwrap(cell) { Ok(mut node) => next = match node.tail.take() { Repr::Cell(cell) => Some(cell), _ => None, }, Err(_) => break, } } }
}

impl<T: Clone> List<T> {
    pub fn nil() -> Self { List(Repr::Nil) }
    pub fn cons(head: T, mut tail: List<T>) -> Self { List(match tail.take() { Repr::Nil => { let mut buffer = Vec::with_capacity(16); buffer.push(head); Repr::Run { buffer: Rc::new(buffer), len: 1 } }, Repr::Run { mut buffer, len } => { match Rc::get_mut(&mut buffer) { Some(cells) => { cells.truncate(len); cells.push(head); Repr::Run { buffer, len: len + 1 } }, None => Repr::Cell(Rc::new(Node { head, tail: List(Repr::Run { buffer, len }) })), } }, rest => Repr::Cell(Rc::new(Node { head, tail: List(rest) })), }) }
    pub fn uncons(&self) -> Option<(T, List<T>)> { match &self.0 { Repr::Nil => None, Repr::Run { buffer, len } => { let head = buffer[len - 1].clone(); Some((head, List(if *len == 1 { Repr::Nil } else { Repr::Run { buffer: buffer.clone(), len: len - 1 } }))) }, Repr::Cell(cell) => Some((cell.head.clone(), cell.tail.clone())), } }
    pub fn length(&self) -> u64 { let mut count = 0; let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); count += 1; cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for _ in buffer[..*len].iter().rev() { tick(1); count += 1; } }, _ => { }, }; count }
    pub fn append(a: List<T>, b: List<T>) -> List<T> { List::onto(a.items(), b) }
    pub fn index(&self, i: u64) -> Option<T> { let mut position = 0; let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); if position == i { return Some(cell.head.clone()); }; position += 1; cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for item in buffer[..*len].iter().rev() { tick(1); if position == i { return Some(item.clone()); }; position += 1; } }, _ => { }, }; None }
    pub fn slice(&self, start: u64, count: u64) -> Option<List<T>> { let end = u128::from(start) + u128::from(count); let mut part = Vec::new(); let mut position: u128 = 0; let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); if position >= end { return Some(List::onto(part, List::nil())); }; if position >= u128::from(start) { part.push(cell.head.clone()); }; position += 1; cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for item in buffer[..*len].iter().rev() { tick(1); if position >= end { return Some(List::onto(part, List::nil())); }; if position >= u128::from(start) { part.push(item.clone()); }; position += 1; } }, _ => { }, }; if position < end { None } else { Some(List::onto(part, List::nil())) } }
    fn items(&self) -> Vec<T> { let mut out = Vec::new(); let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); out.push(cell.head.clone()); cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for item in buffer[..*len].iter().rev() { tick(1); out.push(item.clone()); } }, _ => { }, }; out }
    fn onto(mut items: Vec<T>, tail: List<T>) -> List<T> { let mut out = tail; while let Some(item) = items.pop() { tick(1); out = List::cons(item, out); }; out }
}

pub fn chars(text: &str) -> u64 { let mut count = 0; for _ in text.chars() { tick(1); count += 1; }; count }

impl Same for Str {
    fn same(&self, other: &Self) -> bool { let mut left = self.0.chars(); let mut right = other.0.chars(); loop { tick(1); match (left.next(), right.next()) { (None, None) => return true, (a, b) if a != b => return false, _ => { }, } } }
}

impl Same for Bytes {
    fn same(&self, other: &Self) -> bool { tick(1 + self.0.len().min(other.0.len()) as u64); self.0 == other.0 }
}

impl Key for Str {
    fn key(&self, other: &Self) -> Ordering { let mut left = self.0.chars(); let mut right = other.0.chars(); loop { tick(1); match (left.next(), right.next()) { (None, None) => return Ordering::Equal, (None, Some(_)) => return Ordering::Less, (Some(_), None) => return Ordering::Greater, (Some(a), Some(b)) => match a.cmp(&b) { Ordering::Equal => { }, decided => return decided, }, } } }
}

pub fn canonical_decimal(text: &str) -> Option<Option<i128>> { let digits = match text.strip_prefix('-') { Some(rest) => rest, None => text, }; let mut canonical = !digits.is_empty() && (digits == "0" || !digits.starts_with('0')) && text != "-0"; for c in digits.chars() { tick(1); canonical = canonical && c.is_ascii_digit(); }; if !canonical { return None; }; Some(text.parse::<i128>().ok()) }

pub fn parse_int(text: Str) -> R<Option<i64>> { match canonical_decimal(&text.0) { None => Ok(None), Some(Some(n)) => match i64::try_from(n) { Ok(value) => Ok(Some(value)), Err(_) => Err(Overflow), }, Some(None) => Err(Overflow), } }

pub fn format_u8(a: u8) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u8(text: Str) -> Option<u8> { match canonical_decimal(&text.0) { Some(Some(n)) => u8::try_from(n).ok(), _ => None, } }

pub fn format_u16(a: u16) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u16(text: Str) -> Option<u16> { match canonical_decimal(&text.0) { Some(Some(n)) => u16::try_from(n).ok(), _ => None, } }

pub fn format_u32(a: u32) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u32(text: Str) -> Option<u32> { match canonical_decimal(&text.0) { Some(Some(n)) => u32::try_from(n).ok(), _ => None, } }

pub fn format_u64(a: u64) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u64(text: Str) -> Option<u64> { match canonical_decimal(&text.0) { Some(Some(n)) => u64::try_from(n).ok(), _ => None, } }

pub fn format_i8(a: i8) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i8(text: Str) -> Option<i8> { match canonical_decimal(&text.0) { Some(Some(n)) => i8::try_from(n).ok(), _ => None, } }

pub fn format_i16(a: i16) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i16(text: Str) -> Option<i16> { match canonical_decimal(&text.0) { Some(Some(n)) => i16::try_from(n).ok(), _ => None, } }

pub fn format_i32(a: i32) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i32(text: Str) -> Option<i32> { match canonical_decimal(&text.0) { Some(Some(n)) => i32::try_from(n).ok(), _ => None, } }

pub fn format_i64(a: i64) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i64(text: Str) -> Option<i64> { match canonical_decimal(&text.0) { Some(Some(n)) => i64::try_from(n).ok(), _ => None, } }

pub fn append_list<T: Clone>(p0: List<T>, p1: List<T>) -> List<T> {
    List::append(p0, p1)
}

pub fn length_list<T: Clone>(p0: List<T>) -> u64 {
    List::length(&p0)
}

pub fn index_list<T: Clone>(p0: List<T>, p1: u64) -> Option<T> {
    List::index(&p0, p1)
}

pub fn slice_list<T: Clone>(p0: List<T>, p1: u64, p2: u64) -> Option<List<T>> {
    List::slice(&p0, p1, p2)
}

pub fn append_bytes(p0: Bytes, p1: Bytes) -> Bytes {
    Bytes::append(p0, p1)
}

pub fn length_bytes(p0: Bytes) -> u64 {
    Bytes::length(&p0)
}

pub fn length_string(p0: Str) -> u64 {
    Str::length(&p0)
}

pub fn index_bytes(p0: Bytes, p1: u64) -> Option<u8> {
    Bytes::index(&p0, p1)
}

pub fn slice_bytes(p0: Bytes, p1: u64, p2: u64) -> Option<Bytes> {
    Bytes::slice(&p0, p1, p2)
}

pub fn utf8_encode(p0: Str) -> Bytes {
    Str::utf8_encode(&p0)
}

pub fn utf8_decode(p0: Bytes) -> Option<Str> {
    Bytes::utf8_decode(&p0)
}

pub fn compare_bytes(p0: Bytes, p1: Bytes) -> Ordering {
    Bytes::compare(&p0, &p1)
}

pub fn split_exact(p0: Str, p1: Str, p2: u32) -> Option<List<Str>> {
    Str::split_exact(&p0, &p1, p2)
}

pub fn join(p0: List<Str>, p1: Str) -> Str {
    Str::join(p0, &p1)
}

#[derive(Clone)]
pub enum Adt0 {
    C0(u32, u32, u32, u32),
}

#[derive(Clone)]
pub enum Adt1 {
    C0(u64, u64, u64),
}

#[derive(Clone)]
pub enum Adt2 {
    C0(Adt0, bool, bool),
}

#[derive(Clone)]
pub enum Fn0 {
    F8,
}

impl Fn0 {
    pub fn apply(&self, p0: Option<Adt1>) -> Option<Adt1> {
        match self {
            Fn0::F8 => f8(p0),
        }
    }
}

#[derive(Clone)]
pub enum Fn1 {
    F11,
}

impl Fn1 {
    pub fn apply(&self, p0: Option<Adt2>) -> Option<Adt2> {
        match self {
            Fn1::F11 => f11(p0),
        }
    }
}

#[derive(Clone)]
pub enum Fn2 {
    F13,
}

impl Fn2 {
    pub fn apply(&self, p0: Option<(u32, i64)>) -> R<Option<(u32, i64)>> {
        match self {
            Fn2::F13 => f13(p0),
        }
    }
}

pub fn f0(v0: u32, v1: u32) -> R<Option<u32>> {
    let m2 = {
        let a1 = v0;
        fixed_u64::convert(i128::from(a1))
    };
    match m2 {
        None => {
            Ok(None::<u32>)
        }
        Some(v2) => {
            let m4 = {
                let a3 = v1;
                fixed_u64::convert(i128::from(a3))
            };
            match m4 {
                None => {
                    Ok(None::<u32>)
                }
                Some(v3) => {
                    let m5 = f1(v2, v3)?;
                    match m5 {
                        None => {
                            Ok(None::<u32>)
                        }
                        Some(v4) => {
                            let a6 = v4;
                            Ok(fixed_u32::convert(i128::from(a6)))
                        }
                    }
                }
            }
        }
    }
}

pub fn f1(v0: u64, v1: u64) -> R<Option<u64>> {
    let v2: u64 = {
        let a9 = {
            let a7 = v0;
            let a8 = v1;
            fixed_u64::bit_xor(a7, a8)
        };
        let a10 = 2147483648u64;
        fixed_u64::bit_and(a9, a10)
    };
    let v3: u64 = {
        let a11 = v0;
        let a12 = 8388607u64;
        fixed_u64::bit_and(a11, a12)
    };
    let v4: u64 = {
        let a13 = v1;
        let a14 = 8388607u64;
        fixed_u64::bit_and(a13, a14)
    };
    let m17 = {
        let a15 = v0;
        let a16 = 23u32;
        fixed_u64::shift_right(a15, a16)
    };
    match m17 {
        None => {
            Ok(None::<u64>)
        }
        Some(v5) => {
            let m20 = {
                let a18 = v1;
                let a19 = 23u32;
                fixed_u64::shift_right(a18, a19)
            };
            match m20 {
                None => {
                    Ok(None::<u64>)
                }
                Some(v6) => {
                    let v7: u64 = {
                        let a21 = v5;
                        let a22 = 255u64;
                        fixed_u64::bit_and(a21, a22)
                    };
                    let v8: u64 = {
                        let a23 = v6;
                        let a24 = 255u64;
                        fixed_u64::bit_and(a23, a24)
                    };
                    let a25 = v7;
                    let a26 = 255u64;
                    if if equal(a25, a26) {
                        let a29 = {
                            let a27 = v3;
                            let a28 = 0u64;
                            equal(a27, a28)
                        };
                        bool_not(a29)
                    } else {
                        false
                    } {
                        Ok(Some({
                            let a30 = v0;
                            let a31 = 4194304u64;
                            fixed_u64::bit_or(a30, a31)
                        }))
                    } else {
                        let a32 = v8;
                        let a33 = 255u64;
                        if if equal(a32, a33) {
                            let a36 = {
                                let a34 = v4;
                                let a35 = 0u64;
                                equal(a34, a35)
                            };
                            bool_not(a36)
                        } else {
                            false
                        } {
                            Ok(Some({
                                let a37 = v1;
                                let a38 = 4194304u64;
                                fixed_u64::bit_or(a37, a38)
                            }))
                        } else {
                            let a41 = {
                                let a39 = v0;
                                let a40 = 2147483647u64;
                                fixed_u64::bit_and(a39, a40)
                            };
                            let a42 = 0u64;
                            if if if equal(a41, a42) {
                                let a45 = {
                                    let a43 = v1;
                                    let a44 = 2147483647u64;
                                    fixed_u64::bit_and(a43, a44)
                                };
                                let a46 = 0u64;
                                equal(a45, a46)
                            } else {
                                false
                            } {
                                true
                            } else {
                                let a47 = v7;
                                let a48 = 255u64;
                                if equal(a47, a48) {
                                    let a49 = v8;
                                    let a50 = 255u64;
                                    equal(a49, a50)
                                } else {
                                    false
                                }
                            } {
                                Ok(Some(2143289344u64))
                            } else {
                                let a51 = v7;
                                let a52 = 255u64;
                                if if equal(a51, a52) {
                                    true
                                } else {
                                    let a55 = {
                                        let a53 = v1;
                                        let a54 = 2147483647u64;
                                        fixed_u64::bit_and(a53, a54)
                                    };
                                    let a56 = 0u64;
                                    equal(a55, a56)
                                } {
                                    Ok(Some({
                                        let a57 = v2;
                                        let a58 = 2139095040u64;
                                        fixed_u64::bit_or(a57, a58)
                                    }))
                                } else {
                                    let a59 = v8;
                                    let a60 = 255u64;
                                    if if equal(a59, a60) {
                                        true
                                    } else {
                                        let a63 = {
                                            let a61 = v0;
                                            let a62 = 2147483647u64;
                                            fixed_u64::bit_and(a61, a62)
                                        };
                                        let a64 = 0u64;
                                        equal(a63, a64)
                                    } {
                                        Ok(Some(v2))
                                    } else {
                                        let m66 = {
                                            let a65 = v7;
                                            fixed_u8::convert(i128::from(a65))
                                        };
                                        match m66 {
                                            None => {
                                                Ok(None::<u64>)
                                            }
                                            Some(v9) => {
                                                let m68 = {
                                                    let a67 = v8;
                                                    fixed_u8::convert(i128::from(a67))
                                                };
                                                match m68 {
                                                    None => {
                                                        Ok(None::<u64>)
                                                    }
                                                    Some(v10) => {
                                                        let v11: u64 = {
                                                            let a69 = v7;
                                                            let a70 = 0u64;
                                                            if equal(a69, a70) {
                                                                v3
                                                            } else {
                                                                let a71 = v3;
                                                                let a72 = 8388608u64;
                                                                fixed_u64::bit_or(a71, a72)
                                                            }
                                                        };
                                                        let v12: u64 = {
                                                            let a73 = v8;
                                                            let a74 = 0u64;
                                                            if equal(a73, a74) {
                                                                v4
                                                            } else {
                                                                let a75 = v4;
                                                                let a76 = 8388608u64;
                                                                fixed_u64::bit_or(a75, a76)
                                                            }
                                                        };
                                                        let v14: i64 = {
                                                            let a77 = v7;
                                                            let a78 = 0u64;
                                                            if equal(a77, a78) {
                                                                1i64
                                                            } else {
                                                                let v13: u8 = v9;
                                                                let a130 = {
                                                                    let a102 = {
                                                                        let a88 = {
                                                                            let a81 = {
                                                                                let a79 = v13;
                                                                                let a80 = 128u8;
                                                                                fixed_u8::bit_and(a79, a80)
                                                                            };
                                                                            let a82 = 128u8;
                                                                            if equal(a81, a82) {
                                                                                128i64
                                                                            } else {
                                                                                0i64
                                                                            }
                                                                        };
                                                                        let a89 = {
                                                                            let a87 = {
                                                                                let a85 = {
                                                                                    let a83 = v13;
                                                                                    let a84 = 64u8;
                                                                                    fixed_u8::bit_and(a83, a84)
                                                                                };
                                                                                let a86 = 64u8;
                                                                                if equal(a85, a86) {
                                                                                    64i64
                                                                                } else {
                                                                                    0i64
                                                                                }
                                                                            };
                                                                            int_neg(a87)?
                                                                        };
                                                                        int_sub(a88, a89)?
                                                                    };
                                                                    let a103 = {
                                                                        let a101 = {
                                                                            let a99 = {
                                                                                let a92 = {
                                                                                    let a90 = v13;
                                                                                    let a91 = 32u8;
                                                                                    fixed_u8::bit_and(a90, a91)
                                                                                };
                                                                                let a93 = 32u8;
                                                                                if equal(a92, a93) {
                                                                                    32i64
                                                                                } else {
                                                                                    0i64
                                                                                }
                                                                            };
                                                                            let a100 = {
                                                                                let a98 = {
                                                                                    let a96 = {
                                                                                        let a94 = v13;
                                                                                        let a95 = 16u8;
                                                                                        fixed_u8::bit_and(a94, a95)
                                                                                    };
                                                                                    let a97 = 16u8;
                                                                                    if equal(a96, a97) {
                                                                                        16i64
                                                                                    } else {
                                                                                        0i64
                                                                                    }
                                                                                };
                                                                                int_neg(a98)?
                                                                            };
                                                                            int_sub(a99, a100)?
                                                                        };
                                                                        int_neg(a101)?
                                                                    };
                                                                    int_sub(a102, a103)?
                                                                };
                                                                let a131 = {
                                                                    let a129 = {
                                                                        let a127 = {
                                                                            let a113 = {
                                                                                let a106 = {
                                                                                    let a104 = v13;
                                                                                    let a105 = 8u8;
                                                                                    fixed_u8::bit_and(a104, a105)
                                                                                };
                                                                                let a107 = 8u8;
                                                                                if equal(a106, a107) {
                                                                                    8i64
                                                                                } else {
                                                                                    0i64
                                                                                }
                                                                            };
                                                                            let a114 = {
                                                                                let a112 = {
                                                                                    let a110 = {
                                                                                        let a108 = v13;
                                                                                        let a109 = 4u8;
                                                                                        fixed_u8::bit_and(a108, a109)
                                                                                    };
                                                                                    let a111 = 4u8;
                                                                                    if equal(a110, a111) {
                                                                                        4i64
                                                                                    } else {
                                                                                        0i64
                                                                                    }
                                                                                };
                                                                                int_neg(a112)?
                                                                            };
                                                                            int_sub(a113, a114)?
                                                                        };
                                                                        let a128 = {
                                                                            let a126 = {
                                                                                let a124 = {
                                                                                    let a117 = {
                                                                                        let a115 = v13;
                                                                                        let a116 = 2u8;
                                                                                        fixed_u8::bit_and(a115, a116)
                                                                                    };
                                                                                    let a118 = 2u8;
                                                                                    if equal(a117, a118) {
                                                                                        2i64
                                                                                    } else {
                                                                                        0i64
                                                                                    }
                                                                                };
                                                                                let a125 = {
                                                                                    let a123 = {
                                                                                        let a121 = {
                                                                                            let a119 = v13;
                                                                                            let a120 = 1u8;
                                                                                            fixed_u8::bit_and(a119, a120)
                                                                                        };
                                                                                        let a122 = 1u8;
                                                                                        if equal(a121, a122) {
                                                                                            1i64
                                                                                        } else {
                                                                                            0i64
                                                                                        }
                                                                                    };
                                                                                    int_neg(a123)?
                                                                                };
                                                                                int_sub(a124, a125)?
                                                                            };
                                                                            int_neg(a126)?
                                                                        };
                                                                        int_sub(a127, a128)?
                                                                    };
                                                                    int_neg(a129)?
                                                                };
                                                                int_sub(a130, a131)?
                                                            }
                                                        };
                                                        let v16: i64 = {
                                                            let a132 = v8;
                                                            let a133 = 0u64;
                                                            if equal(a132, a133) {
                                                                1i64
                                                            } else {
                                                                let v15: u8 = v10;
                                                                let a185 = {
                                                                    let a157 = {
                                                                        let a143 = {
                                                                            let a136 = {
                                                                                let a134 = v15;
                                                                                let a135 = 128u8;
                                                                                fixed_u8::bit_and(a134, a135)
                                                                            };
                                                                            let a137 = 128u8;
                                                                            if equal(a136, a137) {
                                                                                128i64
                                                                            } else {
                                                                                0i64
                                                                            }
                                                                        };
                                                                        let a144 = {
                                                                            let a142 = {
                                                                                let a140 = {
                                                                                    let a138 = v15;
                                                                                    let a139 = 64u8;
                                                                                    fixed_u8::bit_and(a138, a139)
                                                                                };
                                                                                let a141 = 64u8;
                                                                                if equal(a140, a141) {
                                                                                    64i64
                                                                                } else {
                                                                                    0i64
                                                                                }
                                                                            };
                                                                            int_neg(a142)?
                                                                        };
                                                                        int_sub(a143, a144)?
                                                                    };
                                                                    let a158 = {
                                                                        let a156 = {
                                                                            let a154 = {
                                                                                let a147 = {
                                                                                    let a145 = v15;
                                                                                    let a146 = 32u8;
                                                                                    fixed_u8::bit_and(a145, a146)
                                                                                };
                                                                                let a148 = 32u8;
                                                                                if equal(a147, a148) {
                                                                                    32i64
                                                                                } else {
                                                                                    0i64
                                                                                }
                                                                            };
                                                                            let a155 = {
                                                                                let a153 = {
                                                                                    let a151 = {
                                                                                        let a149 = v15;
                                                                                        let a150 = 16u8;
                                                                                        fixed_u8::bit_and(a149, a150)
                                                                                    };
                                                                                    let a152 = 16u8;
                                                                                    if equal(a151, a152) {
                                                                                        16i64
                                                                                    } else {
                                                                                        0i64
                                                                                    }
                                                                                };
                                                                                int_neg(a153)?
                                                                            };
                                                                            int_sub(a154, a155)?
                                                                        };
                                                                        int_neg(a156)?
                                                                    };
                                                                    int_sub(a157, a158)?
                                                                };
                                                                let a186 = {
                                                                    let a184 = {
                                                                        let a182 = {
                                                                            let a168 = {
                                                                                let a161 = {
                                                                                    let a159 = v15;
                                                                                    let a160 = 8u8;
                                                                                    fixed_u8::bit_and(a159, a160)
                                                                                };
                                                                                let a162 = 8u8;
                                                                                if equal(a161, a162) {
                                                                                    8i64
                                                                                } else {
                                                                                    0i64
                                                                                }
                                                                            };
                                                                            let a169 = {
                                                                                let a167 = {
                                                                                    let a165 = {
                                                                                        let a163 = v15;
                                                                                        let a164 = 4u8;
                                                                                        fixed_u8::bit_and(a163, a164)
                                                                                    };
                                                                                    let a166 = 4u8;
                                                                                    if equal(a165, a166) {
                                                                                        4i64
                                                                                    } else {
                                                                                        0i64
                                                                                    }
                                                                                };
                                                                                int_neg(a167)?
                                                                            };
                                                                            int_sub(a168, a169)?
                                                                        };
                                                                        let a183 = {
                                                                            let a181 = {
                                                                                let a179 = {
                                                                                    let a172 = {
                                                                                        let a170 = v15;
                                                                                        let a171 = 2u8;
                                                                                        fixed_u8::bit_and(a170, a171)
                                                                                    };
                                                                                    let a173 = 2u8;
                                                                                    if equal(a172, a173) {
                                                                                        2i64
                                                                                    } else {
                                                                                        0i64
                                                                                    }
                                                                                };
                                                                                let a180 = {
                                                                                    let a178 = {
                                                                                        let a176 = {
                                                                                            let a174 = v15;
                                                                                            let a175 = 1u8;
                                                                                            fixed_u8::bit_and(a174, a175)
                                                                                        };
                                                                                        let a177 = 1u8;
                                                                                        if equal(a176, a177) {
                                                                                            1i64
                                                                                        } else {
                                                                                            0i64
                                                                                        }
                                                                                    };
                                                                                    int_neg(a178)?
                                                                                };
                                                                                int_sub(a179, a180)?
                                                                            };
                                                                            int_neg(a181)?
                                                                        };
                                                                        int_sub(a182, a183)?
                                                                    };
                                                                    int_neg(a184)?
                                                                };
                                                                int_sub(a185, a186)?
                                                            }
                                                        };
                                                        let m187 = f2(v11);
                                                        match m187 {
                                                            None => {
                                                                Ok(None::<u64>)
                                                            }
                                                            Some(v17) => {
                                                                let m188 = f2(v12);
                                                                match m188 {
                                                                    None => {
                                                                        Ok(None::<u64>)
                                                                    }
                                                                    Some(v18) => {
                                                                        let m189 = f3(v17)?;
                                                                        match m189 {
                                                                            None => {
                                                                                Ok(None::<u64>)
                                                                            }
                                                                            Some(v19) => {
                                                                                let m190 = f3(v18)?;
                                                                                match m190 {
                                                                                    None => {
                                                                                        Ok(None::<u64>)
                                                                                    }
                                                                                    Some(v20) => {
                                                                                        let m194 = {
                                                                                            let a193 = {
                                                                                                let a191 = 24i64;
                                                                                                let a192 = v19;
                                                                                                int_sub(a191, a192)?
                                                                                            };
                                                                                            fixed_u32::convert(i128::from(a193))
                                                                                        };
                                                                                        match m194 {
                                                                                            None => {
                                                                                                Ok(None::<u64>)
                                                                                            }
                                                                                            Some(v21) => {
                                                                                                let m198 = {
                                                                                                    let a197 = {
                                                                                                        let a195 = 24i64;
                                                                                                        let a196 = v20;
                                                                                                        int_sub(a195, a196)?
                                                                                                    };
                                                                                                    fixed_u32::convert(i128::from(a197))
                                                                                                };
                                                                                                match m198 {
                                                                                                    None => {
                                                                                                        Ok(None::<u64>)
                                                                                                    }
                                                                                                    Some(v22) => {
                                                                                                        let m201 = {
                                                                                                            let a199 = v11;
                                                                                                            let a200 = v21;
                                                                                                            fixed_u64::shift_left(a199, a200)
                                                                                                        };
                                                                                                        match m201 {
                                                                                                            None => {
                                                                                                                Ok(None::<u64>)
                                                                                                            }
                                                                                                            Some(v23) => {
                                                                                                                let m204 = {
                                                                                                                    let a202 = v12;
                                                                                                                    let a203 = v22;
                                                                                                                    fixed_u64::shift_left(a202, a203)
                                                                                                                };
                                                                                                                match m204 {
                                                                                                                    None => {
                                                                                                                        Ok(None::<u64>)
                                                                                                                    }
                                                                                                                    Some(v24) => {
                                                                                                                        let v25: bool = {
                                                                                                                            let m207 = {
                                                                                                                                let a205 = v23;
                                                                                                                                let a206 = v24;
                                                                                                                                compare(a205, a206)
                                                                                                                            };
                                                                                                                            match m207 {
                                                                                                                                Ordering::Less => {
                                                                                                                                    true
                                                                                                                                }
                                                                                                                                Ordering::Equal => {
                                                                                                                                    false
                                                                                                                                }
                                                                                                                                Ordering::Greater => {
                                                                                                                                    false
                                                                                                                                }
                                                                                                                            }
                                                                                                                        };
                                                                                                                        let v26: i64 = {
                                                                                                                            let a212 = {
                                                                                                                                let a208 = v14;
                                                                                                                                let a209 = v16;
                                                                                                                                int_sub(a208, a209)?
                                                                                                                            };
                                                                                                                            let a213 = {
                                                                                                                                let a210 = v20;
                                                                                                                                let a211 = v19;
                                                                                                                                int_sub(a210, a211)?
                                                                                                                            };
                                                                                                                            int_sub(a212, a213)?
                                                                                                                        };
                                                                                                                        let v27: i64 = if v25 {
                                                                                                                            let a214 = v26;
                                                                                                                            let a215 = 1i64;
                                                                                                                            int_sub(a214, a215)?
                                                                                                                        } else {
                                                                                                                            v26
                                                                                                                        };
                                                                                                                        let v28: i64 = {
                                                                                                                            let a216 = -124i64;
                                                                                                                            let a217 = v27;
                                                                                                                            int_sub(a216, a217)?
                                                                                                                        };
                                                                                                                        let v29: i64 = {
                                                                                                                            let m220 = {
                                                                                                                                let a218 = 2i64;
                                                                                                                                let a219 = v28;
                                                                                                                                compare(a218, a219)
                                                                                                                            };
                                                                                                                            if match m220 {
                                                                                                                                Ordering::Less => {
                                                                                                                                    true
                                                                                                                                }
                                                                                                                                Ordering::Equal => {
                                                                                                                                    false
                                                                                                                                }
                                                                                                                                Ordering::Greater => {
                                                                                                                                    false
                                                                                                                                }
                                                                                                                            } {
                                                                                                                                v28
                                                                                                                            } else {
                                                                                                                                2i64
                                                                                                                            }
                                                                                                                        };
                                                                                                                        let m223 = if v25 {
                                                                                                                            let a221 = v23;
                                                                                                                            let a222 = 1u32;
                                                                                                                            fixed_u64::shift_left(a221, a222)
                                                                                                                        } else {
                                                                                                                            Some(v23)
                                                                                                                        };
                                                                                                                        match m223 {
                                                                                                                            None => {
                                                                                                                                Ok(None::<u64>)
                                                                                                                            }
                                                                                                                            Some(v30) => {
                                                                                                                                let m224 = f4(v30, v24);
                                                                                                                                match m224 {
                                                                                                                                    None => {
                                                                                                                                        Ok(None::<u64>)
                                                                                                                                    }
                                                                                                                                    Some(v31) => {
                                                                                                                                        let m225 = f2(v31);
                                                                                                                                        match m225 {
                                                                                                                                            None => {
                                                                                                                                                Ok(None::<u64>)
                                                                                                                                            }
                                                                                                                                            Some(v32) => {
                                                                                                                                                let m226 = f5(v32, v29)?;
                                                                                                                                                match m226 {
                                                                                                                                                    None => {
                                                                                                                                                        Ok(None::<u64>)
                                                                                                                                                    }
                                                                                                                                                    Some(v33) => {
                                                                                                                                                        let v34: bool = {
                                                                                                                                                            let a227 = v33;
                                                                                                                                                            let a228 = 16777216u64;
                                                                                                                                                            equal(a227, a228)
                                                                                                                                                        };
                                                                                                                                                        let v35: i64 = if v34 {
                                                                                                                                                            let a229 = v27;
                                                                                                                                                            let a230 = -1i64;
                                                                                                                                                            int_sub(a229, a230)?
                                                                                                                                                        } else {
                                                                                                                                                            v27
                                                                                                                                                        };
                                                                                                                                                        let v36: i64 = {
                                                                                                                                                            let m233 = {
                                                                                                                                                                let a231 = v35;
                                                                                                                                                                let a232 = -126i64;
                                                                                                                                                                compare(a231, a232)
                                                                                                                                                            };
                                                                                                                                                            if match m233 {
                                                                                                                                                                Ordering::Less => {
                                                                                                                                                                    true
                                                                                                                                                                }
                                                                                                                                                                Ordering::Equal => {
                                                                                                                                                                    false
                                                                                                                                                                }
                                                                                                                                                                Ordering::Greater => {
                                                                                                                                                                    false
                                                                                                                                                                }
                                                                                                                                                            } {
                                                                                                                                                                let m236 = {
                                                                                                                                                                    let a234 = v33;
                                                                                                                                                                    let a235 = 8388608u64;
                                                                                                                                                                    compare(a234, a235)
                                                                                                                                                                };
                                                                                                                                                                if match m236 {
                                                                                                                                                                    Ordering::Less => {
                                                                                                                                                                        true
                                                                                                                                                                    }
                                                                                                                                                                    Ordering::Equal => {
                                                                                                                                                                        false
                                                                                                                                                                    }
                                                                                                                                                                    Ordering::Greater => {
                                                                                                                                                                        false
                                                                                                                                                                    }
                                                                                                                                                                } {
                                                                                                                                                                    0i64
                                                                                                                                                                } else {
                                                                                                                                                                    1i64
                                                                                                                                                                }
                                                                                                                                                            } else {
                                                                                                                                                                let a237 = v35;
                                                                                                                                                                let a238 = -127i64;
                                                                                                                                                                int_sub(a237, a238)?
                                                                                                                                                            }
                                                                                                                                                        };
                                                                                                                                                        let m241 = {
                                                                                                                                                            let a239 = 254i64;
                                                                                                                                                            let a240 = v36;
                                                                                                                                                            compare(a239, a240)
                                                                                                                                                        };
                                                                                                                                                        if match m241 {
                                                                                                                                                            Ordering::Less => {
                                                                                                                                                                true
                                                                                                                                                            }
                                                                                                                                                            Ordering::Equal => {
                                                                                                                                                                false
                                                                                                                                                            }
                                                                                                                                                            Ordering::Greater => {
                                                                                                                                                                false
                                                                                                                                                            }
                                                                                                                                                        } {
                                                                                                                                                            Ok(Some({
                                                                                                                                                                let a242 = v2;
                                                                                                                                                                let a243 = 2139095040u64;
                                                                                                                                                                fixed_u64::bit_or(a242, a243)
                                                                                                                                                            }))
                                                                                                                                                        } else {
                                                                                                                                                            let m246 = if v34 {
                                                                                                                                                                let a244 = v33;
                                                                                                                                                                let a245 = 1u32;
                                                                                                                                                                fixed_u64::shift_right(a244, a245)
                                                                                                                                                            } else {
                                                                                                                                                                Some(v33)
                                                                                                                                                            };
                                                                                                                                                            match m246 {
                                                                                                                                                                None => {
                                                                                                                                                                    Ok(None::<u64>)
                                                                                                                                                                }
                                                                                                                                                                Some(v37) => {
                                                                                                                                                                    let m248 = {
                                                                                                                                                                        let a247 = v36;
                                                                                                                                                                        fixed_u64::convert(i128::from(a247))
                                                                                                                                                                    };
                                                                                                                                                                    match m248 {
                                                                                                                                                                        None => {
                                                                                                                                                                            Ok(None::<u64>)
                                                                                                                                                                        }
                                                                                                                                                                        Some(v38) => {
                                                                                                                                                                            let m251 = {
                                                                                                                                                                                let a249 = v38;
                                                                                                                                                                                let a250 = 23u32;
                                                                                                                                                                                fixed_u64::shift_left(a249, a250)
                                                                                                                                                                            };
                                                                                                                                                                            match m251 {
                                                                                                                                                                                None => {
                                                                                                                                                                                    Ok(None::<u64>)
                                                                                                                                                                                }
                                                                                                                                                                                Some(v39) => {
                                                                                                                                                                                    Ok(Some({
                                                                                                                                                                                        let a256 = v2;
                                                                                                                                                                                        let a257 = {
                                                                                                                                                                                            let a254 = v39;
                                                                                                                                                                                            let a255 = {
                                                                                                                                                                                                let a252 = v37;
                                                                                                                                                                                                let a253 = 8388607u64;
                                                                                                                                                                                                fixed_u64::bit_and(a252, a253)
                                                                                                                                                                                            };
                                                                                                                                                                                            fixed_u64::bit_or(a254, a255)
                                                                                                                                                                                        };
                                                                                                                                                                                        fixed_u64::bit_or(a256, a257)
                                                                                                                                                                                    }))
                                                                                                                                                                                }
                                                                                                                                                                            }
                                                                                                                                                                        }
                                                                                                                                                                    }
                                                                                                                                                                }
                                                                                                                                                            }
                                                                                                                                                        }
                                                                                                                                                    }
                                                                                                                                                }
                                                                                                                                            }
                                                                                                                                        }
                                                                                                                                    }
                                                                                                                                }
                                                                                                                            }
                                                                                                                        }
                                                                                                                    }
                                                                                                                }
                                                                                                            }
                                                                                                        }
                                                                                                    }
                                                                                                }
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

pub fn f2(v0: u64) -> Option<Adt0> {
    let m261 = {
        let a260 = {
            let a258 = v0;
            let a259 = 4294967295u64;
            fixed_u64::bit_and(a258, a259)
        };
        fixed_u32::convert(i128::from(a260))
    };
    match m261 {
        None => {
            None::<Adt0>
        }
        Some(v1) => {
            let m264 = {
                let a262 = v0;
                let a263 = 32u32;
                fixed_u64::shift_right(a262, a263)
            };
            match m264 {
                None => {
                    None::<Adt0>
                }
                Some(v2) => {
                    let m266 = {
                        let a265 = v2;
                        fixed_u32::convert(i128::from(a265))
                    };
                    match m266 {
                        None => {
                            None::<Adt0>
                        }
                        Some(v3) => {
                            Some(Adt0::C0(v1, v3, 0u32, 0u32))
                        }
                    }
                }
            }
        }
    }
}

pub fn f3(v0: Adt0) -> R<Option<i64>> {
    let a268 = match v0.clone() {
        Adt0::C0(_, _, _, h267) => {
            h267
        }
    };
    let a269 = 0u32;
    if equal(a268, a269) {
        let a271 = match v0.clone() {
            Adt0::C0(_, _, h270, _) => {
                h270
            }
        };
        let a272 = 0u32;
        if equal(a271, a272) {
            let a274 = match v0.clone() {
                Adt0::C0(_, h273, _, _) => {
                    h273
                }
            };
            let a275 = 0u32;
            if equal(a274, a275) {
                f6(match v0 {
                    Adt0::C0(h276, _, _, _) => {
                        h276
                    }
                })
            } else {
                let m278 = f6(match v0 {
                    Adt0::C0(_, h277, _, _) => {
                        h277
                    }
                })?;
                match m278 {
                    None => {
                        Ok(None::<i64>)
                    }
                    Some(v1) => {
                        Ok(Some({
                            let a279 = v1;
                            let a280 = -32i64;
                            int_sub(a279, a280)?
                        }))
                    }
                }
            }
        } else {
            let m282 = f6(match v0 {
                Adt0::C0(_, _, h281, _) => {
                    h281
                }
            })?;
            match m282 {
                None => {
                    Ok(None::<i64>)
                }
                Some(v2) => {
                    Ok(Some({
                        let a283 = v2;
                        let a284 = -64i64;
                        int_sub(a283, a284)?
                    }))
                }
            }
        }
    } else {
        let m286 = f6(match v0 {
            Adt0::C0(_, _, _, h285) => {
                h285
            }
        })?;
        match m286 {
            None => {
                Ok(None::<i64>)
            }
            Some(v3) => {
                Ok(Some({
                    let a287 = v3;
                    let a288 = -96i64;
                    int_sub(a287, a288)?
                }))
            }
        }
    }
}

pub fn f4(v0: u64, v1: u64) -> Option<u64> {
    let m291 = {
        let a289 = v0;
        let a290 = v1;
        fixed_u64::checked_sub(a289, a290)
    };
    match m291 {
        None => {
            None::<u64>
        }
        Some(v2) => {
            let m292 = f7(Fn0::F8, 25u64, Some(Adt1::C0(1u64, v2, v1)));
            match m292 {
                None => {
                    None::<u64>
                }
                Some(v3) => {
                    Some({
                        let a297 = match v3.clone() {
                            Adt1::C0(h293, _, _) => {
                                h293
                            }
                        };
                        let a298 = {
                            let a295 = match v3 {
                                Adt1::C0(_, h294, _) => {
                                    h294
                                }
                            };
                            let a296 = 0u64;
                            if equal(a295, a296) {
                                0u64
                            } else {
                                1u64
                            }
                        };
                        fixed_u64::bit_or(a297, a298)
                    })
                }
            }
        }
    }
}

pub fn f5(v0: Adt0, v1: i64) -> R<Option<u64>> {
    let m301 = {
        let a299 = v1;
        let a300 = 0i64;
        compare(a299, a300)
    };
    if match m301 {
        Ordering::Less => {
            true
        }
        Ordering::Equal => {
            false
        }
        Ordering::Greater => {
            false
        }
    } {
        let m304 = {
            let a303 = {
                let a302 = v1;
                int_neg(a302)?
            };
            fixed_u32::convert(i128::from(a303))
        };
        match m304 {
            None => {
                Ok(None::<u64>)
            }
            Some(v2) => {
                let m305 = f9(v0);
                match m305 {
                    None => {
                        Ok(None::<u64>)
                    }
                    Some(v3) => {
                        let a306 = v3;
                        let a307 = v2;
                        Ok(fixed_u64::shift_left(a306, a307))
                    }
                }
            }
        }
    } else {
        let m310 = {
            let a308 = 128i64;
            let a309 = v1;
            compare(a308, a309)
        };
        if match m310 {
            Ordering::Less => {
                true
            }
            Ordering::Equal => {
                false
            }
            Ordering::Greater => {
                false
            }
        } {
            Ok(Some(0u64))
        } else {
            let m312 = {
                let a311 = v1;
                fixed_u8::convert(i128::from(a311))
            };
            match m312 {
                None => {
                    Ok(None::<u64>)
                }
                Some(v4) => {
                    let m359 = f10(Fn1::F11, {
                        let v5: u8 = v4;
                        let a357 = {
                            let a333 = {
                                let a321 = {
                                    let a315 = {
                                        let a313 = v5;
                                        let a314 = 128u8;
                                        fixed_u8::bit_and(a313, a314)
                                    };
                                    let a316 = 128u8;
                                    if equal(a315, a316) {
                                        128u64
                                    } else {
                                        0u64
                                    }
                                };
                                let a322 = {
                                    let a319 = {
                                        let a317 = v5;
                                        let a318 = 64u8;
                                        fixed_u8::bit_and(a317, a318)
                                    };
                                    let a320 = 64u8;
                                    if equal(a319, a320) {
                                        64u64
                                    } else {
                                        0u64
                                    }
                                };
                                nat_add(a321, a322)?
                            };
                            let a334 = {
                                let a331 = {
                                    let a325 = {
                                        let a323 = v5;
                                        let a324 = 32u8;
                                        fixed_u8::bit_and(a323, a324)
                                    };
                                    let a326 = 32u8;
                                    if equal(a325, a326) {
                                        32u64
                                    } else {
                                        0u64
                                    }
                                };
                                let a332 = {
                                    let a329 = {
                                        let a327 = v5;
                                        let a328 = 16u8;
                                        fixed_u8::bit_and(a327, a328)
                                    };
                                    let a330 = 16u8;
                                    if equal(a329, a330) {
                                        16u64
                                    } else {
                                        0u64
                                    }
                                };
                                nat_add(a331, a332)?
                            };
                            nat_add(a333, a334)?
                        };
                        let a358 = {
                            let a355 = {
                                let a343 = {
                                    let a337 = {
                                        let a335 = v5;
                                        let a336 = 8u8;
                                        fixed_u8::bit_and(a335, a336)
                                    };
                                    let a338 = 8u8;
                                    if equal(a337, a338) {
                                        8u64
                                    } else {
                                        0u64
                                    }
                                };
                                let a344 = {
                                    let a341 = {
                                        let a339 = v5;
                                        let a340 = 4u8;
                                        fixed_u8::bit_and(a339, a340)
                                    };
                                    let a342 = 4u8;
                                    if equal(a341, a342) {
                                        4u64
                                    } else {
                                        0u64
                                    }
                                };
                                nat_add(a343, a344)?
                            };
                            let a356 = {
                                let a353 = {
                                    let a347 = {
                                        let a345 = v5;
                                        let a346 = 2u8;
                                        fixed_u8::bit_and(a345, a346)
                                    };
                                    let a348 = 2u8;
                                    if equal(a347, a348) {
                                        2u64
                                    } else {
                                        0u64
                                    }
                                };
                                let a354 = {
                                    let a351 = {
                                        let a349 = v5;
                                        let a350 = 1u8;
                                        fixed_u8::bit_and(a349, a350)
                                    };
                                    let a352 = 1u8;
                                    if equal(a351, a352) {
                                        1u64
                                    } else {
                                        0u64
                                    }
                                };
                                nat_add(a353, a354)?
                            };
                            nat_add(a355, a356)?
                        };
                        nat_add(a357, a358)?
                    }, Some(Adt2::C0(v0, false, false)));
                    match m359 {
                        None => {
                            Ok(None::<u64>)
                        }
                        Some(v6) => {
                            let m361 = f9(match v6.clone() {
                                Adt2::C0(h360, _, _) => {
                                    h360
                                }
                            });
                            match m361 {
                                None => {
                                    Ok(None::<u64>)
                                }
                                Some(v7) => {
                                    if if match v6.clone() {
                                        Adt2::C0(_, h362, _) => {
                                            h362
                                        }
                                    } {
                                        if match v6 {
                                            Adt2::C0(_, _, h363) => {
                                                h363
                                            }
                                        } {
                                            true
                                        } else {
                                            let a366 = {
                                                let a364 = v7;
                                                let a365 = 1u64;
                                                fixed_u64::bit_and(a364, a365)
                                            };
                                            let a367 = 1u64;
                                            equal(a366, a367)
                                        }
                                    } else {
                                        false
                                    } {
                                        let a368 = v7;
                                        let a369 = 1u64;
                                        Ok(fixed_u64::checked_add(a368, a369))
                                    } else {
                                        Ok(Some(v7))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

pub fn f6(v0: u32) -> R<Option<i64>> {
    let m370 = f12(Fn2::F13, 32u64, Some((v0, 0i64)))?;
    match m370 {
        None => {
            Ok(None::<i64>)
        }
        Some(v1) => {
            Ok(Some({
                let (_, h371) = v1;
                h371
            }))
        }
    }
}

pub fn f7(v0: Fn0, p375: u64, p376: Option<Adt1>) -> Option<Adt1> {
    let m374 = (p375, p376);
    {
        let mut m374 = m374;
        loop {
            let step = {
                let (v1, v2) = m374;
                let m372 = v1;
                if m372 == 0 {
                    Err::<(u64, Option<Adt1>), Option<Adt1>>(v2)
                } else {
                    let v3 = m372 - 1;
                    Ok::<(u64, Option<Adt1>), Option<Adt1>>((v3, {
                        let c373: Fn0 = v0.clone();
                        c373.apply(v2)
                    }))
                }
            };
            match step {
                Ok(next) => { m374 = next; }
                Err(done) => break done,
            }
        }
    }
}

pub fn f8(v0: Option<Adt1>) -> Option<Adt1> {
    f14(v0)
}

pub fn f9(v0: Adt0) -> Option<u64> {
    let a378 = match v0.clone() {
        Adt0::C0(_, _, h377, _) => {
            h377
        }
    };
    let a379 = 0u32;
    if if equal(a378, a379) {
        let a381 = match v0.clone() {
            Adt0::C0(_, _, _, h380) => {
                h380
            }
        };
        let a382 = 0u32;
        equal(a381, a382)
    } else {
        false
    } {
        let m385 = {
            let a384 = match v0.clone() {
                Adt0::C0(h383, _, _, _) => {
                    h383
                }
            };
            fixed_u64::convert(i128::from(a384))
        };
        match m385 {
            None => {
                None::<u64>
            }
            Some(v1) => {
                let m388 = {
                    let a387 = match v0 {
                        Adt0::C0(_, h386, _, _) => {
                            h386
                        }
                    };
                    fixed_u64::convert(i128::from(a387))
                };
                match m388 {
                    None => {
                        None::<u64>
                    }
                    Some(v2) => {
                        let m391 = {
                            let a389 = v2;
                            let a390 = 32u32;
                            fixed_u64::shift_left(a389, a390)
                        };
                        match m391 {
                            None => {
                                None::<u64>
                            }
                            Some(v3) => {
                                Some({
                                    let a392 = v1;
                                    let a393 = v3;
                                    fixed_u64::bit_or(a392, a393)
                                })
                            }
                        }
                    }
                }
            }
        }
    } else {
        None::<u64>
    }
}

pub fn f10(v0: Fn1, p397: u64, p398: Option<Adt2>) -> Option<Adt2> {
    let m396 = (p397, p398);
    {
        let mut m396 = m396;
        loop {
            let step = {
                let (v1, v2) = m396;
                let m394 = v1;
                if m394 == 0 {
                    Err::<(u64, Option<Adt2>), Option<Adt2>>(v2)
                } else {
                    let v3 = m394 - 1;
                    Ok::<(u64, Option<Adt2>), Option<Adt2>>((v3, {
                        let c395: Fn1 = v0.clone();
                        c395.apply(v2)
                    }))
                }
            };
            match step {
                Ok(next) => { m396 = next; }
                Err(done) => break done,
            }
        }
    }
}

pub fn f11(v0: Option<Adt2>) -> Option<Adt2> {
    f15(v0)
}

pub fn f12(v0: Fn2, p402: u64, p403: Option<(u32, i64)>) -> R<Option<(u32, i64)>> {
    let m401 = (p402, p403);
    {
        let mut m401 = m401;
        loop {
            let step = {
                let (v1, v2) = m401;
                let m399 = v1;
                if m399 == 0 {
                    Err::<(u64, Option<(u32, i64)>), R<Option<(u32, i64)>>>(Ok(v2))
                } else {
                    let v3 = m399 - 1;
                    Ok::<(u64, Option<(u32, i64)>), R<Option<(u32, i64)>>>((v3, {
                        let c400: Fn2 = v0.clone();
                        c400.apply(v2)?
                    }))
                }
            };
            match step {
                Ok(next) => { m401 = next; }
                Err(done) => break done,
            }
        }
    }
}

pub fn f13(v0: Option<(u32, i64)>) -> R<Option<(u32, i64)>> {
    f16(v0)
}

pub fn f14(v0: Option<Adt1>) -> Option<Adt1> {
    let m404 = v0;
    match m404 {
        None => {
            None::<Adt1>
        }
        Some(v1) => {
            let m408 = {
                let a406 = match v1.clone() {
                    Adt1::C0(_, h405, _) => {
                        h405
                    }
                };
                let a407 = 2u64;
                fixed_u64::checked_mul(a406, a407)
            };
            match m408 {
                None => {
                    None::<Adt1>
                }
                Some(v2) => {
                    let m412 = {
                        let a410 = match v1.clone() {
                            Adt1::C0(h409, _, _) => {
                                h409
                            }
                        };
                        let a411 = 2u64;
                        fixed_u64::checked_mul(a410, a411)
                    };
                    match m412 {
                        None => {
                            None::<Adt1>
                        }
                        Some(v3) => {
                            let m416 = {
                                let a414 = v2;
                                let a415 = match v1.clone() {
                                    Adt1::C0(_, _, h413) => {
                                        h413
                                    }
                                };
                                fixed_u64::checked_sub(a414, a415)
                            };
                            match m416 {
                                None => {
                                    Some(Adt1::C0(v3, v2, match v1 {
                                        Adt1::C0(_, _, h421) => {
                                            h421
                                        }
                                    }))
                                }
                                Some(v4) => {
                                    let m419 = {
                                        let a417 = v3;
                                        let a418 = 1u64;
                                        fixed_u64::checked_add(a417, a418)
                                    };
                                    match m419 {
                                        None => {
                                            None::<Adt1>
                                        }
                                        Some(v5) => {
                                            Some(Adt1::C0(v5, v4, match v1 {
                                                Adt1::C0(_, _, h420) => {
                                                    h420
                                                }
                                            }))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

pub fn f15(v0: Option<Adt2>) -> Option<Adt2> {
    let m422 = v0;
    match m422 {
        None => {
            None::<Adt2>
        }
        Some(v1) => {
            let m424 = f17(match v1.clone() {
                Adt2::C0(h423, _, _) => {
                    h423
                }
            });
            match m424 {
                None => {
                    None::<Adt2>
                }
                Some(v2) => {
                    Some(Adt2::C0(v2, {
                        let a430 = {
                            let a428 = {
                                let m427 = match v1.clone() {
                                    Adt2::C0(h426, _, _) => {
                                        h426
                                    }
                                };
                                match m427 {
                                    Adt0::C0(h425, _, _, _) => {
                                        h425
                                    }
                                }
                            };
                            let a429 = 1u32;
                            fixed_u32::bit_and(a428, a429)
                        };
                        let a431 = 1u32;
                        equal(a430, a431)
                    }, if match v1.clone() {
                        Adt2::C0(_, _, h432) => {
                            h432
                        }
                    } {
                        true
                    } else {
                        match v1 {
                            Adt2::C0(_, h433, _) => {
                                h433
                            }
                        }
                    }))
                }
            }
        }
    }
}

pub fn f16(v0: Option<(u32, i64)>) -> R<Option<(u32, i64)>> {
    let m434 = v0;
    match m434 {
        None => {
            Ok(None::<(u32, i64)>)
        }
        Some(v1) => {
            let m438 = {
                let a436 = {
                    let (h435, _) = v1;
                    h435
                };
                let a437 = 1u32;
                fixed_u32::shift_right(a436, a437)
            };
            match m438 {
                None => {
                    Ok(None::<(u32, i64)>)
                }
                Some(v2) => {
                    Ok(Some((v2, {
                        let a440 = {
                            let (h439, _) = v1;
                            h439
                        };
                        let a441 = 0u32;
                        if equal(a440, a441) {
                            let (_, h442) = v1;
                            h442
                        } else {
                            let a444 = {
                                let (_, h443) = v1;
                                h443
                            };
                            let a445 = -1i64;
                            int_sub(a444, a445)?
                        }
                    })))
                }
            }
        }
    }
}

pub fn f17(v0: Adt0) -> Option<Adt0> {
    let m449 = {
        let a447 = match v0.clone() {
            Adt0::C0(h446, _, _, _) => {
                h446
            }
        };
        let a448 = 1u32;
        fixed_u32::shift_right(a447, a448)
    };
    match m449 {
        None => {
            None::<Adt0>
        }
        Some(v1) => {
            let m453 = {
                let a451 = match v0.clone() {
                    Adt0::C0(_, h450, _, _) => {
                        h450
                    }
                };
                let a452 = 1u32;
                fixed_u32::shift_right(a451, a452)
            };
            match m453 {
                None => {
                    None::<Adt0>
                }
                Some(v2) => {
                    let m457 = {
                        let a455 = match v0.clone() {
                            Adt0::C0(_, _, h454, _) => {
                                h454
                            }
                        };
                        let a456 = 1u32;
                        fixed_u32::shift_right(a455, a456)
                    };
                    match m457 {
                        None => {
                            None::<Adt0>
                        }
                        Some(v3) => {
                            let m461 = {
                                let a459 = match v0.clone() {
                                    Adt0::C0(_, _, _, h458) => {
                                        h458
                                    }
                                };
                                let a460 = 1u32;
                                fixed_u32::shift_right(a459, a460)
                            };
                            match m461 {
                                None => {
                                    None::<Adt0>
                                }
                                Some(v4) => {
                                    let m467 = {
                                        let a465 = {
                                            let a463 = match v0.clone() {
                                                Adt0::C0(_, h462, _, _) => {
                                                    h462
                                                }
                                            };
                                            let a464 = 1u32;
                                            fixed_u32::bit_and(a463, a464)
                                        };
                                        let a466 = 31u32;
                                        fixed_u32::shift_left(a465, a466)
                                    };
                                    match m467 {
                                        None => {
                                            None::<Adt0>
                                        }
                                        Some(v5) => {
                                            let m473 = {
                                                let a471 = {
                                                    let a469 = match v0.clone() {
                                                        Adt0::C0(_, _, h468, _) => {
                                                            h468
                                                        }
                                                    };
                                                    let a470 = 1u32;
                                                    fixed_u32::bit_and(a469, a470)
                                                };
                                                let a472 = 31u32;
                                                fixed_u32::shift_left(a471, a472)
                                            };
                                            match m473 {
                                                None => {
                                                    None::<Adt0>
                                                }
                                                Some(v6) => {
                                                    let m479 = {
                                                        let a477 = {
                                                            let a475 = match v0 {
                                                                Adt0::C0(_, _, _, h474) => {
                                                                    h474
                                                                }
                                                            };
                                                            let a476 = 1u32;
                                                            fixed_u32::bit_and(a475, a476)
                                                        };
                                                        let a478 = 31u32;
                                                        fixed_u32::shift_left(a477, a478)
                                                    };
                                                    match m479 {
                                                        None => {
                                                            None::<Adt0>
                                                        }
                                                        Some(v7) => {
                                                            Some(Adt0::C0({
                                                                let a480 = v1;
                                                                let a481 = v5;
                                                                fixed_u32::bit_or(a480, a481)
                                                            }, {
                                                                let a482 = v2;
                                                                let a483 = v6;
                                                                fixed_u32::bit_or(a482, a483)
                                                            }, {
                                                                let a484 = v3;
                                                                let a485 = v7;
                                                                fixed_u32::bit_or(a484, a485)
                                                            }, v4))
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

pub fn run(p0: u32, p1: u32) -> R<Option<u32>> {
    f0(p0, p1)
}

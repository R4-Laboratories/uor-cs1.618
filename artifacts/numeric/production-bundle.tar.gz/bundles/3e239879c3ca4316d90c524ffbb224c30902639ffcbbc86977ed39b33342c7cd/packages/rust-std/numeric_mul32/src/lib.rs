#![forbid(unsafe_code)]
use core::cmp::Ordering;

use core::sync::atomic::{AtomicU64, Ordering as Memory};

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub struct Overflow;

pub type R<T> = Result<T, Overflow>;

static WORK: AtomicU64 = AtomicU64::new(0);

pub fn tick(units: u64) { WORK.fetch_add(units, Memory::Relaxed); }

pub fn work() -> u64 { WORK.load(Memory::Relaxed) }

pub trait Same {
    fn same(&self, other: &Self) -> bool;
}

pub trait Key {
    fn key(&self, other: &Self) -> Ordering;
}

impl Same for bool {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for bool {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u8 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u8 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u16 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u16 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u32 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u32 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u64 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u64 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i8 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i8 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i16 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i16 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i32 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i32 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i64 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i64 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for Ordering {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl<A: Key, B: Key> Key for (A, B) {
    fn key(&self, other: &Self) -> Ordering { match self.0.key(&other.0) { Ordering::Equal => self.1.key(&other.1), decided => decided, } }
}

pub fn equal<T: Same>(a: T, b: T) -> bool { a.same(&b) }

pub fn compare<T: Key>(a: T, b: T) -> Ordering { a.key(&b) }

pub fn nat_add(p0: u64, p1: u64) -> R<u64> {
    match u64::checked_add(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<u64, Overflow>(Overflow)
        }
    }
}

pub fn nat_sub(p0: u64, p1: u64) -> u64 {
    u64::saturating_sub(p0, p1)
}

pub fn nat_mul(p0: u64, p1: u64) -> R<u64> {
    match u64::checked_mul(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<u64, Overflow>(Overflow)
        }
    }
}

pub fn nat_quot(p0: u64, p1: u64, p2: u64) -> u64 {
    u64::checked_div(p0, p1).unwrap_or(p2)
}

pub fn nat_rem(p0: u64, p1: u64, p2: u64) -> u64 {
    u64::checked_rem(p0, p1).unwrap_or(p2)
}

pub fn nat_eq(p0: u64, p1: u64) -> bool {
    core::cmp::PartialEq::eq(&p0, &p1)
}

pub fn nat_le(p0: u64, p1: u64) -> bool {
    core::cmp::PartialOrd::le(&p0, &p1)
}

pub fn nat_lt(p0: u64, p1: u64) -> bool {
    core::cmp::PartialOrd::lt(&p0, &p1)
}

pub fn nat_succ(p0: u64) -> R<u64> {
    match u64::checked_add(p0, 1u64) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<u64, Overflow>(Overflow)
        }
    }
}

pub fn int_add(p0: i64, p1: i64) -> R<i64> {
    match i64::checked_add(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_sub(p0: i64, p1: i64) -> R<i64> {
    match i64::checked_sub(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_mul(p0: i64, p1: i64) -> R<i64> {
    match i64::checked_mul(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_neg(p0: i64) -> R<i64> {
    match i64::checked_neg(p0) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_quot(p0: i64, p1: i64, p2: i64) -> R<i64> {
    { let value = { let (a, b, z): (i64, i64, i64) = (p0, p1, p2); if b == 0 { Some(z) } else { a.checked_div(b) } }; match value {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    } }
}

pub fn int_rem(p0: i64, p1: i64, p2: i64) -> i64 {
    { let (a, b, z): (i64, i64, i64) = (p0, p1, p2); if b == 0 { z } else { a.wrapping_rem(b) } }
}

pub fn bool_not(p0: bool) -> bool {
    !p0
}

pub fn bool_and(p0: bool, p1: bool) -> bool {
    if p0 {
        p1
    } else {
        false
    }
}

pub fn bool_or(p0: bool, p1: bool) -> bool {
    if p0 {
        true
    } else {
        p1
    }
}

pub mod fixed_u8 {
    pub fn checked_add(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u8, p1: u8) -> u8 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u8, p1: u8) -> u8 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u8, p1: u8) -> u8 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u8) -> u8 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u8, p1: u32) -> Option<u8> {
        u8::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u8, p1: u32) -> Option<u8> {
        u8::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u8> {
        u8::try_from(p0).ok()
    }
}

pub mod fixed_u16 {
    pub fn checked_add(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u16, p1: u16) -> u16 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u16, p1: u16) -> u16 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u16, p1: u16) -> u16 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u16) -> u16 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u16, p1: u32) -> Option<u16> {
        u16::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u16, p1: u32) -> Option<u16> {
        u16::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u16> {
        u16::try_from(p0).ok()
    }
}

pub mod fixed_u32 {
    pub fn checked_add(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u32, p1: u32) -> u32 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u32, p1: u32) -> u32 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u32, p1: u32) -> u32 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u32) -> u32 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u32> {
        u32::try_from(p0).ok()
    }
}

pub mod fixed_u64 {
    pub fn checked_add(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u64, p1: u64) -> u64 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u64, p1: u64) -> u64 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u64, p1: u64) -> u64 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u64) -> u64 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u64, p1: u32) -> Option<u64> {
        u64::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u64, p1: u32) -> Option<u64> {
        u64::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u64> {
        u64::try_from(p0).ok()
    }
}

pub mod fixed_i8 {
    pub fn checked_add(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i8, p1: i8) -> i8 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i8, p1: i8) -> i8 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i8, p1: i8) -> i8 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i8) -> i8 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i8, p1: u32) -> Option<i8> {
        i8::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i8, p1: u32) -> Option<i8> {
        i8::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i8> {
        i8::try_from(p0).ok()
    }
}

pub fn checked_neg_i8(p0: i8) -> Option<i8> {
    i8::checked_neg(p0)
}

pub mod fixed_i16 {
    pub fn checked_add(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i16, p1: i16) -> i16 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i16, p1: i16) -> i16 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i16, p1: i16) -> i16 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i16) -> i16 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i16, p1: u32) -> Option<i16> {
        i16::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i16, p1: u32) -> Option<i16> {
        i16::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i16> {
        i16::try_from(p0).ok()
    }
}

pub fn checked_neg_i16(p0: i16) -> Option<i16> {
    i16::checked_neg(p0)
}

pub mod fixed_i32 {
    pub fn checked_add(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i32, p1: i32) -> i32 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i32, p1: i32) -> i32 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i32, p1: i32) -> i32 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i32) -> i32 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i32, p1: u32) -> Option<i32> {
        i32::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i32, p1: u32) -> Option<i32> {
        i32::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i32> {
        i32::try_from(p0).ok()
    }
}

pub fn checked_neg_i32(p0: i32) -> Option<i32> {
    i32::checked_neg(p0)
}

pub mod fixed_i64 {
    pub fn checked_add(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i64, p1: i64) -> i64 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i64, p1: i64) -> i64 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i64, p1: i64) -> i64 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i64) -> i64 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i64, p1: u32) -> Option<i64> {
        i64::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i64, p1: u32) -> Option<i64> {
        i64::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i64> {
        i64::try_from(p0).ok()
    }
}

pub fn checked_neg_i64(p0: i64) -> Option<i64> {
    i64::checked_neg(p0)
}
use core::str;

use std::mem;

use std::rc::Rc;

#[derive(Clone)]
pub struct Str(Rc<str>);

impl Str {
    pub fn lit(text: &str) -> Str { Str(Rc::from(text)) }
    pub fn text(&self) -> &str { &self.0 }
    pub fn length(&self) -> u64 { chars(&self.0) }
    pub fn utf8_encode(&self) -> Bytes { tick(self.0.len() as u64); Bytes::lit(self.0.as_bytes()) }
    pub fn split_exact(&self, delimiter: &Str, maximum: u32) -> Option<List<Str>> { if delimiter.0.is_empty() { return None; }; chars(&self.0); let mut fields: Vec<Str> = Vec::new(); for piece in self.0.split(&*delimiter.0) { fields.push(Str::lit(piece)); }; if fields.len() as u128 > u128::from(maximum) { return None; }; Some(List::onto(fields, List::nil())) }
    pub fn join(texts: List<Str>, delimiter: &Str) -> Str { let mut out = String::new(); let mut first = true; let mut cursor = &texts; while let Repr::Cell(cell) = &cursor.0 { tick(1); if !first { chars(&delimiter.0); out.push_str(&delimiter.0); }; first = false; chars(&cell.head.0); out.push_str(&cell.head.0); cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for text in buffer[..*len].iter().rev() { tick(1); if !first { chars(&delimiter.0); out.push_str(&delimiter.0); }; first = false; chars(&text.0); out.push_str(&text.0); } }, _ => { }, }; Str::lit(&out) }
}

#[derive(Clone)]
pub struct Bytes(Rc<[u8]>);

impl Bytes {
    pub fn lit(octets: &[u8]) -> Bytes { Bytes(Rc::from(octets)) }
    pub fn octets(&self) -> &[u8] { &self.0 }
    pub fn append(a: Bytes, b: Bytes) -> Bytes { tick((a.0.len() + b.0.len()) as u64); let mut out = Vec::with_capacity(a.0.len() + b.0.len()); out.extend_from_slice(&a.0); out.extend_from_slice(&b.0); Bytes(Rc::from(out)) }
    pub fn length(&self) -> u64 { self.0.len() as u64 }
    pub fn index(&self, i: u64) -> Option<u8> { match usize::try_from(i) { Ok(at) => self.0.get(at).copied(), Err(_) => None, } }
    pub fn slice(&self, start: u64, count: u64) -> Option<Bytes> { let end = u128::from(start) + u128::from(count); if end > self.0.len() as u128 { return None; }; tick(count); Some(Bytes::lit(&self.0[start as usize..end as usize])) }
    pub fn utf8_decode(&self) -> Option<Str> { tick(self.0.len() as u64); match str::from_utf8(&self.0) { Ok(text) => Some(Str::lit(text)), Err(_) => None, } }
    pub fn compare(&self, other: &Bytes) -> Ordering { tick(1 + self.0.len().min(other.0.len()) as u64); self.0.cmp(&other.0) }
}

pub struct Node<T> { head: T, tail: List<T> }

pub enum Repr<T> { Nil, Run { buffer: Rc<Vec<T>>, len: usize }, Cell(Rc<Node<T>>) }

pub struct List<T>(Repr<T>);

impl<T> Clone for List<T> {
    fn clone(&self) -> Self { List(match &self.0 { Repr::Nil => Repr::Nil, Repr::Run { buffer, len } => Repr::Run { buffer: buffer.clone(), len: *len }, Repr::Cell(cell) => Repr::Cell(cell.clone()), }) }
}

impl<T> List<T> {
    fn take(&mut self) -> Repr<T> { mem::replace(&mut self.0, Repr::Nil) }
}

impl<T> Drop for Node<T> {
    fn drop(&mut self) { let mut next = match self.tail.take() { Repr::Cell(cell) => Some(cell), _ => None, }; while let Some(cell) = next { match Rc::try_unwrap(cell) { Ok(mut node) => next = match node.tail.take() { Repr::Cell(cell) => Some(cell), _ => None, }, Err(_) => break, } } }
}

impl<T: Clone> List<T> {
    pub fn nil() -> Self { List(Repr::Nil) }
    pub fn cons(head: T, mut tail: List<T>) -> Self { List(match tail.take() { Repr::Nil => { let mut buffer = Vec::with_capacity(16); buffer.push(head); Repr::Run { buffer: Rc::new(buffer), len: 1 } }, Repr::Run { mut buffer, len } => { match Rc::get_mut(&mut buffer) { Some(cells) => { cells.truncate(len); cells.push(head); Repr::Run { buffer, len: len + 1 } }, None => Repr::Cell(Rc::new(Node { head, tail: List(Repr::Run { buffer, len }) })), } }, rest => Repr::Cell(Rc::new(Node { head, tail: List(rest) })), }) }
    pub fn uncons(&self) -> Option<(T, List<T>)> { match &self.0 { Repr::Nil => None, Repr::Run { buffer, len } => { let head = buffer[len - 1].clone(); Some((head, List(if *len == 1 { Repr::Nil } else { Repr::Run { buffer: buffer.clone(), len: len - 1 } }))) }, Repr::Cell(cell) => Some((cell.head.clone(), cell.tail.clone())), } }
    pub fn length(&self) -> u64 { let mut count = 0; let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); count += 1; cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for _ in buffer[..*len].iter().rev() { tick(1); count += 1; } }, _ => { }, }; count }
    pub fn append(a: List<T>, b: List<T>) -> List<T> { List::onto(a.items(), b) }
    pub fn index(&self, i: u64) -> Option<T> { let mut position = 0; let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); if position == i { return Some(cell.head.clone()); }; position += 1; cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for item in buffer[..*len].iter().rev() { tick(1); if position == i { return Some(item.clone()); }; position += 1; } }, _ => { }, }; None }
    pub fn slice(&self, start: u64, count: u64) -> Option<List<T>> { let end = u128::from(start) + u128::from(count); let mut part = Vec::new(); let mut position: u128 = 0; let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); if position >= end { return Some(List::onto(part, List::nil())); }; if position >= u128::from(start) { part.push(cell.head.clone()); }; position += 1; cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for item in buffer[..*len].iter().rev() { tick(1); if position >= end { return Some(List::onto(part, List::nil())); }; if position >= u128::from(start) { part.push(item.clone()); }; position += 1; } }, _ => { }, }; if position < end { None } else { Some(List::onto(part, List::nil())) } }
    fn items(&self) -> Vec<T> { let mut out = Vec::new(); let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); out.push(cell.head.clone()); cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for item in buffer[..*len].iter().rev() { tick(1); out.push(item.clone()); } }, _ => { }, }; out }
    fn onto(mut items: Vec<T>, tail: List<T>) -> List<T> { let mut out = tail; while let Some(item) = items.pop() { tick(1); out = List::cons(item, out); }; out }
}

pub fn chars(text: &str) -> u64 { let mut count = 0; for _ in text.chars() { tick(1); count += 1; }; count }

impl Same for Str {
    fn same(&self, other: &Self) -> bool { let mut left = self.0.chars(); let mut right = other.0.chars(); loop { tick(1); match (left.next(), right.next()) { (None, None) => return true, (a, b) if a != b => return false, _ => { }, } } }
}

impl Same for Bytes {
    fn same(&self, other: &Self) -> bool { tick(1 + self.0.len().min(other.0.len()) as u64); self.0 == other.0 }
}

impl Key for Str {
    fn key(&self, other: &Self) -> Ordering { let mut left = self.0.chars(); let mut right = other.0.chars(); loop { tick(1); match (left.next(), right.next()) { (None, None) => return Ordering::Equal, (None, Some(_)) => return Ordering::Less, (Some(_), None) => return Ordering::Greater, (Some(a), Some(b)) => match a.cmp(&b) { Ordering::Equal => { }, decided => return decided, }, } } }
}

pub fn canonical_decimal(text: &str) -> Option<Option<i128>> { let digits = match text.strip_prefix('-') { Some(rest) => rest, None => text, }; let mut canonical = !digits.is_empty() && (digits == "0" || !digits.starts_with('0')) && text != "-0"; for c in digits.chars() { tick(1); canonical = canonical && c.is_ascii_digit(); }; if !canonical { return None; }; Some(text.parse::<i128>().ok()) }

pub fn parse_int(text: Str) -> R<Option<i64>> { match canonical_decimal(&text.0) { None => Ok(None), Some(Some(n)) => match i64::try_from(n) { Ok(value) => Ok(Some(value)), Err(_) => Err(Overflow), }, Some(None) => Err(Overflow), } }

pub fn format_u8(a: u8) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u8(text: Str) -> Option<u8> { match canonical_decimal(&text.0) { Some(Some(n)) => u8::try_from(n).ok(), _ => None, } }

pub fn format_u16(a: u16) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u16(text: Str) -> Option<u16> { match canonical_decimal(&text.0) { Some(Some(n)) => u16::try_from(n).ok(), _ => None, } }

pub fn format_u32(a: u32) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u32(text: Str) -> Option<u32> { match canonical_decimal(&text.0) { Some(Some(n)) => u32::try_from(n).ok(), _ => None, } }

pub fn format_u64(a: u64) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u64(text: Str) -> Option<u64> { match canonical_decimal(&text.0) { Some(Some(n)) => u64::try_from(n).ok(), _ => None, } }

pub fn format_i8(a: i8) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i8(text: Str) -> Option<i8> { match canonical_decimal(&text.0) { Some(Some(n)) => i8::try_from(n).ok(), _ => None, } }

pub fn format_i16(a: i16) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i16(text: Str) -> Option<i16> { match canonical_decimal(&text.0) { Some(Some(n)) => i16::try_from(n).ok(), _ => None, } }

pub fn format_i32(a: i32) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i32(text: Str) -> Option<i32> { match canonical_decimal(&text.0) { Some(Some(n)) => i32::try_from(n).ok(), _ => None, } }

pub fn format_i64(a: i64) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i64(text: Str) -> Option<i64> { match canonical_decimal(&text.0) { Some(Some(n)) => i64::try_from(n).ok(), _ => None, } }

pub fn append_list<T: Clone>(p0: List<T>, p1: List<T>) -> List<T> {
    List::append(p0, p1)
}

pub fn length_list<T: Clone>(p0: List<T>) -> u64 {
    List::length(&p0)
}

pub fn index_list<T: Clone>(p0: List<T>, p1: u64) -> Option<T> {
    List::index(&p0, p1)
}

pub fn slice_list<T: Clone>(p0: List<T>, p1: u64, p2: u64) -> Option<List<T>> {
    List::slice(&p0, p1, p2)
}

pub fn append_bytes(p0: Bytes, p1: Bytes) -> Bytes {
    Bytes::append(p0, p1)
}

pub fn length_bytes(p0: Bytes) -> u64 {
    Bytes::length(&p0)
}

pub fn length_string(p0: Str) -> u64 {
    Str::length(&p0)
}

pub fn index_bytes(p0: Bytes, p1: u64) -> Option<u8> {
    Bytes::index(&p0, p1)
}

pub fn slice_bytes(p0: Bytes, p1: u64, p2: u64) -> Option<Bytes> {
    Bytes::slice(&p0, p1, p2)
}

pub fn utf8_encode(p0: Str) -> Bytes {
    Str::utf8_encode(&p0)
}

pub fn utf8_decode(p0: Bytes) -> Option<Str> {
    Bytes::utf8_decode(&p0)
}

pub fn compare_bytes(p0: Bytes, p1: Bytes) -> Ordering {
    Bytes::compare(&p0, &p1)
}

pub fn split_exact(p0: Str, p1: Str, p2: u32) -> Option<List<Str>> {
    Str::split_exact(&p0, &p1, p2)
}

pub fn join(p0: List<Str>, p1: Str) -> Str {
    Str::join(p0, &p1)
}

#[derive(Clone)]
pub enum Adt0 {
    C0(u32, u32, u32, u32),
}

#[derive(Clone)]
pub enum Adt1 {
    C0(Adt0, bool, bool),
}

#[derive(Clone)]
pub enum Fn0 {
    F8,
}

impl Fn0 {
    pub fn apply(&self, p0: Option<Adt1>) -> Option<Adt1> {
        match self {
            Fn0::F8 => f8(p0),
        }
    }
}

#[derive(Clone)]
pub enum Fn1 {
    F10,
}

impl Fn1 {
    pub fn apply(&self, p0: Option<(u32, i64)>) -> R<Option<(u32, i64)>> {
        match self {
            Fn1::F10 => f10(p0),
        }
    }
}

pub fn f0(v0: u32, v1: u32) -> R<Option<u32>> {
    let m2 = {
        let a1 = v0;
        fixed_u64::convert(i128::from(a1))
    };
    match m2 {
        None => {
            Ok(None::<u32>)
        }
        Some(v2) => {
            let m4 = {
                let a3 = v1;
                fixed_u64::convert(i128::from(a3))
            };
            match m4 {
                None => {
                    Ok(None::<u32>)
                }
                Some(v3) => {
                    let m5 = f1(v2, v3)?;
                    match m5 {
                        None => {
                            Ok(None::<u32>)
                        }
                        Some(v4) => {
                            let a6 = v4;
                            Ok(fixed_u32::convert(i128::from(a6)))
                        }
                    }
                }
            }
        }
    }
}

pub fn f1(v0: u64, v1: u64) -> R<Option<u64>> {
    let v2: u64 = {
        let a9 = {
            let a7 = v0;
            let a8 = v1;
            fixed_u64::bit_xor(a7, a8)
        };
        let a10 = 2147483648u64;
        fixed_u64::bit_and(a9, a10)
    };
    let v3: u64 = {
        let a11 = v0;
        let a12 = 8388607u64;
        fixed_u64::bit_and(a11, a12)
    };
    let v4: u64 = {
        let a13 = v1;
        let a14 = 8388607u64;
        fixed_u64::bit_and(a13, a14)
    };
    let m17 = {
        let a15 = v0;
        let a16 = 23u32;
        fixed_u64::shift_right(a15, a16)
    };
    match m17 {
        None => {
            Ok(None::<u64>)
        }
        Some(v5) => {
            let m20 = {
                let a18 = v1;
                let a19 = 23u32;
                fixed_u64::shift_right(a18, a19)
            };
            match m20 {
                None => {
                    Ok(None::<u64>)
                }
                Some(v6) => {
                    let v7: u64 = {
                        let a21 = v5;
                        let a22 = 255u64;
                        fixed_u64::bit_and(a21, a22)
                    };
                    let v8: u64 = {
                        let a23 = v6;
                        let a24 = 255u64;
                        fixed_u64::bit_and(a23, a24)
                    };
                    let a25 = v7;
                    let a26 = 255u64;
                    if if equal(a25, a26) {
                        let a29 = {
                            let a27 = v3;
                            let a28 = 0u64;
                            equal(a27, a28)
                        };
                        bool_not(a29)
                    } else {
                        false
                    } {
                        Ok(Some({
                            let a30 = v0;
                            let a31 = 4194304u64;
                            fixed_u64::bit_or(a30, a31)
                        }))
                    } else {
                        let a32 = v8;
                        let a33 = 255u64;
                        if if equal(a32, a33) {
                            let a36 = {
                                let a34 = v4;
                                let a35 = 0u64;
                                equal(a34, a35)
                            };
                            bool_not(a36)
                        } else {
                            false
                        } {
                            Ok(Some({
                                let a37 = v1;
                                let a38 = 4194304u64;
                                fixed_u64::bit_or(a37, a38)
                            }))
                        } else {
                            let a39 = v7;
                            let a40 = 255u64;
                            if if equal(a39, a40) {
                                true
                            } else {
                                let a41 = v8;
                                let a42 = 255u64;
                                equal(a41, a42)
                            } {
                                Ok(Some({
                                    let a45 = {
                                        let a43 = v0;
                                        let a44 = 2147483647u64;
                                        fixed_u64::bit_and(a43, a44)
                                    };
                                    let a46 = 0u64;
                                    if if equal(a45, a46) {
                                        true
                                    } else {
                                        let a49 = {
                                            let a47 = v1;
                                            let a48 = 2147483647u64;
                                            fixed_u64::bit_and(a47, a48)
                                        };
                                        let a50 = 0u64;
                                        equal(a49, a50)
                                    } {
                                        2143289344u64
                                    } else {
                                        let a51 = v2;
                                        let a52 = 2139095040u64;
                                        fixed_u64::bit_or(a51, a52)
                                    }
                                }))
                            } else {
                                let a55 = {
                                    let a53 = v0;
                                    let a54 = 2147483647u64;
                                    fixed_u64::bit_and(a53, a54)
                                };
                                let a56 = 0u64;
                                if if equal(a55, a56) {
                                    true
                                } else {
                                    let a59 = {
                                        let a57 = v1;
                                        let a58 = 2147483647u64;
                                        fixed_u64::bit_and(a57, a58)
                                    };
                                    let a60 = 0u64;
                                    equal(a59, a60)
                                } {
                                    Ok(Some(v2))
                                } else {
                                    let m62 = {
                                        let a61 = v7;
                                        fixed_u8::convert(i128::from(a61))
                                    };
                                    match m62 {
                                        None => {
                                            Ok(None::<u64>)
                                        }
                                        Some(v9) => {
                                            let m64 = {
                                                let a63 = v8;
                                                fixed_u8::convert(i128::from(a63))
                                            };
                                            match m64 {
                                                None => {
                                                    Ok(None::<u64>)
                                                }
                                                Some(v10) => {
                                                    let v11: u64 = {
                                                        let a65 = v7;
                                                        let a66 = 0u64;
                                                        if equal(a65, a66) {
                                                            v3
                                                        } else {
                                                            let a67 = v3;
                                                            let a68 = 8388608u64;
                                                            fixed_u64::bit_or(a67, a68)
                                                        }
                                                    };
                                                    let v12: u64 = {
                                                        let a69 = v8;
                                                        let a70 = 0u64;
                                                        if equal(a69, a70) {
                                                            v4
                                                        } else {
                                                            let a71 = v4;
                                                            let a72 = 8388608u64;
                                                            fixed_u64::bit_or(a71, a72)
                                                        }
                                                    };
                                                    let v14: i64 = {
                                                        let a73 = v7;
                                                        let a74 = 0u64;
                                                        if equal(a73, a74) {
                                                            1i64
                                                        } else {
                                                            let v13: u8 = v9;
                                                            let a126 = {
                                                                let a98 = {
                                                                    let a84 = {
                                                                        let a77 = {
                                                                            let a75 = v13;
                                                                            let a76 = 128u8;
                                                                            fixed_u8::bit_and(a75, a76)
                                                                        };
                                                                        let a78 = 128u8;
                                                                        if equal(a77, a78) {
                                                                            128i64
                                                                        } else {
                                                                            0i64
                                                                        }
                                                                    };
                                                                    let a85 = {
                                                                        let a83 = {
                                                                            let a81 = {
                                                                                let a79 = v13;
                                                                                let a80 = 64u8;
                                                                                fixed_u8::bit_and(a79, a80)
                                                                            };
                                                                            let a82 = 64u8;
                                                                            if equal(a81, a82) {
                                                                                64i64
                                                                            } else {
                                                                                0i64
                                                                            }
                                                                        };
                                                                        int_neg(a83)?
                                                                    };
                                                                    int_sub(a84, a85)?
                                                                };
                                                                let a99 = {
                                                                    let a97 = {
                                                                        let a95 = {
                                                                            let a88 = {
                                                                                let a86 = v13;
                                                                                let a87 = 32u8;
                                                                                fixed_u8::bit_and(a86, a87)
                                                                            };
                                                                            let a89 = 32u8;
                                                                            if equal(a88, a89) {
                                                                                32i64
                                                                            } else {
                                                                                0i64
                                                                            }
                                                                        };
                                                                        let a96 = {
                                                                            let a94 = {
                                                                                let a92 = {
                                                                                    let a90 = v13;
                                                                                    let a91 = 16u8;
                                                                                    fixed_u8::bit_and(a90, a91)
                                                                                };
                                                                                let a93 = 16u8;
                                                                                if equal(a92, a93) {
                                                                                    16i64
                                                                                } else {
                                                                                    0i64
                                                                                }
                                                                            };
                                                                            int_neg(a94)?
                                                                        };
                                                                        int_sub(a95, a96)?
                                                                    };
                                                                    int_neg(a97)?
                                                                };
                                                                int_sub(a98, a99)?
                                                            };
                                                            let a127 = {
                                                                let a125 = {
                                                                    let a123 = {
                                                                        let a109 = {
                                                                            let a102 = {
                                                                                let a100 = v13;
                                                                                let a101 = 8u8;
                                                                                fixed_u8::bit_and(a100, a101)
                                                                            };
                                                                            let a103 = 8u8;
                                                                            if equal(a102, a103) {
                                                                                8i64
                                                                            } else {
                                                                                0i64
                                                                            }
                                                                        };
                                                                        let a110 = {
                                                                            let a108 = {
                                                                                let a106 = {
                                                                                    let a104 = v13;
                                                                                    let a105 = 4u8;
                                                                                    fixed_u8::bit_and(a104, a105)
                                                                                };
                                                                                let a107 = 4u8;
                                                                                if equal(a106, a107) {
                                                                                    4i64
                                                                                } else {
                                                                                    0i64
                                                                                }
                                                                            };
                                                                            int_neg(a108)?
                                                                        };
                                                                        int_sub(a109, a110)?
                                                                    };
                                                                    let a124 = {
                                                                        let a122 = {
                                                                            let a120 = {
                                                                                let a113 = {
                                                                                    let a111 = v13;
                                                                                    let a112 = 2u8;
                                                                                    fixed_u8::bit_and(a111, a112)
                                                                                };
                                                                                let a114 = 2u8;
                                                                                if equal(a113, a114) {
                                                                                    2i64
                                                                                } else {
                                                                                    0i64
                                                                                }
                                                                            };
                                                                            let a121 = {
                                                                                let a119 = {
                                                                                    let a117 = {
                                                                                        let a115 = v13;
                                                                                        let a116 = 1u8;
                                                                                        fixed_u8::bit_and(a115, a116)
                                                                                    };
                                                                                    let a118 = 1u8;
                                                                                    if equal(a117, a118) {
                                                                                        1i64
                                                                                    } else {
                                                                                        0i64
                                                                                    }
                                                                                };
                                                                                int_neg(a119)?
                                                                            };
                                                                            int_sub(a120, a121)?
                                                                        };
                                                                        int_neg(a122)?
                                                                    };
                                                                    int_sub(a123, a124)?
                                                                };
                                                                int_neg(a125)?
                                                            };
                                                            int_sub(a126, a127)?
                                                        }
                                                    };
                                                    let v16: i64 = {
                                                        let a128 = v8;
                                                        let a129 = 0u64;
                                                        if equal(a128, a129) {
                                                            1i64
                                                        } else {
                                                            let v15: u8 = v10;
                                                            let a181 = {
                                                                let a153 = {
                                                                    let a139 = {
                                                                        let a132 = {
                                                                            let a130 = v15;
                                                                            let a131 = 128u8;
                                                                            fixed_u8::bit_and(a130, a131)
                                                                        };
                                                                        let a133 = 128u8;
                                                                        if equal(a132, a133) {
                                                                            128i64
                                                                        } else {
                                                                            0i64
                                                                        }
                                                                    };
                                                                    let a140 = {
                                                                        let a138 = {
                                                                            let a136 = {
                                                                                let a134 = v15;
                                                                                let a135 = 64u8;
                                                                                fixed_u8::bit_and(a134, a135)
                                                                            };
                                                                            let a137 = 64u8;
                                                                            if equal(a136, a137) {
                                                                                64i64
                                                                            } else {
                                                                                0i64
                                                                            }
                                                                        };
                                                                        int_neg(a138)?
                                                                    };
                                                                    int_sub(a139, a140)?
                                                                };
                                                                let a154 = {
                                                                    let a152 = {
                                                                        let a150 = {
                                                                            let a143 = {
                                                                                let a141 = v15;
                                                                                let a142 = 32u8;
                                                                                fixed_u8::bit_and(a141, a142)
                                                                            };
                                                                            let a144 = 32u8;
                                                                            if equal(a143, a144) {
                                                                                32i64
                                                                            } else {
                                                                                0i64
                                                                            }
                                                                        };
                                                                        let a151 = {
                                                                            let a149 = {
                                                                                let a147 = {
                                                                                    let a145 = v15;
                                                                                    let a146 = 16u8;
                                                                                    fixed_u8::bit_and(a145, a146)
                                                                                };
                                                                                let a148 = 16u8;
                                                                                if equal(a147, a148) {
                                                                                    16i64
                                                                                } else {
                                                                                    0i64
                                                                                }
                                                                            };
                                                                            int_neg(a149)?
                                                                        };
                                                                        int_sub(a150, a151)?
                                                                    };
                                                                    int_neg(a152)?
                                                                };
                                                                int_sub(a153, a154)?
                                                            };
                                                            let a182 = {
                                                                let a180 = {
                                                                    let a178 = {
                                                                        let a164 = {
                                                                            let a157 = {
                                                                                let a155 = v15;
                                                                                let a156 = 8u8;
                                                                                fixed_u8::bit_and(a155, a156)
                                                                            };
                                                                            let a158 = 8u8;
                                                                            if equal(a157, a158) {
                                                                                8i64
                                                                            } else {
                                                                                0i64
                                                                            }
                                                                        };
                                                                        let a165 = {
                                                                            let a163 = {
                                                                                let a161 = {
                                                                                    let a159 = v15;
                                                                                    let a160 = 4u8;
                                                                                    fixed_u8::bit_and(a159, a160)
                                                                                };
                                                                                let a162 = 4u8;
                                                                                if equal(a161, a162) {
                                                                                    4i64
                                                                                } else {
                                                                                    0i64
                                                                                }
                                                                            };
                                                                            int_neg(a163)?
                                                                        };
                                                                        int_sub(a164, a165)?
                                                                    };
                                                                    let a179 = {
                                                                        let a177 = {
                                                                            let a175 = {
                                                                                let a168 = {
                                                                                    let a166 = v15;
                                                                                    let a167 = 2u8;
                                                                                    fixed_u8::bit_and(a166, a167)
                                                                                };
                                                                                let a169 = 2u8;
                                                                                if equal(a168, a169) {
                                                                                    2i64
                                                                                } else {
                                                                                    0i64
                                                                                }
                                                                            };
                                                                            let a176 = {
                                                                                let a174 = {
                                                                                    let a172 = {
                                                                                        let a170 = v15;
                                                                                        let a171 = 1u8;
                                                                                        fixed_u8::bit_and(a170, a171)
                                                                                    };
                                                                                    let a173 = 1u8;
                                                                                    if equal(a172, a173) {
                                                                                        1i64
                                                                                    } else {
                                                                                        0i64
                                                                                    }
                                                                                };
                                                                                int_neg(a174)?
                                                                            };
                                                                            int_sub(a175, a176)?
                                                                        };
                                                                        int_neg(a177)?
                                                                    };
                                                                    int_sub(a178, a179)?
                                                                };
                                                                int_neg(a180)?
                                                            };
                                                            int_sub(a181, a182)?
                                                        }
                                                    };
                                                    let v17: i64 = {
                                                        let a186 = {
                                                            let a184 = v14;
                                                            let a185 = {
                                                                let a183 = v16;
                                                                int_neg(a183)?
                                                            };
                                                            int_sub(a184, a185)?
                                                        };
                                                        let a187 = 300i64;
                                                        int_sub(a186, a187)?
                                                    };
                                                    let m188 = f2(v11, v12);
                                                    match m188 {
                                                        None => {
                                                            Ok(None::<u64>)
                                                        }
                                                        Some(v18) => {
                                                            let m189 = f3(v18.clone())?;
                                                            match m189 {
                                                                None => {
                                                                    Ok(None::<u64>)
                                                                }
                                                                Some(v19) => {
                                                                    let v20: i64 = {
                                                                        let a190 = v19;
                                                                        let a191 = 1i64;
                                                                        int_sub(a190, a191)?
                                                                    };
                                                                    let v21: i64 = {
                                                                        let a193 = v20;
                                                                        let a194 = {
                                                                            let a192 = v17;
                                                                            int_neg(a192)?
                                                                        };
                                                                        int_sub(a193, a194)?
                                                                    };
                                                                    let v22: i64 = {
                                                                        let a195 = v20;
                                                                        let a196 = 23i64;
                                                                        int_sub(a195, a196)?
                                                                    };
                                                                    let v23: i64 = {
                                                                        let a197 = -149i64;
                                                                        let a198 = v17;
                                                                        int_sub(a197, a198)?
                                                                    };
                                                                    let v24: i64 = {
                                                                        let m201 = {
                                                                            let a199 = v22;
                                                                            let a200 = v23;
                                                                            compare(a199, a200)
                                                                        };
                                                                        if match m201 {
                                                                            Ordering::Less => {
                                                                                true
                                                                            }
                                                                            Ordering::Equal => {
                                                                                false
                                                                            }
                                                                            Ordering::Greater => {
                                                                                false
                                                                            }
                                                                        } {
                                                                            v23
                                                                        } else {
                                                                            v22
                                                                        }
                                                                    };
                                                                    let m202 = f4(v18, v24)?;
                                                                    match m202 {
                                                                        None => {
                                                                            Ok(None::<u64>)
                                                                        }
                                                                        Some(v25) => {
                                                                            let v26: bool = {
                                                                                let a203 = v25;
                                                                                let a204 = 16777216u64;
                                                                                equal(a203, a204)
                                                                            };
                                                                            let v27: i64 = if v26 {
                                                                                let a205 = v21;
                                                                                let a206 = -1i64;
                                                                                int_sub(a205, a206)?
                                                                            } else {
                                                                                v21
                                                                            };
                                                                            let v28: i64 = {
                                                                                let m209 = {
                                                                                    let a207 = v27;
                                                                                    let a208 = -126i64;
                                                                                    compare(a207, a208)
                                                                                };
                                                                                if match m209 {
                                                                                    Ordering::Less => {
                                                                                        true
                                                                                    }
                                                                                    Ordering::Equal => {
                                                                                        false
                                                                                    }
                                                                                    Ordering::Greater => {
                                                                                        false
                                                                                    }
                                                                                } {
                                                                                    let m212 = {
                                                                                        let a210 = v25;
                                                                                        let a211 = 8388608u64;
                                                                                        compare(a210, a211)
                                                                                    };
                                                                                    if match m212 {
                                                                                        Ordering::Less => {
                                                                                            true
                                                                                        }
                                                                                        Ordering::Equal => {
                                                                                            false
                                                                                        }
                                                                                        Ordering::Greater => {
                                                                                            false
                                                                                        }
                                                                                    } {
                                                                                        0i64
                                                                                    } else {
                                                                                        1i64
                                                                                    }
                                                                                } else {
                                                                                    let a213 = v27;
                                                                                    let a214 = -127i64;
                                                                                    int_sub(a213, a214)?
                                                                                }
                                                                            };
                                                                            let m217 = {
                                                                                let a215 = 254i64;
                                                                                let a216 = v28;
                                                                                compare(a215, a216)
                                                                            };
                                                                            if match m217 {
                                                                                Ordering::Less => {
                                                                                    true
                                                                                }
                                                                                Ordering::Equal => {
                                                                                    false
                                                                                }
                                                                                Ordering::Greater => {
                                                                                    false
                                                                                }
                                                                            } {
                                                                                Ok(Some({
                                                                                    let a218 = v2;
                                                                                    let a219 = 2139095040u64;
                                                                                    fixed_u64::bit_or(a218, a219)
                                                                                }))
                                                                            } else {
                                                                                let m222 = if v26 {
                                                                                    let a220 = v25;
                                                                                    let a221 = 1u32;
                                                                                    fixed_u64::shift_right(a220, a221)
                                                                                } else {
                                                                                    Some(v25)
                                                                                };
                                                                                match m222 {
                                                                                    None => {
                                                                                        Ok(None::<u64>)
                                                                                    }
                                                                                    Some(v29) => {
                                                                                        let m224 = {
                                                                                            let a223 = v28;
                                                                                            fixed_u64::convert(i128::from(a223))
                                                                                        };
                                                                                        match m224 {
                                                                                            None => {
                                                                                                Ok(None::<u64>)
                                                                                            }
                                                                                            Some(v30) => {
                                                                                                let m227 = {
                                                                                                    let a225 = v30;
                                                                                                    let a226 = 23u32;
                                                                                                    fixed_u64::shift_left(a225, a226)
                                                                                                };
                                                                                                match m227 {
                                                                                                    None => {
                                                                                                        Ok(None::<u64>)
                                                                                                    }
                                                                                                    Some(v31) => {
                                                                                                        Ok(Some({
                                                                                                            let a232 = v2;
                                                                                                            let a233 = {
                                                                                                                let a230 = v31;
                                                                                                                let a231 = {
                                                                                                                    let a228 = v29;
                                                                                                                    let a229 = 8388607u64;
                                                                                                                    fixed_u64::bit_and(a228, a229)
                                                                                                                };
                                                                                                                fixed_u64::bit_or(a230, a231)
                                                                                                            };
                                                                                                            fixed_u64::bit_or(a232, a233)
                                                                                                        }))
                                                                                                    }
                                                                                                }
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

pub fn f2(v0: u64, v1: u64) -> Option<Adt0> {
    let m236 = Some({
        let a234 = v0;
        let a235 = 4294967295u64;
        fixed_u64::bit_and(a234, a235)
    });
    match m236 {
        None => {
            None::<Adt0>
        }
        Some(v2) => {
            let m239 = {
                let a237 = v0;
                let a238 = 32u32;
                fixed_u64::shift_right(a237, a238)
            };
            match m239 {
                None => {
                    None::<Adt0>
                }
                Some(v3) => {
                    let m242 = Some({
                        let a240 = v1;
                        let a241 = 4294967295u64;
                        fixed_u64::bit_and(a240, a241)
                    });
                    match m242 {
                        None => {
                            None::<Adt0>
                        }
                        Some(v4) => {
                            let m245 = {
                                let a243 = v1;
                                let a244 = 32u32;
                                fixed_u64::shift_right(a243, a244)
                            };
                            match m245 {
                                None => {
                                    None::<Adt0>
                                }
                                Some(v5) => {
                                    let m248 = {
                                        let a246 = v2;
                                        let a247 = v4;
                                        fixed_u64::checked_mul(a246, a247)
                                    };
                                    match m248 {
                                        None => {
                                            None::<Adt0>
                                        }
                                        Some(v6) => {
                                            let m251 = {
                                                let a249 = v6;
                                                let a250 = 32u32;
                                                fixed_u64::shift_right(a249, a250)
                                            };
                                            match m251 {
                                                None => {
                                                    None::<Adt0>
                                                }
                                                Some(v7) => {
                                                    let m254 = {
                                                        let a252 = v3;
                                                        let a253 = v4;
                                                        fixed_u64::checked_mul(a252, a253)
                                                    };
                                                    match m254 {
                                                        None => {
                                                            None::<Adt0>
                                                        }
                                                        Some(v8) => {
                                                            let m257 = {
                                                                let a255 = v8;
                                                                let a256 = v7;
                                                                fixed_u64::checked_add(a255, a256)
                                                            };
                                                            match m257 {
                                                                None => {
                                                                    None::<Adt0>
                                                                }
                                                                Some(v9) => {
                                                                    let m260 = {
                                                                        let a258 = v2;
                                                                        let a259 = v5;
                                                                        fixed_u64::checked_mul(a258, a259)
                                                                    };
                                                                    match m260 {
                                                                        None => {
                                                                            None::<Adt0>
                                                                        }
                                                                        Some(v10) => {
                                                                            let m265 = {
                                                                                let a263 = v10;
                                                                                let a264 = {
                                                                                    let a261 = v9;
                                                                                    let a262 = 4294967295u64;
                                                                                    fixed_u64::bit_and(a261, a262)
                                                                                };
                                                                                fixed_u64::checked_add(a263, a264)
                                                                            };
                                                                            match m265 {
                                                                                None => {
                                                                                    None::<Adt0>
                                                                                }
                                                                                Some(v11) => {
                                                                                    let m268 = {
                                                                                        let a266 = v9;
                                                                                        let a267 = 32u32;
                                                                                        fixed_u64::shift_right(a266, a267)
                                                                                    };
                                                                                    match m268 {
                                                                                        None => {
                                                                                            None::<Adt0>
                                                                                        }
                                                                                        Some(v12) => {
                                                                                            let m271 = {
                                                                                                let a269 = v11;
                                                                                                let a270 = 32u32;
                                                                                                fixed_u64::shift_right(a269, a270)
                                                                                            };
                                                                                            match m271 {
                                                                                                None => {
                                                                                                    None::<Adt0>
                                                                                                }
                                                                                                Some(v13) => {
                                                                                                    let m274 = {
                                                                                                        let a272 = v3;
                                                                                                        let a273 = v5;
                                                                                                        fixed_u64::checked_mul(a272, a273)
                                                                                                    };
                                                                                                    match m274 {
                                                                                                        None => {
                                                                                                            None::<Adt0>
                                                                                                        }
                                                                                                        Some(v14) => {
                                                                                                            let m277 = {
                                                                                                                let a275 = v14;
                                                                                                                let a276 = v12;
                                                                                                                fixed_u64::checked_add(a275, a276)
                                                                                                            };
                                                                                                            match m277 {
                                                                                                                None => {
                                                                                                                    None::<Adt0>
                                                                                                                }
                                                                                                                Some(v15) => {
                                                                                                                    let m280 = {
                                                                                                                        let a278 = v15;
                                                                                                                        let a279 = v13;
                                                                                                                        fixed_u64::checked_add(a278, a279)
                                                                                                                    };
                                                                                                                    match m280 {
                                                                                                                        None => {
                                                                                                                            None::<Adt0>
                                                                                                                        }
                                                                                                                        Some(v16) => {
                                                                                                                            let m283 = {
                                                                                                                                let a281 = v16;
                                                                                                                                let a282 = 32u32;
                                                                                                                                fixed_u64::shift_right(a281, a282)
                                                                                                                            };
                                                                                                                            match m283 {
                                                                                                                                None => {
                                                                                                                                    None::<Adt0>
                                                                                                                                }
                                                                                                                                Some(v17) => {
                                                                                                                                    let m287 = {
                                                                                                                                        let a286 = {
                                                                                                                                            let a284 = v6;
                                                                                                                                            let a285 = 4294967295u64;
                                                                                                                                            fixed_u64::bit_and(a284, a285)
                                                                                                                                        };
                                                                                                                                        fixed_u32::convert(i128::from(a286))
                                                                                                                                    };
                                                                                                                                    match m287 {
                                                                                                                                        None => {
                                                                                                                                            None::<Adt0>
                                                                                                                                        }
                                                                                                                                        Some(v18) => {
                                                                                                                                            let m291 = {
                                                                                                                                                let a290 = {
                                                                                                                                                    let a288 = v11;
                                                                                                                                                    let a289 = 4294967295u64;
                                                                                                                                                    fixed_u64::bit_and(a288, a289)
                                                                                                                                                };
                                                                                                                                                fixed_u32::convert(i128::from(a290))
                                                                                                                                            };
                                                                                                                                            match m291 {
                                                                                                                                                None => {
                                                                                                                                                    None::<Adt0>
                                                                                                                                                }
                                                                                                                                                Some(v19) => {
                                                                                                                                                    let m295 = {
                                                                                                                                                        let a294 = {
                                                                                                                                                            let a292 = v16;
                                                                                                                                                            let a293 = 4294967295u64;
                                                                                                                                                            fixed_u64::bit_and(a292, a293)
                                                                                                                                                        };
                                                                                                                                                        fixed_u32::convert(i128::from(a294))
                                                                                                                                                    };
                                                                                                                                                    match m295 {
                                                                                                                                                        None => {
                                                                                                                                                            None::<Adt0>
                                                                                                                                                        }
                                                                                                                                                        Some(v20) => {
                                                                                                                                                            let m299 = {
                                                                                                                                                                let a298 = {
                                                                                                                                                                    let a296 = v17;
                                                                                                                                                                    let a297 = 4294967295u64;
                                                                                                                                                                    fixed_u64::bit_and(a296, a297)
                                                                                                                                                                };
                                                                                                                                                                fixed_u32::convert(i128::from(a298))
                                                                                                                                                            };
                                                                                                                                                            match m299 {
                                                                                                                                                                None => {
                                                                                                                                                                    None::<Adt0>
                                                                                                                                                                }
                                                                                                                                                                Some(v21) => {
                                                                                                                                                                    Some(Adt0::C0(v18, v19, v20, v21))
                                                                                                                                                                }
                                                                                                                                                            }
                                                                                                                                                        }
                                                                                                                                                    }
                                                                                                                                                }
                                                                                                                                            }
                                                                                                                                        }
                                                                                                                                    }
                                                                                                                                }
                                                                                                                            }
                                                                                                                        }
                                                                                                                    }
                                                                                                                }
                                                                                                            }
                                                                                                        }
                                                                                                    }
                                                                                                }
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

pub fn f3(v0: Adt0) -> R<Option<i64>> {
    let a301 = match v0.clone() {
        Adt0::C0(_, _, _, h300) => {
            h300
        }
    };
    let a302 = 0u32;
    if equal(a301, a302) {
        let a304 = match v0.clone() {
            Adt0::C0(_, _, h303, _) => {
                h303
            }
        };
        let a305 = 0u32;
        if equal(a304, a305) {
            let a307 = match v0.clone() {
                Adt0::C0(_, h306, _, _) => {
                    h306
                }
            };
            let a308 = 0u32;
            if equal(a307, a308) {
                f5(match v0 {
                    Adt0::C0(h309, _, _, _) => {
                        h309
                    }
                })
            } else {
                let m311 = f5(match v0 {
                    Adt0::C0(_, h310, _, _) => {
                        h310
                    }
                })?;
                match m311 {
                    None => {
                        Ok(None::<i64>)
                    }
                    Some(v1) => {
                        Ok(Some({
                            let a312 = v1;
                            let a313 = -32i64;
                            int_sub(a312, a313)?
                        }))
                    }
                }
            }
        } else {
            let m315 = f5(match v0 {
                Adt0::C0(_, _, h314, _) => {
                    h314
                }
            })?;
            match m315 {
                None => {
                    Ok(None::<i64>)
                }
                Some(v2) => {
                    Ok(Some({
                        let a316 = v2;
                        let a317 = -64i64;
                        int_sub(a316, a317)?
                    }))
                }
            }
        }
    } else {
        let m319 = f5(match v0 {
            Adt0::C0(_, _, _, h318) => {
                h318
            }
        })?;
        match m319 {
            None => {
                Ok(None::<i64>)
            }
            Some(v3) => {
                Ok(Some({
                    let a320 = v3;
                    let a321 = -96i64;
                    int_sub(a320, a321)?
                }))
            }
        }
    }
}

pub fn f4(v0: Adt0, v1: i64) -> R<Option<u64>> {
    let m324 = {
        let a322 = v1;
        let a323 = 0i64;
        compare(a322, a323)
    };
    if match m324 {
        Ordering::Less => {
            true
        }
        Ordering::Equal => {
            false
        }
        Ordering::Greater => {
            false
        }
    } {
        let m327 = {
            let a326 = {
                let a325 = v1;
                int_neg(a325)?
            };
            fixed_u32::convert(i128::from(a326))
        };
        match m327 {
            None => {
                Ok(None::<u64>)
            }
            Some(v2) => {
                let m328 = f6(v0);
                match m328 {
                    None => {
                        Ok(None::<u64>)
                    }
                    Some(v3) => {
                        let a329 = v3;
                        let a330 = v2;
                        Ok(fixed_u64::shift_left(a329, a330))
                    }
                }
            }
        }
    } else {
        let m333 = {
            let a331 = 128i64;
            let a332 = v1;
            compare(a331, a332)
        };
        if match m333 {
            Ordering::Less => {
                true
            }
            Ordering::Equal => {
                false
            }
            Ordering::Greater => {
                false
            }
        } {
            Ok(Some(0u64))
        } else {
            let m335 = {
                let a334 = v1;
                fixed_u8::convert(i128::from(a334))
            };
            match m335 {
                None => {
                    Ok(None::<u64>)
                }
                Some(v4) => {
                    let m382 = f7(Fn0::F8, {
                        let v5: u8 = v4;
                        let a380 = {
                            let a356 = {
                                let a344 = {
                                    let a338 = {
                                        let a336 = v5;
                                        let a337 = 128u8;
                                        fixed_u8::bit_and(a336, a337)
                                    };
                                    let a339 = 128u8;
                                    if equal(a338, a339) {
                                        128u64
                                    } else {
                                        0u64
                                    }
                                };
                                let a345 = {
                                    let a342 = {
                                        let a340 = v5;
                                        let a341 = 64u8;
                                        fixed_u8::bit_and(a340, a341)
                                    };
                                    let a343 = 64u8;
                                    if equal(a342, a343) {
                                        64u64
                                    } else {
                                        0u64
                                    }
                                };
                                nat_add(a344, a345)?
                            };
                            let a357 = {
                                let a354 = {
                                    let a348 = {
                                        let a346 = v5;
                                        let a347 = 32u8;
                                        fixed_u8::bit_and(a346, a347)
                                    };
                                    let a349 = 32u8;
                                    if equal(a348, a349) {
                                        32u64
                                    } else {
                                        0u64
                                    }
                                };
                                let a355 = {
                                    let a352 = {
                                        let a350 = v5;
                                        let a351 = 16u8;
                                        fixed_u8::bit_and(a350, a351)
                                    };
                                    let a353 = 16u8;
                                    if equal(a352, a353) {
                                        16u64
                                    } else {
                                        0u64
                                    }
                                };
                                nat_add(a354, a355)?
                            };
                            nat_add(a356, a357)?
                        };
                        let a381 = {
                            let a378 = {
                                let a366 = {
                                    let a360 = {
                                        let a358 = v5;
                                        let a359 = 8u8;
                                        fixed_u8::bit_and(a358, a359)
                                    };
                                    let a361 = 8u8;
                                    if equal(a360, a361) {
                                        8u64
                                    } else {
                                        0u64
                                    }
                                };
                                let a367 = {
                                    let a364 = {
                                        let a362 = v5;
                                        let a363 = 4u8;
                                        fixed_u8::bit_and(a362, a363)
                                    };
                                    let a365 = 4u8;
                                    if equal(a364, a365) {
                                        4u64
                                    } else {
                                        0u64
                                    }
                                };
                                nat_add(a366, a367)?
                            };
                            let a379 = {
                                let a376 = {
                                    let a370 = {
                                        let a368 = v5;
                                        let a369 = 2u8;
                                        fixed_u8::bit_and(a368, a369)
                                    };
                                    let a371 = 2u8;
                                    if equal(a370, a371) {
                                        2u64
                                    } else {
                                        0u64
                                    }
                                };
                                let a377 = {
                                    let a374 = {
                                        let a372 = v5;
                                        let a373 = 1u8;
                                        fixed_u8::bit_and(a372, a373)
                                    };
                                    let a375 = 1u8;
                                    if equal(a374, a375) {
                                        1u64
                                    } else {
                                        0u64
                                    }
                                };
                                nat_add(a376, a377)?
                            };
                            nat_add(a378, a379)?
                        };
                        nat_add(a380, a381)?
                    }, Some(Adt1::C0(v0, false, false)));
                    match m382 {
                        None => {
                            Ok(None::<u64>)
                        }
                        Some(v6) => {
                            let m384 = f6(match v6.clone() {
                                Adt1::C0(h383, _, _) => {
                                    h383
                                }
                            });
                            match m384 {
                                None => {
                                    Ok(None::<u64>)
                                }
                                Some(v7) => {
                                    if if match v6.clone() {
                                        Adt1::C0(_, h385, _) => {
                                            h385
                                        }
                                    } {
                                        if match v6 {
                                            Adt1::C0(_, _, h386) => {
                                                h386
                                            }
                                        } {
                                            true
                                        } else {
                                            let a389 = {
                                                let a387 = v7;
                                                let a388 = 1u64;
                                                fixed_u64::bit_and(a387, a388)
                                            };
                                            let a390 = 1u64;
                                            equal(a389, a390)
                                        }
                                    } else {
                                        false
                                    } {
                                        let a391 = v7;
                                        let a392 = 1u64;
                                        Ok(fixed_u64::checked_add(a391, a392))
                                    } else {
                                        Ok(Some(v7))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

pub fn f5(v0: u32) -> R<Option<i64>> {
    let m393 = f9(Fn1::F10, 32u64, Some((v0, 0i64)))?;
    match m393 {
        None => {
            Ok(None::<i64>)
        }
        Some(v1) => {
            Ok(Some({
                let (_, h394) = v1;
                h394
            }))
        }
    }
}

pub fn f6(v0: Adt0) -> Option<u64> {
    let a396 = match v0.clone() {
        Adt0::C0(_, _, h395, _) => {
            h395
        }
    };
    let a397 = 0u32;
    if if equal(a396, a397) {
        let a399 = match v0.clone() {
            Adt0::C0(_, _, _, h398) => {
                h398
            }
        };
        let a400 = 0u32;
        equal(a399, a400)
    } else {
        false
    } {
        let m403 = {
            let a402 = match v0.clone() {
                Adt0::C0(h401, _, _, _) => {
                    h401
                }
            };
            fixed_u64::convert(i128::from(a402))
        };
        match m403 {
            None => {
                None::<u64>
            }
            Some(v1) => {
                let m406 = {
                    let a405 = match v0 {
                        Adt0::C0(_, h404, _, _) => {
                            h404
                        }
                    };
                    fixed_u64::convert(i128::from(a405))
                };
                match m406 {
                    None => {
                        None::<u64>
                    }
                    Some(v2) => {
                        let m409 = {
                            let a407 = v2;
                            let a408 = 32u32;
                            fixed_u64::shift_left(a407, a408)
                        };
                        match m409 {
                            None => {
                                None::<u64>
                            }
                            Some(v3) => {
                                Some({
                                    let a410 = v1;
                                    let a411 = v3;
                                    fixed_u64::bit_or(a410, a411)
                                })
                            }
                        }
                    }
                }
            }
        }
    } else {
        None::<u64>
    }
}

pub fn f7(v0: Fn0, p415: u64, p416: Option<Adt1>) -> Option<Adt1> {
    let m414 = (p415, p416);
    {
        let mut m414 = m414;
        loop {
            let step = {
                let (v1, v2) = m414;
                let m412 = v1;
                if m412 == 0 {
                    Err::<(u64, Option<Adt1>), Option<Adt1>>(v2)
                } else {
                    let v3 = m412 - 1;
                    Ok::<(u64, Option<Adt1>), Option<Adt1>>((v3, {
                        let c413: Fn0 = v0.clone();
                        c413.apply(v2)
                    }))
                }
            };
            match step {
                Ok(next) => { m414 = next; }
                Err(done) => break done,
            }
        }
    }
}

pub fn f8(v0: Option<Adt1>) -> Option<Adt1> {
    f11(v0)
}

pub fn f9(v0: Fn1, p420: u64, p421: Option<(u32, i64)>) -> R<Option<(u32, i64)>> {
    let m419 = (p420, p421);
    {
        let mut m419 = m419;
        loop {
            let step = {
                let (v1, v2) = m419;
                let m417 = v1;
                if m417 == 0 {
                    Err::<(u64, Option<(u32, i64)>), R<Option<(u32, i64)>>>(Ok(v2))
                } else {
                    let v3 = m417 - 1;
                    Ok::<(u64, Option<(u32, i64)>), R<Option<(u32, i64)>>>((v3, {
                        let c418: Fn1 = v0.clone();
                        c418.apply(v2)?
                    }))
                }
            };
            match step {
                Ok(next) => { m419 = next; }
                Err(done) => break done,
            }
        }
    }
}

pub fn f10(v0: Option<(u32, i64)>) -> R<Option<(u32, i64)>> {
    f12(v0)
}

pub fn f11(v0: Option<Adt1>) -> Option<Adt1> {
    let m422 = v0;
    match m422 {
        None => {
            None::<Adt1>
        }
        Some(v1) => {
            let m424 = f13(match v1.clone() {
                Adt1::C0(h423, _, _) => {
                    h423
                }
            });
            match m424 {
                None => {
                    None::<Adt1>
                }
                Some(v2) => {
                    Some(Adt1::C0(v2, {
                        let a430 = {
                            let a428 = {
                                let m427 = match v1.clone() {
                                    Adt1::C0(h426, _, _) => {
                                        h426
                                    }
                                };
                                match m427 {
                                    Adt0::C0(h425, _, _, _) => {
                                        h425
                                    }
                                }
                            };
                            let a429 = 1u32;
                            fixed_u32::bit_and(a428, a429)
                        };
                        let a431 = 1u32;
                        equal(a430, a431)
                    }, if match v1.clone() {
                        Adt1::C0(_, _, h432) => {
                            h432
                        }
                    } {
                        true
                    } else {
                        match v1 {
                            Adt1::C0(_, h433, _) => {
                                h433
                            }
                        }
                    }))
                }
            }
        }
    }
}

pub fn f12(v0: Option<(u32, i64)>) -> R<Option<(u32, i64)>> {
    let m434 = v0;
    match m434 {
        None => {
            Ok(None::<(u32, i64)>)
        }
        Some(v1) => {
            let m438 = {
                let a436 = {
                    let (h435, _) = v1;
                    h435
                };
                let a437 = 1u32;
                fixed_u32::shift_right(a436, a437)
            };
            match m438 {
                None => {
                    Ok(None::<(u32, i64)>)
                }
                Some(v2) => {
                    Ok(Some((v2, {
                        let a440 = {
                            let (h439, _) = v1;
                            h439
                        };
                        let a441 = 0u32;
                        if equal(a440, a441) {
                            let (_, h442) = v1;
                            h442
                        } else {
                            let a444 = {
                                let (_, h443) = v1;
                                h443
                            };
                            let a445 = -1i64;
                            int_sub(a444, a445)?
                        }
                    })))
                }
            }
        }
    }
}

pub fn f13(v0: Adt0) -> Option<Adt0> {
    let m449 = {
        let a447 = match v0.clone() {
            Adt0::C0(h446, _, _, _) => {
                h446
            }
        };
        let a448 = 1u32;
        fixed_u32::shift_right(a447, a448)
    };
    match m449 {
        None => {
            None::<Adt0>
        }
        Some(v1) => {
            let m453 = {
                let a451 = match v0.clone() {
                    Adt0::C0(_, h450, _, _) => {
                        h450
                    }
                };
                let a452 = 1u32;
                fixed_u32::shift_right(a451, a452)
            };
            match m453 {
                None => {
                    None::<Adt0>
                }
                Some(v2) => {
                    let m457 = {
                        let a455 = match v0.clone() {
                            Adt0::C0(_, _, h454, _) => {
                                h454
                            }
                        };
                        let a456 = 1u32;
                        fixed_u32::shift_right(a455, a456)
                    };
                    match m457 {
                        None => {
                            None::<Adt0>
                        }
                        Some(v3) => {
                            let m461 = {
                                let a459 = match v0.clone() {
                                    Adt0::C0(_, _, _, h458) => {
                                        h458
                                    }
                                };
                                let a460 = 1u32;
                                fixed_u32::shift_right(a459, a460)
                            };
                            match m461 {
                                None => {
                                    None::<Adt0>
                                }
                                Some(v4) => {
                                    let m467 = {
                                        let a465 = {
                                            let a463 = match v0.clone() {
                                                Adt0::C0(_, h462, _, _) => {
                                                    h462
                                                }
                                            };
                                            let a464 = 1u32;
                                            fixed_u32::bit_and(a463, a464)
                                        };
                                        let a466 = 31u32;
                                        fixed_u32::shift_left(a465, a466)
                                    };
                                    match m467 {
                                        None => {
                                            None::<Adt0>
                                        }
                                        Some(v5) => {
                                            let m473 = {
                                                let a471 = {
                                                    let a469 = match v0.clone() {
                                                        Adt0::C0(_, _, h468, _) => {
                                                            h468
                                                        }
                                                    };
                                                    let a470 = 1u32;
                                                    fixed_u32::bit_and(a469, a470)
                                                };
                                                let a472 = 31u32;
                                                fixed_u32::shift_left(a471, a472)
                                            };
                                            match m473 {
                                                None => {
                                                    None::<Adt0>
                                                }
                                                Some(v6) => {
                                                    let m479 = {
                                                        let a477 = {
                                                            let a475 = match v0 {
                                                                Adt0::C0(_, _, _, h474) => {
                                                                    h474
                                                                }
                                                            };
                                                            let a476 = 1u32;
                                                            fixed_u32::bit_and(a475, a476)
                                                        };
                                                        let a478 = 31u32;
                                                        fixed_u32::shift_left(a477, a478)
                                                    };
                                                    match m479 {
                                                        None => {
                                                            None::<Adt0>
                                                        }
                                                        Some(v7) => {
                                                            Some(Adt0::C0({
                                                                let a480 = v1;
                                                                let a481 = v5;
                                                                fixed_u32::bit_or(a480, a481)
                                                            }, {
                                                                let a482 = v2;
                                                                let a483 = v6;
                                                                fixed_u32::bit_or(a482, a483)
                                                            }, {
                                                                let a484 = v3;
                                                                let a485 = v7;
                                                                fixed_u32::bit_or(a484, a485)
                                                            }, v4))
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

pub fn run(p0: u32, p1: u32) -> R<Option<u32>> {
    f0(p0, p1)
}

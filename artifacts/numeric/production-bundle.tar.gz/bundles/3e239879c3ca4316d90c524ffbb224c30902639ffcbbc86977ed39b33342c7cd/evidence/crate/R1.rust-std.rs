#![forbid(unsafe_code)]
use core::cmp::Ordering;

use core::sync::atomic::{AtomicU64, Ordering as Memory};

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub struct Overflow;

pub type R<T> = Result<T, Overflow>;

static WORK: AtomicU64 = AtomicU64::new(0);

pub fn tick(units: u64) { WORK.fetch_add(units, Memory::Relaxed); }

pub fn work() -> u64 { WORK.load(Memory::Relaxed) }

pub trait Same {
    fn same(&self, other: &Self) -> bool;
}

pub trait Key {
    fn key(&self, other: &Self) -> Ordering;
}

impl Same for bool {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for bool {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u8 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u8 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u16 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u16 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u32 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u32 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u64 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u64 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i8 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i8 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i16 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i16 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i32 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i32 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i64 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i64 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for Ordering {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl<A: Key, B: Key> Key for (A, B) {
    fn key(&self, other: &Self) -> Ordering { match self.0.key(&other.0) { Ordering::Equal => self.1.key(&other.1), decided => decided, } }
}

pub fn equal<T: Same>(a: T, b: T) -> bool { a.same(&b) }

pub fn compare<T: Key>(a: T, b: T) -> Ordering { a.key(&b) }

pub fn nat_add(p0: u64, p1: u64) -> R<u64> {
    match u64::checked_add(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<u64, Overflow>(Overflow)
        }
    }
}

pub fn nat_sub(p0: u64, p1: u64) -> u64 {
    u64::saturating_sub(p0, p1)
}

pub fn nat_mul(p0: u64, p1: u64) -> R<u64> {
    match u64::checked_mul(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<u64, Overflow>(Overflow)
        }
    }
}

pub fn nat_quot(p0: u64, p1: u64, p2: u64) -> u64 {
    u64::checked_div(p0, p1).unwrap_or(p2)
}

pub fn nat_rem(p0: u64, p1: u64, p2: u64) -> u64 {
    u64::checked_rem(p0, p1).unwrap_or(p2)
}

pub fn nat_eq(p0: u64, p1: u64) -> bool {
    core::cmp::PartialEq::eq(&p0, &p1)
}

pub fn nat_le(p0: u64, p1: u64) -> bool {
    core::cmp::PartialOrd::le(&p0, &p1)
}

pub fn nat_lt(p0: u64, p1: u64) -> bool {
    core::cmp::PartialOrd::lt(&p0, &p1)
}

pub fn nat_succ(p0: u64) -> R<u64> {
    match u64::checked_add(p0, 1u64) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<u64, Overflow>(Overflow)
        }
    }
}

pub fn int_add(p0: i64, p1: i64) -> R<i64> {
    match i64::checked_add(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_sub(p0: i64, p1: i64) -> R<i64> {
    match i64::checked_sub(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_mul(p0: i64, p1: i64) -> R<i64> {
    match i64::checked_mul(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_neg(p0: i64) -> R<i64> {
    match i64::checked_neg(p0) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_quot(p0: i64, p1: i64, p2: i64) -> R<i64> {
    { let value = { let (a, b, z): (i64, i64, i64) = (p0, p1, p2); if b == 0 { Some(z) } else { a.checked_div(b) } }; match value {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    } }
}

pub fn int_rem(p0: i64, p1: i64, p2: i64) -> i64 {
    { let (a, b, z): (i64, i64, i64) = (p0, p1, p2); if b == 0 { z } else { a.wrapping_rem(b) } }
}

pub fn bool_not(p0: bool) -> bool {
    !p0
}

pub fn bool_and(p0: bool, p1: bool) -> bool {
    if p0 {
        p1
    } else {
        false
    }
}

pub fn bool_or(p0: bool, p1: bool) -> bool {
    if p0 {
        true
    } else {
        p1
    }
}

pub mod fixed_u8 {
    pub fn checked_add(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u8, p1: u8) -> u8 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u8, p1: u8) -> u8 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u8, p1: u8) -> u8 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u8) -> u8 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u8, p1: u32) -> Option<u8> {
        u8::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u8, p1: u32) -> Option<u8> {
        u8::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u8> {
        u8::try_from(p0).ok()
    }
}

pub mod fixed_u16 {
    pub fn checked_add(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u16, p1: u16) -> u16 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u16, p1: u16) -> u16 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u16, p1: u16) -> u16 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u16) -> u16 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u16, p1: u32) -> Option<u16> {
        u16::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u16, p1: u32) -> Option<u16> {
        u16::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u16> {
        u16::try_from(p0).ok()
    }
}

pub mod fixed_u32 {
    pub fn checked_add(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u32, p1: u32) -> u32 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u32, p1: u32) -> u32 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u32, p1: u32) -> u32 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u32) -> u32 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u32> {
        u32::try_from(p0).ok()
    }
}

pub mod fixed_u64 {
    pub fn checked_add(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u64, p1: u64) -> u64 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u64, p1: u64) -> u64 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u64, p1: u64) -> u64 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u64) -> u64 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u64, p1: u32) -> Option<u64> {
        u64::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u64, p1: u32) -> Option<u64> {
        u64::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u64> {
        u64::try_from(p0).ok()
    }
}

pub mod fixed_i8 {
    pub fn checked_add(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i8, p1: i8) -> i8 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i8, p1: i8) -> i8 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i8, p1: i8) -> i8 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i8) -> i8 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i8, p1: u32) -> Option<i8> {
        i8::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i8, p1: u32) -> Option<i8> {
        i8::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i8> {
        i8::try_from(p0).ok()
    }
}

pub fn checked_neg_i8(p0: i8) -> Option<i8> {
    i8::checked_neg(p0)
}

pub mod fixed_i16 {
    pub fn checked_add(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i16, p1: i16) -> i16 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i16, p1: i16) -> i16 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i16, p1: i16) -> i16 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i16) -> i16 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i16, p1: u32) -> Option<i16> {
        i16::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i16, p1: u32) -> Option<i16> {
        i16::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i16> {
        i16::try_from(p0).ok()
    }
}

pub fn checked_neg_i16(p0: i16) -> Option<i16> {
    i16::checked_neg(p0)
}

pub mod fixed_i32 {
    pub fn checked_add(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i32, p1: i32) -> i32 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i32, p1: i32) -> i32 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i32, p1: i32) -> i32 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i32) -> i32 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i32, p1: u32) -> Option<i32> {
        i32::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i32, p1: u32) -> Option<i32> {
        i32::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i32> {
        i32::try_from(p0).ok()
    }
}

pub fn checked_neg_i32(p0: i32) -> Option<i32> {
    i32::checked_neg(p0)
}

pub mod fixed_i64 {
    pub fn checked_add(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i64, p1: i64) -> i64 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i64, p1: i64) -> i64 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i64, p1: i64) -> i64 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i64) -> i64 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i64, p1: u32) -> Option<i64> {
        i64::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i64, p1: u32) -> Option<i64> {
        i64::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i64> {
        i64::try_from(p0).ok()
    }
}

pub fn checked_neg_i64(p0: i64) -> Option<i64> {
    i64::checked_neg(p0)
}
use core::str;

use std::mem;

use std::rc::Rc;

#[derive(Clone)]
pub struct Str(Rc<str>);

impl Str {
    pub fn lit(text: &str) -> Str { Str(Rc::from(text)) }
    pub fn text(&self) -> &str { &self.0 }
    pub fn length(&self) -> u64 { chars(&self.0) }
    pub fn utf8_encode(&self) -> Bytes { tick(self.0.len() as u64); Bytes::lit(self.0.as_bytes()) }
    pub fn split_exact(&self, delimiter: &Str, maximum: u32) -> Option<List<Str>> { if delimiter.0.is_empty() { return None; }; chars(&self.0); let mut fields: Vec<Str> = Vec::new(); for piece in self.0.split(&*delimiter.0) { fields.push(Str::lit(piece)); }; if fields.len() as u128 > u128::from(maximum) { return None; }; Some(List::onto(fields, List::nil())) }
    pub fn join(texts: List<Str>, delimiter: &Str) -> Str { let mut out = String::new(); let mut first = true; let mut cursor = &texts; while let Repr::Cell(cell) = &cursor.0 { tick(1); if !first { chars(&delimiter.0); out.push_str(&delimiter.0); }; first = false; chars(&cell.head.0); out.push_str(&cell.head.0); cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for text in buffer[..*len].iter().rev() { tick(1); if !first { chars(&delimiter.0); out.push_str(&delimiter.0); }; first = false; chars(&text.0); out.push_str(&text.0); } }, _ => { }, }; Str::lit(&out) }
}

#[derive(Clone)]
pub struct Bytes(Rc<[u8]>);

impl Bytes {
    pub fn lit(octets: &[u8]) -> Bytes { Bytes(Rc::from(octets)) }
    pub fn octets(&self) -> &[u8] { &self.0 }
    pub fn append(a: Bytes, b: Bytes) -> Bytes { tick((a.0.len() + b.0.len()) as u64); let mut out = Vec::with_capacity(a.0.len() + b.0.len()); out.extend_from_slice(&a.0); out.extend_from_slice(&b.0); Bytes(Rc::from(out)) }
    pub fn length(&self) -> u64 { self.0.len() as u64 }
    pub fn index(&self, i: u64) -> Option<u8> { match usize::try_from(i) { Ok(at) => self.0.get(at).copied(), Err(_) => None, } }
    pub fn slice(&self, start: u64, count: u64) -> Option<Bytes> { let end = u128::from(start) + u128::from(count); if end > self.0.len() as u128 { return None; }; tick(count); Some(Bytes::lit(&self.0[start as usize..end as usize])) }
    pub fn utf8_decode(&self) -> Option<Str> { tick(self.0.len() as u64); match str::from_utf8(&self.0) { Ok(text) => Some(Str::lit(text)), Err(_) => None, } }
    pub fn compare(&self, other: &Bytes) -> Ordering { tick(1 + self.0.len().min(other.0.len()) as u64); self.0.cmp(&other.0) }
}

pub struct Node<T> { head: T, tail: List<T> }

pub enum Repr<T> { Nil, Run { buffer: Rc<Vec<T>>, len: usize }, Cell(Rc<Node<T>>) }

pub struct List<T>(Repr<T>);

impl<T> Clone for List<T> {
    fn clone(&self) -> Self { List(match &self.0 { Repr::Nil => Repr::Nil, Repr::Run { buffer, len } => Repr::Run { buffer: buffer.clone(), len: *len }, Repr::Cell(cell) => Repr::Cell(cell.clone()), }) }
}

impl<T> List<T> {
    fn take(&mut self) -> Repr<T> { mem::replace(&mut self.0, Repr::Nil) }
}

impl<T> Drop for Node<T> {
    fn drop(&mut self) { let mut next = match self.tail.take() { Repr::Cell(cell) => Some(cell), _ => None, }; while let Some(cell) = next { match Rc::try_unwrap(cell) { Ok(mut node) => next = match node.tail.take() { Repr::Cell(cell) => Some(cell), _ => None, }, Err(_) => break, } } }
}

impl<T: Clone> List<T> {
    pub fn nil() -> Self { List(Repr::Nil) }
    pub fn cons(head: T, mut tail: List<T>) -> Self { List(match tail.take() { Repr::Nil => { let mut buffer = Vec::with_capacity(16); buffer.push(head); Repr::Run { buffer: Rc::new(buffer), len: 1 } }, Repr::Run { mut buffer, len } => { match Rc::get_mut(&mut buffer) { Some(cells) => { cells.truncate(len); cells.push(head); Repr::Run { buffer, len: len + 1 } }, None => Repr::Cell(Rc::new(Node { head, tail: List(Repr::Run { buffer, len }) })), } }, rest => Repr::Cell(Rc::new(Node { head, tail: List(rest) })), }) }
    pub fn uncons(&self) -> Option<(T, List<T>)> { match &self.0 { Repr::Nil => None, Repr::Run { buffer, len } => { let head = buffer[len - 1].clone(); Some((head, List(if *len == 1 { Repr::Nil } else { Repr::Run { buffer: buffer.clone(), len: len - 1 } }))) }, Repr::Cell(cell) => Some((cell.head.clone(), cell.tail.clone())), } }
    pub fn length(&self) -> u64 { let mut count = 0; let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); count += 1; cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for _ in buffer[..*len].iter().rev() { tick(1); count += 1; } }, _ => { }, }; count }
    pub fn append(a: List<T>, b: List<T>) -> List<T> { List::onto(a.items(), b) }
    pub fn index(&self, i: u64) -> Option<T> { let mut position = 0; let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); if position == i { return Some(cell.head.clone()); }; position += 1; cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for item in buffer[..*len].iter().rev() { tick(1); if position == i { return Some(item.clone()); }; position += 1; } }, _ => { }, }; None }
    pub fn slice(&self, start: u64, count: u64) -> Option<List<T>> { let end = u128::from(start) + u128::from(count); let mut part = Vec::new(); let mut position: u128 = 0; let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); if position >= end { return Some(List::onto(part, List::nil())); }; if position >= u128::from(start) { part.push(cell.head.clone()); }; position += 1; cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for item in buffer[..*len].iter().rev() { tick(1); if position >= end { return Some(List::onto(part, List::nil())); }; if position >= u128::from(start) { part.push(item.clone()); }; position += 1; } }, _ => { }, }; if position < end { None } else { Some(List::onto(part, List::nil())) } }
    fn items(&self) -> Vec<T> { let mut out = Vec::new(); let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); out.push(cell.head.clone()); cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for item in buffer[..*len].iter().rev() { tick(1); out.push(item.clone()); } }, _ => { }, }; out }
    fn onto(mut items: Vec<T>, tail: List<T>) -> List<T> { let mut out = tail; while let Some(item) = items.pop() { tick(1); out = List::cons(item, out); }; out }
}

pub fn chars(text: &str) -> u64 { let mut count = 0; for _ in text.chars() { tick(1); count += 1; }; count }

impl Same for Str {
    fn same(&self, other: &Self) -> bool { let mut left = self.0.chars(); let mut right = other.0.chars(); loop { tick(1); match (left.next(), right.next()) { (None, None) => return true, (a, b) if a != b => return false, _ => { }, } } }
}

impl Same for Bytes {
    fn same(&self, other: &Self) -> bool { tick(1 + self.0.len().min(other.0.len()) as u64); self.0 == other.0 }
}

impl Key for Str {
    fn key(&self, other: &Self) -> Ordering { let mut left = self.0.chars(); let mut right = other.0.chars(); loop { tick(1); match (left.next(), right.next()) { (None, None) => return Ordering::Equal, (None, Some(_)) => return Ordering::Less, (Some(_), None) => return Ordering::Greater, (Some(a), Some(b)) => match a.cmp(&b) { Ordering::Equal => { }, decided => return decided, }, } } }
}

pub fn canonical_decimal(text: &str) -> Option<Option<i128>> { let digits = match text.strip_prefix('-') { Some(rest) => rest, None => text, }; let mut canonical = !digits.is_empty() && (digits == "0" || !digits.starts_with('0')) && text != "-0"; for c in digits.chars() { tick(1); canonical = canonical && c.is_ascii_digit(); }; if !canonical { return None; }; Some(text.parse::<i128>().ok()) }

pub fn parse_int(text: Str) -> R<Option<i64>> { match canonical_decimal(&text.0) { None => Ok(None), Some(Some(n)) => match i64::try_from(n) { Ok(value) => Ok(Some(value)), Err(_) => Err(Overflow), }, Some(None) => Err(Overflow), } }

pub fn format_u8(a: u8) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u8(text: Str) -> Option<u8> { match canonical_decimal(&text.0) { Some(Some(n)) => u8::try_from(n).ok(), _ => None, } }

pub fn format_u16(a: u16) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u16(text: Str) -> Option<u16> { match canonical_decimal(&text.0) { Some(Some(n)) => u16::try_from(n).ok(), _ => None, } }

pub fn format_u32(a: u32) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u32(text: Str) -> Option<u32> { match canonical_decimal(&text.0) { Some(Some(n)) => u32::try_from(n).ok(), _ => None, } }

pub fn format_u64(a: u64) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u64(text: Str) -> Option<u64> { match canonical_decimal(&text.0) { Some(Some(n)) => u64::try_from(n).ok(), _ => None, } }

pub fn format_i8(a: i8) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i8(text: Str) -> Option<i8> { match canonical_decimal(&text.0) { Some(Some(n)) => i8::try_from(n).ok(), _ => None, } }

pub fn format_i16(a: i16) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i16(text: Str) -> Option<i16> { match canonical_decimal(&text.0) { Some(Some(n)) => i16::try_from(n).ok(), _ => None, } }

pub fn format_i32(a: i32) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i32(text: Str) -> Option<i32> { match canonical_decimal(&text.0) { Some(Some(n)) => i32::try_from(n).ok(), _ => None, } }

pub fn format_i64(a: i64) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i64(text: Str) -> Option<i64> { match canonical_decimal(&text.0) { Some(Some(n)) => i64::try_from(n).ok(), _ => None, } }

pub fn append_list<T: Clone>(p0: List<T>, p1: List<T>) -> List<T> {
    List::append(p0, p1)
}

pub fn length_list<T: Clone>(p0: List<T>) -> u64 {
    List::length(&p0)
}

pub fn index_list<T: Clone>(p0: List<T>, p1: u64) -> Option<T> {
    List::index(&p0, p1)
}

pub fn slice_list<T: Clone>(p0: List<T>, p1: u64, p2: u64) -> Option<List<T>> {
    List::slice(&p0, p1, p2)
}

pub fn append_bytes(p0: Bytes, p1: Bytes) -> Bytes {
    Bytes::append(p0, p1)
}

pub fn length_bytes(p0: Bytes) -> u64 {
    Bytes::length(&p0)
}

pub fn length_string(p0: Str) -> u64 {
    Str::length(&p0)
}

pub fn index_bytes(p0: Bytes, p1: u64) -> Option<u8> {
    Bytes::index(&p0, p1)
}

pub fn slice_bytes(p0: Bytes, p1: u64, p2: u64) -> Option<Bytes> {
    Bytes::slice(&p0, p1, p2)
}

pub fn utf8_encode(p0: Str) -> Bytes {
    Str::utf8_encode(&p0)
}

pub fn utf8_decode(p0: Bytes) -> Option<Str> {
    Bytes::utf8_decode(&p0)
}

pub fn compare_bytes(p0: Bytes, p1: Bytes) -> Ordering {
    Bytes::compare(&p0, &p1)
}

pub fn split_exact(p0: Str, p1: Str, p2: u32) -> Option<List<Str>> {
    Str::split_exact(&p0, &p1, p2)
}

pub fn join(p0: List<Str>, p1: Str) -> Str {
    Str::join(p0, &p1)
}

#[derive(Clone)]
pub enum Adt0 {
    C0(u32, u32, u32, u32),
}

#[derive(Clone)]
pub enum Adt1 {
    C0(Adt0, bool, bool),
}

#[derive(Clone)]
pub enum Fn0 {
    F8,
}

impl Fn0 {
    pub fn apply(&self, p0: Option<Adt1>) -> Option<Adt1> {
        match self {
            Fn0::F8 => f8(p0),
        }
    }
}

#[derive(Clone)]
pub enum Fn1 {
    F10,
}

impl Fn1 {
    pub fn apply(&self, p0: Option<(u32, i64)>) -> R<Option<(u32, i64)>> {
        match self {
            Fn1::F10 => f10(p0),
        }
    }
}

pub fn f0(v0: u64, v1: u64) -> R<Option<u64>> {
    f1(v0, v1)
}

pub fn f1(v0: u64, v1: u64) -> R<Option<u64>> {
    let v2: u64 = {
        let a3 = {
            let a1 = v0;
            let a2 = v1;
            fixed_u64::bit_xor(a1, a2)
        };
        let a4 = 9223372036854775808u64;
        fixed_u64::bit_and(a3, a4)
    };
    let v3: u64 = {
        let a5 = v0;
        let a6 = 4503599627370495u64;
        fixed_u64::bit_and(a5, a6)
    };
    let v4: u64 = {
        let a7 = v1;
        let a8 = 4503599627370495u64;
        fixed_u64::bit_and(a7, a8)
    };
    let m11 = {
        let a9 = v0;
        let a10 = 52u32;
        fixed_u64::shift_right(a9, a10)
    };
    match m11 {
        None => {
            Ok(None::<u64>)
        }
        Some(v5) => {
            let m14 = {
                let a12 = v1;
                let a13 = 52u32;
                fixed_u64::shift_right(a12, a13)
            };
            match m14 {
                None => {
                    Ok(None::<u64>)
                }
                Some(v6) => {
                    let v7: u64 = {
                        let a15 = v5;
                        let a16 = 2047u64;
                        fixed_u64::bit_and(a15, a16)
                    };
                    let v8: u64 = {
                        let a17 = v6;
                        let a18 = 2047u64;
                        fixed_u64::bit_and(a17, a18)
                    };
                    let a19 = v7;
                    let a20 = 2047u64;
                    if if equal(a19, a20) {
                        let a23 = {
                            let a21 = v3;
                            let a22 = 0u64;
                            equal(a21, a22)
                        };
                        bool_not(a23)
                    } else {
                        false
                    } {
                        Ok(Some({
                            let a24 = v0;
                            let a25 = 2251799813685248u64;
                            fixed_u64::bit_or(a24, a25)
                        }))
                    } else {
                        let a26 = v8;
                        let a27 = 2047u64;
                        if if equal(a26, a27) {
                            let a30 = {
                                let a28 = v4;
                                let a29 = 0u64;
                                equal(a28, a29)
                            };
                            bool_not(a30)
                        } else {
                            false
                        } {
                            Ok(Some({
                                let a31 = v1;
                                let a32 = 2251799813685248u64;
                                fixed_u64::bit_or(a31, a32)
                            }))
                        } else {
                            let a33 = v7;
                            let a34 = 2047u64;
                            if if equal(a33, a34) {
                                true
                            } else {
                                let a35 = v8;
                                let a36 = 2047u64;
                                equal(a35, a36)
                            } {
                                Ok(Some({
                                    let a39 = {
                                        let a37 = v0;
                                        let a38 = 9223372036854775807u64;
                                        fixed_u64::bit_and(a37, a38)
                                    };
                                    let a40 = 0u64;
                                    if if equal(a39, a40) {
                                        true
                                    } else {
                                        let a43 = {
                                            let a41 = v1;
                                            let a42 = 9223372036854775807u64;
                                            fixed_u64::bit_and(a41, a42)
                                        };
                                        let a44 = 0u64;
                                        equal(a43, a44)
                                    } {
                                        9221120237041090560u64
                                    } else {
                                        let a45 = v2;
                                        let a46 = 9218868437227405312u64;
                                        fixed_u64::bit_or(a45, a46)
                                    }
                                }))
                            } else {
                                let a49 = {
                                    let a47 = v0;
                                    let a48 = 9223372036854775807u64;
                                    fixed_u64::bit_and(a47, a48)
                                };
                                let a50 = 0u64;
                                if if equal(a49, a50) {
                                    true
                                } else {
                                    let a53 = {
                                        let a51 = v1;
                                        let a52 = 9223372036854775807u64;
                                        fixed_u64::bit_and(a51, a52)
                                    };
                                    let a54 = 0u64;
                                    equal(a53, a54)
                                } {
                                    Ok(Some(v2))
                                } else {
                                    let m56 = {
                                        let a55 = v7;
                                        fixed_u16::convert(i128::from(a55))
                                    };
                                    match m56 {
                                        None => {
                                            Ok(None::<u64>)
                                        }
                                        Some(v9) => {
                                            let m58 = {
                                                let a57 = v8;
                                                fixed_u16::convert(i128::from(a57))
                                            };
                                            match m58 {
                                                None => {
                                                    Ok(None::<u64>)
                                                }
                                                Some(v10) => {
                                                    let v11: u64 = {
                                                        let a59 = v7;
                                                        let a60 = 0u64;
                                                        if equal(a59, a60) {
                                                            v3
                                                        } else {
                                                            let a61 = v3;
                                                            let a62 = 4503599627370496u64;
                                                            fixed_u64::bit_or(a61, a62)
                                                        }
                                                    };
                                                    let v12: u64 = {
                                                        let a63 = v8;
                                                        let a64 = 0u64;
                                                        if equal(a63, a64) {
                                                            v4
                                                        } else {
                                                            let a65 = v4;
                                                            let a66 = 4503599627370496u64;
                                                            fixed_u64::bit_or(a65, a66)
                                                        }
                                                    };
                                                    let v14: i64 = {
                                                        let a67 = v7;
                                                        let a68 = 0u64;
                                                        if equal(a67, a68) {
                                                            1i64
                                                        } else {
                                                            let v13: u16 = v9;
                                                            let a176 = {
                                                                let a120 = {
                                                                    let a92 = {
                                                                        let a78 = {
                                                                            let a71 = {
                                                                                let a69 = v13;
                                                                                let a70 = 32768u16;
                                                                                fixed_u16::bit_and(a69, a70)
                                                                            };
                                                                            let a72 = 32768u16;
                                                                            if equal(a71, a72) {
                                                                                32768i64
                                                                            } else {
                                                                                0i64
                                                                            }
                                                                        };
                                                                        let a79 = {
                                                                            let a77 = {
                                                                                let a75 = {
                                                                                    let a73 = v13;
                                                                                    let a74 = 16384u16;
                                                                                    fixed_u16::bit_and(a73, a74)
                                                                                };
                                                                                let a76 = 16384u16;
                                                                                if equal(a75, a76) {
                                                                                    16384i64
                                                                                } else {
                                                                                    0i64
                                                                                }
                                                                            };
                                                                            int_neg(a77)?
                                                                        };
                                                                        int_sub(a78, a79)?
                                                                    };
                                                                    let a93 = {
                                                                        let a91 = {
                                                                            let a89 = {
                                                                                let a82 = {
                                                                                    let a80 = v13;
                                                                                    let a81 = 8192u16;
                                                                                    fixed_u16::bit_and(a80, a81)
                                                                                };
                                                                                let a83 = 8192u16;
                                                                                if equal(a82, a83) {
                                                                                    8192i64
                                                                                } else {
                                                                                    0i64
                                                                                }
                                                                            };
                                                                            let a90 = {
                                                                                let a88 = {
                                                                                    let a86 = {
                                                                                        let a84 = v13;
                                                                                        let a85 = 4096u16;
                                                                                        fixed_u16::bit_and(a84, a85)
                                                                                    };
                                                                                    let a87 = 4096u16;
                                                                                    if equal(a86, a87) {
                                                                                        4096i64
                                                                                    } else {
                                                                                        0i64
                                                                                    }
                                                                                };
                                                                                int_neg(a88)?
                                                                            };
                                                                            int_sub(a89, a90)?
                                                                        };
                                                                        int_neg(a91)?
                                                                    };
                                                                    int_sub(a92, a93)?
                                                                };
                                                                let a121 = {
                                                                    let a119 = {
                                                                        let a117 = {
                                                                            let a103 = {
                                                                                let a96 = {
                                                                                    let a94 = v13;
                                                                                    let a95 = 2048u16;
                                                                                    fixed_u16::bit_and(a94, a95)
                                                                                };
                                                                                let a97 = 2048u16;
                                                                                if equal(a96, a97) {
                                                                                    2048i64
                                                                                } else {
                                                                                    0i64
                                                                                }
                                                                            };
                                                                            let a104 = {
                                                                                let a102 = {
                                                                                    let a100 = {
                                                                                        let a98 = v13;
                                                                                        let a99 = 1024u16;
                                                                                        fixed_u16::bit_and(a98, a99)
                                                                                    };
                                                                                    let a101 = 1024u16;
                                                                                    if equal(a100, a101) {
                                                                                        1024i64
                                                                                    } else {
                                                                                        0i64
                                                                                    }
                                                                                };
                                                                                int_neg(a102)?
                                                                            };
                                                                            int_sub(a103, a104)?
                                                                        };
                                                                        let a118 = {
                                                                            let a116 = {
                                                                                let a114 = {
                                                                                    let a107 = {
                                                                                        let a105 = v13;
                                                                                        let a106 = 512u16;
                                                                                        fixed_u16::bit_and(a105, a106)
                                                                                    };
                                                                                    let a108 = 512u16;
                                                                                    if equal(a107, a108) {
                                                                                        512i64
                                                                                    } else {
                                                                                        0i64
                                                                                    }
                                                                                };
                                                                                let a115 = {
                                                                                    let a113 = {
                                                                                        let a111 = {
                                                                                            let a109 = v13;
                                                                                            let a110 = 256u16;
                                                                                            fixed_u16::bit_and(a109, a110)
                                                                                        };
                                                                                        let a112 = 256u16;
                                                                                        if equal(a111, a112) {
                                                                                            256i64
                                                                                        } else {
                                                                                            0i64
                                                                                        }
                                                                                    };
                                                                                    int_neg(a113)?
                                                                                };
                                                                                int_sub(a114, a115)?
                                                                            };
                                                                            int_neg(a116)?
                                                                        };
                                                                        int_sub(a117, a118)?
                                                                    };
                                                                    int_neg(a119)?
                                                                };
                                                                int_sub(a120, a121)?
                                                            };
                                                            let a177 = {
                                                                let a175 = {
                                                                    let a173 = {
                                                                        let a145 = {
                                                                            let a131 = {
                                                                                let a124 = {
                                                                                    let a122 = v13;
                                                                                    let a123 = 128u16;
                                                                                    fixed_u16::bit_and(a122, a123)
                                                                                };
                                                                                let a125 = 128u16;
                                                                                if equal(a124, a125) {
                                                                                    128i64
                                                                                } else {
                                                                                    0i64
                                                                                }
                                                                            };
                                                                            let a132 = {
                                                                                let a130 = {
                                                                                    let a128 = {
                                                                                        let a126 = v13;
                                                                                        let a127 = 64u16;
                                                                                        fixed_u16::bit_and(a126, a127)
                                                                                    };
                                                                                    let a129 = 64u16;
                                                                                    if equal(a128, a129) {
                                                                                        64i64
                                                                                    } else {
                                                                                        0i64
                                                                                    }
                                                                                };
                                                                                int_neg(a130)?
                                                                            };
                                                                            int_sub(a131, a132)?
                                                                        };
                                                                        let a146 = {
                                                                            let a144 = {
                                                                                let a142 = {
                                                                                    let a135 = {
                                                                                        let a133 = v13;
                                                                                        let a134 = 32u16;
                                                                                        fixed_u16::bit_and(a133, a134)
                                                                                    };
                                                                                    let a136 = 32u16;
                                                                                    if equal(a135, a136) {
                                                                                        32i64
                                                                                    } else {
                                                                                        0i64
                                                                                    }
                                                                                };
                                                                                let a143 = {
                                                                                    let a141 = {
                                                                                        let a139 = {
                                                                                            let a137 = v13;
                                                                                            let a138 = 16u16;
                                                                                            fixed_u16::bit_and(a137, a138)
                                                                                        };
                                                                                        let a140 = 16u16;
                                                                                        if equal(a139, a140) {
                                                                                            16i64
                                                                                        } else {
                                                                                            0i64
                                                                                        }
                                                                                    };
                                                                                    int_neg(a141)?
                                                                                };
                                                                                int_sub(a142, a143)?
                                                                            };
                                                                            int_neg(a144)?
                                                                        };
                                                                        int_sub(a145, a146)?
                                                                    };
                                                                    let a174 = {
                                                                        let a172 = {
                                                                            let a170 = {
                                                                                let a156 = {
                                                                                    let a149 = {
                                                                                        let a147 = v13;
                                                                                        let a148 = 8u16;
                                                                                        fixed_u16::bit_and(a147, a148)
                                                                                    };
                                                                                    let a150 = 8u16;
                                                                                    if equal(a149, a150) {
                                                                                        8i64
                                                                                    } else {
                                                                                        0i64
                                                                                    }
                                                                                };
                                                                                let a157 = {
                                                                                    let a155 = {
                                                                                        let a153 = {
                                                                                            let a151 = v13;
                                                                                            let a152 = 4u16;
                                                                                            fixed_u16::bit_and(a151, a152)
                                                                                        };
                                                                                        let a154 = 4u16;
                                                                                        if equal(a153, a154) {
                                                                                            4i64
                                                                                        } else {
                                                                                            0i64
                                                                                        }
                                                                                    };
                                                                                    int_neg(a155)?
                                                                                };
                                                                                int_sub(a156, a157)?
                                                                            };
                                                                            let a171 = {
                                                                                let a169 = {
                                                                                    let a167 = {
                                                                                        let a160 = {
                                                                                            let a158 = v13;
                                                                                            let a159 = 2u16;
                                                                                            fixed_u16::bit_and(a158, a159)
                                                                                        };
                                                                                        let a161 = 2u16;
                                                                                        if equal(a160, a161) {
                                                                                            2i64
                                                                                        } else {
                                                                                            0i64
                                                                                        }
                                                                                    };
                                                                                    let a168 = {
                                                                                        let a166 = {
                                                                                            let a164 = {
                                                                                                let a162 = v13;
                                                                                                let a163 = 1u16;
                                                                                                fixed_u16::bit_and(a162, a163)
                                                                                            };
                                                                                            let a165 = 1u16;
                                                                                            if equal(a164, a165) {
                                                                                                1i64
                                                                                            } else {
                                                                                                0i64
                                                                                            }
                                                                                        };
                                                                                        int_neg(a166)?
                                                                                    };
                                                                                    int_sub(a167, a168)?
                                                                                };
                                                                                int_neg(a169)?
                                                                            };
                                                                            int_sub(a170, a171)?
                                                                        };
                                                                        int_neg(a172)?
                                                                    };
                                                                    int_sub(a173, a174)?
                                                                };
                                                                int_neg(a175)?
                                                            };
                                                            int_sub(a176, a177)?
                                                        }
                                                    };
                                                    let v16: i64 = {
                                                        let a178 = v8;
                                                        let a179 = 0u64;
                                                        if equal(a178, a179) {
                                                            1i64
                                                        } else {
                                                            let v15: u16 = v10;
                                                            let a287 = {
                                                                let a231 = {
                                                                    let a203 = {
                                                                        let a189 = {
                                                                            let a182 = {
                                                                                let a180 = v15;
                                                                                let a181 = 32768u16;
                                                                                fixed_u16::bit_and(a180, a181)
                                                                            };
                                                                            let a183 = 32768u16;
                                                                            if equal(a182, a183) {
                                                                                32768i64
                                                                            } else {
                                                                                0i64
                                                                            }
                                                                        };
                                                                        let a190 = {
                                                                            let a188 = {
                                                                                let a186 = {
                                                                                    let a184 = v15;
                                                                                    let a185 = 16384u16;
                                                                                    fixed_u16::bit_and(a184, a185)
                                                                                };
                                                                                let a187 = 16384u16;
                                                                                if equal(a186, a187) {
                                                                                    16384i64
                                                                                } else {
                                                                                    0i64
                                                                                }
                                                                            };
                                                                            int_neg(a188)?
                                                                        };
                                                                        int_sub(a189, a190)?
                                                                    };
                                                                    let a204 = {
                                                                        let a202 = {
                                                                            let a200 = {
                                                                                let a193 = {
                                                                                    let a191 = v15;
                                                                                    let a192 = 8192u16;
                                                                                    fixed_u16::bit_and(a191, a192)
                                                                                };
                                                                                let a194 = 8192u16;
                                                                                if equal(a193, a194) {
                                                                                    8192i64
                                                                                } else {
                                                                                    0i64
                                                                                }
                                                                            };
                                                                            let a201 = {
                                                                                let a199 = {
                                                                                    let a197 = {
                                                                                        let a195 = v15;
                                                                                        let a196 = 4096u16;
                                                                                        fixed_u16::bit_and(a195, a196)
                                                                                    };
                                                                                    let a198 = 4096u16;
                                                                                    if equal(a197, a198) {
                                                                                        4096i64
                                                                                    } else {
                                                                                        0i64
                                                                                    }
                                                                                };
                                                                                int_neg(a199)?
                                                                            };
                                                                            int_sub(a200, a201)?
                                                                        };
                                                                        int_neg(a202)?
                                                                    };
                                                                    int_sub(a203, a204)?
                                                                };
                                                                let a232 = {
                                                                    let a230 = {
                                                                        let a228 = {
                                                                            let a214 = {
                                                                                let a207 = {
                                                                                    let a205 = v15;
                                                                                    let a206 = 2048u16;
                                                                                    fixed_u16::bit_and(a205, a206)
                                                                                };
                                                                                let a208 = 2048u16;
                                                                                if equal(a207, a208) {
                                                                                    2048i64
                                                                                } else {
                                                                                    0i64
                                                                                }
                                                                            };
                                                                            let a215 = {
                                                                                let a213 = {
                                                                                    let a211 = {
                                                                                        let a209 = v15;
                                                                                        let a210 = 1024u16;
                                                                                        fixed_u16::bit_and(a209, a210)
                                                                                    };
                                                                                    let a212 = 1024u16;
                                                                                    if equal(a211, a212) {
                                                                                        1024i64
                                                                                    } else {
                                                                                        0i64
                                                                                    }
                                                                                };
                                                                                int_neg(a213)?
                                                                            };
                                                                            int_sub(a214, a215)?
                                                                        };
                                                                        let a229 = {
                                                                            let a227 = {
                                                                                let a225 = {
                                                                                    let a218 = {
                                                                                        let a216 = v15;
                                                                                        let a217 = 512u16;
                                                                                        fixed_u16::bit_and(a216, a217)
                                                                                    };
                                                                                    let a219 = 512u16;
                                                                                    if equal(a218, a219) {
                                                                                        512i64
                                                                                    } else {
                                                                                        0i64
                                                                                    }
                                                                                };
                                                                                let a226 = {
                                                                                    let a224 = {
                                                                                        let a222 = {
                                                                                            let a220 = v15;
                                                                                            let a221 = 256u16;
                                                                                            fixed_u16::bit_and(a220, a221)
                                                                                        };
                                                                                        let a223 = 256u16;
                                                                                        if equal(a222, a223) {
                                                                                            256i64
                                                                                        } else {
                                                                                            0i64
                                                                                        }
                                                                                    };
                                                                                    int_neg(a224)?
                                                                                };
                                                                                int_sub(a225, a226)?
                                                                            };
                                                                            int_neg(a227)?
                                                                        };
                                                                        int_sub(a228, a229)?
                                                                    };
                                                                    int_neg(a230)?
                                                                };
                                                                int_sub(a231, a232)?
                                                            };
                                                            let a288 = {
                                                                let a286 = {
                                                                    let a284 = {
                                                                        let a256 = {
                                                                            let a242 = {
                                                                                let a235 = {
                                                                                    let a233 = v15;
                                                                                    let a234 = 128u16;
                                                                                    fixed_u16::bit_and(a233, a234)
                                                                                };
                                                                                let a236 = 128u16;
                                                                                if equal(a235, a236) {
                                                                                    128i64
                                                                                } else {
                                                                                    0i64
                                                                                }
                                                                            };
                                                                            let a243 = {
                                                                                let a241 = {
                                                                                    let a239 = {
                                                                                        let a237 = v15;
                                                                                        let a238 = 64u16;
                                                                                        fixed_u16::bit_and(a237, a238)
                                                                                    };
                                                                                    let a240 = 64u16;
                                                                                    if equal(a239, a240) {
                                                                                        64i64
                                                                                    } else {
                                                                                        0i64
                                                                                    }
                                                                                };
                                                                                int_neg(a241)?
                                                                            };
                                                                            int_sub(a242, a243)?
                                                                        };
                                                                        let a257 = {
                                                                            let a255 = {
                                                                                let a253 = {
                                                                                    let a246 = {
                                                                                        let a244 = v15;
                                                                                        let a245 = 32u16;
                                                                                        fixed_u16::bit_and(a244, a245)
                                                                                    };
                                                                                    let a247 = 32u16;
                                                                                    if equal(a246, a247) {
                                                                                        32i64
                                                                                    } else {
                                                                                        0i64
                                                                                    }
                                                                                };
                                                                                let a254 = {
                                                                                    let a252 = {
                                                                                        let a250 = {
                                                                                            let a248 = v15;
                                                                                            let a249 = 16u16;
                                                                                            fixed_u16::bit_and(a248, a249)
                                                                                        };
                                                                                        let a251 = 16u16;
                                                                                        if equal(a250, a251) {
                                                                                            16i64
                                                                                        } else {
                                                                                            0i64
                                                                                        }
                                                                                    };
                                                                                    int_neg(a252)?
                                                                                };
                                                                                int_sub(a253, a254)?
                                                                            };
                                                                            int_neg(a255)?
                                                                        };
                                                                        int_sub(a256, a257)?
                                                                    };
                                                                    let a285 = {
                                                                        let a283 = {
                                                                            let a281 = {
                                                                                let a267 = {
                                                                                    let a260 = {
                                                                                        let a258 = v15;
                                                                                        let a259 = 8u16;
                                                                                        fixed_u16::bit_and(a258, a259)
                                                                                    };
                                                                                    let a261 = 8u16;
                                                                                    if equal(a260, a261) {
                                                                                        8i64
                                                                                    } else {
                                                                                        0i64
                                                                                    }
                                                                                };
                                                                                let a268 = {
                                                                                    let a266 = {
                                                                                        let a264 = {
                                                                                            let a262 = v15;
                                                                                            let a263 = 4u16;
                                                                                            fixed_u16::bit_and(a262, a263)
                                                                                        };
                                                                                        let a265 = 4u16;
                                                                                        if equal(a264, a265) {
                                                                                            4i64
                                                                                        } else {
                                                                                            0i64
                                                                                        }
                                                                                    };
                                                                                    int_neg(a266)?
                                                                                };
                                                                                int_sub(a267, a268)?
                                                                            };
                                                                            let a282 = {
                                                                                let a280 = {
                                                                                    let a278 = {
                                                                                        let a271 = {
                                                                                            let a269 = v15;
                                                                                            let a270 = 2u16;
                                                                                            fixed_u16::bit_and(a269, a270)
                                                                                        };
                                                                                        let a272 = 2u16;
                                                                                        if equal(a271, a272) {
                                                                                            2i64
                                                                                        } else {
                                                                                            0i64
                                                                                        }
                                                                                    };
                                                                                    let a279 = {
                                                                                        let a277 = {
                                                                                            let a275 = {
                                                                                                let a273 = v15;
                                                                                                let a274 = 1u16;
                                                                                                fixed_u16::bit_and(a273, a274)
                                                                                            };
                                                                                            let a276 = 1u16;
                                                                                            if equal(a275, a276) {
                                                                                                1i64
                                                                                            } else {
                                                                                                0i64
                                                                                            }
                                                                                        };
                                                                                        int_neg(a277)?
                                                                                    };
                                                                                    int_sub(a278, a279)?
                                                                                };
                                                                                int_neg(a280)?
                                                                            };
                                                                            int_sub(a281, a282)?
                                                                        };
                                                                        int_neg(a283)?
                                                                    };
                                                                    int_sub(a284, a285)?
                                                                };
                                                                int_neg(a286)?
                                                            };
                                                            int_sub(a287, a288)?
                                                        }
                                                    };
                                                    let v17: i64 = {
                                                        let a292 = {
                                                            let a290 = v14;
                                                            let a291 = {
                                                                let a289 = v16;
                                                                int_neg(a289)?
                                                            };
                                                            int_sub(a290, a291)?
                                                        };
                                                        let a293 = 2150i64;
                                                        int_sub(a292, a293)?
                                                    };
                                                    let m294 = f2(v11, v12);
                                                    match m294 {
                                                        None => {
                                                            Ok(None::<u64>)
                                                        }
                                                        Some(v18) => {
                                                            let m295 = f3(v18.clone())?;
                                                            match m295 {
                                                                None => {
                                                                    Ok(None::<u64>)
                                                                }
                                                                Some(v19) => {
                                                                    let v20: i64 = {
                                                                        let a296 = v19;
                                                                        let a297 = 1i64;
                                                                        int_sub(a296, a297)?
                                                                    };
                                                                    let v21: i64 = {
                                                                        let a299 = v20;
                                                                        let a300 = {
                                                                            let a298 = v17;
                                                                            int_neg(a298)?
                                                                        };
                                                                        int_sub(a299, a300)?
                                                                    };
                                                                    let v22: i64 = {
                                                                        let a301 = v20;
                                                                        let a302 = 52i64;
                                                                        int_sub(a301, a302)?
                                                                    };
                                                                    let v23: i64 = {
                                                                        let a303 = -1074i64;
                                                                        let a304 = v17;
                                                                        int_sub(a303, a304)?
                                                                    };
                                                                    let v24: i64 = {
                                                                        let m307 = {
                                                                            let a305 = v22;
                                                                            let a306 = v23;
                                                                            compare(a305, a306)
                                                                        };
                                                                        if match m307 {
                                                                            Ordering::Less => {
                                                                                true
                                                                            }
                                                                            Ordering::Equal => {
                                                                                false
                                                                            }
                                                                            Ordering::Greater => {
                                                                                false
                                                                            }
                                                                        } {
                                                                            v23
                                                                        } else {
                                                                            v22
                                                                        }
                                                                    };
                                                                    let m308 = f4(v18, v24)?;
                                                                    match m308 {
                                                                        None => {
                                                                            Ok(None::<u64>)
                                                                        }
                                                                        Some(v25) => {
                                                                            let v26: bool = {
                                                                                let a309 = v25;
                                                                                let a310 = 9007199254740992u64;
                                                                                equal(a309, a310)
                                                                            };
                                                                            let v27: i64 = if v26 {
                                                                                let a311 = v21;
                                                                                let a312 = -1i64;
                                                                                int_sub(a311, a312)?
                                                                            } else {
                                                                                v21
                                                                            };
                                                                            let v28: i64 = {
                                                                                let m315 = {
                                                                                    let a313 = v27;
                                                                                    let a314 = -1022i64;
                                                                                    compare(a313, a314)
                                                                                };
                                                                                if match m315 {
                                                                                    Ordering::Less => {
                                                                                        true
                                                                                    }
                                                                                    Ordering::Equal => {
                                                                                        false
                                                                                    }
                                                                                    Ordering::Greater => {
                                                                                        false
                                                                                    }
                                                                                } {
                                                                                    let m318 = {
                                                                                        let a316 = v25;
                                                                                        let a317 = 4503599627370496u64;
                                                                                        compare(a316, a317)
                                                                                    };
                                                                                    if match m318 {
                                                                                        Ordering::Less => {
                                                                                            true
                                                                                        }
                                                                                        Ordering::Equal => {
                                                                                            false
                                                                                        }
                                                                                        Ordering::Greater => {
                                                                                            false
                                                                                        }
                                                                                    } {
                                                                                        0i64
                                                                                    } else {
                                                                                        1i64
                                                                                    }
                                                                                } else {
                                                                                    let a319 = v27;
                                                                                    let a320 = -1023i64;
                                                                                    int_sub(a319, a320)?
                                                                                }
                                                                            };
                                                                            let m323 = {
                                                                                let a321 = 2046i64;
                                                                                let a322 = v28;
                                                                                compare(a321, a322)
                                                                            };
                                                                            if match m323 {
                                                                                Ordering::Less => {
                                                                                    true
                                                                                }
                                                                                Ordering::Equal => {
                                                                                    false
                                                                                }
                                                                                Ordering::Greater => {
                                                                                    false
                                                                                }
                                                                            } {
                                                                                Ok(Some({
                                                                                    let a324 = v2;
                                                                                    let a325 = 9218868437227405312u64;
                                                                                    fixed_u64::bit_or(a324, a325)
                                                                                }))
                                                                            } else {
                                                                                let m328 = if v26 {
                                                                                    let a326 = v25;
                                                                                    let a327 = 1u32;
                                                                                    fixed_u64::shift_right(a326, a327)
                                                                                } else {
                                                                                    Some(v25)
                                                                                };
                                                                                match m328 {
                                                                                    None => {
                                                                                        Ok(None::<u64>)
                                                                                    }
                                                                                    Some(v29) => {
                                                                                        let m330 = {
                                                                                            let a329 = v28;
                                                                                            fixed_u64::convert(i128::from(a329))
                                                                                        };
                                                                                        match m330 {
                                                                                            None => {
                                                                                                Ok(None::<u64>)
                                                                                            }
                                                                                            Some(v30) => {
                                                                                                let m333 = {
                                                                                                    let a331 = v30;
                                                                                                    let a332 = 52u32;
                                                                                                    fixed_u64::shift_left(a331, a332)
                                                                                                };
                                                                                                match m333 {
                                                                                                    None => {
                                                                                                        Ok(None::<u64>)
                                                                                                    }
                                                                                                    Some(v31) => {
                                                                                                        Ok(Some({
                                                                                                            let a338 = v2;
                                                                                                            let a339 = {
                                                                                                                let a336 = v31;
                                                                                                                let a337 = {
                                                                                                                    let a334 = v29;
                                                                                                                    let a335 = 4503599627370495u64;
                                                                                                                    fixed_u64::bit_and(a334, a335)
                                                                                                                };
                                                                                                                fixed_u64::bit_or(a336, a337)
                                                                                                            };
                                                                                                            fixed_u64::bit_or(a338, a339)
                                                                                                        }))
                                                                                                    }
                                                                                                }
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

pub fn f2(v0: u64, v1: u64) -> Option<Adt0> {
    let m342 = Some({
        let a340 = v0;
        let a341 = 4294967295u64;
        fixed_u64::bit_and(a340, a341)
    });
    match m342 {
        None => {
            None::<Adt0>
        }
        Some(v2) => {
            let m345 = {
                let a343 = v0;
                let a344 = 32u32;
                fixed_u64::shift_right(a343, a344)
            };
            match m345 {
                None => {
                    None::<Adt0>
                }
                Some(v3) => {
                    let m348 = Some({
                        let a346 = v1;
                        let a347 = 4294967295u64;
                        fixed_u64::bit_and(a346, a347)
                    });
                    match m348 {
                        None => {
                            None::<Adt0>
                        }
                        Some(v4) => {
                            let m351 = {
                                let a349 = v1;
                                let a350 = 32u32;
                                fixed_u64::shift_right(a349, a350)
                            };
                            match m351 {
                                None => {
                                    None::<Adt0>
                                }
                                Some(v5) => {
                                    let m354 = {
                                        let a352 = v2;
                                        let a353 = v4;
                                        fixed_u64::checked_mul(a352, a353)
                                    };
                                    match m354 {
                                        None => {
                                            None::<Adt0>
                                        }
                                        Some(v6) => {
                                            let m357 = {
                                                let a355 = v6;
                                                let a356 = 32u32;
                                                fixed_u64::shift_right(a355, a356)
                                            };
                                            match m357 {
                                                None => {
                                                    None::<Adt0>
                                                }
                                                Some(v7) => {
                                                    let m360 = {
                                                        let a358 = v3;
                                                        let a359 = v4;
                                                        fixed_u64::checked_mul(a358, a359)
                                                    };
                                                    match m360 {
                                                        None => {
                                                            None::<Adt0>
                                                        }
                                                        Some(v8) => {
                                                            let m363 = {
                                                                let a361 = v8;
                                                                let a362 = v7;
                                                                fixed_u64::checked_add(a361, a362)
                                                            };
                                                            match m363 {
                                                                None => {
                                                                    None::<Adt0>
                                                                }
                                                                Some(v9) => {
                                                                    let m366 = {
                                                                        let a364 = v2;
                                                                        let a365 = v5;
                                                                        fixed_u64::checked_mul(a364, a365)
                                                                    };
                                                                    match m366 {
                                                                        None => {
                                                                            None::<Adt0>
                                                                        }
                                                                        Some(v10) => {
                                                                            let m371 = {
                                                                                let a369 = v10;
                                                                                let a370 = {
                                                                                    let a367 = v9;
                                                                                    let a368 = 4294967295u64;
                                                                                    fixed_u64::bit_and(a367, a368)
                                                                                };
                                                                                fixed_u64::checked_add(a369, a370)
                                                                            };
                                                                            match m371 {
                                                                                None => {
                                                                                    None::<Adt0>
                                                                                }
                                                                                Some(v11) => {
                                                                                    let m374 = {
                                                                                        let a372 = v9;
                                                                                        let a373 = 32u32;
                                                                                        fixed_u64::shift_right(a372, a373)
                                                                                    };
                                                                                    match m374 {
                                                                                        None => {
                                                                                            None::<Adt0>
                                                                                        }
                                                                                        Some(v12) => {
                                                                                            let m377 = {
                                                                                                let a375 = v11;
                                                                                                let a376 = 32u32;
                                                                                                fixed_u64::shift_right(a375, a376)
                                                                                            };
                                                                                            match m377 {
                                                                                                None => {
                                                                                                    None::<Adt0>
                                                                                                }
                                                                                                Some(v13) => {
                                                                                                    let m380 = {
                                                                                                        let a378 = v3;
                                                                                                        let a379 = v5;
                                                                                                        fixed_u64::checked_mul(a378, a379)
                                                                                                    };
                                                                                                    match m380 {
                                                                                                        None => {
                                                                                                            None::<Adt0>
                                                                                                        }
                                                                                                        Some(v14) => {
                                                                                                            let m383 = {
                                                                                                                let a381 = v14;
                                                                                                                let a382 = v12;
                                                                                                                fixed_u64::checked_add(a381, a382)
                                                                                                            };
                                                                                                            match m383 {
                                                                                                                None => {
                                                                                                                    None::<Adt0>
                                                                                                                }
                                                                                                                Some(v15) => {
                                                                                                                    let m386 = {
                                                                                                                        let a384 = v15;
                                                                                                                        let a385 = v13;
                                                                                                                        fixed_u64::checked_add(a384, a385)
                                                                                                                    };
                                                                                                                    match m386 {
                                                                                                                        None => {
                                                                                                                            None::<Adt0>
                                                                                                                        }
                                                                                                                        Some(v16) => {
                                                                                                                            let m389 = {
                                                                                                                                let a387 = v16;
                                                                                                                                let a388 = 32u32;
                                                                                                                                fixed_u64::shift_right(a387, a388)
                                                                                                                            };
                                                                                                                            match m389 {
                                                                                                                                None => {
                                                                                                                                    None::<Adt0>
                                                                                                                                }
                                                                                                                                Some(v17) => {
                                                                                                                                    let m393 = {
                                                                                                                                        let a392 = {
                                                                                                                                            let a390 = v6;
                                                                                                                                            let a391 = 4294967295u64;
                                                                                                                                            fixed_u64::bit_and(a390, a391)
                                                                                                                                        };
                                                                                                                                        fixed_u32::convert(i128::from(a392))
                                                                                                                                    };
                                                                                                                                    match m393 {
                                                                                                                                        None => {
                                                                                                                                            None::<Adt0>
                                                                                                                                        }
                                                                                                                                        Some(v18) => {
                                                                                                                                            let m397 = {
                                                                                                                                                let a396 = {
                                                                                                                                                    let a394 = v11;
                                                                                                                                                    let a395 = 4294967295u64;
                                                                                                                                                    fixed_u64::bit_and(a394, a395)
                                                                                                                                                };
                                                                                                                                                fixed_u32::convert(i128::from(a396))
                                                                                                                                            };
                                                                                                                                            match m397 {
                                                                                                                                                None => {
                                                                                                                                                    None::<Adt0>
                                                                                                                                                }
                                                                                                                                                Some(v19) => {
                                                                                                                                                    let m401 = {
                                                                                                                                                        let a400 = {
                                                                                                                                                            let a398 = v16;
                                                                                                                                                            let a399 = 4294967295u64;
                                                                                                                                                            fixed_u64::bit_and(a398, a399)
                                                                                                                                                        };
                                                                                                                                                        fixed_u32::convert(i128::from(a400))
                                                                                                                                                    };
                                                                                                                                                    match m401 {
                                                                                                                                                        None => {
                                                                                                                                                            None::<Adt0>
                                                                                                                                                        }
                                                                                                                                                        Some(v20) => {
                                                                                                                                                            let m405 = {
                                                                                                                                                                let a404 = {
                                                                                                                                                                    let a402 = v17;
                                                                                                                                                                    let a403 = 4294967295u64;
                                                                                                                                                                    fixed_u64::bit_and(a402, a403)
                                                                                                                                                                };
                                                                                                                                                                fixed_u32::convert(i128::from(a404))
                                                                                                                                                            };
                                                                                                                                                            match m405 {
                                                                                                                                                                None => {
                                                                                                                                                                    None::<Adt0>
                                                                                                                                                                }
                                                                                                                                                                Some(v21) => {
                                                                                                                                                                    Some(Adt0::C0(v18, v19, v20, v21))
                                                                                                                                                                }
                                                                                                                                                            }
                                                                                                                                                        }
                                                                                                                                                    }
                                                                                                                                                }
                                                                                                                                            }
                                                                                                                                        }
                                                                                                                                    }
                                                                                                                                }
                                                                                                                            }
                                                                                                                        }
                                                                                                                    }
                                                                                                                }
                                                                                                            }
                                                                                                        }
                                                                                                    }
                                                                                                }
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

pub fn f3(v0: Adt0) -> R<Option<i64>> {
    let a407 = match v0.clone() {
        Adt0::C0(_, _, _, h406) => {
            h406
        }
    };
    let a408 = 0u32;
    if equal(a407, a408) {
        let a410 = match v0.clone() {
            Adt0::C0(_, _, h409, _) => {
                h409
            }
        };
        let a411 = 0u32;
        if equal(a410, a411) {
            let a413 = match v0.clone() {
                Adt0::C0(_, h412, _, _) => {
                    h412
                }
            };
            let a414 = 0u32;
            if equal(a413, a414) {
                f5(match v0 {
                    Adt0::C0(h415, _, _, _) => {
                        h415
                    }
                })
            } else {
                let m417 = f5(match v0 {
                    Adt0::C0(_, h416, _, _) => {
                        h416
                    }
                })?;
                match m417 {
                    None => {
                        Ok(None::<i64>)
                    }
                    Some(v1) => {
                        Ok(Some({
                            let a418 = v1;
                            let a419 = -32i64;
                            int_sub(a418, a419)?
                        }))
                    }
                }
            }
        } else {
            let m421 = f5(match v0 {
                Adt0::C0(_, _, h420, _) => {
                    h420
                }
            })?;
            match m421 {
                None => {
                    Ok(None::<i64>)
                }
                Some(v2) => {
                    Ok(Some({
                        let a422 = v2;
                        let a423 = -64i64;
                        int_sub(a422, a423)?
                    }))
                }
            }
        }
    } else {
        let m425 = f5(match v0 {
            Adt0::C0(_, _, _, h424) => {
                h424
            }
        })?;
        match m425 {
            None => {
                Ok(None::<i64>)
            }
            Some(v3) => {
                Ok(Some({
                    let a426 = v3;
                    let a427 = -96i64;
                    int_sub(a426, a427)?
                }))
            }
        }
    }
}

pub fn f4(v0: Adt0, v1: i64) -> R<Option<u64>> {
    let m430 = {
        let a428 = v1;
        let a429 = 0i64;
        compare(a428, a429)
    };
    if match m430 {
        Ordering::Less => {
            true
        }
        Ordering::Equal => {
            false
        }
        Ordering::Greater => {
            false
        }
    } {
        let m433 = {
            let a432 = {
                let a431 = v1;
                int_neg(a431)?
            };
            fixed_u32::convert(i128::from(a432))
        };
        match m433 {
            None => {
                Ok(None::<u64>)
            }
            Some(v2) => {
                let m434 = f6(v0);
                match m434 {
                    None => {
                        Ok(None::<u64>)
                    }
                    Some(v3) => {
                        let a435 = v3;
                        let a436 = v2;
                        Ok(fixed_u64::shift_left(a435, a436))
                    }
                }
            }
        }
    } else {
        let m439 = {
            let a437 = 128i64;
            let a438 = v1;
            compare(a437, a438)
        };
        if match m439 {
            Ordering::Less => {
                true
            }
            Ordering::Equal => {
                false
            }
            Ordering::Greater => {
                false
            }
        } {
            Ok(Some(0u64))
        } else {
            let m441 = {
                let a440 = v1;
                fixed_u8::convert(i128::from(a440))
            };
            match m441 {
                None => {
                    Ok(None::<u64>)
                }
                Some(v4) => {
                    let m488 = f7(Fn0::F8, {
                        let v5: u8 = v4;
                        let a486 = {
                            let a462 = {
                                let a450 = {
                                    let a444 = {
                                        let a442 = v5;
                                        let a443 = 128u8;
                                        fixed_u8::bit_and(a442, a443)
                                    };
                                    let a445 = 128u8;
                                    if equal(a444, a445) {
                                        128u64
                                    } else {
                                        0u64
                                    }
                                };
                                let a451 = {
                                    let a448 = {
                                        let a446 = v5;
                                        let a447 = 64u8;
                                        fixed_u8::bit_and(a446, a447)
                                    };
                                    let a449 = 64u8;
                                    if equal(a448, a449) {
                                        64u64
                                    } else {
                                        0u64
                                    }
                                };
                                nat_add(a450, a451)?
                            };
                            let a463 = {
                                let a460 = {
                                    let a454 = {
                                        let a452 = v5;
                                        let a453 = 32u8;
                                        fixed_u8::bit_and(a452, a453)
                                    };
                                    let a455 = 32u8;
                                    if equal(a454, a455) {
                                        32u64
                                    } else {
                                        0u64
                                    }
                                };
                                let a461 = {
                                    let a458 = {
                                        let a456 = v5;
                                        let a457 = 16u8;
                                        fixed_u8::bit_and(a456, a457)
                                    };
                                    let a459 = 16u8;
                                    if equal(a458, a459) {
                                        16u64
                                    } else {
                                        0u64
                                    }
                                };
                                nat_add(a460, a461)?
                            };
                            nat_add(a462, a463)?
                        };
                        let a487 = {
                            let a484 = {
                                let a472 = {
                                    let a466 = {
                                        let a464 = v5;
                                        let a465 = 8u8;
                                        fixed_u8::bit_and(a464, a465)
                                    };
                                    let a467 = 8u8;
                                    if equal(a466, a467) {
                                        8u64
                                    } else {
                                        0u64
                                    }
                                };
                                let a473 = {
                                    let a470 = {
                                        let a468 = v5;
                                        let a469 = 4u8;
                                        fixed_u8::bit_and(a468, a469)
                                    };
                                    let a471 = 4u8;
                                    if equal(a470, a471) {
                                        4u64
                                    } else {
                                        0u64
                                    }
                                };
                                nat_add(a472, a473)?
                            };
                            let a485 = {
                                let a482 = {
                                    let a476 = {
                                        let a474 = v5;
                                        let a475 = 2u8;
                                        fixed_u8::bit_and(a474, a475)
                                    };
                                    let a477 = 2u8;
                                    if equal(a476, a477) {
                                        2u64
                                    } else {
                                        0u64
                                    }
                                };
                                let a483 = {
                                    let a480 = {
                                        let a478 = v5;
                                        let a479 = 1u8;
                                        fixed_u8::bit_and(a478, a479)
                                    };
                                    let a481 = 1u8;
                                    if equal(a480, a481) {
                                        1u64
                                    } else {
                                        0u64
                                    }
                                };
                                nat_add(a482, a483)?
                            };
                            nat_add(a484, a485)?
                        };
                        nat_add(a486, a487)?
                    }, Some(Adt1::C0(v0, false, false)));
                    match m488 {
                        None => {
                            Ok(None::<u64>)
                        }
                        Some(v6) => {
                            let m490 = f6(match v6.clone() {
                                Adt1::C0(h489, _, _) => {
                                    h489
                                }
                            });
                            match m490 {
                                None => {
                                    Ok(None::<u64>)
                                }
                                Some(v7) => {
                                    if if match v6.clone() {
                                        Adt1::C0(_, h491, _) => {
                                            h491
                                        }
                                    } {
                                        if match v6 {
                                            Adt1::C0(_, _, h492) => {
                                                h492
                                            }
                                        } {
                                            true
                                        } else {
                                            let a495 = {
                                                let a493 = v7;
                                                let a494 = 1u64;
                                                fixed_u64::bit_and(a493, a494)
                                            };
                                            let a496 = 1u64;
                                            equal(a495, a496)
                                        }
                                    } else {
                                        false
                                    } {
                                        let a497 = v7;
                                        let a498 = 1u64;
                                        Ok(fixed_u64::checked_add(a497, a498))
                                    } else {
                                        Ok(Some(v7))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

pub fn f5(v0: u32) -> R<Option<i64>> {
    let m499 = f9(Fn1::F10, 32u64, Some((v0, 0i64)))?;
    match m499 {
        None => {
            Ok(None::<i64>)
        }
        Some(v1) => {
            Ok(Some({
                let (_, h500) = v1;
                h500
            }))
        }
    }
}

pub fn f6(v0: Adt0) -> Option<u64> {
    let a502 = match v0.clone() {
        Adt0::C0(_, _, h501, _) => {
            h501
        }
    };
    let a503 = 0u32;
    if if equal(a502, a503) {
        let a505 = match v0.clone() {
            Adt0::C0(_, _, _, h504) => {
                h504
            }
        };
        let a506 = 0u32;
        equal(a505, a506)
    } else {
        false
    } {
        let m509 = {
            let a508 = match v0.clone() {
                Adt0::C0(h507, _, _, _) => {
                    h507
                }
            };
            fixed_u64::convert(i128::from(a508))
        };
        match m509 {
            None => {
                None::<u64>
            }
            Some(v1) => {
                let m512 = {
                    let a511 = match v0 {
                        Adt0::C0(_, h510, _, _) => {
                            h510
                        }
                    };
                    fixed_u64::convert(i128::from(a511))
                };
                match m512 {
                    None => {
                        None::<u64>
                    }
                    Some(v2) => {
                        let m515 = {
                            let a513 = v2;
                            let a514 = 32u32;
                            fixed_u64::shift_left(a513, a514)
                        };
                        match m515 {
                            None => {
                                None::<u64>
                            }
                            Some(v3) => {
                                Some({
                                    let a516 = v1;
                                    let a517 = v3;
                                    fixed_u64::bit_or(a516, a517)
                                })
                            }
                        }
                    }
                }
            }
        }
    } else {
        None::<u64>
    }
}

pub fn f7(v0: Fn0, p521: u64, p522: Option<Adt1>) -> Option<Adt1> {
    let m520 = (p521, p522);
    {
        let mut m520 = m520;
        loop {
            let step = {
                let (v1, v2) = m520;
                let m518 = v1;
                if m518 == 0 {
                    Err::<(u64, Option<Adt1>), Option<Adt1>>(v2)
                } else {
                    let v3 = m518 - 1;
                    Ok::<(u64, Option<Adt1>), Option<Adt1>>((v3, {
                        let c519: Fn0 = v0.clone();
                        c519.apply(v2)
                    }))
                }
            };
            match step {
                Ok(next) => { m520 = next; }
                Err(done) => break done,
            }
        }
    }
}

pub fn f8(v0: Option<Adt1>) -> Option<Adt1> {
    f11(v0)
}

pub fn f9(v0: Fn1, p526: u64, p527: Option<(u32, i64)>) -> R<Option<(u32, i64)>> {
    let m525 = (p526, p527);
    {
        let mut m525 = m525;
        loop {
            let step = {
                let (v1, v2) = m525;
                let m523 = v1;
                if m523 == 0 {
                    Err::<(u64, Option<(u32, i64)>), R<Option<(u32, i64)>>>(Ok(v2))
                } else {
                    let v3 = m523 - 1;
                    Ok::<(u64, Option<(u32, i64)>), R<Option<(u32, i64)>>>((v3, {
                        let c524: Fn1 = v0.clone();
                        c524.apply(v2)?
                    }))
                }
            };
            match step {
                Ok(next) => { m525 = next; }
                Err(done) => break done,
            }
        }
    }
}

pub fn f10(v0: Option<(u32, i64)>) -> R<Option<(u32, i64)>> {
    f12(v0)
}

pub fn f11(v0: Option<Adt1>) -> Option<Adt1> {
    let m528 = v0;
    match m528 {
        None => {
            None::<Adt1>
        }
        Some(v1) => {
            let m530 = f13(match v1.clone() {
                Adt1::C0(h529, _, _) => {
                    h529
                }
            });
            match m530 {
                None => {
                    None::<Adt1>
                }
                Some(v2) => {
                    Some(Adt1::C0(v2, {
                        let a536 = {
                            let a534 = {
                                let m533 = match v1.clone() {
                                    Adt1::C0(h532, _, _) => {
                                        h532
                                    }
                                };
                                match m533 {
                                    Adt0::C0(h531, _, _, _) => {
                                        h531
                                    }
                                }
                            };
                            let a535 = 1u32;
                            fixed_u32::bit_and(a534, a535)
                        };
                        let a537 = 1u32;
                        equal(a536, a537)
                    }, if match v1.clone() {
                        Adt1::C0(_, _, h538) => {
                            h538
                        }
                    } {
                        true
                    } else {
                        match v1 {
                            Adt1::C0(_, h539, _) => {
                                h539
                            }
                        }
                    }))
                }
            }
        }
    }
}

pub fn f12(v0: Option<(u32, i64)>) -> R<Option<(u32, i64)>> {
    let m540 = v0;
    match m540 {
        None => {
            Ok(None::<(u32, i64)>)
        }
        Some(v1) => {
            let m544 = {
                let a542 = {
                    let (h541, _) = v1;
                    h541
                };
                let a543 = 1u32;
                fixed_u32::shift_right(a542, a543)
            };
            match m544 {
                None => {
                    Ok(None::<(u32, i64)>)
                }
                Some(v2) => {
                    Ok(Some((v2, {
                        let a546 = {
                            let (h545, _) = v1;
                            h545
                        };
                        let a547 = 0u32;
                        if equal(a546, a547) {
                            let (_, h548) = v1;
                            h548
                        } else {
                            let a550 = {
                                let (_, h549) = v1;
                                h549
                            };
                            let a551 = -1i64;
                            int_sub(a550, a551)?
                        }
                    })))
                }
            }
        }
    }
}

pub fn f13(v0: Adt0) -> Option<Adt0> {
    let m555 = {
        let a553 = match v0.clone() {
            Adt0::C0(h552, _, _, _) => {
                h552
            }
        };
        let a554 = 1u32;
        fixed_u32::shift_right(a553, a554)
    };
    match m555 {
        None => {
            None::<Adt0>
        }
        Some(v1) => {
            let m559 = {
                let a557 = match v0.clone() {
                    Adt0::C0(_, h556, _, _) => {
                        h556
                    }
                };
                let a558 = 1u32;
                fixed_u32::shift_right(a557, a558)
            };
            match m559 {
                None => {
                    None::<Adt0>
                }
                Some(v2) => {
                    let m563 = {
                        let a561 = match v0.clone() {
                            Adt0::C0(_, _, h560, _) => {
                                h560
                            }
                        };
                        let a562 = 1u32;
                        fixed_u32::shift_right(a561, a562)
                    };
                    match m563 {
                        None => {
                            None::<Adt0>
                        }
                        Some(v3) => {
                            let m567 = {
                                let a565 = match v0.clone() {
                                    Adt0::C0(_, _, _, h564) => {
                                        h564
                                    }
                                };
                                let a566 = 1u32;
                                fixed_u32::shift_right(a565, a566)
                            };
                            match m567 {
                                None => {
                                    None::<Adt0>
                                }
                                Some(v4) => {
                                    let m573 = {
                                        let a571 = {
                                            let a569 = match v0.clone() {
                                                Adt0::C0(_, h568, _, _) => {
                                                    h568
                                                }
                                            };
                                            let a570 = 1u32;
                                            fixed_u32::bit_and(a569, a570)
                                        };
                                        let a572 = 31u32;
                                        fixed_u32::shift_left(a571, a572)
                                    };
                                    match m573 {
                                        None => {
                                            None::<Adt0>
                                        }
                                        Some(v5) => {
                                            let m579 = {
                                                let a577 = {
                                                    let a575 = match v0.clone() {
                                                        Adt0::C0(_, _, h574, _) => {
                                                            h574
                                                        }
                                                    };
                                                    let a576 = 1u32;
                                                    fixed_u32::bit_and(a575, a576)
                                                };
                                                let a578 = 31u32;
                                                fixed_u32::shift_left(a577, a578)
                                            };
                                            match m579 {
                                                None => {
                                                    None::<Adt0>
                                                }
                                                Some(v6) => {
                                                    let m585 = {
                                                        let a583 = {
                                                            let a581 = match v0 {
                                                                Adt0::C0(_, _, _, h580) => {
                                                                    h580
                                                                }
                                                            };
                                                            let a582 = 1u32;
                                                            fixed_u32::bit_and(a581, a582)
                                                        };
                                                        let a584 = 31u32;
                                                        fixed_u32::shift_left(a583, a584)
                                                    };
                                                    match m585 {
                                                        None => {
                                                            None::<Adt0>
                                                        }
                                                        Some(v7) => {
                                                            Some(Adt0::C0({
                                                                let a586 = v1;
                                                                let a587 = v5;
                                                                fixed_u32::bit_or(a586, a587)
                                                            }, {
                                                                let a588 = v2;
                                                                let a589 = v6;
                                                                fixed_u32::bit_or(a588, a589)
                                                            }, {
                                                                let a590 = v3;
                                                                let a591 = v7;
                                                                fixed_u32::bit_or(a590, a591)
                                                            }, v4))
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
